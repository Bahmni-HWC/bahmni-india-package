--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Drop databases (except postgres and template1)
--

DROP DATABASE openchs;




--
-- Drop roles
--



--
-- Roles
--

CREATE ROLE gok;
ALTER ROLE gok WITH NOSUPERUSER NOINHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:cT1IYLKLb9tvDOxw0DxXkA==$9aj+kihZ67muRh1ExCwA8gXZjh+MWEVbgw430wJ2uTc=:v2gYZYsQlPaDe5tOrbrIG5XX/5CeHPqDKOssE9sb95Q=';
CREATE ROLE openchs_impl;
ALTER ROLE openchs_impl WITH NOSUPERUSER NOINHERIT CREATEROLE NOCREATEDB NOLOGIN NOREPLICATION NOBYPASSRLS;


--
-- User Configurations
--


--
-- Role memberships
--

GRANT gok TO openchs GRANTED BY openchs;
GRANT openchs_impl TO openchs GRANTED BY openchs;






--
-- Databases
--

--
-- Database "template1" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.3 (Debian 15.3-1.pgdg120+1)
-- Dumped by pg_dump version 15.3 (Debian 15.3-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

UPDATE pg_catalog.pg_database SET datistemplate = false WHERE datname = 'template1';
DROP DATABASE template1;
--
-- Name: template1; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE template1 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE template1 OWNER TO postgres;

\connect template1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE template1; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE template1 IS 'default template for new databases';


--
-- Name: template1; Type: DATABASE PROPERTIES; Schema: -; Owner: postgres
--

ALTER DATABASE template1 IS_TEMPLATE = true;


\connect template1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE template1; Type: ACL; Schema: -; Owner: postgres
--

REVOKE CONNECT,TEMPORARY ON DATABASE template1 FROM PUBLIC;
GRANT CONNECT ON DATABASE template1 TO PUBLIC;


--
-- PostgreSQL database dump complete
--

--
-- Database "openchs" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.3 (Debian 15.3-1.pgdg120+1)
-- Dumped by pg_dump version 15.3 (Debian 15.3-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: openchs; Type: DATABASE; Schema: -; Owner: openchs
--

CREATE DATABASE openchs WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE openchs OWNER TO openchs;

\connect openchs

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: gok; Type: SCHEMA; Schema: -; Owner: gok
--

CREATE SCHEMA gok;


ALTER SCHEMA gok OWNER TO gok;

--
-- Name: hstore; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS hstore WITH SCHEMA public;


--
-- Name: EXTENSION hstore; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION hstore IS 'data type for storing sets of (key, value) pairs';


--
-- Name: ltree; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS ltree WITH SCHEMA public;


--
-- Name: EXTENSION ltree; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION ltree IS 'data type for hierarchical tree-like structures';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: append_manual_update_history(text, text); Type: FUNCTION; Schema: public; Owner: openchs
--

CREATE FUNCTION public.append_manual_update_history(current_value text, text_to_be_added text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
BEGIN
    if current_value is null or trim(current_value) = '' then
        RETURN concat(to_char(current_timestamp, 'DD/MM/YYYY hh:mm:ss'), ' - ', text_to_be_added);
    else
        RETURN concat(to_char(current_timestamp, 'DD/MM/YYYY hh:mm:ss'), ' - ', text_to_be_added, ' || ',
                      current_value);
    end if;
END
$$;


ALTER FUNCTION public.append_manual_update_history(current_value text, text_to_be_added text) OWNER TO openchs;

--
-- Name: audit_table_trigger(); Type: FUNCTION; Schema: public; Owner: openchs
--

CREATE FUNCTION public.audit_table_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    audit_id INTEGER;
BEGIN
    IF NEW.audit_id is null THEN
        audit_id = nextval('audit_id_seq');
        NEW.audit_id = audit_id;
        RAISE NOTICE 'setting value of audit to %', NEW.audit_id ;
        insert into audit (id, uuid, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time)
        values (audit_id, uuid_generate_v4(), NEW.created_by_id, NEW.last_modified_by_id, NEW.created_date_time,
                NEW.last_modified_date_time);
    else
        update audit
        set last_modified_date_time = NEW.last_modified_date_time,
            last_modified_by_id     = NEW.last_modified_by_id
        where id = NEW.audit_id;
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.audit_table_trigger() OWNER TO openchs;

--
-- Name: concept_name(text); Type: FUNCTION; Schema: public; Owner: openchs
--

CREATE FUNCTION public.concept_name(text) RETURNS text
    LANGUAGE sql STABLE STRICT
    AS $_$
SELECT name
FROM concept
WHERE uuid = $1;
$_$;


ALTER FUNCTION public.concept_name(text) OWNER TO openchs;

--
-- Name: create_audit(); Type: FUNCTION; Schema: public; Owner: openchs
--

CREATE FUNCTION public.create_audit() RETURNS integer
    LANGUAGE sql
    AS $$select create_audit(1)$$;


ALTER FUNCTION public.create_audit() OWNER TO openchs;

--
-- Name: create_audit(numeric); Type: FUNCTION; Schema: public; Owner: openchs
--

CREATE FUNCTION public.create_audit(user_id numeric) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE result INTEGER;
BEGIN
  INSERT INTO audit(created_by_id, last_modified_by_id, created_date_time, last_modified_date_time)
  VALUES(user_id, user_id, now(), now()) RETURNING id into result;
  RETURN result;
END $$;


ALTER FUNCTION public.create_audit(user_id numeric) OWNER TO openchs;

--
-- Name: create_audit_columns(text); Type: FUNCTION; Schema: public; Owner: openchs
--

CREATE FUNCTION public.create_audit_columns(table_name text) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    execute 'alter table ' || table_name || '
        add column created_by_id           bigint,
        add column last_modified_by_id     bigint,
        add column created_date_time       timestamp(3) with time zone,
        add column last_modified_date_time timestamp(3) with time zone;';
    RAISE NOTICE 'added columns to %', table_name ;
END
$$;


ALTER FUNCTION public.create_audit_columns(table_name text) OWNER TO openchs;

--
-- Name: create_db_user(text, text); Type: FUNCTION; Schema: public; Owner: openchs
--

CREATE FUNCTION public.create_db_user(inrolname text, inpassword text) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
  BEGIN
    IF NOT EXISTS(SELECT rolname FROM pg_roles WHERE rolname = inrolname)
    THEN
      EXECUTE 'CREATE ROLE ' || quote_ident(inrolname) || ' NOINHERIT LOGIN PASSWORD ' || quote_literal(inpassword);
    END IF;
    EXECUTE 'GRANT ' || quote_ident(inrolname) || ' TO openchs';
    PERFORM grant_all_on_all(inrolname);
    RETURN 1;
  END
$$;


ALTER FUNCTION public.create_db_user(inrolname text, inpassword text) OWNER TO openchs;

--
-- Name: create_implementation_schema(text, text); Type: FUNCTION; Schema: public; Owner: openchs
--

CREATE FUNCTION public.create_implementation_schema(schema_name text, db_user text) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
BEGIN
  EXECUTE 'CREATE SCHEMA IF NOT EXISTS "' || schema_name || '" AUTHORIZATION "' || db_user || '"';
  EXECUTE 'GRANT ALL PRIVILEGES ON SCHEMA "' || schema_name || '" TO "' || db_user || '"';
  RETURN 1;
END
$$;


ALTER FUNCTION public.create_implementation_schema(schema_name text, db_user text) OWNER TO openchs;

--
-- Name: create_view(text, text, text); Type: FUNCTION; Schema: public; Owner: openchs
--

CREATE FUNCTION public.create_view(schema_name text, view_name text, sql_query text) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
BEGIN
--     EXECUTE 'set search_path = ' || ;
    EXECUTE 'DROP VIEW IF EXISTS ' || schema_name || '.' || view_name;
    EXECUTE 'CREATE OR REPLACE VIEW ' || schema_name || '.' || view_name || ' AS ' || sql_query;
    RETURN 1;
END
$$;


ALTER FUNCTION public.create_view(schema_name text, view_name text, sql_query text) OWNER TO openchs;

--
-- Name: delete_etl_metadata_for_org(text, text); Type: FUNCTION; Schema: public; Owner: openchs
--

CREATE FUNCTION public.delete_etl_metadata_for_org(in_impl_schema text, in_db_user text) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    EXECUTE 'set role openchs;';
    execute 'drop schema ' || in_impl_schema || ' cascade;';
    execute 'delete from entity_sync_status where db_user = ''' || in_db_user || ''';';
    execute 'delete from entity_sync_status where schema_name = ''' || in_impl_schema || ''';';
    execute 'delete from index_metadata where table_metadata_id in (select id from table_metadata where schema_name = ''' || in_impl_schema || ''');';
    execute 'delete from column_metadata where table_id in (select id from table_metadata where schema_name = ''' || in_impl_schema || ''');';
    execute 'delete from table_metadata where schema_name = ''' || in_impl_schema || ''';';
    return true;
END
$$;


ALTER FUNCTION public.delete_etl_metadata_for_org(in_impl_schema text, in_db_user text) OWNER TO openchs;

--
-- Name: delete_etl_metadata_for_schema(text, text); Type: FUNCTION; Schema: public; Owner: openchs
--

CREATE FUNCTION public.delete_etl_metadata_for_schema(in_impl_schema text, in_db_user text) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    EXECUTE 'set role ' || in_impl_schema || ';';
    execute 'drop schema ' || in_impl_schema || ' cascade;';
    execute 'delete from entity_sync_status where db_user = ''' || in_db_user || ''';';
    execute 'delete from entity_sync_status where schema_name = ''' || in_impl_schema || ''';';
    execute 'delete from index_metadata where table_metadata_id in (select id from table_metadata where schema_name = ''' || in_impl_schema || ''');';
    execute 'delete from column_metadata where table_id in (select id from table_metadata where schema_name = ''' || in_impl_schema || ''');';
    execute 'delete from table_metadata where schema_name = ''' || in_impl_schema || ''';';
    return true;
END
$$;


ALTER FUNCTION public.delete_etl_metadata_for_schema(in_impl_schema text, in_db_user text) OWNER TO openchs;

--
-- Name: deps_restore_dependencies(character varying, character varying); Type: FUNCTION; Schema: public; Owner: openchs
--

CREATE FUNCTION public.deps_restore_dependencies(p_view_schema character varying, p_view_name character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
    v_curr record;
begin
    for v_curr in
        (
            select deps_ddl_to_run
            from deps_saved_ddl
            where deps_view_schema = p_view_schema
              and deps_view_name = p_view_name
            order by deps_id desc
        )
        loop
            execute v_curr.deps_ddl_to_run;
        end loop;
    delete
    from deps_saved_ddl
    where deps_view_schema = p_view_schema
      and deps_view_name = p_view_name;
end;
$$;


ALTER FUNCTION public.deps_restore_dependencies(p_view_schema character varying, p_view_name character varying) OWNER TO openchs;

--
-- Name: deps_save_and_drop_dependencies(character varying, character varying); Type: FUNCTION; Schema: public; Owner: openchs
--

CREATE FUNCTION public.deps_save_and_drop_dependencies(p_view_schema character varying, p_view_name character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
    v_curr record;
begin
    for v_curr in
        (
            select obj_schema, obj_name, obj_type
            from (
                     with recursive recursive_deps(obj_schema, obj_name, obj_type, depth) as
                                        (
                                            select p_view_schema COLLATE "C", p_view_name COLLATE "C", null::varchar, 0
                                            union
                                            select dep_schema::varchar,
                                                   dep_name::varchar,
                                                   dep_type::varchar,
                                                   recursive_deps.depth + 1
                                            from (
                                                     select ref_nsp.nspname ref_schema,
                                                            ref_cl.relname  ref_name,
                                                            rwr_cl.relkind  dep_type,
                                                            rwr_nsp.nspname dep_schema,
                                                            rwr_cl.relname  dep_name
                                                     from pg_depend dep
                                                              join pg_class ref_cl on dep.refobjid = ref_cl.oid
                                                              join pg_namespace ref_nsp on ref_cl.relnamespace = ref_nsp.oid
                                                              join pg_rewrite rwr on dep.objid = rwr.oid
                                                              join pg_class rwr_cl on rwr.ev_class = rwr_cl.oid
                                                              join pg_namespace rwr_nsp on rwr_cl.relnamespace = rwr_nsp.oid
                                                     where dep.deptype = 'n'
                                                       and dep.classid = 'pg_rewrite'::regclass
                                                 ) deps
                                                     join recursive_deps
                                                          on deps.ref_schema = recursive_deps.obj_schema and
                                                             deps.ref_name = recursive_deps.obj_name
                                            where (deps.ref_schema != deps.dep_schema or deps.ref_name != deps.dep_name)
                                        )
                     select obj_schema, obj_name, obj_type, depth
                     from recursive_deps
                     where depth > 0
                 ) t
            group by obj_schema, obj_name, obj_type
            order by max(depth) desc
        )
        loop

            insert into deps_saved_ddl(deps_view_schema, deps_view_name, deps_ddl_to_run)
            select p_view_schema,
                   p_view_name,
                   'COMMENT ON ' ||
                   case
                       when c.relkind = 'v' then 'VIEW'
                       when c.relkind = 'm' then 'MATERIALIZED VIEW'
                       else ''
                       end
                       || ' ' || n.nspname || '.' || c.relname || ' IS ''' || replace(d.description, '''', '''''') ||
                   ''';'
            from pg_class c
                     join pg_namespace n on n.oid = c.relnamespace
                     join pg_description d on d.objoid = c.oid and d.objsubid = 0
            where n.nspname = v_curr.obj_schema
              and c.relname = v_curr.obj_name
              and d.description is not null;

            insert into deps_saved_ddl(deps_view_schema, deps_view_name, deps_ddl_to_run)
            select p_view_schema,
                   p_view_name,
                   'COMMENT ON COLUMN ' || n.nspname || '.' || c.relname || '.' || a.attname || ' IS ''' ||
                   replace(d.description, '''', '''''') || ''';'
            from pg_class c
                     join pg_attribute a on c.oid = a.attrelid
                     join pg_namespace n on n.oid = c.relnamespace
                     join pg_description d on d.objoid = c.oid and d.objsubid = a.attnum
            where n.nspname = v_curr.obj_schema
              and c.relname = v_curr.obj_name
              and d.description is not null;

            insert into deps_saved_ddl(deps_view_schema, deps_view_name, deps_ddl_to_run)
            select p_view_schema,
                   p_view_name,
                   'GRANT ' || privilege_type || ' ON ' || table_schema || '.' || table_name || ' TO ' || '"' ||
                   grantee || '"'
            from information_schema.role_table_grants
            where table_schema = v_curr.obj_schema
              and table_name = v_curr.obj_name;

            if v_curr.obj_type = 'v' then
                insert into deps_saved_ddl(deps_view_schema, deps_view_name, deps_ddl_to_run)
                select p_view_schema,
                       p_view_name,
                       'CREATE VIEW ' || v_curr.obj_schema || '.' || v_curr.obj_name || ' AS ' || view_definition
                from information_schema.views
                where table_schema = v_curr.obj_schema
                  and table_name = v_curr.obj_name;
            elsif v_curr.obj_type = 'm' then
                insert into deps_saved_ddl(deps_view_schema, deps_view_name, deps_ddl_to_run)
                select p_view_schema,
                       p_view_name,
                       'CREATE MATERIALIZED VIEW ' || v_curr.obj_schema || '.' || v_curr.obj_name || ' AS ' ||
                       definition
                from pg_matviews
                where schemaname = v_curr.obj_schema
                  and matviewname = v_curr.obj_name;
            end if;

            execute 'DROP ' ||
                    case
                        when v_curr.obj_type = 'v' then 'VIEW'
                        when v_curr.obj_type = 'm' then 'MATERIALIZED VIEW'
                        end
                        || ' ' || v_curr.obj_schema || '.' || v_curr.obj_name;

        end loop;
end;
$$;


ALTER FUNCTION public.deps_save_and_drop_dependencies(p_view_schema character varying, p_view_name character varying) OWNER TO openchs;

--
-- Name: drop_view(text, text); Type: FUNCTION; Schema: public; Owner: openchs
--

CREATE FUNCTION public.drop_view(schema_name text, view_name text) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
BEGIN
    EXECUTE 'set search_path = ' || schema_name;
    EXECUTE 'DROP VIEW IF EXISTS ' || view_name;
    EXECUTE 'reset search_path';
    RETURN 1;
END
$$;


ALTER FUNCTION public.drop_view(schema_name text, view_name text) OWNER TO openchs;

--
-- Name: enable_rls_on_ref_table(text); Type: FUNCTION; Schema: public; Owner: openchs
--

CREATE FUNCTION public.enable_rls_on_ref_table(tablename text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
    tabl   TEXT := quote_ident(tablename);
    polisy TEXT := quote_ident(tablename || '_orgs') || ' ON ' || tabl || ' ';
BEGIN
    EXECUTE 'DROP POLICY IF EXISTS ' || polisy;
    EXECUTE 'CREATE POLICY ' || polisy || '
            USING (organisation_id IN (SELECT id FROM org_ids UNION SELECT organisation_id from organisation_group_organisation)
            OR organisation_id IN (SELECT organisation_id from organisation_group_organisation))
  WITH CHECK ((organisation_id = (select id
                                  from organisation
                                  where db_user = current_user)))';
    EXECUTE 'ALTER TABLE ' || tabl || ' ENABLE ROW LEVEL SECURITY';
    RETURN 'CREATED POLICY ' || polisy;
END
$$;


ALTER FUNCTION public.enable_rls_on_ref_table(tablename text) OWNER TO openchs;

--
-- Name: enable_rls_on_tx_table(text); Type: FUNCTION; Schema: public; Owner: openchs
--

CREATE FUNCTION public.enable_rls_on_tx_table(tablename text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
    tabl   TEXT := quote_ident(tablename);
    polisy TEXT := quote_ident(tablename || '_orgs') || ' ON ' || tabl || ' ';
BEGIN
    EXECUTE 'DROP POLICY IF EXISTS ' || polisy;
    EXECUTE 'CREATE POLICY ' || polisy || '
            USING ((organisation_id = (select id from organisation where db_user = current_user)
            OR organisation_id IN (SELECT organisation_id from organisation_group_organisation)))
    WITH CHECK ((organisation_id = (select id from organisation where db_user = current_user)))';
    EXECUTE 'ALTER TABLE ' || tabl || ' ENABLE ROW LEVEL SECURITY';
    RETURN 'CREATED POLICY ' || polisy;
END
$$;


ALTER FUNCTION public.enable_rls_on_tx_table(tablename text) OWNER TO openchs;

--
-- Name: frequency_and_percentage(text); Type: FUNCTION; Schema: public; Owner: openchs
--

CREATE FUNCTION public.frequency_and_percentage(frequency_query text) RETURNS TABLE(total bigint, percentage double precision, gender character varying, address_type character varying)
    LANGUAGE plpgsql
    AS $$
DECLARE separator TEXT;
BEGIN
  SELECT md5(random() :: TEXT) :: TEXT
      INTO separator;
  EXECUTE format('CREATE TEMPORARY TABLE query_output_%s (
    uuid         VARCHAR,
    gender_name  VARCHAR,
    address_type VARCHAR,
    address_name VARCHAR
  ) ON COMMIT DROP', separator);

  EXECUTE format('CREATE TEMPORARY TABLE aggregates_%s (
    total        BIGINT,
    percentage   FLOAT,
    gender       VARCHAR,
    address_type VARCHAR
  ) ON COMMIT DROP', separator);

  -- Store filtered query into a temporary variable


  EXECUTE FORMAT('INSERT INTO query_output_%s (uuid, gender_name, address_type, address_name) %s', separator,
                 frequency_query);

  EXECUTE format('INSERT INTO aggregates_%s (total, gender, address_type)
    SELECT
      count(qo.uuid)  total,
      qo.gender_name  gender,
      qo.address_type address_type
    FROM query_output_%s qo
    GROUP BY qo.gender_name, qo.address_type', separator, separator);


  EXECUTE format('INSERT INTO aggregates_%s (total, gender, address_type)
    SELECT
      count(qo.uuid)  total,
      ''Total''         gender,
      qo.address_type address_type
    FROM query_output_%s qo
    GROUP BY qo.address_type', separator, separator);

  EXECUTE format('INSERT INTO aggregates_%s (total, gender, address_type)
    SELECT
      count(qo.uuid)  total,
      qo.gender_name  gender,
      ''All'' address_type
    FROM query_output_%s qo
    GROUP BY qo.gender_name', separator, separator);

  EXECUTE format('INSERT INTO aggregates_%s (total, gender, address_type)
    SELECT
      count(qo.uuid) total,
      ''Total''        gender,
      ''All''          address_type
    FROM query_output_%s qo', separator, separator);

  EXECUTE format('UPDATE aggregates_%s ag1
  SET percentage = coalesce(round(((ag1.total / (SELECT sum(ag2.total)
                                                 FROM aggregates_%s ag2
                                                 WHERE (ag2.address_type = ag1.address_type AND ag2.gender != ''Total'')))
                                   * 100), 2), 100)', separator, separator);

  EXECUTE FORMAT('INSERT INTO aggregates_%s (total, percentage, address_type, gender)
                        SELECT 0, 0, atname, gname from (
                            SELECT DISTINCT type atname,
                            name gname
                          FROM address_level_type_view, gender
                          WHERE name != ''Other''
                          UNION ALL
                          SELECT
                            ''All'' atname,
                            name gname
                          FROM gender
                          WHERE name != ''Other''
                          UNION ALL
                          SELECT DISTINCT
                            type atname,
                            ''Total'' gname
                          FROM address_level_type_view
                          UNION ALL
                          SELECT
                            ''All'' atname,
                            ''Total'' gname) as agt where (atname, gname) not in (select address_type, gender from aggregates_%s)',
                 separator, separator);

  RETURN QUERY EXECUTE format('SELECT *
               FROM aggregates_%s order by address_type, gender', separator);
END
$$;


ALTER FUNCTION public.frequency_and_percentage(frequency_query text) OWNER TO openchs;

--
-- Name: frequency_and_percentage(text, text); Type: FUNCTION; Schema: public; Owner: openchs
--

CREATE FUNCTION public.frequency_and_percentage(frequency_query text, denominator_query text) RETURNS TABLE(total bigint, percentage double precision, gender character varying, address_type character varying)
    LANGUAGE plpgsql
    AS $$
DECLARE separator TEXT;
BEGIN
  SELECT md5(random() :: TEXT) :: TEXT
      INTO separator;
  EXECUTE FORMAT('CREATE TEMPORARY TABLE query_output_%s (
    uuid         VARCHAR,
    gender_name  VARCHAR,
    address_type VARCHAR,
    address_name VARCHAR
  ) ON COMMIT DROP', separator);

  EXECUTE FORMAT('CREATE TEMPORARY TABLE denominator_query_output_%s (
    uuid         VARCHAR,
    gender_name  VARCHAR,
    address_type VARCHAR,
    address_name VARCHAR
  ) ON COMMIT DROP', separator);

  EXECUTE format('CREATE TEMPORARY TABLE aggregates_%s (
    total        BIGINT,
    percentage   FLOAT,
    gender       VARCHAR,
    address_type VARCHAR
  ) ON COMMIT DROP', separator);

  EXECUTE FORMAT('CREATE TEMPORARY TABLE denominator_aggregates_%s (
    total        BIGINT,
    gender       VARCHAR,
    address_type VARCHAR
  ) ON COMMIT DROP', separator);
  -- Store filtered query into a temporary variable

  EXECUTE FORMAT('INSERT INTO query_output_%s (uuid, gender_name, address_type, address_name) %s', separator,
                 frequency_query);

  EXECUTE FORMAT('INSERT INTO denominator_query_output_%s (uuid, gender_name, address_type, address_name) %s',
                 separator,
                 denominator_query);

  EXECUTE format('INSERT INTO aggregates_%s (total, gender, address_type)
    SELECT
      count(qo.uuid)  total,
      qo.gender_name  gender,
      qo.address_type address_type
    FROM query_output_%s qo
    GROUP BY qo.gender_name, qo.address_type', separator, separator);

  EXECUTE format('INSERT INTO denominator_aggregates_%s (total, gender, address_type)
    SELECT
      count(qo.uuid)  total,
      qo.gender_name  gender,
      qo.address_type address_type
    FROM denominator_query_output_%s qo
    GROUP BY qo.gender_name, qo.address_type', separator, separator);


  EXECUTE format('INSERT INTO aggregates_%s (total, gender, address_type)
    SELECT
      count(qo.uuid)  total,
      ''Total''         gender,
      qo.address_type address_type
    FROM query_output_%s qo
    GROUP BY qo.address_type', separator, separator);

  EXECUTE format('INSERT INTO denominator_aggregates_%s (total, gender, address_type)
    SELECT
      count(qo.uuid)  total,
      ''Total''         gender,
      qo.address_type address_type
    FROM denominator_query_output_%s qo
    GROUP BY qo.address_type', separator, separator);

  EXECUTE format('INSERT INTO aggregates_%s (total, gender, address_type)
    SELECT
      count(qo.uuid)  total,
      qo.gender_name  gender,
      ''All'' address_type
    FROM query_output_%s qo
    GROUP BY qo.gender_name', separator, separator);

  EXECUTE format('INSERT INTO denominator_aggregates_%s (total, gender, address_type)
    SELECT
      count(qo.uuid)  total,
      qo.gender_name  gender,
      ''All'' address_type
    FROM denominator_query_output_%s qo
    GROUP BY qo.gender_name', separator, separator);

  EXECUTE format('INSERT INTO aggregates_%s (total, gender, address_type)
    SELECT
      count(qo.uuid) total,
      ''Total''        gender,
      ''All''          address_type
    FROM query_output_%s qo', separator, separator);

  EXECUTE format('INSERT INTO denominator_aggregates_%s (total, gender, address_type)
    SELECT
      count(qo.uuid) total,
      ''Total''        gender,
      ''All''          address_type
    FROM denominator_query_output_%s qo', separator, separator);

  EXECUTE FORMAT('UPDATE aggregates_%s ag1
  SET percentage = (SELECT coalesce(round(((ag2.total :: FLOAT / dag1.total) * 100) :: NUMERIC, 2), 100)
                    FROM aggregates_%s ag2
                      INNER JOIN denominator_aggregates_%s dag1
                        ON ag2.address_type = dag1.address_type AND ag2.gender = dag1.gender
                    WHERE ag2.address_type = ag1.address_type AND ag2.gender = ag1.gender
                    LIMIT 1)', separator, separator, separator);

  EXECUTE FORMAT('INSERT INTO aggregates_%s (total, percentage, address_type, gender)
                        SELECT 0, 0, atname, gname from (
                            SELECT DISTINCT type atname,
                            name gname
                          FROM address_level_type_view, gender
                          WHERE name != ''Other''
                          UNION ALL
                          SELECT
                            ''All'' atname,
                            name gname
                          FROM gender
                          WHERE name != ''Other''
                          UNION ALL
                          SELECT DISTINCT
                            type atname,
                            ''Total'' gname
                          FROM address_level_type_view
                          UNION ALL
                          SELECT
                            ''All'' atname,
                            ''Total'' gname) as agt where (atname, gname) not in (select address_type, gender from aggregates_%s)',
                 separator, separator);

  RETURN QUERY EXECUTE format('SELECT *
               FROM aggregates_%s order by address_type, gender', separator);
END
$$;


ALTER FUNCTION public.frequency_and_percentage(frequency_query text, denominator_query text) OWNER TO openchs;

--
-- Name: get_coded_string_value(jsonb, public.hstore); Type: FUNCTION; Schema: public; Owner: openchs
--

CREATE FUNCTION public.get_coded_string_value(obs jsonb, obs_store public.hstore) RETURNS character varying
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
    result VARCHAR;
BEGIN
    BEGIN
        IF JSONB_TYPEOF(obs) = 'array'
        THEN
            select STRING_AGG(obs_store -> OB.UUID, ', ') from JSONB_ARRAY_ELEMENTS_TEXT(obs) AS OB (UUID)
            INTO RESULT;
        ELSE
            SELECT obs_store -> (obs ->> 0) INTO RESULT;
        END IF;
        RETURN RESULT;
    EXCEPTION
        WHEN OTHERS
            THEN
                RAISE NOTICE 'Failed while processing get_coded_string_value(''%'')', obs :: TEXT;
                RAISE NOTICE '% %', SQLERRM, SQLSTATE;
    END;
END
$$;


ALTER FUNCTION public.get_coded_string_value(obs jsonb, obs_store public.hstore) OWNER TO openchs;

--
-- Name: grant_all_on_all(text); Type: FUNCTION; Schema: public; Owner: openchs
--

CREATE FUNCTION public.grant_all_on_all(rolename text) RETURNS text
    LANGUAGE plpgsql
    AS $$
BEGIN
    EXECUTE (
        SELECT 'GRANT ALL ON TABLE '
                   || string_agg(format('%I.%I', table_schema, table_name), ',')
                   || ' TO ' || quote_ident(rolename) || ''
        FROM information_schema.tables
        WHERE table_schema = 'public'
          AND table_type = 'BASE TABLE'
    );

    EXECUTE (
        SELECT 'GRANT SELECT ON '
                   || string_agg(format('%I.%I', schemaname, viewname), ',')
                   || ' TO ' || quote_ident(rolename) || ''
        FROM pg_catalog.pg_views
        WHERE schemaname = 'public'
          and viewowner in ('openchs')
    );

    EXECUTE 'GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO ' || quote_ident(rolename) || '';
    EXECUTE 'GRANT ALL ON ALL FUNCTIONS IN SCHEMA public TO ' || quote_ident(rolename) || '';
    RETURN 'ALL PERMISSIONS GRANTED TO ' || quote_ident(rolename);
END;
$$;


ALTER FUNCTION public.grant_all_on_all(rolename text) OWNER TO openchs;

--
-- Name: grant_all_on_views(text[], text); Type: FUNCTION; Schema: public; Owner: openchs
--

CREATE FUNCTION public.grant_all_on_views(view_names text[], role text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
    view_names_string text;
BEGIN
    view_names_string := array_to_string(view_names, ',');
    EXECUTE 'GRANT ALL ON ' || view_names_string || ' TO ' || quote_ident(role) || '';
    RETURN 'EXECUTE GRANT ALL ON ' || view_names_string || ' TO ' || quote_ident(role) || '';
END;
$$;


ALTER FUNCTION public.grant_all_on_views(view_names text[], role text) OWNER TO openchs;

--
-- Name: grant_permission_on_account_admin(text); Type: FUNCTION; Schema: public; Owner: openchs
--

CREATE FUNCTION public.grant_permission_on_account_admin(rolename text) RETURNS text
    LANGUAGE plpgsql
    AS $$
BEGIN
    EXECUTE 'GRANT ALL ON TABLE account_admin TO ' || quote_ident(rolename) || '';
    RETURN 'PERMISSIONS GRANTED FOR account_admin TO ' || quote_ident(rolename);
END;
$$;


ALTER FUNCTION public.grant_permission_on_account_admin(rolename text) OWNER TO openchs;

--
-- Name: jsonb_object_values_contain(jsonb, text); Type: FUNCTION; Schema: public; Owner: openchs
--

CREATE FUNCTION public.jsonb_object_values_contain(obs jsonb, pattern text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
BEGIN
  return EXISTS (select true from jsonb_each_text(obs) where value ilike pattern);
END;
$$;


ALTER FUNCTION public.jsonb_object_values_contain(obs jsonb, pattern text) OWNER TO openchs;

--
-- Name: revoke_permissions_on_account(text); Type: FUNCTION; Schema: public; Owner: openchs
--

CREATE FUNCTION public.revoke_permissions_on_account(rolename text) RETURNS text
    LANGUAGE plpgsql
    AS $$
BEGIN
    EXECUTE 'REVOKE ALL ON TABLE account FROM ' || quote_ident(rolename) || '';
    RETURN 'ALL ACCOUNT PERMISSIONS REVOKED FROM ' || quote_ident(rolename);
END;
$$;


ALTER FUNCTION public.revoke_permissions_on_account(rolename text) OWNER TO openchs;

--
-- Name: solidify_audit_columns(text); Type: FUNCTION; Schema: public; Owner: openchs
--

CREATE FUNCTION public.solidify_audit_columns(table_name text) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    execute 'alter table ' || table_name || '
        alter column created_by_id set not null,
        alter column last_modified_by_id set not null,
        alter column created_date_time set not null,
        alter column last_modified_date_time set not null;';
    RAISE NOTICE 'set audit fields to non-null %', table_name ;

    execute ' drop index if exists ' || table_name || '_last_modified_time_idx';
    execute 'CREATE INDEX ' || table_name || '_last_modified_time_idx
        ON ' || table_name || '(last_modified_date_time);';
    RAISE NOTICE 'create index on last_modified_date_time %', table_name ;

    execute 'drop trigger if exists ' || table_name ||   '_update_audit_before_insert on ' || table_name ;
    execute 'CREATE TRIGGER ' || table_name ||  '_update_audit_before_insert
            BEFORE INSERT
            ON ' || table_name || '
            FOR EACH ROW
        EXECUTE PROCEDURE audit_table_trigger();';
    RAISE NOTICE 'create trigger on insert %', table_name ;

    execute 'drop trigger if exists ' || table_name ||   '_update_audit_before_update on ' || table_name ;
    execute 'CREATE TRIGGER ' || table_name ||  '_update_audit_before_update
            BEFORE UPDATE
            ON ' || table_name || '
            FOR EACH ROW
        EXECUTE PROCEDURE audit_table_trigger();';
    RAISE NOTICE 'create trigger on update %', table_name ;
END
$$;


ALTER FUNCTION public.solidify_audit_columns(table_name text) OWNER TO openchs;

--
-- Name: title_lineage_locations_function(bigint); Type: FUNCTION; Schema: public; Owner: openchs
--

CREATE FUNCTION public.title_lineage_locations_function(addressid bigint) RETURNS TABLE(lowestpoint_id integer, title_lineage text)
    LANGUAGE sql
    AS $$
select al.id lowestpoint_id, string_agg(alevel_in_lineage.title, ', ' order by lineage.level) title_lineage
from address_level al
         join regexp_split_to_table(al.lineage :: text, '[.]') with ordinality lineage (point_id, level) ON TRUE
         join address_level alevel_in_lineage on alevel_in_lineage.id = lineage.point_id :: int
where case when addressId isnull then true else al.id = addressId end
group by al.id
$$;


ALTER FUNCTION public.title_lineage_locations_function(addressid bigint) OWNER TO openchs;

--
-- Name: update_audit_columns_from_audit_table(text); Type: PROCEDURE; Schema: public; Owner: openchs
--

CREATE PROCEDURE public.update_audit_columns_from_audit_table(IN table_name text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    execute 'update ' || table_name || '
        set created_by_id           = a.created_by_id,
            last_modified_by_id     = a.last_modified_by_id,
            created_date_time       = a.created_date_time,
            last_modified_date_time = a.last_modified_date_time
        from audit a
        where ' || table_name || '.audit_id = a.id;';
    RAISE NOTICE 'updated values of audit fields in %', table_name;
END
$$;


ALTER PROCEDURE public.update_audit_columns_from_audit_table(IN table_name text) OWNER TO openchs;

--
-- Name: virtual_catchment_address_mapping_table_function(); Type: FUNCTION; Schema: public; Owner: openchs
--

CREATE FUNCTION public.virtual_catchment_address_mapping_table_function() RETURNS TABLE(id bigint, catchment_id integer, addresslevel_id integer, type_id integer)
    LANGUAGE sql
    AS $$
select row_number() OVER ()  AS id,
       cam.catchment_id::int AS catchment_id,
       al.id                 AS addresslevel_id,
       al.type_id            AS type_id
from address_level al
         left outer join regexp_split_to_table((al.lineage)::text, '[.]'::text) WITH ORDINALITY lineage(point_id, level)
                         ON (true)
         left outer join catchment_address_mapping cam on cam.addresslevel_id = point_id::int
where catchment_id notnull
group by 2, 3
$$;


ALTER FUNCTION public.virtual_catchment_address_mapping_table_function() OWNER TO openchs;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.account (
    id integer NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.account OWNER TO openchs;

--
-- Name: account_admin; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.account_admin (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    account_id integer NOT NULL,
    admin_id integer NOT NULL
);


ALTER TABLE public.account_admin OWNER TO openchs;

--
-- Name: account_admin_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.account_admin_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_admin_id_seq OWNER TO openchs;

--
-- Name: account_admin_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.account_admin_id_seq OWNED BY public.account_admin.id;


--
-- Name: account_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.account_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_id_seq OWNER TO openchs;

--
-- Name: account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.account_id_seq OWNED BY public.account.id;


--
-- Name: address_level; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.address_level (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    uuid character varying(255) NOT NULL,
    version integer NOT NULL,
    organisation_id integer DEFAULT 1 NOT NULL,
    audit_id integer,
    is_voided boolean DEFAULT false NOT NULL,
    type_id integer,
    lineage public.ltree,
    parent_id integer,
    gps_coordinates point,
    location_properties jsonb,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    legacy_id character varying,
    CONSTRAINT lineage_parent_consistency CHECK ((((parent_id IS NOT NULL) AND (public.subltree(lineage, 0, public.nlevel(lineage)) OPERATOR(public.~) (concat('*.', parent_id, '.', id))::public.lquery)) OR ((parent_id IS NULL) AND (lineage OPERATOR(public.~) (concat('', id))::public.lquery))))
);


ALTER TABLE public.address_level OWNER TO openchs;

--
-- Name: address_level_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.address_level_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.address_level_id_seq OWNER TO openchs;

--
-- Name: address_level_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.address_level_id_seq OWNED BY public.address_level.id;


--
-- Name: address_level_type; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.address_level_type (
    id integer NOT NULL,
    uuid character varying(255) DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    organisation_id integer NOT NULL,
    version integer NOT NULL,
    audit_id integer,
    level double precision DEFAULT 0,
    parent_id integer,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.address_level_type OWNER TO openchs;

--
-- Name: address_level_type_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.address_level_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.address_level_type_id_seq OWNER TO openchs;

--
-- Name: address_level_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.address_level_type_id_seq OWNED BY public.address_level_type.id;


--
-- Name: organisation; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.organisation (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    db_user character varying(255) NOT NULL,
    uuid character varying(255) NOT NULL,
    parent_organisation_id integer,
    is_voided boolean DEFAULT false NOT NULL,
    media_directory text,
    username_suffix text,
    account_id integer DEFAULT 1 NOT NULL,
    schema_name character varying(255) NOT NULL,
    has_analytics_db boolean DEFAULT false NOT NULL
);


ALTER TABLE public.organisation OWNER TO openchs;

--
-- Name: address_level_type_view; Type: VIEW; Schema: public; Owner: openchs
--

CREATE VIEW public.address_level_type_view AS
 WITH RECURSIVE list_of_orgs(id, parent_organisation_id) AS (
         SELECT organisation.id,
            organisation.parent_organisation_id
           FROM public.organisation
          WHERE ((organisation.db_user)::text = CURRENT_USER)
        UNION ALL
         SELECT o.id,
            o.parent_organisation_id
           FROM public.organisation o,
            list_of_orgs log
          WHERE (o.id = log.parent_organisation_id)
        )
 SELECT al.id,
    al.title,
    al.uuid,
    alt.level,
    al.version,
    al.organisation_id,
    al.audit_id,
    al.is_voided,
    al.type_id,
    alt.name AS type
   FROM ((public.address_level al
     JOIN public.address_level_type alt ON ((al.type_id = alt.id)))
     JOIN list_of_orgs loo ON ((loo.id = al.organisation_id)))
  WHERE (alt.is_voided IS NOT TRUE);


ALTER TABLE public.address_level_type_view OWNER TO openchs;

--
-- Name: form; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.form (
    id integer NOT NULL,
    name character varying(255),
    form_type character varying(255) NOT NULL,
    uuid character varying(255) NOT NULL,
    version integer NOT NULL,
    organisation_id integer DEFAULT 1 NOT NULL,
    audit_id integer,
    is_voided boolean DEFAULT false NOT NULL,
    decision_rule text,
    validation_rule text,
    visit_schedule_rule text,
    checklists_rule text,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    validation_declarative_rule jsonb,
    decision_declarative_rule jsonb,
    visit_schedule_declarative_rule jsonb,
    task_schedule_declarative_rule text,
    task_schedule_rule text
);


ALTER TABLE public.form OWNER TO openchs;

--
-- Name: form_mapping; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.form_mapping (
    id integer NOT NULL,
    form_id bigint,
    uuid character varying(255) NOT NULL,
    version integer NOT NULL,
    entity_id bigint,
    observations_type_entity_id integer,
    organisation_id integer DEFAULT 1 NOT NULL,
    audit_id integer,
    is_voided boolean DEFAULT false NOT NULL,
    subject_type_id integer,
    enable_approval boolean DEFAULT false NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    task_type_id integer,
    CONSTRAINT subject_type_check CHECK (((subject_type_id IS NOT NULL) OR (task_type_id IS NOT NULL)))
);


ALTER TABLE public.form_mapping OWNER TO openchs;

--
-- Name: operational_encounter_type; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.operational_encounter_type (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    organisation_id integer NOT NULL,
    encounter_type_id integer NOT NULL,
    version integer NOT NULL,
    audit_id integer,
    name character varying(255),
    is_voided boolean DEFAULT false NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.operational_encounter_type OWNER TO openchs;

--
-- Name: operational_program; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.operational_program (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    organisation_id integer NOT NULL,
    program_id integer NOT NULL,
    version integer NOT NULL,
    audit_id integer,
    name character varying(255),
    is_voided boolean DEFAULT false NOT NULL,
    program_subject_label text,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.operational_program OWNER TO openchs;

--
-- Name: all_forms; Type: VIEW; Schema: public; Owner: openchs
--

CREATE VIEW public.all_forms AS
 SELECT DISTINCT x.organisation_id,
    x.form_id,
    x.form_name
   FROM ( SELECT form.id AS form_id,
            form.name AS form_name,
            m2.organisation_id
           FROM (public.form
             JOIN public.form_mapping m2 ON ((form.id = m2.form_id)))
          WHERE ((NOT form.is_voided) OR (NOT m2.is_voided))
        UNION
         SELECT form.id AS form_id,
            form.name AS form_name,
            oet.organisation_id
           FROM ((public.form
             JOIN public.form_mapping m2 ON (((form.id = m2.form_id) AND (m2.organisation_id = 1))))
             JOIN public.operational_encounter_type oet ON ((oet.encounter_type_id = m2.observations_type_entity_id)))
          WHERE ((NOT form.is_voided) OR (NOT m2.is_voided) OR (NOT oet.is_voided))
        UNION
         SELECT form.id AS form_id,
            form.name AS form_name,
            op.organisation_id
           FROM ((public.form
             JOIN public.form_mapping m2 ON (((form.id = m2.form_id) AND (m2.organisation_id = 1))))
             JOIN public.operational_program op ON ((op.program_id = m2.entity_id)))
          WHERE ((NOT form.is_voided) OR (NOT m2.is_voided) OR (NOT op.is_voided))) x;


ALTER TABLE public.all_forms OWNER TO openchs;

--
-- Name: concept; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.concept (
    id integer NOT NULL,
    data_type character varying(255) NOT NULL,
    high_absolute double precision,
    high_normal double precision,
    low_absolute double precision,
    low_normal double precision,
    name character varying(255) NOT NULL,
    uuid character varying(255) NOT NULL,
    version integer NOT NULL,
    unit character varying(50),
    organisation_id integer DEFAULT 1 NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    audit_id integer,
    key_values jsonb,
    active boolean DEFAULT true NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.concept OWNER TO openchs;

--
-- Name: concept_answer; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.concept_answer (
    id integer NOT NULL,
    concept_id bigint NOT NULL,
    answer_concept_id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    version integer NOT NULL,
    answer_order double precision NOT NULL,
    organisation_id integer DEFAULT 1 NOT NULL,
    abnormal boolean DEFAULT false NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    uniq boolean DEFAULT false NOT NULL,
    audit_id integer,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.concept_answer OWNER TO openchs;

--
-- Name: form_element; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.form_element (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    display_order double precision NOT NULL,
    is_mandatory boolean DEFAULT false NOT NULL,
    key_values jsonb,
    concept_id bigint NOT NULL,
    form_element_group_id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    version integer NOT NULL,
    organisation_id integer DEFAULT 1 NOT NULL,
    type character varying(1024) DEFAULT NULL::character varying,
    valid_format_regex character varying(255),
    valid_format_description_key character varying(255),
    audit_id integer,
    is_voided boolean DEFAULT false NOT NULL,
    rule text,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    declarative_rule jsonb,
    group_id integer,
    documentation_id integer,
    CONSTRAINT valid_format_check CHECK ((((valid_format_regex IS NULL) AND (valid_format_description_key IS NULL)) OR ((valid_format_regex IS NOT NULL) AND (valid_format_description_key IS NOT NULL))))
);


ALTER TABLE public.form_element OWNER TO openchs;

--
-- Name: form_element_group; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.form_element_group (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    form_id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    version integer NOT NULL,
    display_order double precision DEFAULT '-1'::integer NOT NULL,
    display character varying(100),
    organisation_id integer DEFAULT 1 NOT NULL,
    audit_id integer,
    is_voided boolean DEFAULT false NOT NULL,
    rule text,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    declarative_rule jsonb,
    start_time integer,
    stay_time integer,
    is_timed boolean DEFAULT false,
    text_colour character varying(20),
    background_colour character varying(20)
);


ALTER TABLE public.form_element_group OWNER TO openchs;

--
-- Name: all_concept_answers; Type: VIEW; Schema: public; Owner: openchs
--

CREATE VIEW public.all_concept_answers AS
 SELECT DISTINCT all_forms.organisation_id,
    c3.name AS answer_concept_name
   FROM ((((((public.form_element
     JOIN public.form_element_group ON ((form_element.form_element_group_id = form_element_group.id)))
     JOIN public.form ON ((form_element_group.form_id = form.id)))
     JOIN public.concept c2 ON ((form_element.concept_id = c2.id)))
     JOIN public.concept_answer a ON ((c2.id = a.concept_id)))
     JOIN public.concept c3 ON ((a.answer_concept_id = c3.id)))
     JOIN public.all_forms ON ((all_forms.form_id = form.id)))
  WHERE ((NOT form_element.is_voided) OR (NOT form_element_group.is_voided) OR (NOT form.is_voided) OR (NOT c2.is_voided) OR (NOT c2.is_voided) OR (NOT c3.is_voided));


ALTER TABLE public.all_concept_answers OWNER TO openchs;

--
-- Name: all_concepts; Type: VIEW; Schema: public; Owner: openchs
--

CREATE VIEW public.all_concepts AS
 SELECT DISTINCT all_forms.organisation_id,
    c2.name AS concept_name
   FROM ((((public.form_element
     JOIN public.form_element_group ON ((form_element.form_element_group_id = form_element_group.id)))
     JOIN public.form ON ((form_element_group.form_id = form.id)))
     JOIN public.concept c2 ON ((form_element.concept_id = c2.id)))
     JOIN public.all_forms ON ((all_forms.form_id = form.id)))
  WHERE ((NOT form_element.is_voided) OR (NOT form_element_group.is_voided) OR (NOT form.is_voided) OR (NOT c2.is_voided));


ALTER TABLE public.all_concepts OWNER TO openchs;

--
-- Name: encounter_type; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.encounter_type (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    concept_id bigint,
    uuid character varying(255) NOT NULL,
    version integer NOT NULL,
    organisation_id integer DEFAULT 1 NOT NULL,
    audit_id integer,
    is_voided boolean DEFAULT false NOT NULL,
    encounter_eligibility_check_rule text,
    active boolean DEFAULT true NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    encounter_eligibility_check_declarative_rule jsonb,
    is_immutable boolean DEFAULT false
);


ALTER TABLE public.encounter_type OWNER TO openchs;

--
-- Name: all_encounter_types; Type: VIEW; Schema: public; Owner: openchs
--

CREATE VIEW public.all_encounter_types AS
 SELECT DISTINCT operational_encounter_type.organisation_id,
    et.name AS encounter_type_name
   FROM (public.operational_encounter_type
     JOIN public.encounter_type et ON ((operational_encounter_type.encounter_type_id = et.id)))
  WHERE ((NOT operational_encounter_type.is_voided) OR (NOT et.is_voided));


ALTER TABLE public.all_encounter_types OWNER TO openchs;

--
-- Name: all_form_element_groups; Type: VIEW; Schema: public; Owner: openchs
--

CREATE VIEW public.all_form_element_groups AS
 SELECT DISTINCT all_forms.organisation_id,
    form_element_group.name AS form_element_group_name
   FROM ((public.form_element_group
     JOIN public.form ON ((form_element_group.form_id = form.id)))
     JOIN public.all_forms ON ((all_forms.form_id = form.id)))
  WHERE ((NOT form_element_group.is_voided) OR (NOT form.is_voided));


ALTER TABLE public.all_form_element_groups OWNER TO openchs;

--
-- Name: all_form_elements; Type: VIEW; Schema: public; Owner: openchs
--

CREATE VIEW public.all_form_elements AS
 SELECT DISTINCT all_forms.organisation_id,
    form_element.name AS form_element_name
   FROM (((public.form_element
     JOIN public.form_element_group ON ((form_element.form_element_group_id = form_element_group.id)))
     JOIN public.form ON ((form_element_group.form_id = form.id)))
     JOIN public.all_forms ON ((all_forms.form_id = form.id)))
  WHERE ((NOT form_element.is_voided) OR (NOT form_element_group.is_voided));


ALTER TABLE public.all_form_elements OWNER TO openchs;

--
-- Name: all_operational_encounter_types; Type: VIEW; Schema: public; Owner: openchs
--

CREATE VIEW public.all_operational_encounter_types AS
 SELECT DISTINCT operational_encounter_type.organisation_id,
    operational_encounter_type.name AS operational_encounter_type_name
   FROM (public.operational_encounter_type
     JOIN public.encounter_type et ON ((operational_encounter_type.encounter_type_id = et.id)))
  WHERE ((NOT operational_encounter_type.is_voided) OR (NOT et.is_voided));


ALTER TABLE public.all_operational_encounter_types OWNER TO openchs;

--
-- Name: program; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.program (
    id smallint NOT NULL,
    uuid character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    version integer NOT NULL,
    colour character varying(20),
    organisation_id integer DEFAULT 1 NOT NULL,
    audit_id integer,
    is_voided boolean DEFAULT false NOT NULL,
    enrolment_summary_rule text,
    enrolment_eligibility_check_rule text,
    active boolean DEFAULT true NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    enrolment_eligibility_check_declarative_rule jsonb,
    manual_eligibility_check_required boolean DEFAULT false NOT NULL,
    manual_enrolment_eligibility_check_rule text,
    manual_enrolment_eligibility_check_declarative_rule text,
    allow_multiple_enrolments boolean DEFAULT false NOT NULL
);


ALTER TABLE public.program OWNER TO openchs;

--
-- Name: all_operational_programs; Type: VIEW; Schema: public; Owner: openchs
--

CREATE VIEW public.all_operational_programs AS
 SELECT DISTINCT operational_program.organisation_id,
    operational_program.name AS operational_program_name
   FROM (public.operational_program
     JOIN public.program p ON ((p.id = operational_program.program_id)))
  WHERE ((NOT operational_program.is_voided) OR (NOT p.is_voided));


ALTER TABLE public.all_operational_programs OWNER TO openchs;

--
-- Name: all_programs; Type: VIEW; Schema: public; Owner: openchs
--

CREATE VIEW public.all_programs AS
 SELECT DISTINCT operational_program.organisation_id,
    p.name AS program_name
   FROM (public.operational_program
     JOIN public.program p ON ((p.id = operational_program.program_id)))
  WHERE ((NOT operational_program.is_voided) OR (NOT p.is_voided));


ALTER TABLE public.all_programs OWNER TO openchs;

--
-- Name: answer_concept_migration; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.answer_concept_migration (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    concept_id integer NOT NULL,
    old_answer_concept_name character varying(255) NOT NULL,
    new_answer_concept_name character varying(255) NOT NULL,
    organisation_id integer NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    version integer NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.answer_concept_migration OWNER TO openchs;

--
-- Name: answer_concept_migration_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.answer_concept_migration_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.answer_concept_migration_id_seq OWNER TO openchs;

--
-- Name: answer_concept_migration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.answer_concept_migration_id_seq OWNED BY public.answer_concept_migration.id;


--
-- Name: approval_status; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.approval_status (
    id integer NOT NULL,
    uuid text NOT NULL,
    status text NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    created_date_time timestamp with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.approval_status OWNER TO openchs;

--
-- Name: approval_status_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.approval_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.approval_status_id_seq OWNER TO openchs;

--
-- Name: approval_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.approval_status_id_seq OWNED BY public.approval_status.id;


--
-- Name: audit; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.audit (
    id integer NOT NULL,
    uuid character varying(255),
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.audit OWNER TO openchs;

--
-- Name: audit_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.audit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_id_seq OWNER TO openchs;

--
-- Name: audit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.audit_id_seq OWNED BY public.audit.id;


--
-- Name: batch_job_execution; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.batch_job_execution (
    job_execution_id bigint NOT NULL,
    version bigint,
    job_instance_id bigint NOT NULL,
    create_time timestamp without time zone NOT NULL,
    start_time timestamp without time zone,
    end_time timestamp without time zone,
    status character varying(10),
    exit_code character varying(2500),
    exit_message character varying(2500),
    last_updated timestamp without time zone,
    job_configuration_location character varying(2500)
);


ALTER TABLE public.batch_job_execution OWNER TO openchs;

--
-- Name: batch_job_execution_context; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.batch_job_execution_context (
    job_execution_id bigint NOT NULL,
    short_context character varying(2500) NOT NULL,
    serialized_context text
);


ALTER TABLE public.batch_job_execution_context OWNER TO openchs;

--
-- Name: batch_job_execution_params; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.batch_job_execution_params (
    job_execution_id bigint NOT NULL,
    type_cd character varying(6) NOT NULL,
    key_name character varying(100) NOT NULL,
    string_val character varying(250),
    date_val timestamp without time zone,
    long_val bigint,
    double_val double precision,
    identifying character(1) NOT NULL
);


ALTER TABLE public.batch_job_execution_params OWNER TO openchs;

--
-- Name: batch_job_execution_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.batch_job_execution_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.batch_job_execution_seq OWNER TO openchs;

--
-- Name: batch_job_instance; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.batch_job_instance (
    job_instance_id bigint NOT NULL,
    version bigint,
    job_name character varying(100) NOT NULL,
    job_key character varying(32) NOT NULL
);


ALTER TABLE public.batch_job_instance OWNER TO openchs;

--
-- Name: batch_job_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.batch_job_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.batch_job_seq OWNER TO openchs;

--
-- Name: batch_step_execution; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.batch_step_execution (
    step_execution_id bigint NOT NULL,
    version bigint NOT NULL,
    step_name character varying(100) NOT NULL,
    job_execution_id bigint NOT NULL,
    start_time timestamp without time zone NOT NULL,
    end_time timestamp without time zone,
    status character varying(10),
    commit_count bigint,
    read_count bigint,
    filter_count bigint,
    write_count bigint,
    read_skip_count bigint,
    write_skip_count bigint,
    process_skip_count bigint,
    rollback_count bigint,
    exit_code character varying(2500),
    exit_message character varying(2500),
    last_updated timestamp without time zone
);


ALTER TABLE public.batch_step_execution OWNER TO openchs;

--
-- Name: batch_step_execution_context; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.batch_step_execution_context (
    step_execution_id bigint NOT NULL,
    short_context character varying(2500) NOT NULL,
    serialized_context text
);


ALTER TABLE public.batch_step_execution_context OWNER TO openchs;

--
-- Name: batch_step_execution_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.batch_step_execution_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.batch_step_execution_seq OWNER TO openchs;

--
-- Name: catchment; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.catchment (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    uuid character varying(255) NOT NULL,
    version integer NOT NULL,
    organisation_id integer DEFAULT 1 NOT NULL,
    type character varying(1024) DEFAULT 'Villages'::character varying NOT NULL,
    audit_id integer,
    is_voided boolean DEFAULT false NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.catchment OWNER TO openchs;

--
-- Name: catchment_address_mapping; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.catchment_address_mapping (
    id integer NOT NULL,
    catchment_id bigint NOT NULL,
    addresslevel_id bigint NOT NULL
);


ALTER TABLE public.catchment_address_mapping OWNER TO openchs;

--
-- Name: catchment_address_mapping_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.catchment_address_mapping_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.catchment_address_mapping_id_seq OWNER TO openchs;

--
-- Name: catchment_address_mapping_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.catchment_address_mapping_id_seq OWNED BY public.catchment_address_mapping.id;


--
-- Name: catchment_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.catchment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.catchment_id_seq OWNER TO openchs;

--
-- Name: catchment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.catchment_id_seq OWNED BY public.catchment.id;


--
-- Name: checklist; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.checklist (
    id integer NOT NULL,
    program_enrolment_id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    version integer NOT NULL,
    base_date timestamp with time zone NOT NULL,
    organisation_id integer DEFAULT 1 NOT NULL,
    audit_id integer,
    is_voided boolean DEFAULT false NOT NULL,
    checklist_detail_id integer,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    manual_update_history text
);


ALTER TABLE public.checklist OWNER TO openchs;

--
-- Name: checklist_detail; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.checklist_detail (
    id smallint NOT NULL,
    uuid character varying(255) NOT NULL,
    version integer NOT NULL,
    audit_id integer NOT NULL,
    name character varying NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    organisation_id integer NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.checklist_detail OWNER TO openchs;

--
-- Name: checklist_detail_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.checklist_detail_id_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.checklist_detail_id_seq OWNER TO openchs;

--
-- Name: checklist_detail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.checklist_detail_id_seq OWNED BY public.checklist_detail.id;


--
-- Name: checklist_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.checklist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.checklist_id_seq OWNER TO openchs;

--
-- Name: checklist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.checklist_id_seq OWNED BY public.checklist.id;


--
-- Name: checklist_item; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.checklist_item (
    id integer NOT NULL,
    completion_date timestamp with time zone,
    checklist_id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    version integer NOT NULL,
    organisation_id integer DEFAULT 1 NOT NULL,
    audit_id integer,
    is_voided boolean DEFAULT false NOT NULL,
    observations jsonb,
    checklist_item_detail_id integer,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    manual_update_history text
);


ALTER TABLE public.checklist_item OWNER TO openchs;

--
-- Name: checklist_item_detail; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.checklist_item_detail (
    id smallint NOT NULL,
    uuid character varying(255) NOT NULL,
    version integer NOT NULL,
    audit_id integer NOT NULL,
    form_id integer NOT NULL,
    concept_id integer NOT NULL,
    checklist_detail_id integer NOT NULL,
    status jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    organisation_id integer NOT NULL,
    dependent_on integer,
    schedule_on_expiry_of_dependency boolean DEFAULT false NOT NULL,
    min_days_from_start_date smallint,
    min_days_from_dependent integer,
    expires_after integer,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.checklist_item_detail OWNER TO openchs;

--
-- Name: checklist_item_detail_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.checklist_item_detail_id_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.checklist_item_detail_id_seq OWNER TO openchs;

--
-- Name: checklist_item_detail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.checklist_item_detail_id_seq OWNED BY public.checklist_item_detail.id;


--
-- Name: checklist_item_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.checklist_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.checklist_item_id_seq OWNER TO openchs;

--
-- Name: checklist_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.checklist_item_id_seq OWNED BY public.checklist_item.id;


--
-- Name: column_metadata; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.column_metadata (
    id integer NOT NULL,
    table_id integer,
    name text,
    type text,
    concept_id integer,
    concept_type text,
    concept_uuid character varying(255),
    schema_name text,
    parent_concept_uuid character varying(255)
);


ALTER TABLE public.column_metadata OWNER TO openchs;

--
-- Name: column_metadata_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.column_metadata_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.column_metadata_id_seq OWNER TO openchs;

--
-- Name: column_metadata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.column_metadata_id_seq OWNED BY public.column_metadata.id;


--
-- Name: comment; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.comment (
    id integer NOT NULL,
    organisation_id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    text text NOT NULL,
    subject_id bigint NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    audit_id bigint NOT NULL,
    version bigint DEFAULT 0 NOT NULL,
    comment_thread_id bigint,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.comment OWNER TO openchs;

--
-- Name: comment_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.comment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.comment_id_seq OWNER TO openchs;

--
-- Name: comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.comment_id_seq OWNED BY public.comment.id;


--
-- Name: comment_thread; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.comment_thread (
    id integer NOT NULL,
    organisation_id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    status text NOT NULL,
    open_date_time timestamp with time zone,
    resolved_date_time timestamp with time zone,
    is_voided boolean DEFAULT false NOT NULL,
    audit_id bigint NOT NULL,
    version bigint DEFAULT 0 NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.comment_thread OWNER TO openchs;

--
-- Name: comment_thread_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.comment_thread_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.comment_thread_id_seq OWNER TO openchs;

--
-- Name: comment_thread_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.comment_thread_id_seq OWNED BY public.comment_thread.id;


--
-- Name: concept_answer_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.concept_answer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.concept_answer_id_seq OWNER TO openchs;

--
-- Name: concept_answer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.concept_answer_id_seq OWNED BY public.concept_answer.id;


--
-- Name: concept_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.concept_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.concept_id_seq OWNER TO openchs;

--
-- Name: concept_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.concept_id_seq OWNED BY public.concept.id;


--
-- Name: custom_query; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.custom_query (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    name text NOT NULL,
    query text NOT NULL,
    organisation_id integer NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    version integer NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.custom_query OWNER TO openchs;

--
-- Name: custom_query_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.custom_query_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.custom_query_id_seq OWNER TO openchs;

--
-- Name: custom_query_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.custom_query_id_seq OWNED BY public.custom_query.id;


--
-- Name: dashboard; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.dashboard (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    is_voided boolean DEFAULT false NOT NULL,
    version integer,
    organisation_id integer NOT NULL,
    audit_id integer,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.dashboard OWNER TO openchs;

--
-- Name: dashboard_card_mapping; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.dashboard_card_mapping (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    dashboard_id bigint NOT NULL,
    card_id bigint NOT NULL,
    display_order double precision DEFAULT '-1'::integer NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    version integer,
    organisation_id integer NOT NULL,
    audit_id integer,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.dashboard_card_mapping OWNER TO openchs;

--
-- Name: dashboard_card_mapping_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.dashboard_card_mapping_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dashboard_card_mapping_id_seq OWNER TO openchs;

--
-- Name: dashboard_card_mapping_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.dashboard_card_mapping_id_seq OWNED BY public.dashboard_card_mapping.id;


--
-- Name: dashboard_filter; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.dashboard_filter (
    id integer NOT NULL,
    dashboard_id integer NOT NULL,
    filter_config jsonb NOT NULL,
    uuid character varying(255) NOT NULL,
    organisation_id integer NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    version integer NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.dashboard_filter OWNER TO openchs;

--
-- Name: dashboard_filter_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.dashboard_filter_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dashboard_filter_id_seq OWNER TO openchs;

--
-- Name: dashboard_filter_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.dashboard_filter_id_seq OWNED BY public.dashboard_filter.id;


--
-- Name: dashboard_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.dashboard_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dashboard_id_seq OWNER TO openchs;

--
-- Name: dashboard_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.dashboard_id_seq OWNED BY public.dashboard.id;


--
-- Name: dashboard_section; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.dashboard_section (
    id integer NOT NULL,
    uuid text NOT NULL,
    name text,
    description text,
    dashboard_id bigint NOT NULL,
    view_type text NOT NULL,
    display_order double precision DEFAULT '-1'::integer NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    version integer,
    organisation_id bigint NOT NULL,
    audit_id bigint,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    CONSTRAINT dashboard_section_check CHECK ((((name IS NOT NULL) AND (description IS NOT NULL)) OR (view_type = 'Default'::text)))
);


ALTER TABLE public.dashboard_section OWNER TO openchs;

--
-- Name: dashboard_section_card_mapping; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.dashboard_section_card_mapping (
    id integer NOT NULL,
    uuid text NOT NULL,
    dashboard_section_id bigint NOT NULL,
    card_id bigint NOT NULL,
    display_order double precision DEFAULT '-1'::integer NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    version integer,
    organisation_id bigint NOT NULL,
    audit_id bigint,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.dashboard_section_card_mapping OWNER TO openchs;

--
-- Name: dashboard_section_card_mapping_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.dashboard_section_card_mapping_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dashboard_section_card_mapping_id_seq OWNER TO openchs;

--
-- Name: dashboard_section_card_mapping_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.dashboard_section_card_mapping_id_seq OWNED BY public.dashboard_section_card_mapping.id;


--
-- Name: dashboard_section_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.dashboard_section_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dashboard_section_id_seq OWNER TO openchs;

--
-- Name: dashboard_section_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.dashboard_section_id_seq OWNED BY public.dashboard_section.id;


--
-- Name: decision_concept; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.decision_concept (
    id integer NOT NULL,
    concept_id bigint NOT NULL,
    form_id bigint NOT NULL
);


ALTER TABLE public.decision_concept OWNER TO openchs;

--
-- Name: decision_concept_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.decision_concept_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.decision_concept_id_seq OWNER TO openchs;

--
-- Name: decision_concept_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.decision_concept_id_seq OWNED BY public.decision_concept.id;


--
-- Name: deps_saved_ddl; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.deps_saved_ddl (
    deps_id integer NOT NULL,
    deps_view_schema character varying(255),
    deps_view_name character varying(255),
    deps_ddl_to_run text
);


ALTER TABLE public.deps_saved_ddl OWNER TO openchs;

--
-- Name: deps_saved_ddl_deps_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.deps_saved_ddl_deps_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.deps_saved_ddl_deps_id_seq OWNER TO openchs;

--
-- Name: deps_saved_ddl_deps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.deps_saved_ddl_deps_id_seq OWNED BY public.deps_saved_ddl.deps_id;


--
-- Name: documentation; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.documentation (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    name text NOT NULL,
    organisation_id integer NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    version integer NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    parent_id integer
);


ALTER TABLE public.documentation OWNER TO openchs;

--
-- Name: documentation_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.documentation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.documentation_id_seq OWNER TO openchs;

--
-- Name: documentation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.documentation_id_seq OWNED BY public.documentation.id;


--
-- Name: documentation_item; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.documentation_item (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    documentation_id integer NOT NULL,
    language text NOT NULL,
    content text NOT NULL,
    contenthtml text NOT NULL,
    organisation_id integer NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    version integer NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.documentation_item OWNER TO openchs;

--
-- Name: documentation_item_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.documentation_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.documentation_item_id_seq OWNER TO openchs;

--
-- Name: documentation_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.documentation_item_id_seq OWNED BY public.documentation_item.id;


--
-- Name: encounter; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.encounter (
    id integer NOT NULL,
    observations jsonb NOT NULL,
    encounter_date_time timestamp with time zone,
    encounter_type_id integer NOT NULL,
    individual_id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    version integer NOT NULL,
    organisation_id integer DEFAULT 1 NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    audit_id integer,
    encounter_location point,
    earliest_visit_date_time timestamp with time zone,
    max_visit_date_time timestamp with time zone,
    cancel_date_time timestamp with time zone,
    cancel_observations jsonb,
    cancel_location point,
    name text,
    legacy_id character varying,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    address_id bigint,
    sync_concept_1_value text,
    sync_concept_2_value text,
    manual_update_history text
);


ALTER TABLE public.encounter OWNER TO openchs;

--
-- Name: encounter_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.encounter_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.encounter_id_seq OWNER TO openchs;

--
-- Name: encounter_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.encounter_id_seq OWNED BY public.encounter.id;


--
-- Name: encounter_type_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.encounter_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.encounter_type_id_seq OWNER TO openchs;

--
-- Name: encounter_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.encounter_type_id_seq OWNED BY public.encounter_type.id;


--
-- Name: entity_approval_status; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.entity_approval_status (
    id integer NOT NULL,
    uuid text NOT NULL,
    entity_id bigint NOT NULL,
    entity_type text NOT NULL,
    approval_status_id bigint NOT NULL,
    approval_status_comment text,
    organisation_id bigint NOT NULL,
    auto_approved boolean DEFAULT false NOT NULL,
    audit_id bigint NOT NULL,
    version bigint DEFAULT 0 NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    status_date_time timestamp with time zone NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    entity_type_uuid text DEFAULT ''::text NOT NULL,
    address_id bigint,
    individual_id bigint DEFAULT 1 NOT NULL,
    sync_concept_1_value text,
    sync_concept_2_value text
);


ALTER TABLE public.entity_approval_status OWNER TO openchs;

--
-- Name: entity_approval_status_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.entity_approval_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.entity_approval_status_id_seq OWNER TO openchs;

--
-- Name: entity_approval_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.entity_approval_status_id_seq OWNED BY public.entity_approval_status.id;


--
-- Name: entity_sync_status; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.entity_sync_status (
    id integer NOT NULL,
    db_user text,
    table_metadata_id integer,
    last_sync_time timestamp(3) with time zone,
    sync_status text,
    schema_name text NOT NULL
);


ALTER TABLE public.entity_sync_status OWNER TO openchs;

--
-- Name: entity_sync_status_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.entity_sync_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.entity_sync_status_id_seq OWNER TO openchs;

--
-- Name: entity_sync_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.entity_sync_status_id_seq OWNED BY public.entity_sync_status.id;


--
-- Name: export_job_parameters; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.export_job_parameters (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    user_id integer NOT NULL,
    report_format jsonb NOT NULL,
    timezone text NOT NULL,
    organisation_id integer NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    version integer NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.export_job_parameters OWNER TO openchs;

--
-- Name: export_job_parameters_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.export_job_parameters_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.export_job_parameters_id_seq OWNER TO openchs;

--
-- Name: export_job_parameters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.export_job_parameters_id_seq OWNED BY public.export_job_parameters.id;


--
-- Name: external_system_config; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.external_system_config (
    id integer NOT NULL,
    organisation_id integer NOT NULL,
    uuid character varying(255) DEFAULT public.uuid_generate_v4() NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    version integer NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    system_name character varying(255) NOT NULL,
    config jsonb NOT NULL
);


ALTER TABLE public.external_system_config OWNER TO openchs;

--
-- Name: external_system_config_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.external_system_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.external_system_config_id_seq OWNER TO openchs;

--
-- Name: external_system_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.external_system_config_id_seq OWNED BY public.external_system_config.id;


--
-- Name: facility; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.facility (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    address_id bigint,
    is_voided boolean DEFAULT false NOT NULL,
    organisation_id integer NOT NULL,
    version integer NOT NULL,
    audit_id integer,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.facility OWNER TO openchs;

--
-- Name: facility_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.facility_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.facility_id_seq OWNER TO openchs;

--
-- Name: facility_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.facility_id_seq OWNED BY public.facility.id;


--
-- Name: form_element_group_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.form_element_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.form_element_group_id_seq OWNER TO openchs;

--
-- Name: form_element_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.form_element_group_id_seq OWNED BY public.form_element_group.id;


--
-- Name: form_element_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.form_element_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.form_element_id_seq OWNER TO openchs;

--
-- Name: form_element_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.form_element_id_seq OWNED BY public.form_element.id;


--
-- Name: form_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.form_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.form_id_seq OWNER TO openchs;

--
-- Name: form_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.form_id_seq OWNED BY public.form.id;


--
-- Name: form_mapping_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.form_mapping_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.form_mapping_id_seq OWNER TO openchs;

--
-- Name: form_mapping_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.form_mapping_id_seq OWNED BY public.form_mapping.id;


--
-- Name: gender; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.gender (
    id smallint NOT NULL,
    uuid character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    concept_id bigint,
    version integer NOT NULL,
    audit_id integer,
    is_voided boolean DEFAULT false NOT NULL,
    organisation_id integer NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.gender OWNER TO openchs;

--
-- Name: gender_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.gender_id_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gender_id_seq OWNER TO openchs;

--
-- Name: gender_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.gender_id_seq OWNED BY public.gender.id;


--
-- Name: group_dashboard; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.group_dashboard (
    id integer NOT NULL,
    uuid text NOT NULL,
    organisation_id bigint NOT NULL,
    is_primary_dashboard boolean DEFAULT false NOT NULL,
    audit_id bigint NOT NULL,
    version bigint DEFAULT 0 NOT NULL,
    group_id bigint NOT NULL,
    dashboard_id bigint NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.group_dashboard OWNER TO openchs;

--
-- Name: group_dashboard_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.group_dashboard_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.group_dashboard_id_seq OWNER TO openchs;

--
-- Name: group_dashboard_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.group_dashboard_id_seq OWNED BY public.group_dashboard.id;


--
-- Name: group_privilege; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.group_privilege (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    group_id integer NOT NULL,
    privilege_id integer NOT NULL,
    subject_type_id integer,
    program_id integer,
    program_encounter_type_id integer,
    encounter_type_id integer,
    checklist_detail_id integer,
    allow boolean DEFAULT false NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    version integer,
    organisation_id integer NOT NULL,
    audit_id integer,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.group_privilege OWNER TO openchs;

--
-- Name: group_privilege_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.group_privilege_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.group_privilege_id_seq OWNER TO openchs;

--
-- Name: group_privilege_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.group_privilege_id_seq OWNED BY public.group_privilege.id;


--
-- Name: group_role; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.group_role (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    group_subject_type_id integer NOT NULL,
    role text,
    member_subject_type_id integer NOT NULL,
    is_primary boolean DEFAULT false NOT NULL,
    maximum_number_of_members integer NOT NULL,
    minimum_number_of_members integer NOT NULL,
    organisation_id integer NOT NULL,
    audit_id integer,
    is_voided boolean DEFAULT false NOT NULL,
    version integer,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.group_role OWNER TO openchs;

--
-- Name: group_role_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.group_role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.group_role_id_seq OWNER TO openchs;

--
-- Name: group_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.group_role_id_seq OWNED BY public.group_role.id;


--
-- Name: group_subject; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.group_subject (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    group_subject_id integer NOT NULL,
    member_subject_id integer NOT NULL,
    group_role_id integer NOT NULL,
    membership_start_date timestamp with time zone,
    membership_end_date timestamp with time zone,
    organisation_id integer NOT NULL,
    audit_id integer,
    is_voided boolean DEFAULT false NOT NULL,
    version integer,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    member_subject_address_id bigint NOT NULL,
    group_subject_address_id bigint NOT NULL,
    group_subject_sync_concept_1_value text,
    group_subject_sync_concept_2_value text
);


ALTER TABLE public.group_subject OWNER TO openchs;

--
-- Name: group_subject_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.group_subject_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.group_subject_id_seq OWNER TO openchs;

--
-- Name: group_subject_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.group_subject_id_seq OWNED BY public.group_subject.id;


--
-- Name: groups; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.groups (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    version integer,
    organisation_id integer NOT NULL,
    audit_id integer,
    has_all_privileges boolean DEFAULT false NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.groups OWNER TO openchs;

--
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.groups_id_seq OWNER TO openchs;

--
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.groups_id_seq OWNED BY public.groups.id;


--
-- Name: identifier_assignment; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.identifier_assignment (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    identifier_source_id integer NOT NULL,
    identifier text NOT NULL,
    assignment_order integer NOT NULL,
    assigned_to_user_id integer NOT NULL,
    individual_id integer,
    program_enrolment_id integer,
    version integer NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    organisation_id integer DEFAULT 1 NOT NULL,
    audit_id integer NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.identifier_assignment OWNER TO openchs;

--
-- Name: identifier_assignment_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.identifier_assignment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.identifier_assignment_id_seq OWNER TO openchs;

--
-- Name: identifier_assignment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.identifier_assignment_id_seq OWNED BY public.identifier_assignment.id;


--
-- Name: identifier_source; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.identifier_source (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    type text NOT NULL,
    catchment_id integer,
    minimum_balance integer DEFAULT 20 NOT NULL,
    batch_generation_size integer DEFAULT 100 NOT NULL,
    options jsonb DEFAULT '{}'::jsonb NOT NULL,
    version integer NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    organisation_id integer DEFAULT 1 NOT NULL,
    audit_id integer NOT NULL,
    min_length integer DEFAULT 0 NOT NULL,
    max_length integer DEFAULT 0 NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.identifier_source OWNER TO openchs;

--
-- Name: identifier_source_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.identifier_source_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.identifier_source_id_seq OWNER TO openchs;

--
-- Name: identifier_source_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.identifier_source_id_seq OWNED BY public.identifier_source.id;


--
-- Name: identifier_user_assignment; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.identifier_user_assignment (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    identifier_source_id integer NOT NULL,
    assigned_to_user_id integer NOT NULL,
    identifier_start text NOT NULL,
    identifier_end text NOT NULL,
    last_assigned_identifier text,
    version integer NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    organisation_id integer DEFAULT 1 NOT NULL,
    audit_id integer NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.identifier_user_assignment OWNER TO openchs;

--
-- Name: identifier_user_assignment_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.identifier_user_assignment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.identifier_user_assignment_id_seq OWNER TO openchs;

--
-- Name: identifier_user_assignment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.identifier_user_assignment_id_seq OWNED BY public.identifier_user_assignment.id;


--
-- Name: index_metadata; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.index_metadata (
    id integer NOT NULL,
    table_metadata_id integer,
    column_id integer,
    name text
);


ALTER TABLE public.index_metadata OWNER TO openchs;

--
-- Name: index_metadata_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.index_metadata_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.index_metadata_id_seq OWNER TO openchs;

--
-- Name: index_metadata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.index_metadata_id_seq OWNED BY public.index_metadata.id;


--
-- Name: individual; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.individual (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    address_id bigint,
    observations jsonb,
    version integer NOT NULL,
    date_of_birth date,
    date_of_birth_verified boolean NOT NULL,
    gender_id bigint,
    registration_date date DEFAULT '2017-01-01'::date NOT NULL,
    organisation_id integer DEFAULT 1 NOT NULL,
    first_name character varying(256),
    last_name character varying(256),
    is_voided boolean DEFAULT false NOT NULL,
    audit_id integer,
    facility_id bigint,
    registration_location point,
    subject_type_id integer NOT NULL,
    legacy_id character varying,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    sync_concept_1_value text,
    sync_concept_2_value text,
    profile_picture text,
    middle_name character varying(255),
    manual_update_history text
);


ALTER TABLE public.individual OWNER TO openchs;

--
-- Name: individual_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.individual_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.individual_id_seq OWNER TO openchs;

--
-- Name: individual_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.individual_id_seq OWNED BY public.individual.id;


--
-- Name: program_enrolment; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.program_enrolment (
    id integer NOT NULL,
    program_id smallint NOT NULL,
    individual_id bigint NOT NULL,
    program_outcome_id smallint,
    observations jsonb,
    program_exit_observations jsonb,
    enrolment_date_time timestamp with time zone NOT NULL,
    program_exit_date_time timestamp with time zone,
    uuid character varying(255) NOT NULL,
    version integer NOT NULL,
    organisation_id integer DEFAULT 1 NOT NULL,
    audit_id integer,
    is_voided boolean DEFAULT false NOT NULL,
    enrolment_location point,
    exit_location point,
    legacy_id character varying,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    address_id bigint,
    sync_concept_1_value text,
    sync_concept_2_value text,
    manual_update_history text
);


ALTER TABLE public.program_enrolment OWNER TO openchs;

--
-- Name: individual_program_enrolment_search_view; Type: VIEW; Schema: public; Owner: openchs
--

CREATE VIEW public.individual_program_enrolment_search_view AS
 SELECT progralalise.individual_id,
    string_agg(progralalise.programname, ','::text) AS program_name
   FROM ( SELECT pe.individual_id,
            concat(op.name, ':', prog.colour) AS programname
           FROM ((public.program_enrolment pe
             JOIN public.program prog ON ((prog.id = pe.program_id)))
             JOIN public.operational_program op ON (((prog.id = op.program_id) AND (pe.organisation_id = op.organisation_id))))
          WHERE ((pe.program_exit_date_time IS NULL) AND (pe.is_voided = false))
          GROUP BY pe.individual_id, op.name, prog.colour) progralalise
  GROUP BY progralalise.individual_id;


ALTER TABLE public.individual_program_enrolment_search_view OWNER TO openchs;

--
-- Name: individual_relation; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.individual_relation (
    id smallint NOT NULL,
    uuid character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    organisation_id integer NOT NULL,
    version integer NOT NULL,
    audit_id integer,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.individual_relation OWNER TO openchs;

--
-- Name: individual_relation_gender_mapping; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.individual_relation_gender_mapping (
    id smallint NOT NULL,
    uuid character varying(255) NOT NULL,
    relation_id smallint NOT NULL,
    gender_id smallint NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    organisation_id integer NOT NULL,
    version integer NOT NULL,
    audit_id integer,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.individual_relation_gender_mapping OWNER TO openchs;

--
-- Name: individual_relation_gender_mapping_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.individual_relation_gender_mapping_id_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.individual_relation_gender_mapping_id_seq OWNER TO openchs;

--
-- Name: individual_relation_gender_mapping_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.individual_relation_gender_mapping_id_seq OWNED BY public.individual_relation_gender_mapping.id;


--
-- Name: individual_relation_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.individual_relation_id_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.individual_relation_id_seq OWNER TO openchs;

--
-- Name: individual_relation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.individual_relation_id_seq OWNED BY public.individual_relation.id;


--
-- Name: individual_relationship; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.individual_relationship (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    individual_a_id bigint NOT NULL,
    individual_b_id bigint NOT NULL,
    relationship_type_id smallint NOT NULL,
    enter_date_time timestamp with time zone,
    exit_date_time timestamp with time zone,
    exit_observations jsonb,
    is_voided boolean DEFAULT false NOT NULL,
    organisation_id integer NOT NULL,
    version integer NOT NULL,
    audit_id integer,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.individual_relationship OWNER TO openchs;

--
-- Name: individual_relationship_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.individual_relationship_id_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.individual_relationship_id_seq OWNER TO openchs;

--
-- Name: individual_relationship_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.individual_relationship_id_seq OWNED BY public.individual_relationship.id;


--
-- Name: individual_relationship_type; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.individual_relationship_type (
    id smallint NOT NULL,
    uuid character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    individual_a_is_to_b_relation_id smallint NOT NULL,
    individual_b_is_to_a_relation_id smallint NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    organisation_id integer NOT NULL,
    version integer NOT NULL,
    audit_id integer,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.individual_relationship_type OWNER TO openchs;

--
-- Name: individual_relationship_type_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.individual_relationship_type_id_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.individual_relationship_type_id_seq OWNER TO openchs;

--
-- Name: individual_relationship_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.individual_relationship_type_id_seq OWNED BY public.individual_relationship_type.id;


--
-- Name: individual_relative; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.individual_relative (
    id smallint NOT NULL,
    uuid character varying(255) NOT NULL,
    individual_id bigint NOT NULL,
    relative_individual_id bigint NOT NULL,
    relation_id smallint NOT NULL,
    enter_date_time timestamp with time zone,
    exit_date_time timestamp with time zone,
    is_voided boolean DEFAULT false NOT NULL,
    organisation_id integer NOT NULL,
    version integer NOT NULL,
    audit_id integer,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.individual_relative OWNER TO openchs;

--
-- Name: individual_relative_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.individual_relative_id_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.individual_relative_id_seq OWNER TO openchs;

--
-- Name: individual_relative_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.individual_relative_id_seq OWNED BY public.individual_relative.id;


--
-- Name: location_location_mapping; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.location_location_mapping (
    id integer NOT NULL,
    location_id bigint,
    parent_location_id bigint,
    version integer NOT NULL,
    audit_id bigint,
    uuid character varying(255) NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    organisation_id bigint,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.location_location_mapping OWNER TO openchs;

--
-- Name: location_location_mapping_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.location_location_mapping_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.location_location_mapping_id_seq OWNER TO openchs;

--
-- Name: location_location_mapping_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.location_location_mapping_id_seq OWNED BY public.location_location_mapping.id;


--
-- Name: manual_message; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.manual_message (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    organisation_id integer NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    message_template_id text NOT NULL,
    parameters text[],
    version integer NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    next_trigger_details json
);


ALTER TABLE public.manual_message OWNER TO openchs;

--
-- Name: manual_message_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.manual_message_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.manual_message_id_seq OWNER TO openchs;

--
-- Name: manual_message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.manual_message_id_seq OWNED BY public.manual_message.id;


--
-- Name: menu_item; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.menu_item (
    id integer NOT NULL,
    organisation_id integer NOT NULL,
    uuid character varying(255) DEFAULT public.uuid_generate_v4() NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    version integer NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    display_key character varying(255) NOT NULL,
    type character varying(100) NOT NULL,
    menu_group character varying(255) NOT NULL,
    icon character varying(255),
    link_function character varying(10000)
);


ALTER TABLE public.menu_item OWNER TO openchs;

--
-- Name: menu_item_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.menu_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menu_item_id_seq OWNER TO openchs;

--
-- Name: menu_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.menu_item_id_seq OWNED BY public.menu_item.id;


--
-- Name: message_receiver; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.message_receiver (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    receiver_type text NOT NULL,
    organisation_id integer NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    external_id text,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    version integer NOT NULL,
    receiver_id integer
);


ALTER TABLE public.message_receiver OWNER TO openchs;

--
-- Name: message_receiver_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.message_receiver_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.message_receiver_id_seq OWNER TO openchs;

--
-- Name: message_receiver_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.message_receiver_id_seq OWNED BY public.message_receiver.id;


--
-- Name: message_request_queue; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.message_request_queue (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    organisation_id integer NOT NULL,
    message_rule_id bigint,
    message_receiver_id bigint NOT NULL,
    scheduled_date_time timestamp(3) with time zone NOT NULL,
    delivered_date_time timestamp(3) with time zone,
    delivery_status text NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    version integer NOT NULL,
    entity_id integer,
    manual_message_id bigint
);


ALTER TABLE public.message_request_queue OWNER TO openchs;

--
-- Name: message_request_queue_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.message_request_queue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.message_request_queue_id_seq OWNER TO openchs;

--
-- Name: message_request_queue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.message_request_queue_id_seq OWNED BY public.message_request_queue.id;


--
-- Name: message_rule; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.message_rule (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    name text NOT NULL,
    message_rule text,
    schedule_rule text,
    organisation_id integer NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    entity_type text NOT NULL,
    message_template_id text NOT NULL,
    version integer NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    entity_type_id integer NOT NULL,
    receiver_type text DEFAULT 'Subject'::text NOT NULL
);


ALTER TABLE public.message_rule OWNER TO openchs;

--
-- Name: message_rule_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.message_rule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.message_rule_id_seq OWNER TO openchs;

--
-- Name: message_rule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.message_rule_id_seq OWNED BY public.message_rule.id;


--
-- Name: msg91_config; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.msg91_config (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    auth_key character varying(255) NOT NULL,
    otp_sms_template_id character varying(255) NOT NULL,
    otp_length smallint,
    organisation_id integer NOT NULL,
    audit_id integer,
    is_voided boolean DEFAULT false NOT NULL,
    version integer,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.msg91_config OWNER TO openchs;

--
-- Name: msg91_config_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.msg91_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.msg91_config_id_seq OWNER TO openchs;

--
-- Name: msg91_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.msg91_config_id_seq OWNED BY public.msg91_config.id;


--
-- Name: news; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.news (
    id integer NOT NULL,
    organisation_id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    title text NOT NULL,
    content text,
    contenthtml text,
    hero_image text,
    published_date timestamp with time zone,
    is_voided boolean DEFAULT false NOT NULL,
    audit_id bigint NOT NULL,
    version bigint DEFAULT 0 NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.news OWNER TO openchs;

--
-- Name: news_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.news_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.news_id_seq OWNER TO openchs;

--
-- Name: news_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.news_id_seq OWNED BY public.news.id;


--
-- Name: non_applicable_form_element; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.non_applicable_form_element (
    id integer NOT NULL,
    organisation_id bigint,
    form_element_id bigint,
    is_voided boolean DEFAULT false NOT NULL,
    version integer DEFAULT 0 NOT NULL,
    audit_id integer,
    uuid character varying(255) NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.non_applicable_form_element OWNER TO openchs;

--
-- Name: non_applicable_form_element_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.non_applicable_form_element_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.non_applicable_form_element_id_seq OWNER TO openchs;

--
-- Name: non_applicable_form_element_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.non_applicable_form_element_id_seq OWNED BY public.non_applicable_form_element.id;


--
-- Name: operational_encounter_type_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.operational_encounter_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.operational_encounter_type_id_seq OWNER TO openchs;

--
-- Name: operational_encounter_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.operational_encounter_type_id_seq OWNED BY public.operational_encounter_type.id;


--
-- Name: operational_program_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.operational_program_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.operational_program_id_seq OWNER TO openchs;

--
-- Name: operational_program_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.operational_program_id_seq OWNED BY public.operational_program.id;


--
-- Name: operational_subject_type; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.operational_subject_type (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    subject_type_id integer NOT NULL,
    organisation_id bigint NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    audit_id bigint NOT NULL,
    version integer DEFAULT 1,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.operational_subject_type OWNER TO openchs;

--
-- Name: operational_subject_type_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.operational_subject_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.operational_subject_type_id_seq OWNER TO openchs;

--
-- Name: operational_subject_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.operational_subject_type_id_seq OWNED BY public.operational_subject_type.id;


--
-- Name: org_ids; Type: VIEW; Schema: public; Owner: openchs
--

CREATE VIEW public.org_ids WITH (security_barrier='true') AS
 WITH RECURSIVE list_of_orgs(id, parent_organisation_id) AS (
         SELECT organisation.id,
            organisation.parent_organisation_id
           FROM public.organisation
          WHERE ((organisation.db_user)::text = CURRENT_USER)
        UNION ALL
         SELECT o.id,
            o.parent_organisation_id
           FROM public.organisation o,
            list_of_orgs log
          WHERE (o.id = log.parent_organisation_id)
        )
 SELECT list_of_orgs.id
   FROM list_of_orgs;


ALTER TABLE public.org_ids OWNER TO openchs;

--
-- Name: organisation_config; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.organisation_config (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    organisation_id bigint NOT NULL,
    settings jsonb,
    audit_id bigint,
    version integer DEFAULT 1,
    is_voided boolean DEFAULT false,
    worklist_updation_rule text,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    export_settings jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.organisation_config OWNER TO openchs;

--
-- Name: organisation_config_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.organisation_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.organisation_config_id_seq OWNER TO openchs;

--
-- Name: organisation_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.organisation_config_id_seq OWNED BY public.organisation_config.id;


--
-- Name: organisation_group; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.organisation_group (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    db_user character varying(255) NOT NULL,
    account_id integer NOT NULL,
    schema_name text,
    has_analytics_db boolean DEFAULT false NOT NULL
);


ALTER TABLE public.organisation_group OWNER TO openchs;

--
-- Name: organisation_group_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.organisation_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.organisation_group_id_seq OWNER TO openchs;

--
-- Name: organisation_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.organisation_group_id_seq OWNED BY public.organisation_group.id;


--
-- Name: organisation_group_organisation; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.organisation_group_organisation (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    organisation_group_id integer NOT NULL,
    organisation_id integer NOT NULL
);


ALTER TABLE public.organisation_group_organisation OWNER TO openchs;

--
-- Name: organisation_group_organisation_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.organisation_group_organisation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.organisation_group_organisation_id_seq OWNER TO openchs;

--
-- Name: organisation_group_organisation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.organisation_group_organisation_id_seq OWNED BY public.organisation_group_organisation.id;


--
-- Name: organisation_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.organisation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.organisation_id_seq OWNER TO openchs;

--
-- Name: organisation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.organisation_id_seq OWNED BY public.organisation.id;


--
-- Name: platform_translation; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.platform_translation (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    translation_json jsonb NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    platform character varying(255) NOT NULL,
    language character varying(255),
    version integer NOT NULL,
    audit_id integer NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.platform_translation OWNER TO openchs;

--
-- Name: platform_translation_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.platform_translation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.platform_translation_id_seq OWNER TO openchs;

--
-- Name: platform_translation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.platform_translation_id_seq OWNED BY public.platform_translation.id;


--
-- Name: privilege; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.privilege (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    entity_type character varying(255) NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    created_date_time timestamp with time zone,
    last_modified_date_time timestamp(3) with time zone
);


ALTER TABLE public.privilege OWNER TO openchs;

--
-- Name: privilege_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.privilege_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.privilege_id_seq OWNER TO openchs;

--
-- Name: privilege_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.privilege_id_seq OWNED BY public.privilege.id;


--
-- Name: program_encounter; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.program_encounter (
    id integer NOT NULL,
    observations jsonb NOT NULL,
    earliest_visit_date_time timestamp with time zone,
    encounter_date_time timestamp with time zone,
    program_enrolment_id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    version integer NOT NULL,
    encounter_type_id integer DEFAULT 1 NOT NULL,
    name character varying(255),
    max_visit_date_time timestamp with time zone,
    organisation_id integer DEFAULT 1 NOT NULL,
    cancel_date_time timestamp with time zone,
    cancel_observations jsonb,
    audit_id integer,
    is_voided boolean DEFAULT false NOT NULL,
    encounter_location point,
    cancel_location point,
    legacy_id character varying,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    address_id bigint,
    individual_id bigint NOT NULL,
    sync_concept_1_value text,
    sync_concept_2_value text,
    manual_update_history text,
    CONSTRAINT program_encounter_cannot_cancel_and_perform_check CHECK (((encounter_date_time IS NULL) OR (cancel_date_time IS NULL)))
);


ALTER TABLE public.program_encounter OWNER TO openchs;

--
-- Name: program_encounter_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.program_encounter_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.program_encounter_id_seq OWNER TO openchs;

--
-- Name: program_encounter_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.program_encounter_id_seq OWNED BY public.program_encounter.id;


--
-- Name: program_enrolment_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.program_enrolment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.program_enrolment_id_seq OWNER TO openchs;

--
-- Name: program_enrolment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.program_enrolment_id_seq OWNED BY public.program_enrolment.id;


--
-- Name: program_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.program_id_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.program_id_seq OWNER TO openchs;

--
-- Name: program_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.program_id_seq OWNED BY public.program.id;


--
-- Name: program_organisation_config; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.program_organisation_config (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    program_id bigint NOT NULL,
    organisation_id bigint NOT NULL,
    visit_schedule jsonb,
    version integer NOT NULL,
    audit_id integer,
    is_voided boolean DEFAULT false NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.program_organisation_config OWNER TO openchs;

--
-- Name: program_organisation_config_at_risk_concept; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.program_organisation_config_at_risk_concept (
    id integer NOT NULL,
    program_organisation_config_id integer NOT NULL,
    concept_id integer NOT NULL
);


ALTER TABLE public.program_organisation_config_at_risk_concept OWNER TO openchs;

--
-- Name: program_organisation_config_at_risk_concept_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.program_organisation_config_at_risk_concept_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.program_organisation_config_at_risk_concept_id_seq OWNER TO openchs;

--
-- Name: program_organisation_config_at_risk_concept_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.program_organisation_config_at_risk_concept_id_seq OWNED BY public.program_organisation_config_at_risk_concept.id;


--
-- Name: program_organisation_config_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.program_organisation_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.program_organisation_config_id_seq OWNER TO openchs;

--
-- Name: program_organisation_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.program_organisation_config_id_seq OWNED BY public.program_organisation_config.id;


--
-- Name: program_outcome; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.program_outcome (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    version integer NOT NULL,
    organisation_id integer DEFAULT 1 NOT NULL,
    audit_id integer,
    is_voided boolean DEFAULT false NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.program_outcome OWNER TO openchs;

--
-- Name: program_outcome_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.program_outcome_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.program_outcome_id_seq OWNER TO openchs;

--
-- Name: program_outcome_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.program_outcome_id_seq OWNED BY public.program_outcome.id;


--
-- Name: report_card; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.report_card (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    query text,
    description text,
    colour character varying(20),
    is_voided boolean DEFAULT false NOT NULL,
    version integer,
    organisation_id integer NOT NULL,
    audit_id integer,
    standard_report_card_type_id bigint,
    icon_file_s3_key text,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    CONSTRAINT report_card_optional_standard_report_card_type CHECK (((standard_report_card_type_id IS NOT NULL) OR (query IS NOT NULL)))
);


ALTER TABLE public.report_card OWNER TO openchs;

--
-- Name: report_card_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.report_card_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.report_card_id_seq OWNER TO openchs;

--
-- Name: report_card_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.report_card_id_seq OWNED BY public.report_card.id;


--
-- Name: reset_sync; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.reset_sync (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    user_id integer,
    subject_type_id integer,
    organisation_id integer NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    version integer NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.reset_sync OWNER TO openchs;

--
-- Name: reset_sync_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.reset_sync_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reset_sync_id_seq OWNER TO openchs;

--
-- Name: reset_sync_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.reset_sync_id_seq OWNED BY public.reset_sync.id;


--
-- Name: rule; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.rule (
    id smallint NOT NULL,
    uuid character varying(255) NOT NULL,
    version integer NOT NULL,
    audit_id integer NOT NULL,
    type character varying NOT NULL,
    rule_dependency_id integer,
    name character varying NOT NULL,
    fn_name character varying NOT NULL,
    data jsonb,
    organisation_id integer NOT NULL,
    execution_order double precision DEFAULT 10000.0 NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    entity jsonb NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.rule OWNER TO openchs;

--
-- Name: rule_dependency; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.rule_dependency (
    id smallint NOT NULL,
    uuid character varying(255) NOT NULL,
    version integer NOT NULL,
    audit_id integer NOT NULL,
    checksum character varying NOT NULL,
    code text NOT NULL,
    organisation_id integer NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.rule_dependency OWNER TO openchs;

--
-- Name: rule_dependency_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.rule_dependency_id_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rule_dependency_id_seq OWNER TO openchs;

--
-- Name: rule_dependency_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.rule_dependency_id_seq OWNED BY public.rule_dependency.id;


--
-- Name: rule_failure_log; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.rule_failure_log (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    form_id character varying(255) NOT NULL,
    rule_type character varying(255) NOT NULL,
    entity_type character varying(255) NOT NULL,
    entity_id character varying(255) NOT NULL,
    error_message character varying(255) NOT NULL,
    stacktrace text NOT NULL,
    source character varying(255) NOT NULL,
    audit_id integer,
    is_voided boolean DEFAULT false NOT NULL,
    version integer NOT NULL,
    organisation_id bigint NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.rule_failure_log OWNER TO openchs;

--
-- Name: rule_failure_log_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.rule_failure_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rule_failure_log_id_seq OWNER TO openchs;

--
-- Name: rule_failure_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.rule_failure_log_id_seq OWNED BY public.rule_failure_log.id;


--
-- Name: rule_failure_telemetry; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.rule_failure_telemetry (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    user_id integer NOT NULL,
    organisation_id bigint NOT NULL,
    version integer DEFAULT 1,
    rule_uuid character varying(255) NOT NULL,
    individual_uuid character varying(255) NOT NULL,
    error_message text NOT NULL,
    stacktrace text NOT NULL,
    error_date_time timestamp with time zone,
    close_date_time timestamp with time zone,
    is_closed boolean DEFAULT false NOT NULL,
    audit_id bigint,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.rule_failure_telemetry OWNER TO openchs;

--
-- Name: rule_failure_telemetry_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.rule_failure_telemetry_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rule_failure_telemetry_id_seq OWNER TO openchs;

--
-- Name: rule_failure_telemetry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.rule_failure_telemetry_id_seq OWNED BY public.rule_failure_telemetry.id;


--
-- Name: rule_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.rule_id_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rule_id_seq OWNER TO openchs;

--
-- Name: rule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.rule_id_seq OWNED BY public.rule.id;


--
-- Name: schema_version; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.schema_version (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.schema_version OWNER TO openchs;

--
-- Name: standard_report_card_type; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.standard_report_card_type (
    id integer NOT NULL,
    uuid text NOT NULL,
    name text NOT NULL,
    description text,
    is_voided boolean DEFAULT false NOT NULL,
    created_date_time timestamp with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.standard_report_card_type OWNER TO openchs;

--
-- Name: standard_report_card_type_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.standard_report_card_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.standard_report_card_type_id_seq OWNER TO openchs;

--
-- Name: standard_report_card_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.standard_report_card_type_id_seq OWNED BY public.standard_report_card_type.id;


--
-- Name: subject_migration; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.subject_migration (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    individual_id integer NOT NULL,
    old_address_level_id integer,
    new_address_level_id integer,
    organisation_id integer NOT NULL,
    audit_id integer NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    version integer NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    old_sync_concept_1_value text,
    new_sync_concept_1_value text,
    old_sync_concept_2_value text,
    new_sync_concept_2_value text,
    subject_type_id integer NOT NULL,
    manual_update_history text
);


ALTER TABLE public.subject_migration OWNER TO openchs;

--
-- Name: subject_migration_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.subject_migration_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.subject_migration_id_seq OWNER TO openchs;

--
-- Name: subject_migration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.subject_migration_id_seq OWNED BY public.subject_migration.id;


--
-- Name: subject_program_eligibility; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.subject_program_eligibility (
    id integer NOT NULL,
    organisation_id integer NOT NULL,
    uuid character varying(255) DEFAULT public.uuid_generate_v4() NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    version integer NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    subject_id bigint NOT NULL,
    program_id integer NOT NULL,
    is_eligible boolean NOT NULL,
    check_date timestamp with time zone NOT NULL,
    observations jsonb
);


ALTER TABLE public.subject_program_eligibility OWNER TO openchs;

--
-- Name: subject_program_eligibility_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.subject_program_eligibility_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.subject_program_eligibility_id_seq OWNER TO openchs;

--
-- Name: subject_program_eligibility_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.subject_program_eligibility_id_seq OWNED BY public.subject_program_eligibility.id;


--
-- Name: subject_type; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.subject_type (
    id integer NOT NULL,
    uuid character varying(255),
    name character varying(255) NOT NULL,
    organisation_id bigint NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    audit_id bigint NOT NULL,
    version integer DEFAULT 1,
    is_group boolean DEFAULT false NOT NULL,
    is_household boolean DEFAULT false NOT NULL,
    active boolean DEFAULT true NOT NULL,
    type character varying(255),
    subject_summary_rule text,
    allow_empty_location boolean DEFAULT false NOT NULL,
    unique_name boolean DEFAULT false NOT NULL,
    valid_first_name_regex text,
    valid_first_name_description_key text,
    valid_last_name_regex text,
    valid_last_name_description_key text,
    icon_file_s3_key text,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    directly_assignable boolean DEFAULT false,
    should_sync_by_location boolean DEFAULT true,
    sync_registration_concept_1 character varying(255),
    sync_registration_concept_2 character varying(255),
    sync_registration_concept_1_usable boolean,
    sync_registration_concept_2_usable boolean,
    name_help_text text,
    allow_profile_picture boolean DEFAULT false NOT NULL,
    valid_middle_name_regex text,
    valid_middle_name_description_key text,
    allow_middle_name boolean DEFAULT false,
    program_eligibility_check_rule text,
    program_eligibility_check_declarative_rule text
);


ALTER TABLE public.subject_type OWNER TO openchs;

--
-- Name: subject_type_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.subject_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.subject_type_id_seq OWNER TO openchs;

--
-- Name: subject_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.subject_type_id_seq OWNED BY public.subject_type.id;


--
-- Name: sync_telemetry; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.sync_telemetry (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    user_id integer NOT NULL,
    organisation_id bigint NOT NULL,
    version integer DEFAULT 1,
    sync_status character varying(255) NOT NULL,
    sync_start_time timestamp with time zone NOT NULL,
    sync_end_time timestamp with time zone,
    entity_status jsonb,
    device_name character varying(255),
    android_version character varying(255),
    app_version character varying(255),
    device_info jsonb,
    sync_source text
);


ALTER TABLE public.sync_telemetry OWNER TO openchs;

--
-- Name: sync_telemetry_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.sync_telemetry_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sync_telemetry_id_seq OWNER TO openchs;

--
-- Name: sync_telemetry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.sync_telemetry_id_seq OWNED BY public.sync_telemetry.id;


--
-- Name: table_metadata; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.table_metadata (
    id integer NOT NULL,
    name text,
    type text,
    schema_name text,
    subject_type_uuid character varying(255),
    program_uuid character varying(255),
    encounter_type_uuid character varying(255),
    form_uuid character varying(255)
);


ALTER TABLE public.table_metadata OWNER TO openchs;

--
-- Name: table_metadata_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.table_metadata_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.table_metadata_id_seq OWNER TO openchs;

--
-- Name: table_metadata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.table_metadata_id_seq OWNED BY public.table_metadata.id;


--
-- Name: task; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.task (
    id integer NOT NULL,
    organisation_id integer NOT NULL,
    uuid character varying(255) DEFAULT public.uuid_generate_v4() NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    version integer NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    legacy_id character varying,
    name text NOT NULL,
    task_status_id integer NOT NULL,
    scheduled_on timestamp without time zone NOT NULL,
    completed_on timestamp without time zone,
    assigned_user_id integer,
    metadata jsonb NOT NULL,
    subject_id bigint,
    observations jsonb NOT NULL,
    task_type_id integer,
    manual_update_history text
);


ALTER TABLE public.task OWNER TO openchs;

--
-- Name: task_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.task_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.task_id_seq OWNER TO openchs;

--
-- Name: task_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.task_id_seq OWNED BY public.task.id;


--
-- Name: task_status; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.task_status (
    id integer NOT NULL,
    organisation_id integer NOT NULL,
    uuid character varying(255) DEFAULT public.uuid_generate_v4() NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    version integer NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    name text NOT NULL,
    task_type_id integer NOT NULL,
    is_terminal boolean NOT NULL
);


ALTER TABLE public.task_status OWNER TO openchs;

--
-- Name: task_status_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.task_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.task_status_id_seq OWNER TO openchs;

--
-- Name: task_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.task_status_id_seq OWNED BY public.task_status.id;


--
-- Name: task_type; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.task_type (
    id integer NOT NULL,
    organisation_id integer NOT NULL,
    uuid character varying(255) DEFAULT public.uuid_generate_v4() NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    version integer NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    metadata_search_fields text[]
);


ALTER TABLE public.task_type OWNER TO openchs;

--
-- Name: task_type_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.task_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.task_type_id_seq OWNER TO openchs;

--
-- Name: task_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.task_type_id_seq OWNED BY public.task_type.id;


--
-- Name: task_unassignment; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.task_unassignment (
    id integer NOT NULL,
    organisation_id integer NOT NULL,
    uuid character varying(255) DEFAULT public.uuid_generate_v4() NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    version integer NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    task_id bigint NOT NULL,
    unassigned_user_id integer NOT NULL
);


ALTER TABLE public.task_unassignment OWNER TO openchs;

--
-- Name: task_unassignment_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.task_unassignment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.task_unassignment_id_seq OWNER TO openchs;

--
-- Name: task_unassignment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.task_unassignment_id_seq OWNED BY public.task_unassignment.id;


--
-- Name: title_lineage_locations_view; Type: VIEW; Schema: public; Owner: openchs
--

CREATE VIEW public.title_lineage_locations_view AS
 SELECT title_lineage_locations_function.lowestpoint_id,
    title_lineage_locations_function.title_lineage
   FROM public.title_lineage_locations_function(NULL::bigint) title_lineage_locations_function(lowestpoint_id, title_lineage);


ALTER TABLE public.title_lineage_locations_view OWNER TO openchs;

--
-- Name: translation; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.translation (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    organisation_id bigint NOT NULL,
    audit_id bigint NOT NULL,
    version integer DEFAULT 1,
    translation_json jsonb NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    language character varying(255),
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.translation OWNER TO openchs;

--
-- Name: translation_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.translation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.translation_id_seq OWNER TO openchs;

--
-- Name: translation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.translation_id_seq OWNED BY public.translation.id;


--
-- Name: user_group; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.user_group (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    version integer,
    organisation_id integer NOT NULL,
    audit_id integer,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL,
    manual_update_history text
);


ALTER TABLE public.user_group OWNER TO openchs;

--
-- Name: user_group_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.user_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_group_id_seq OWNER TO openchs;

--
-- Name: user_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.user_group_id_seq OWNED BY public.user_group.id;


--
-- Name: user_subject_assignment; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.user_subject_assignment (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    user_id integer NOT NULL,
    subject_id integer NOT NULL,
    organisation_id integer NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    version integer NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.user_subject_assignment OWNER TO openchs;

--
-- Name: user_subject_assignment_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.user_subject_assignment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_subject_assignment_id_seq OWNER TO openchs;

--
-- Name: user_subject_assignment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.user_subject_assignment_id_seq OWNED BY public.user_subject_assignment.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.users (
    id integer NOT NULL,
    uuid character varying(255) NOT NULL,
    username character varying(255) NOT NULL,
    organisation_id integer,
    created_by_id bigint DEFAULT 1 NOT NULL,
    last_modified_by_id bigint DEFAULT 1 NOT NULL,
    created_date_time timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_modified_date_time timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    is_voided boolean DEFAULT false NOT NULL,
    catchment_id integer,
    is_org_admin boolean DEFAULT false NOT NULL,
    operating_individual_scope character varying(255) NOT NULL,
    settings jsonb,
    email character varying(320),
    phone_number character varying(32),
    disabled_in_cognito boolean DEFAULT false,
    name character varying(255),
    sync_settings jsonb DEFAULT '{}'::jsonb,
    CONSTRAINT users_check CHECK ((((operating_individual_scope)::text <> 'ByCatchment'::text) OR (catchment_id IS NOT NULL)))
);


ALTER TABLE public.users OWNER TO openchs;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO openchs;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: video; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.video (
    id integer NOT NULL,
    version integer DEFAULT 1,
    audit_id bigint NOT NULL,
    uuid character varying(255),
    organisation_id bigint NOT NULL,
    title character varying(255) NOT NULL,
    file_path character varying(255) NOT NULL,
    description character varying(255),
    duration integer,
    is_voided boolean DEFAULT false NOT NULL,
    created_by_id bigint NOT NULL,
    last_modified_by_id bigint NOT NULL,
    created_date_time timestamp(3) with time zone NOT NULL,
    last_modified_date_time timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.video OWNER TO openchs;

--
-- Name: video_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.video_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.video_id_seq OWNER TO openchs;

--
-- Name: video_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.video_id_seq OWNED BY public.video.id;


--
-- Name: video_telemetric; Type: TABLE; Schema: public; Owner: openchs
--

CREATE TABLE public.video_telemetric (
    id integer NOT NULL,
    uuid character varying(255),
    video_start_time double precision NOT NULL,
    video_end_time double precision NOT NULL,
    player_open_time timestamp with time zone NOT NULL,
    player_close_time timestamp with time zone NOT NULL,
    video_id integer NOT NULL,
    user_id integer NOT NULL,
    created_datetime timestamp with time zone NOT NULL,
    organisation_id integer NOT NULL,
    is_voided boolean DEFAULT false NOT NULL
);


ALTER TABLE public.video_telemetric OWNER TO openchs;

--
-- Name: video_telemetric_id_seq; Type: SEQUENCE; Schema: public; Owner: openchs
--

CREATE SEQUENCE public.video_telemetric_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.video_telemetric_id_seq OWNER TO openchs;

--
-- Name: video_telemetric_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: openchs
--

ALTER SEQUENCE public.video_telemetric_id_seq OWNED BY public.video_telemetric.id;


--
-- Name: virtual_catchment_address_mapping_table; Type: VIEW; Schema: public; Owner: openchs
--

CREATE VIEW public.virtual_catchment_address_mapping_table AS
 SELECT virtual_catchment_address_mapping_table_function.id,
    virtual_catchment_address_mapping_table_function.catchment_id,
    virtual_catchment_address_mapping_table_function.addresslevel_id,
    virtual_catchment_address_mapping_table_function.type_id
   FROM public.virtual_catchment_address_mapping_table_function() virtual_catchment_address_mapping_table_function(id, catchment_id, addresslevel_id, type_id);


ALTER TABLE public.virtual_catchment_address_mapping_table OWNER TO openchs;

--
-- Name: account id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.account ALTER COLUMN id SET DEFAULT nextval('public.account_id_seq'::regclass);


--
-- Name: account_admin id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.account_admin ALTER COLUMN id SET DEFAULT nextval('public.account_admin_id_seq'::regclass);


--
-- Name: address_level id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.address_level ALTER COLUMN id SET DEFAULT nextval('public.address_level_id_seq'::regclass);


--
-- Name: address_level_type id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.address_level_type ALTER COLUMN id SET DEFAULT nextval('public.address_level_type_id_seq'::regclass);


--
-- Name: answer_concept_migration id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.answer_concept_migration ALTER COLUMN id SET DEFAULT nextval('public.answer_concept_migration_id_seq'::regclass);


--
-- Name: approval_status id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.approval_status ALTER COLUMN id SET DEFAULT nextval('public.approval_status_id_seq'::regclass);


--
-- Name: audit id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.audit ALTER COLUMN id SET DEFAULT nextval('public.audit_id_seq'::regclass);


--
-- Name: catchment id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.catchment ALTER COLUMN id SET DEFAULT nextval('public.catchment_id_seq'::regclass);


--
-- Name: catchment_address_mapping id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.catchment_address_mapping ALTER COLUMN id SET DEFAULT nextval('public.catchment_address_mapping_id_seq'::regclass);


--
-- Name: checklist id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.checklist ALTER COLUMN id SET DEFAULT nextval('public.checklist_id_seq'::regclass);


--
-- Name: checklist_detail id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.checklist_detail ALTER COLUMN id SET DEFAULT nextval('public.checklist_detail_id_seq'::regclass);


--
-- Name: checklist_item id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.checklist_item ALTER COLUMN id SET DEFAULT nextval('public.checklist_item_id_seq'::regclass);


--
-- Name: checklist_item_detail id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.checklist_item_detail ALTER COLUMN id SET DEFAULT nextval('public.checklist_item_detail_id_seq'::regclass);


--
-- Name: column_metadata id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.column_metadata ALTER COLUMN id SET DEFAULT nextval('public.column_metadata_id_seq'::regclass);


--
-- Name: comment id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.comment ALTER COLUMN id SET DEFAULT nextval('public.comment_id_seq'::regclass);


--
-- Name: comment_thread id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.comment_thread ALTER COLUMN id SET DEFAULT nextval('public.comment_thread_id_seq'::regclass);


--
-- Name: concept id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.concept ALTER COLUMN id SET DEFAULT nextval('public.concept_id_seq'::regclass);


--
-- Name: concept_answer id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.concept_answer ALTER COLUMN id SET DEFAULT nextval('public.concept_answer_id_seq'::regclass);


--
-- Name: custom_query id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.custom_query ALTER COLUMN id SET DEFAULT nextval('public.custom_query_id_seq'::regclass);


--
-- Name: dashboard id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard ALTER COLUMN id SET DEFAULT nextval('public.dashboard_id_seq'::regclass);


--
-- Name: dashboard_card_mapping id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard_card_mapping ALTER COLUMN id SET DEFAULT nextval('public.dashboard_card_mapping_id_seq'::regclass);


--
-- Name: dashboard_filter id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard_filter ALTER COLUMN id SET DEFAULT nextval('public.dashboard_filter_id_seq'::regclass);


--
-- Name: dashboard_section id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard_section ALTER COLUMN id SET DEFAULT nextval('public.dashboard_section_id_seq'::regclass);


--
-- Name: dashboard_section_card_mapping id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard_section_card_mapping ALTER COLUMN id SET DEFAULT nextval('public.dashboard_section_card_mapping_id_seq'::regclass);


--
-- Name: decision_concept id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.decision_concept ALTER COLUMN id SET DEFAULT nextval('public.decision_concept_id_seq'::regclass);


--
-- Name: deps_saved_ddl deps_id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.deps_saved_ddl ALTER COLUMN deps_id SET DEFAULT nextval('public.deps_saved_ddl_deps_id_seq'::regclass);


--
-- Name: documentation id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.documentation ALTER COLUMN id SET DEFAULT nextval('public.documentation_id_seq'::regclass);


--
-- Name: documentation_item id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.documentation_item ALTER COLUMN id SET DEFAULT nextval('public.documentation_item_id_seq'::regclass);


--
-- Name: encounter id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.encounter ALTER COLUMN id SET DEFAULT nextval('public.encounter_id_seq'::regclass);


--
-- Name: encounter_type id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.encounter_type ALTER COLUMN id SET DEFAULT nextval('public.encounter_type_id_seq'::regclass);


--
-- Name: entity_approval_status id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.entity_approval_status ALTER COLUMN id SET DEFAULT nextval('public.entity_approval_status_id_seq'::regclass);


--
-- Name: entity_sync_status id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.entity_sync_status ALTER COLUMN id SET DEFAULT nextval('public.entity_sync_status_id_seq'::regclass);


--
-- Name: export_job_parameters id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.export_job_parameters ALTER COLUMN id SET DEFAULT nextval('public.export_job_parameters_id_seq'::regclass);


--
-- Name: external_system_config id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.external_system_config ALTER COLUMN id SET DEFAULT nextval('public.external_system_config_id_seq'::regclass);


--
-- Name: facility id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.facility ALTER COLUMN id SET DEFAULT nextval('public.facility_id_seq'::regclass);


--
-- Name: form id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form ALTER COLUMN id SET DEFAULT nextval('public.form_id_seq'::regclass);


--
-- Name: form_element id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form_element ALTER COLUMN id SET DEFAULT nextval('public.form_element_id_seq'::regclass);


--
-- Name: form_element_group id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form_element_group ALTER COLUMN id SET DEFAULT nextval('public.form_element_group_id_seq'::regclass);


--
-- Name: form_mapping id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form_mapping ALTER COLUMN id SET DEFAULT nextval('public.form_mapping_id_seq'::regclass);


--
-- Name: gender id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.gender ALTER COLUMN id SET DEFAULT nextval('public.gender_id_seq'::regclass);


--
-- Name: group_dashboard id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_dashboard ALTER COLUMN id SET DEFAULT nextval('public.group_dashboard_id_seq'::regclass);


--
-- Name: group_privilege id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_privilege ALTER COLUMN id SET DEFAULT nextval('public.group_privilege_id_seq'::regclass);


--
-- Name: group_role id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_role ALTER COLUMN id SET DEFAULT nextval('public.group_role_id_seq'::regclass);


--
-- Name: group_subject id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_subject ALTER COLUMN id SET DEFAULT nextval('public.group_subject_id_seq'::regclass);


--
-- Name: groups id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.groups ALTER COLUMN id SET DEFAULT nextval('public.groups_id_seq'::regclass);


--
-- Name: identifier_assignment id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.identifier_assignment ALTER COLUMN id SET DEFAULT nextval('public.identifier_assignment_id_seq'::regclass);


--
-- Name: identifier_source id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.identifier_source ALTER COLUMN id SET DEFAULT nextval('public.identifier_source_id_seq'::regclass);


--
-- Name: identifier_user_assignment id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.identifier_user_assignment ALTER COLUMN id SET DEFAULT nextval('public.identifier_user_assignment_id_seq'::regclass);


--
-- Name: index_metadata id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.index_metadata ALTER COLUMN id SET DEFAULT nextval('public.index_metadata_id_seq'::regclass);


--
-- Name: individual id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual ALTER COLUMN id SET DEFAULT nextval('public.individual_id_seq'::regclass);


--
-- Name: individual_relation id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual_relation ALTER COLUMN id SET DEFAULT nextval('public.individual_relation_id_seq'::regclass);


--
-- Name: individual_relation_gender_mapping id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual_relation_gender_mapping ALTER COLUMN id SET DEFAULT nextval('public.individual_relation_gender_mapping_id_seq'::regclass);


--
-- Name: individual_relationship id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual_relationship ALTER COLUMN id SET DEFAULT nextval('public.individual_relationship_id_seq'::regclass);


--
-- Name: individual_relationship_type id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual_relationship_type ALTER COLUMN id SET DEFAULT nextval('public.individual_relationship_type_id_seq'::regclass);


--
-- Name: individual_relative id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual_relative ALTER COLUMN id SET DEFAULT nextval('public.individual_relative_id_seq'::regclass);


--
-- Name: location_location_mapping id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.location_location_mapping ALTER COLUMN id SET DEFAULT nextval('public.location_location_mapping_id_seq'::regclass);


--
-- Name: manual_message id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.manual_message ALTER COLUMN id SET DEFAULT nextval('public.manual_message_id_seq'::regclass);


--
-- Name: menu_item id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.menu_item ALTER COLUMN id SET DEFAULT nextval('public.menu_item_id_seq'::regclass);


--
-- Name: message_receiver id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.message_receiver ALTER COLUMN id SET DEFAULT nextval('public.message_receiver_id_seq'::regclass);


--
-- Name: message_request_queue id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.message_request_queue ALTER COLUMN id SET DEFAULT nextval('public.message_request_queue_id_seq'::regclass);


--
-- Name: message_rule id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.message_rule ALTER COLUMN id SET DEFAULT nextval('public.message_rule_id_seq'::regclass);


--
-- Name: msg91_config id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.msg91_config ALTER COLUMN id SET DEFAULT nextval('public.msg91_config_id_seq'::regclass);


--
-- Name: news id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.news ALTER COLUMN id SET DEFAULT nextval('public.news_id_seq'::regclass);


--
-- Name: non_applicable_form_element id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.non_applicable_form_element ALTER COLUMN id SET DEFAULT nextval('public.non_applicable_form_element_id_seq'::regclass);


--
-- Name: operational_encounter_type id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.operational_encounter_type ALTER COLUMN id SET DEFAULT nextval('public.operational_encounter_type_id_seq'::regclass);


--
-- Name: operational_program id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.operational_program ALTER COLUMN id SET DEFAULT nextval('public.operational_program_id_seq'::regclass);


--
-- Name: operational_subject_type id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.operational_subject_type ALTER COLUMN id SET DEFAULT nextval('public.operational_subject_type_id_seq'::regclass);


--
-- Name: organisation id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.organisation ALTER COLUMN id SET DEFAULT nextval('public.organisation_id_seq'::regclass);


--
-- Name: organisation_config id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.organisation_config ALTER COLUMN id SET DEFAULT nextval('public.organisation_config_id_seq'::regclass);


--
-- Name: organisation_group id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.organisation_group ALTER COLUMN id SET DEFAULT nextval('public.organisation_group_id_seq'::regclass);


--
-- Name: organisation_group_organisation id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.organisation_group_organisation ALTER COLUMN id SET DEFAULT nextval('public.organisation_group_organisation_id_seq'::regclass);


--
-- Name: platform_translation id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.platform_translation ALTER COLUMN id SET DEFAULT nextval('public.platform_translation_id_seq'::regclass);


--
-- Name: privilege id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.privilege ALTER COLUMN id SET DEFAULT nextval('public.privilege_id_seq'::regclass);


--
-- Name: program id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program ALTER COLUMN id SET DEFAULT nextval('public.program_id_seq'::regclass);


--
-- Name: program_encounter id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_encounter ALTER COLUMN id SET DEFAULT nextval('public.program_encounter_id_seq'::regclass);


--
-- Name: program_enrolment id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_enrolment ALTER COLUMN id SET DEFAULT nextval('public.program_enrolment_id_seq'::regclass);


--
-- Name: program_organisation_config id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_organisation_config ALTER COLUMN id SET DEFAULT nextval('public.program_organisation_config_id_seq'::regclass);


--
-- Name: program_organisation_config_at_risk_concept id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_organisation_config_at_risk_concept ALTER COLUMN id SET DEFAULT nextval('public.program_organisation_config_at_risk_concept_id_seq'::regclass);


--
-- Name: program_outcome id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_outcome ALTER COLUMN id SET DEFAULT nextval('public.program_outcome_id_seq'::regclass);


--
-- Name: report_card id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.report_card ALTER COLUMN id SET DEFAULT nextval('public.report_card_id_seq'::regclass);


--
-- Name: reset_sync id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.reset_sync ALTER COLUMN id SET DEFAULT nextval('public.reset_sync_id_seq'::regclass);


--
-- Name: rule id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.rule ALTER COLUMN id SET DEFAULT nextval('public.rule_id_seq'::regclass);


--
-- Name: rule_dependency id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.rule_dependency ALTER COLUMN id SET DEFAULT nextval('public.rule_dependency_id_seq'::regclass);


--
-- Name: rule_failure_log id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.rule_failure_log ALTER COLUMN id SET DEFAULT nextval('public.rule_failure_log_id_seq'::regclass);


--
-- Name: rule_failure_telemetry id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.rule_failure_telemetry ALTER COLUMN id SET DEFAULT nextval('public.rule_failure_telemetry_id_seq'::regclass);


--
-- Name: standard_report_card_type id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.standard_report_card_type ALTER COLUMN id SET DEFAULT nextval('public.standard_report_card_type_id_seq'::regclass);


--
-- Name: subject_migration id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.subject_migration ALTER COLUMN id SET DEFAULT nextval('public.subject_migration_id_seq'::regclass);


--
-- Name: subject_program_eligibility id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.subject_program_eligibility ALTER COLUMN id SET DEFAULT nextval('public.subject_program_eligibility_id_seq'::regclass);


--
-- Name: subject_type id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.subject_type ALTER COLUMN id SET DEFAULT nextval('public.subject_type_id_seq'::regclass);


--
-- Name: sync_telemetry id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.sync_telemetry ALTER COLUMN id SET DEFAULT nextval('public.sync_telemetry_id_seq'::regclass);


--
-- Name: table_metadata id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.table_metadata ALTER COLUMN id SET DEFAULT nextval('public.table_metadata_id_seq'::regclass);


--
-- Name: task id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task ALTER COLUMN id SET DEFAULT nextval('public.task_id_seq'::regclass);


--
-- Name: task_status id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task_status ALTER COLUMN id SET DEFAULT nextval('public.task_status_id_seq'::regclass);


--
-- Name: task_type id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task_type ALTER COLUMN id SET DEFAULT nextval('public.task_type_id_seq'::regclass);


--
-- Name: task_unassignment id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task_unassignment ALTER COLUMN id SET DEFAULT nextval('public.task_unassignment_id_seq'::regclass);


--
-- Name: translation id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.translation ALTER COLUMN id SET DEFAULT nextval('public.translation_id_seq'::regclass);


--
-- Name: user_group id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.user_group ALTER COLUMN id SET DEFAULT nextval('public.user_group_id_seq'::regclass);


--
-- Name: user_subject_assignment id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.user_subject_assignment ALTER COLUMN id SET DEFAULT nextval('public.user_subject_assignment_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: video id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.video ALTER COLUMN id SET DEFAULT nextval('public.video_id_seq'::regclass);


--
-- Name: video_telemetric id; Type: DEFAULT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.video_telemetric ALTER COLUMN id SET DEFAULT nextval('public.video_telemetric_id_seq'::regclass);


--
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.account (id, name) FROM stdin;
1	default
\.


--
-- Data for Name: account_admin; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.account_admin (id, name, account_id, admin_id) FROM stdin;
1	Samanvay	1	1
\.


--
-- Data for Name: address_level; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.address_level (id, title, uuid, version, organisation_id, audit_id, is_voided, type_id, lineage, parent_id, gps_coordinates, location_properties, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, legacy_id) FROM stdin;
1	KARNATAKA	db9c9afc-9180-490c-bc52-7f8ea8ab19ce	0	2	96	f	1	1	\N	\N	\N	2	2	2023-06-19 03:13:16.242+00	2023-06-19 03:13:16.247+00	\N
2	BENGALURU RURAL	fe9c71da-0251-4f0b-b16e-4d9a81e6d41b	0	2	97	f	2	1.2	1	\N	\N	2	2	2023-06-19 03:13:40.834+00	2023-06-19 03:13:40.849+00	\N
3	HOSAKOTE	7b7a587c-f9e3-4f09-b885-675e8e6bdc6a	0	2	99	f	3	1.2.3	2	\N	\N	2	2	2023-06-19 03:14:05.707+00	2023-06-19 03:14:05.718+00	\N
4	ANUPAHALLI	7807c442-6b21-4bc2-b464-a6c0a6000db1	0	2	101	f	4	1.2.3.4	3	\N	\N	2	2	2023-06-19 03:14:24.871+00	2023-06-19 03:14:24.88+00	\N
5	NANDAGUDI	35a58d91-0075-4e6a-b9b4-9b83e7c4105d	0	2	103	f	4	1.2.3.5	3	\N	\N	2	2	2023-06-19 03:16:04.764+00	2023-06-19 03:16:04.775+00	\N
\.


--
-- Data for Name: address_level_type; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.address_level_type (id, uuid, name, is_voided, organisation_id, version, audit_id, level, parent_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
1	cccf9d5f-7e36-4bd3-94ac-31f389998cce	State	f	2	0	92	1	\N	2	2	2023-06-19 03:11:37.31+00	2023-06-19 03:11:37.31+00
2	0a35783c-6e42-4575-a76d-3ba479cad112	District	f	2	0	93	2	1	2	2	2023-06-19 03:11:51.095+00	2023-06-19 03:11:51.095+00
3	5a1b65a8-936b-4b1c-8287-4889ad2c8605	Sub District	f	2	0	94	3	2	2	2	2023-06-19 03:12:08.12+00	2023-06-19 03:12:08.12+00
4	01dab440-583d-44af-8e26-a6616dcf6801	City/Village	f	2	0	95	4	3	2	2	2023-06-19 03:12:20.411+00	2023-06-19 03:12:20.411+00
\.


--
-- Data for Name: answer_concept_migration; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.answer_concept_migration (id, uuid, concept_id, old_answer_concept_name, new_answer_concept_name, organisation_id, is_voided, version, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: approval_status; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.approval_status (id, uuid, status, is_voided, created_date_time, last_modified_date_time) FROM stdin;
1	e7e3cdc6-510c-43e3-81d7-85450ce66ba0	Pending	f	2023-06-19 03:05:14.431978+00	2023-06-19 03:05:14.938+00
2	db5ce7a3-0b21-4f5b-807c-814dd96ebc1d	Approved	f	2023-06-19 03:05:14.431978+00	2023-06-19 03:05:14.939+00
3	2c2cdf95-ed0d-4328-9431-14d65a6e82e6	Rejected	f	2023-06-19 03:05:14.431978+00	2023-06-19 03:05:14.94+00
\.


--
-- Data for Name: audit; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.audit (id, uuid, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
1	483be0b2-b6ba-40e0-8bf7-91cb33c6e284	1	1	2023-06-19 03:05:09.745433+00	2023-06-19 03:05:09.745+00
2	7038d549-4a3b-4600-b856-f6f3d123fbd8	1	1	2023-06-19 03:05:09.745433+00	2023-06-19 03:05:09.745+00
3	09e1b06f-26be-4f7a-8121-5dba3a11b684	1	1	2023-06-19 03:05:09.745433+00	2023-06-19 03:05:09.745+00
4	d56700ea-fac8-4255-8403-7f8f3b755335	1	1	2023-06-19 03:05:09.745433+00	2023-06-19 03:05:09.745+00
5	fd630fa3-7122-40b5-9a4c-12bfe7a314e0	1	1	2023-06-19 03:05:09.745433+00	2023-06-19 03:05:09.745+00
6	f6532996-a377-48f4-aafc-2e044ad9b1e2	1	1	2023-06-19 03:05:09.745433+00	2023-06-19 03:05:09.745+00
7	e033664f-458c-4698-8090-152ee7fb4cd7	1	1	2023-06-19 03:05:09.745433+00	2023-06-19 03:05:09.745+00
8	ad7d1d14-54fd-45a2-86b7-ea329b744484	1	1	2023-06-19 03:05:09.745433+00	2023-06-19 03:05:09.745+00
9	840de9fb-e565-4d7d-b751-90335ba20490	1	1	2023-06-19 03:05:09.745433+00	2023-06-19 03:05:09.745+00
10	188ad77e-fe46-4328-b0e2-98f3a05c554c	1	1	2023-06-19 03:05:09.745433+00	2023-06-19 03:05:09.745+00
11	5fed2907-df3a-4867-aef5-c87f4c78a31a	1	1	2023-06-19 03:05:09.745433+00	2023-06-19 03:05:09.745+00
12	ade34813-dbfb-44a9-bed0-534cecbaccf2	1	1	2023-06-19 03:05:10.017667+00	2023-06-19 03:05:10.018+00
13	7a12cef2-febd-44e4-91f9-c6b8945d5962	1	1	2023-06-19 03:05:10.017667+00	2023-06-19 03:05:10.018+00
14	0fdf6781-698a-4b7a-bcc9-f622e078c41d	1	1	2023-06-19 03:05:10.017667+00	2023-06-19 03:05:10.018+00
15	30ce916b-557d-4cd4-a3fd-b3154a8b594c	1	1	2023-06-19 03:05:10.017667+00	2023-06-19 03:05:10.018+00
16	f8b7576e-01bc-46d2-a01e-40b260e8e8ed	1	1	2023-06-19 03:05:10.017667+00	2023-06-19 03:05:10.018+00
17	89619c86-e603-4856-af49-bd6b2658f176	1	1	2023-06-19 03:05:10.017667+00	2023-06-19 03:05:10.018+00
18	9c303777-2e18-4d54-9ae1-53cab97893e7	1	1	2023-06-19 03:05:10.017667+00	2023-06-19 03:05:10.018+00
19	1b0789e2-b017-4cfb-817a-9e0cddd2509e	1	1	2023-06-19 03:05:10.017667+00	2023-06-19 03:05:10.018+00
20	b7c4a7f6-0b40-4bdc-a489-7d0b9c82d6e3	1	1	2023-06-19 03:05:10.017667+00	2023-06-19 03:05:10.018+00
21	6b5114c9-2d57-47b6-ad3e-1846c264c229	1	1	2023-06-19 03:05:10.017667+00	2023-06-19 03:05:10.018+00
22	7d1d6931-7af9-4e10-9ece-dd1e44bb4574	1	1	2023-06-19 03:05:10.017667+00	2023-06-19 03:05:10.018+00
23	aae67acd-c1e1-494b-b286-e87e544a3cb4	1	1	2023-06-19 03:05:10.017667+00	2023-06-19 03:05:10.018+00
24	c4ab0751-5b59-4dda-bc9a-4c2088c34f10	1	1	2023-06-19 03:05:10.0642+00	2023-06-19 03:05:10.064+00
25	50357d3f-674b-40e3-82e3-dbea0100924b	1	1	2023-06-19 03:05:10.0642+00	2023-06-19 03:05:10.064+00
26	48053ccf-d22a-4e52-b38d-9ba00ea17ab5	1	1	2023-06-19 03:05:10.0642+00	2023-06-19 03:05:10.064+00
27	bcd2273e-09a5-484d-a5ed-be425a86944f	1	1	2023-06-19 03:05:10.0642+00	2023-06-19 03:05:10.064+00
28	4be076f9-f99a-4d19-b806-17e1da29280a	1	1	2023-06-19 03:05:10.0642+00	2023-06-19 03:05:10.064+00
29	dd5c3255-e0c1-48dd-9815-bee3ec9c03d0	1	1	2023-06-19 03:05:10.0642+00	2023-06-19 03:05:10.064+00
30	830585a0-de1c-41f7-94c8-f003926f5bf9	1	1	2023-06-19 03:05:10.0642+00	2023-06-19 03:05:10.064+00
31	d98c51be-b928-431b-acc5-b35dc47a3bee	1	1	2023-06-19 03:05:10.0642+00	2023-06-19 03:05:10.064+00
32	e2ca259e-2993-4cef-8f37-9b26ddf39962	1	1	2023-06-19 03:05:10.0642+00	2023-06-19 03:05:10.064+00
33	ac12b0f4-4b07-4fcc-95d0-b32430bab2a1	1	1	2023-06-19 03:05:10.0642+00	2023-06-19 03:05:10.064+00
34	d3fb028a-e9c3-450b-965e-4309bd86f414	1	1	2023-06-19 03:05:10.0642+00	2023-06-19 03:05:10.064+00
35	b47f4b3d-5571-4bcf-8942-cb67a61f7735	1	1	2023-06-19 03:05:10.0642+00	2023-06-19 03:05:10.064+00
36	f76141b5-6bb7-4892-bf69-11c6b4dfedc1	1	1	2023-06-19 03:05:10.0642+00	2023-06-19 03:05:10.064+00
37	93b29ce9-cfa6-4882-8a82-c34779525aa9	1	1	2023-06-19 03:05:10.0642+00	2023-06-19 03:05:10.064+00
38	916b476d-c09c-4628-8673-cfe4db6785c5	1	1	2023-06-19 03:05:10.0642+00	2023-06-19 03:05:10.064+00
39	d7b67bd6-0ec3-4f1e-9112-d5b957cabde6	1	1	2023-06-19 03:05:10.0642+00	2023-06-19 03:05:10.064+00
40	b90ee1ce-b5bb-4b0a-b6cc-76384971acfb	1	1	2023-06-19 03:05:10.0642+00	2023-06-19 03:05:10.064+00
41	0bdcb7d3-cc2b-4a2c-8726-c7080587cf7f	1	1	2023-06-19 03:05:10.0642+00	2023-06-19 03:05:10.064+00
42	083b3393-9f46-4ab1-b544-456d3db602ed	1	1	2023-06-19 03:05:10.0642+00	2023-06-19 03:05:10.064+00
43	6dc70f3d-51b4-4dee-a2d5-6a7a52beff16	1	1	2023-06-19 03:05:10.0642+00	2023-06-19 03:05:10.064+00
44	8103bdf8-b22a-4f4b-b226-52436c205bed	1	1	2023-06-19 03:05:10.0642+00	2023-06-19 03:05:10.064+00
45	5564fbbb-ccca-4ebe-bb15-909c9ebd19f1	1	1	2023-06-19 03:05:10.0642+00	2023-06-19 03:05:10.064+00
46	7e876220-20b4-4c17-87b7-0e235926f7a6	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
47	91fd32f2-0261-46a1-92e4-4c201247c9a3	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
48	eeb49484-a07d-49f7-bb4b-932b713fbc66	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
49	5a77c22b-a24f-456e-84a3-9bd12e104f73	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
50	334ea293-fd10-4dab-92f3-04ce153e27aa	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
51	0ab14ce3-cbdb-4cb7-8601-353bebe408c9	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
52	4809d13f-4ab1-49d7-aa57-ee71a821bc3f	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
53	a081882c-6775-4caa-98cd-9720a0d11dfc	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
54	4474c0f3-9d35-4622-a65a-5688f633a274	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
55	82691c26-c042-48d4-972b-664bcb348fc4	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
56	0d0b0e92-79d4-49c1-b33b-cf0508ea550c	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
57	8c382726-92be-4e3e-8b6e-2b032c5cd6a8	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
58	f6e6f570-aaaf-4069-a14d-e2649e9710d7	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
59	2eb6adbc-5a55-46f8-925e-f3061fd16e29	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
60	7c97fe3b-c2e8-437d-a43b-1e6d4357a8d1	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
61	1896f28c-cace-4034-bf29-c0ab42a4c41e	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
62	f2916111-b753-4004-85d5-a63856ce4462	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
63	ec90bb6f-2ccb-4e4c-be01-ae95cc441b98	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
64	ac49854a-776d-4311-9b13-c536b97e0c48	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
65	90de5a8a-cbbc-4bab-8019-edf3f1d02317	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
66	0dff0a2b-ac07-4c31-8338-c32af05b31fc	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
67	db89d727-3c3e-45fc-a18d-a58c3098d5ca	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
68	50a3aa9e-04be-465f-be7b-22e0ab8e500e	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
69	29b20f70-6b3e-481e-96cf-c4fe0e2d46c1	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
70	1d9c019a-9350-44f9-9ef9-a699f0d94a13	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
71	1db2a945-0692-481e-a68c-aaf7cc246d64	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
72	d84d15c2-3d09-416e-8c26-9709ce3c90da	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
73	99ad5750-bdf8-40e6-964c-01cf806707b7	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
74	89d85d58-de14-4249-b9bb-61d4abb94b77	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
75	2a6a496c-6063-4383-8857-0c10a831d85c	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
76	3731d4b6-80f4-410b-baf7-2c0fcc38fe1f	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
77	765bc1ed-441a-414d-b62a-672103b35c95	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
78	8458bbe3-aa87-4c7c-b5e2-a139e01bd88f	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
79	1724ff11-95c5-42c2-b697-f40f1105d696	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
80	28edbf6e-98eb-4218-8950-01d97be476da	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
81	ace301c1-2815-42c1-943e-c7b44f64b376	1	1	2023-06-19 03:05:10.110224+00	2023-06-19 03:05:10.11+00
82	\N	1	1	2023-06-19 03:05:11.539094+00	2023-06-19 03:05:11.539+00
83	\N	1	1	2023-06-19 03:05:13.596173+00	2023-06-19 03:05:13.596+00
84	\N	1	1	2023-06-19 03:05:13.596173+00	2023-06-19 03:05:13.596+00
86	5d7507e2-4d6b-41af-b71a-3787b46984c9	1	1	2023-06-19 03:09:02.455+00	2023-06-19 03:09:02.455+00
87	3fd58241-1426-4d43-9e55-545b5c8c3ba0	1	1	2023-06-19 03:09:02.478+00	2023-06-19 03:09:02.478+00
88	54f7f84b-08a2-4081-b560-c35353809db9	1	1	2023-06-19 03:09:02.482+00	2023-06-19 03:09:02.482+00
89	3e89e3be-336d-4c9f-85a5-d4d114088788	1	1	2023-06-19 03:09:02.501+00	2023-06-19 03:09:02.501+00
136	4a1e3766-4e35-4060-ae4a-41c743eefacc	2	2	2023-06-19 03:30:37.776+00	2023-06-19 03:30:37.776+00
137	68d37247-8502-40d9-9920-aac697eee087	2	2	2023-06-19 03:30:37.784+00	2023-06-19 03:30:37.784+00
85	\N	1	1	2023-06-19 03:08:07.073472+00	2023-06-19 03:08:07.073+00
138	afc3ab7c-cf51-48ac-8ae9-f861e1421b6d	2	2	2023-06-19 03:30:37.805+00	2023-06-19 03:30:37.805+00
91	7834fb38-d872-4c44-9e1c-ab24635599d3	1	1	2023-06-19 03:10:53.16+00	2023-06-19 03:10:53.16+00
92	7ea7d4d6-d3c3-4ab7-8a93-9921e953a0b4	2	2	2023-06-19 03:11:37.31+00	2023-06-19 03:11:37.31+00
93	27dd6219-cd8d-4781-8d93-0d8049a38682	2	2	2023-06-19 03:11:51.095+00	2023-06-19 03:11:51.095+00
94	09ad5abf-f325-4284-809d-d14bd46e890b	2	2	2023-06-19 03:12:08.12+00	2023-06-19 03:12:08.12+00
95	eecb5349-5af1-41f3-a237-08024a562438	2	2	2023-06-19 03:12:20.411+00	2023-06-19 03:12:20.411+00
96	ab90a738-6184-48a9-9668-343a69a94fff	2	2	2023-06-19 03:13:16.242+00	2023-06-19 03:13:16.247+00
98	0fcaa7cf-0b51-4e43-bed6-752b61e23355	2	2	2023-06-19 03:13:40.843+00	2023-06-19 03:13:40.843+00
97	29e51920-6cfd-4bb3-98c7-5e3a13afe93b	2	2	2023-06-19 03:13:40.834+00	2023-06-19 03:13:40.849+00
100	1b4f409a-b650-4c49-a032-773b7d661230	2	2	2023-06-19 03:14:05.712+00	2023-06-19 03:14:05.712+00
99	34b019b3-f5db-44d7-8f0c-790e1b8d4000	2	2	2023-06-19 03:14:05.707+00	2023-06-19 03:14:05.718+00
102	e379dfdc-3a80-4fb8-9c64-b9b5335e7093	2	2	2023-06-19 03:14:24.875+00	2023-06-19 03:14:24.875+00
101	21084ac4-2230-4d24-b009-5cec19813842	2	2	2023-06-19 03:14:24.871+00	2023-06-19 03:14:24.88+00
104	4612abf7-5a0f-40ad-a6a6-9d29ea85a9d4	2	2	2023-06-19 03:16:04.769+00	2023-06-19 03:16:04.769+00
103	02d10796-1811-43b2-acec-9aeb1dcb1b7e	2	2	2023-06-19 03:16:04.764+00	2023-06-19 03:16:04.775+00
105	1dd4b7e5-1b48-4903-a60a-8e4fb06c2bc1	2	2	2023-06-19 03:17:32.449+00	2023-06-19 03:17:32.449+00
106	c05fe9c7-f3ad-42be-a9c1-5ff93bbafb66	2	2	2023-06-19 03:19:01.162+00	2023-06-19 03:19:01.162+00
107	3d698292-fef3-42eb-b632-f30295f81846	2	2	2023-06-19 03:19:28.127+00	2023-06-19 03:19:28.127+00
108	b813fb04-e703-49c1-851f-458e27178153	2	2	2023-06-19 03:20:33.937+00	2023-06-19 03:20:33.937+00
109	5d8950c8-0df9-43b7-83db-03a952f6d93a	2	2	2023-06-19 03:20:33.959+00	2023-06-19 03:20:33.959+00
111	b82074f7-a15d-419e-afd6-53d016948309	2	2	2023-06-19 03:20:34.052+00	2023-06-19 03:20:34.052+00
90	20da9ad3-24a5-4b78-a8fb-da287fed817b	1	2	2023-06-19 03:09:02.523+00	2023-06-19 03:20:34.062+00
112	5f643a03-09d2-4d13-ab45-ae9a19e1128b	2	2	2023-06-19 03:21:29.076+00	2023-06-19 03:21:29.076+00
113	c984b6ea-b054-4062-8839-ce0e2e4ff9f6	2	2	2023-06-19 03:21:45.701+00	2023-06-19 03:21:45.701+00
114	976769d5-ac16-44ae-9d11-32d4996573b1	2	2	2023-06-19 03:22:08.916+00	2023-06-19 03:22:08.916+00
115	3d8c1a23-ffa0-428d-8c51-d9d0af226f2b	2	2	2023-06-19 03:22:28.047+00	2023-06-19 03:22:28.047+00
116	1ec93de4-579c-4b0d-b3a0-75ee9b641a71	2	2	2023-06-19 03:22:47.431+00	2023-06-19 03:22:47.431+00
117	aef86496-c226-43be-aac9-a3f94bcde817	2	2	2023-06-19 03:23:13.564+00	2023-06-19 03:23:13.564+00
118	84a5365d-521a-4852-943f-6ed20a7a7035	2	2	2023-06-19 03:24:07.852+00	2023-06-19 03:24:07.852+00
119	74215a7d-d7d5-4c89-a275-4d08484f5d3a	2	2	2023-06-19 03:24:52.426+00	2023-06-19 03:24:52.426+00
120	fcdaf299-6396-46b7-a172-91afba948a12	2	2	2023-06-19 03:26:49.519+00	2023-06-19 03:26:49.519+00
121	90f2c903-ffea-42a3-ae07-b70fd658c5a1	2	2	2023-06-19 03:28:19.673+00	2023-06-19 03:28:19.673+00
122	5f79668b-7894-4d24-8b11-2a125caeb88a	2	2	2023-06-19 03:29:03.869+00	2023-06-19 03:29:03.869+00
123	be1655f3-5b8c-4b86-a112-f9bba6ddc884	2	2	2023-06-19 03:29:03.886+00	2023-06-19 03:29:03.886+00
125	02bd8804-a34c-43cb-8cc5-ec8e37c5577c	2	2	2023-06-19 03:29:03.919+00	2023-06-19 03:29:03.919+00
126	ae14437d-0d09-4212-b9fa-f67ac9bfab58	2	2	2023-06-19 03:29:03.924+00	2023-06-19 03:29:03.924+00
127	85f5ea0d-dc49-4b4e-bc56-fbaaba911f8e	2	2	2023-06-19 03:29:03.945+00	2023-06-19 03:29:03.945+00
128	3c151051-9017-429f-aee5-d9954bd9bb37	2	2	2023-06-19 03:30:11.248+00	2023-06-19 03:30:11.248+00
129	c9213d8a-5799-424e-acb6-3386433f8524	2	2	2023-06-19 03:30:11.277+00	2023-06-19 03:30:11.277+00
130	58b4b187-8886-400f-9f8b-6c02e462b39c	2	2	2023-06-19 03:30:11.286+00	2023-06-19 03:30:11.286+00
131	6bcc4d3c-b2f0-49a6-8d11-dd106f897814	2	2	2023-06-19 03:30:11.291+00	2023-06-19 03:30:11.291+00
132	dcd65bcf-8f4a-40fa-8998-c9f9c5b0efe3	2	2	2023-06-19 03:30:11.298+00	2023-06-19 03:30:11.298+00
124	3de47649-895a-49e5-accb-19c040f99490	2	2	2023-06-19 03:29:03.895+00	2023-06-19 03:30:11.304+00
133	ddfb8ef7-ff5b-46b7-8626-03946624fba1	2	2	2023-06-19 03:30:37.743+00	2023-06-19 03:30:37.743+00
134	c12598bf-2d88-4296-bfa9-b7421bdab371	2	2	2023-06-19 03:30:37.748+00	2023-06-19 03:30:37.748+00
139	5b951a59-f199-47d0-8a92-f40a77fdcdc2	2	2	2023-06-19 03:31:30.683+00	2023-06-19 03:31:30.683+00
140	d085a930-7fcd-4189-8334-38279f834671	2	2	2023-06-19 03:31:30.697+00	2023-06-19 03:31:30.697+00
135	3aed8fd6-2312-49b5-a1e7-8d72c143017e	2	2	2023-06-19 03:30:37.754+00	2023-06-19 03:31:30.703+00
141	fe92e4c7-a7c3-424e-ba71-f4d4ff0ff879	1	1	2023-06-19 03:36:37.51+00	2023-06-19 03:36:37.51+00
142	3fd3f1ff-2ed9-40f5-bf99-efc9c9d5fd4e	1	1	2023-06-19 03:39:02.879+00	2023-06-19 03:39:02.879+00
147	c0d024d4-494e-424d-a95e-61bb7099c8ee	2	2	2023-06-19 04:20:31.915+00	2023-06-19 04:20:31.915+00
148	2602e270-3d2a-4928-ad40-3d13cdb0a620	2	2	2023-06-19 04:20:31.993+00	2023-06-19 04:20:43.661+00
152	533b20fe-ae6e-421f-b980-864a3b83bfab	2	2	2023-06-19 04:20:32.055+00	2023-06-19 04:20:43.672+00
149	cb571ddc-a6ba-48a2-8964-9332f1dcdc4c	2	2	2023-06-19 04:20:32.006+00	2023-06-19 04:20:59.573+00
150	e3522645-1db7-4b59-9794-d5a3db17d241	2	2	2023-06-19 04:20:32.015+00	2023-06-19 04:20:59.586+00
151	fa57d51b-24ee-4c5f-81ff-7cf06b2daa0e	2	2	2023-06-19 04:20:32.023+00	2023-06-19 04:20:59.587+00
110	037952d1-750a-4964-83f9-ec9fa6f83763	2	2	2023-06-19 03:20:33.99+00	2023-06-19 04:20:59.572+00
\.


--
-- Data for Name: batch_job_execution; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.batch_job_execution (job_execution_id, version, job_instance_id, create_time, start_time, end_time, status, exit_code, exit_message, last_updated, job_configuration_location) FROM stdin;
\.


--
-- Data for Name: batch_job_execution_context; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.batch_job_execution_context (job_execution_id, short_context, serialized_context) FROM stdin;
\.


--
-- Data for Name: batch_job_execution_params; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.batch_job_execution_params (job_execution_id, type_cd, key_name, string_val, date_val, long_val, double_val, identifying) FROM stdin;
\.


--
-- Data for Name: batch_job_instance; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.batch_job_instance (job_instance_id, version, job_name, job_key) FROM stdin;
\.


--
-- Data for Name: batch_step_execution; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.batch_step_execution (step_execution_id, version, step_name, job_execution_id, start_time, end_time, status, commit_count, read_count, filter_count, write_count, read_skip_count, write_skip_count, process_skip_count, rollback_count, exit_code, exit_message, last_updated) FROM stdin;
\.


--
-- Data for Name: batch_step_execution_context; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.batch_step_execution_context (step_execution_id, short_context, serialized_context) FROM stdin;
\.


--
-- Data for Name: catchment; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.catchment (id, name, uuid, version, organisation_id, type, audit_id, is_voided, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
1	Anupahalli SC1	268de78e-b3a4-48f8-843b-8b5530fe0183	0	2	Villages	106	f	2	2	2023-06-19 03:19:01.162+00	2023-06-19 03:19:01.162+00
2	Nandagudi SC1	747e8d49-351a-434c-a347-55ddb0db4e92	0	2	Villages	107	f	2	2	2023-06-19 03:19:28.127+00	2023-06-19 03:19:28.127+00
\.


--
-- Data for Name: catchment_address_mapping; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.catchment_address_mapping (id, catchment_id, addresslevel_id) FROM stdin;
1	1	4
2	2	5
\.


--
-- Data for Name: checklist; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.checklist (id, program_enrolment_id, uuid, version, base_date, organisation_id, audit_id, is_voided, checklist_detail_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, manual_update_history) FROM stdin;
\.


--
-- Data for Name: checklist_detail; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.checklist_detail (id, uuid, version, audit_id, name, is_voided, organisation_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: checklist_item; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.checklist_item (id, completion_date, checklist_id, uuid, version, organisation_id, audit_id, is_voided, observations, checklist_item_detail_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, manual_update_history) FROM stdin;
\.


--
-- Data for Name: checklist_item_detail; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.checklist_item_detail (id, uuid, version, audit_id, form_id, concept_id, checklist_detail_id, status, is_voided, organisation_id, dependent_on, schedule_on_expiry_of_dependency, min_days_from_start_date, min_days_from_dependent, expires_after, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: column_metadata; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.column_metadata (id, table_id, name, type, concept_id, concept_type, concept_uuid, schema_name, parent_concept_uuid) FROM stdin;
\.


--
-- Data for Name: comment; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.comment (id, organisation_id, uuid, text, subject_id, is_voided, audit_id, version, comment_thread_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: comment_thread; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.comment_thread (id, organisation_id, uuid, status, open_date_time, resolved_date_time, is_voided, audit_id, version, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: concept; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.concept (id, data_type, high_absolute, high_normal, low_absolute, low_normal, name, uuid, version, unit, organisation_id, is_voided, audit_id, key_values, active, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
4	Coded	\N	\N	\N	\N	Gender	483be0b2-b6ba-40e0-8bf7-91cb33c6e284	1	\N	1	f	1	\N	t	1	1	2023-06-19 03:05:09.745+00	2023-06-19 03:05:09.745+00
1	NA	\N	\N	\N	\N	Male	7038d549-4a3b-4600-b856-f6f3d123fbd8	1	\N	1	f	2	\N	t	1	1	2023-06-19 03:05:09.745+00	2023-06-19 03:05:09.745+00
2	NA	\N	\N	\N	\N	Female	09e1b06f-26be-4f7a-8121-5dba3a11b684	1	\N	1	f	3	\N	t	1	1	2023-06-19 03:05:09.745+00	2023-06-19 03:05:09.745+00
3	NA	\N	\N	\N	\N	Other Gender	d56700ea-fac8-4255-8403-7f8f3b755335	1	\N	1	f	4	\N	t	1	1	2023-06-19 03:05:09.745+00	2023-06-19 03:05:09.745+00
5	Text	\N	\N	\N	\N	Patient Identifier	ffd35c7d-7414-4f0f-8fdd-7de5e48770da	0	\N	2	f	112	[]	t	2	2	2023-06-19 03:21:29.076+00	2023-06-19 03:21:29.076+00
6	Text	\N	\N	\N	\N	Bahmni_UUID	150edb74-1972-45ad-b222-37a69bc4c34e	0	\N	2	f	113	[]	t	2	2	2023-06-19 03:21:45.701+00	2023-06-19 03:21:45.701+00
7	Numeric	\N	\N	\N	\N	RCH ID	18298f4d-79ec-44b0-8f8b-1f1c5505effc	0	\N	2	f	114	[]	t	2	2	2023-06-19 03:22:08.916+00	2023-06-19 03:22:08.916+00
8	Numeric	\N	\N	\N	\N	Nikshay ID	50ee923b-d2d5-42ec-874d-e3ccd9dd4895	0	\N	2	f	115	[]	t	2	2	2023-06-19 03:22:28.047+00	2023-06-19 03:22:28.047+00
9	Text	\N	\N	\N	\N	Father/Mother's Name	9092d96c-ed9e-416b-9a50-606f003a6b38	0	\N	2	f	116	[]	t	2	2	2023-06-19 03:22:47.431+00	2023-06-19 03:22:47.431+00
10	PhoneNumber	\N	\N	\N	\N	Phone Number	799681f1-9733-4d6d-8c3b-072afa186572	0	\N	2	f	117	[{"key": "verifyPhoneNumber", "value": false}]	t	2	2	2023-06-19 03:23:13.564+00	2023-06-19 03:23:13.564+00
11	Numeric	99	18	\N	12	Respiratory rate	345de932-4d7d-4468-9f3d-a21171d3c8f9	0	\N	2	f	118	[]	t	2	2	2023-06-19 03:24:07.852+00	2023-06-19 03:24:07.852+00
12	Numeric	150	90	\N	60	Diastolic blood pressure	38bbf12b-0360-4558-8dfa-0bac59e3b326	0	mmHg	2	f	119	[]	t	2	2	2023-06-19 03:24:52.426+00	2023-06-19 03:24:52.426+00
13	Numeric	250	140	\N	100	Systolic blood pressure	443c02ad-751c-4c9a-887d-824d4cd30a77	0	mmHg	2	f	120	[]	t	2	2	2023-06-19 03:26:49.519+00	2023-06-19 03:26:49.519+00
14	Numeric	140	\N	40	\N	Temperature	8fe5dca9-711a-44d3-b7d9-3b4e6340f2d7	0	\N	2	f	121	[]	t	2	2	2023-06-19 03:28:19.673+00	2023-06-19 03:28:19.673+00
\.


--
-- Data for Name: concept_answer; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.concept_answer (id, concept_id, answer_concept_id, uuid, version, answer_order, organisation_id, abnormal, is_voided, uniq, audit_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
1	4	1	fd630fa3-7122-40b5-9a4c-12bfe7a314e0	1	1	1	f	f	f	5	1	1	2023-06-19 03:05:09.745+00	2023-06-19 03:05:09.745+00
2	4	2	f6532996-a377-48f4-aafc-2e044ad9b1e2	1	1	1	f	f	f	6	1	1	2023-06-19 03:05:09.745+00	2023-06-19 03:05:09.745+00
3	4	3	e033664f-458c-4698-8090-152ee7fb4cd7	1	1	1	f	f	f	7	1	1	2023-06-19 03:05:09.745+00	2023-06-19 03:05:09.745+00
\.


--
-- Data for Name: custom_query; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.custom_query (id, uuid, name, query, organisation_id, is_voided, version, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: dashboard; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.dashboard (id, uuid, name, description, is_voided, version, organisation_id, audit_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: dashboard_card_mapping; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.dashboard_card_mapping (id, uuid, dashboard_id, card_id, display_order, is_voided, version, organisation_id, audit_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: dashboard_filter; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.dashboard_filter (id, dashboard_id, filter_config, uuid, organisation_id, is_voided, version, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, name) FROM stdin;
\.


--
-- Data for Name: dashboard_section; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.dashboard_section (id, uuid, name, description, dashboard_id, view_type, display_order, is_voided, version, organisation_id, audit_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: dashboard_section_card_mapping; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.dashboard_section_card_mapping (id, uuid, dashboard_section_id, card_id, display_order, is_voided, version, organisation_id, audit_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: decision_concept; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.decision_concept (id, concept_id, form_id) FROM stdin;
\.


--
-- Data for Name: deps_saved_ddl; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.deps_saved_ddl (deps_id, deps_view_schema, deps_view_name, deps_ddl_to_run) FROM stdin;
\.


--
-- Data for Name: documentation; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.documentation (id, uuid, name, organisation_id, is_voided, version, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, parent_id) FROM stdin;
\.


--
-- Data for Name: documentation_item; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.documentation_item (id, uuid, documentation_id, language, content, contenthtml, organisation_id, is_voided, version, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: encounter; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.encounter (id, observations, encounter_date_time, encounter_type_id, individual_id, uuid, version, organisation_id, is_voided, audit_id, encounter_location, earliest_visit_date_time, max_visit_date_time, cancel_date_time, cancel_observations, cancel_location, name, legacy_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, address_id, sync_concept_1_value, sync_concept_2_value, manual_update_history) FROM stdin;
\.


--
-- Data for Name: encounter_type; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.encounter_type (id, name, concept_id, uuid, version, organisation_id, audit_id, is_voided, encounter_eligibility_check_rule, active, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, encounter_eligibility_check_declarative_rule, is_immutable) FROM stdin;
1	Vitals	\N	f824226a-eefc-4b0c-b9fe-9cb074c908e4	0	2	122	f		t	2	2	2023-06-19 03:29:03.869+00	2023-06-19 03:29:03.869+00	\N	f
2	Bahmni Patient Registration	\N	cec9d389-6c6f-460b-827c-72576d1c9e9d	0	2	133	f		t	2	2	2023-06-19 03:30:37.743+00	2023-06-19 03:30:37.743+00	\N	f
\.


--
-- Data for Name: entity_approval_status; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.entity_approval_status (id, uuid, entity_id, entity_type, approval_status_id, approval_status_comment, organisation_id, auto_approved, audit_id, version, is_voided, status_date_time, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, entity_type_uuid, address_id, individual_id, sync_concept_1_value, sync_concept_2_value) FROM stdin;
\.


--
-- Data for Name: entity_sync_status; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.entity_sync_status (id, db_user, table_metadata_id, last_sync_time, sync_status, schema_name) FROM stdin;
\.


--
-- Data for Name: export_job_parameters; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.export_job_parameters (id, uuid, user_id, report_format, timezone, organisation_id, is_voided, version, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: external_system_config; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.external_system_config (id, organisation_id, uuid, is_voided, version, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, system_name, config) FROM stdin;
\.


--
-- Data for Name: facility; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.facility (id, uuid, name, address_id, is_voided, organisation_id, version, audit_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: form; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.form (id, name, form_type, uuid, version, organisation_id, audit_id, is_voided, decision_rule, validation_rule, visit_schedule_rule, checklists_rule, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, validation_declarative_rule, decision_declarative_rule, visit_schedule_declarative_rule, task_schedule_declarative_rule, task_schedule_rule) FROM stdin;
3	Vitals Encounter Cancellation	IndividualEncounterCancellation	1a81bedf-902a-480d-b8ef-cc379d2da8dd	0	2	126	f	\N	\N	\N	\N	2	2	2023-06-19 03:29:03.924+00	2023-06-19 03:29:03.924+00	\N	\N	\N	\N	\N
2	Vitals Encounter	Encounter	61f36d5c-ebca-4a0f-bf9d-ca37750f7d35	0	2	124	f					2	2	2023-06-19 03:29:03.895+00	2023-06-19 03:30:11.304+00	\N	\N	\N	\N	\N
5	Bahmni Patient Registration Encounter Cancellation	IndividualEncounterCancellation	9b262744-3ba0-4ad8-a04a-47aab9a0e840	0	2	137	f	\N	\N	\N	\N	2	2	2023-06-19 03:30:37.784+00	2023-06-19 03:30:37.784+00	\N	\N	\N	\N	\N
4	Bahmni Patient Registration Encounter	Encounter	738e7338-11ff-4e41-897b-db9c1e27e75e	0	2	135	f					2	2	2023-06-19 03:30:37.754+00	2023-06-19 03:31:30.703+00	\N	\N	\N	\N	\N
1	Patient Registration	IndividualProfile	af29950e-93c6-4ffc-88c4-46d08dc0498f	0	2	110	f					2	2	2023-06-19 03:20:33.99+00	2023-06-19 04:20:59.572+00	\N	\N	\N	\N	\N
\.


--
-- Data for Name: form_element; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.form_element (id, name, display_order, is_mandatory, key_values, concept_id, form_element_group_id, uuid, version, organisation_id, type, valid_format_regex, valid_format_description_key, audit_id, is_voided, rule, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, declarative_rule, group_id, documentation_id) FROM stdin;
1	Temperature	1	f	[]	14	1	fb5ab0cb-3360-40b2-9974-e9f2829791c5	0	2	SingleSelect	\N	\N	129	f	\N	2	2	2023-06-19 03:30:11.277+00	2023-06-19 03:30:11.277+00	\N	\N	\N
2	Respiratory rate	2	f	[]	11	1	4fa008b5-b4b7-48de-a458-122a33e7197b	0	2	SingleSelect	\N	\N	130	f	\N	2	2	2023-06-19 03:30:11.286+00	2023-06-19 03:30:11.286+00	\N	\N	\N
3	Diastolic blood pressure	3	f	[]	12	1	31ee8409-20e4-4b64-8bb6-9157f4c3c7bc	0	2	SingleSelect	\N	\N	131	f	\N	2	2	2023-06-19 03:30:11.291+00	2023-06-19 03:30:11.291+00	\N	\N	\N
4	Systolic blood pressure	4	f	[]	13	1	31010a2c-e4e8-4cb4-87d3-56316112cd7f	0	2	SingleSelect	\N	\N	132	f	\N	2	2	2023-06-19 03:30:11.298+00	2023-06-19 03:30:11.298+00	\N	\N	\N
5	Phone Number	1	f	[]	10	2	566ceb1a-4710-4629-88c5-d2c44caa37f6	0	2	SingleSelect	\N	\N	140	f	\N	2	2	2023-06-19 03:31:30.697+00	2023-06-19 03:31:30.697+00	\N	\N	\N
6	Patient Identifier	1	t	[]	5	3	7930e18d-d3e7-4713-878f-5089fb706027	0	2	SingleSelect	\N	\N	148	f	\N	2	2	2023-06-19 04:20:31.993+00	2023-06-19 04:20:43.661+00	\N	\N	\N
10	Phone Number	5	t	[]	10	3	fd2f03b9-2e46-4a8e-b9a9-68fbbcc9b9a2	0	2	SingleSelect	\N	\N	152	f	\N	2	2	2023-06-19 04:20:32.055+00	2023-06-19 04:20:43.672+00	\N	\N	\N
7	Father/Mother's Name	4	f	[]	9	3	42ce9bbc-4243-47d9-8a70-8aa104ea1203	0	2	SingleSelect	\N	\N	149	f	\N	2	2	2023-06-19 04:20:32.006+00	2023-06-19 04:20:59.573+00	\N	\N	\N
8	RCH ID	2	f	[]	7	3	edde014f-568d-4971-b886-d07fef028a17	0	2	SingleSelect	\N	\N	150	f	\N	2	2	2023-06-19 04:20:32.015+00	2023-06-19 04:20:59.586+00	\N	\N	\N
9	Nikshay ID	3	f	[]	8	3	6c76db30-a580-4f41-a1f8-80c0d25ded4e	0	2	SingleSelect	\N	\N	151	f	\N	2	2	2023-06-19 04:20:32.023+00	2023-06-19 04:20:59.587+00	\N	\N	\N
\.


--
-- Data for Name: form_element_group; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.form_element_group (id, name, form_id, uuid, version, display_order, display, organisation_id, audit_id, is_voided, rule, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, declarative_rule, start_time, stay_time, is_timed, text_colour, background_colour) FROM stdin;
1	Vitals	2	040bc268-9982-4bdf-9c4a-71e5e860305a	0	1	Vitals	2	128	f	\N	2	2	2023-06-19 03:30:11.248+00	2023-06-19 03:30:11.248+00	\N	\N	\N	f	\N	\N
2	Bahmni Patient Info	4	006cefa2-5fd5-4ad9-be52-3f0648150a7a	0	1	Bahmni Patient Info	2	139	f	\N	2	2	2023-06-19 03:31:30.683+00	2023-06-19 03:31:30.683+00	\N	\N	\N	f	\N	\N
3	Additional Details	1	e5c736fb-2163-4a47-9985-f1a81521e476	0	1	Additional Details	2	147	f	\N	2	2	2023-06-19 04:20:31.915+00	2023-06-19 04:20:31.915+00	\N	\N	\N	f	\N	\N
\.


--
-- Data for Name: form_mapping; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.form_mapping (id, form_id, uuid, version, entity_id, observations_type_entity_id, organisation_id, audit_id, is_voided, subject_type_id, enable_approval, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, task_type_id) FROM stdin;
1	1	cd44de50-c693-4168-871e-a2a04cf63a88	0	\N	\N	2	111	f	2	f	2	2	2023-06-19 03:20:34.052+00	2023-06-19 03:20:34.052+00	\N
2	2	1cadbf53-269e-41ee-86d6-75db83fdc883	0	\N	1	2	125	f	2	f	2	2	2023-06-19 03:29:03.919+00	2023-06-19 03:29:03.919+00	\N
3	3	269474db-d9bd-4664-8a30-243a3c75ad69	0	\N	1	2	127	f	2	f	2	2	2023-06-19 03:29:03.945+00	2023-06-19 03:29:03.945+00	\N
4	4	eaa27c6b-adf5-4787-ac1b-399bb20688b4	0	\N	2	2	136	f	2	f	2	2	2023-06-19 03:30:37.776+00	2023-06-19 03:30:37.776+00	\N
5	5	aec2647d-48c7-48b2-8bac-5c1a838582ea	0	\N	2	2	138	f	2	f	2	2	2023-06-19 03:30:37.805+00	2023-06-19 03:30:37.805+00	\N
\.


--
-- Data for Name: gender; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.gender (id, uuid, name, concept_id, version, audit_id, is_voided, organisation_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
1	ad7d1d14-54fd-45a2-86b7-ea329b744484	Female	\N	1	8	f	1	1	1	2023-06-19 03:05:09.745+00	2023-06-19 03:05:09.745+00
2	840de9fb-e565-4d7d-b751-90335ba20490	Male	\N	1	9	f	1	1	1	2023-06-19 03:05:09.745+00	2023-06-19 03:05:09.745+00
3	188ad77e-fe46-4328-b0e2-98f3a05c554c	Other	\N	1	10	f	1	1	1	2023-06-19 03:05:09.745+00	2023-06-19 03:05:09.745+00
4	5c98b395-b373-4d69-ad6a-450b957ab189	Male	\N	0	86	f	2	1	1	2023-06-19 03:09:02.455+00	2023-06-19 03:09:02.455+00
5	805eb6c2-8716-4c33-9811-d3e47d88e49f	Female	\N	0	87	f	2	1	1	2023-06-19 03:09:02.478+00	2023-06-19 03:09:02.478+00
6	9d77f000-c644-4954-b2a4-c695be9e1b92	Other	\N	0	88	f	2	1	1	2023-06-19 03:09:02.482+00	2023-06-19 03:09:02.482+00
\.


--
-- Data for Name: group_dashboard; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.group_dashboard (id, uuid, organisation_id, is_primary_dashboard, audit_id, version, group_id, dashboard_id, is_voided, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: group_privilege; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.group_privilege (id, uuid, group_id, privilege_id, subject_type_id, program_id, program_encounter_type_id, encounter_type_id, checklist_detail_id, allow, is_voided, version, organisation_id, audit_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: group_role; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.group_role (id, uuid, group_subject_type_id, role, member_subject_type_id, is_primary, maximum_number_of_members, minimum_number_of_members, organisation_id, audit_id, is_voided, version, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: group_subject; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.group_subject (id, uuid, group_subject_id, member_subject_id, group_role_id, membership_start_date, membership_end_date, organisation_id, audit_id, is_voided, version, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, member_subject_address_id, group_subject_address_id, group_subject_sync_concept_1_value, group_subject_sync_concept_2_value) FROM stdin;
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.groups (id, uuid, name, is_voided, version, organisation_id, audit_id, has_all_privileges, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
1	6944f9f8-9010-4925-8264-ca0a6224fe47	Everyone	f	0	1	83	t	1	1	2023-06-19 03:05:13.596+00	2023-06-19 03:05:13.596+00
2	84c25eaa-a7e5-4f9b-a3ea-e845cc5204ad	Everyone	f	0	2	89	t	1	1	2023-06-19 03:09:02.501+00	2023-06-19 03:09:02.501+00
\.


--
-- Data for Name: identifier_assignment; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.identifier_assignment (id, uuid, identifier_source_id, identifier, assignment_order, assigned_to_user_id, individual_id, program_enrolment_id, version, is_voided, organisation_id, audit_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: identifier_source; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.identifier_source (id, uuid, name, type, catchment_id, minimum_balance, batch_generation_size, options, version, is_voided, organisation_id, audit_id, min_length, max_length, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: identifier_user_assignment; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.identifier_user_assignment (id, uuid, identifier_source_id, assigned_to_user_id, identifier_start, identifier_end, last_assigned_identifier, version, is_voided, organisation_id, audit_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: index_metadata; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.index_metadata (id, table_metadata_id, column_id, name) FROM stdin;
\.


--
-- Data for Name: individual; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.individual (id, uuid, address_id, observations, version, date_of_birth, date_of_birth_verified, gender_id, registration_date, organisation_id, first_name, last_name, is_voided, audit_id, facility_id, registration_location, subject_type_id, legacy_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, sync_concept_1_value, sync_concept_2_value, profile_picture, middle_name, manual_update_history) FROM stdin;
\.


--
-- Data for Name: individual_relation; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.individual_relation (id, uuid, name, is_voided, organisation_id, version, audit_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
1	7e876220-20b4-4c17-87b7-0e235926f7a6	son	f	1	1	46	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
2	91fd32f2-0261-46a1-92e4-4c201247c9a3	daughter	f	1	1	47	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
3	eeb49484-a07d-49f7-bb4b-932b713fbc66	father	f	1	1	48	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
4	5a77c22b-a24f-456e-84a3-9bd12e104f73	mother	f	1	1	49	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
5	334ea293-fd10-4dab-92f3-04ce153e27aa	husband	f	1	1	50	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
6	0ab14ce3-cbdb-4cb7-8601-353bebe408c9	wife	f	1	1	51	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
7	4809d13f-4ab1-49d7-aa57-ee71a821bc3f	brother	f	1	1	52	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
8	a081882c-6775-4caa-98cd-9720a0d11dfc	sister	f	1	1	53	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
9	4474c0f3-9d35-4622-a65a-5688f633a274	grandson	f	1	1	54	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
10	82691c26-c042-48d4-972b-664bcb348fc4	granddaughter	f	1	1	55	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
11	0d0b0e92-79d4-49c1-b33b-cf0508ea550c	grandfather	f	1	1	56	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
12	8c382726-92be-4e3e-8b6e-2b032c5cd6a8	grandmother	f	1	1	57	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
\.


--
-- Data for Name: individual_relation_gender_mapping; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.individual_relation_gender_mapping (id, uuid, relation_id, gender_id, is_voided, organisation_id, version, audit_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
1	f6e6f570-aaaf-4069-a14d-e2649e9710d7	1	2	f	1	1	58	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
2	2eb6adbc-5a55-46f8-925e-f3061fd16e29	2	1	f	1	1	59	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
3	7c97fe3b-c2e8-437d-a43b-1e6d4357a8d1	3	2	f	1	1	60	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
4	1896f28c-cace-4034-bf29-c0ab42a4c41e	4	1	f	1	1	61	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
5	f2916111-b753-4004-85d5-a63856ce4462	5	2	f	1	1	62	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
6	ec90bb6f-2ccb-4e4c-be01-ae95cc441b98	6	1	f	1	1	63	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
7	ac49854a-776d-4311-9b13-c536b97e0c48	7	2	f	1	1	64	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
8	90de5a8a-cbbc-4bab-8019-edf3f1d02317	8	1	f	1	1	65	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
9	0dff0a2b-ac07-4c31-8338-c32af05b31fc	9	2	f	1	1	66	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
10	db89d727-3c3e-45fc-a18d-a58c3098d5ca	10	1	f	1	1	67	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
11	50a3aa9e-04be-465f-be7b-22e0ab8e500e	11	2	f	1	1	68	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
12	29b20f70-6b3e-481e-96cf-c4fe0e2d46c1	12	1	f	1	1	69	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
\.


--
-- Data for Name: individual_relationship; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.individual_relationship (id, uuid, individual_a_id, individual_b_id, relationship_type_id, enter_date_time, exit_date_time, exit_observations, is_voided, organisation_id, version, audit_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: individual_relationship_type; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.individual_relationship_type (id, uuid, name, individual_a_is_to_b_relation_id, individual_b_is_to_a_relation_id, is_voided, organisation_id, version, audit_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
1	1d9c019a-9350-44f9-9ef9-a699f0d94a13	father-son	3	1	f	1	1	70	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
2	1db2a945-0692-481e-a68c-aaf7cc246d64	father-daughter	3	2	f	1	1	71	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
3	d84d15c2-3d09-416e-8c26-9709ce3c90da	mother-son	4	1	f	1	1	72	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
4	99ad5750-bdf8-40e6-964c-01cf806707b7	mother-daughter	4	2	f	1	1	73	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
5	89d85d58-de14-4249-b9bb-61d4abb94b77	spouse	5	6	f	1	1	74	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
6	2a6a496c-6063-4383-8857-0c10a831d85c	brother-brother	7	7	f	1	1	75	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
7	3731d4b6-80f4-410b-baf7-2c0fcc38fe1f	sister-sister	8	8	f	1	1	76	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
8	765bc1ed-441a-414d-b62a-672103b35c95	brother-sister	7	8	f	1	1	77	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
9	8458bbe3-aa87-4c7c-b5e2-a139e01bd88f	grandfather-grandson	11	9	f	1	1	78	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
10	1724ff11-95c5-42c2-b697-f40f1105d696	grandfather-granddaughter	11	10	f	1	1	79	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
11	28edbf6e-98eb-4218-8950-01d97be476da	grandmother-grandson	12	9	f	1	1	80	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
12	ace301c1-2815-42c1-943e-c7b44f64b376	grandmother-granddaughter	12	10	f	1	1	81	1	1	2023-06-19 03:05:10.11+00	2023-06-19 03:05:10.11+00
\.


--
-- Data for Name: individual_relative; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.individual_relative (id, uuid, individual_id, relative_individual_id, relation_id, enter_date_time, exit_date_time, is_voided, organisation_id, version, audit_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: location_location_mapping; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.location_location_mapping (id, location_id, parent_location_id, version, audit_id, uuid, is_voided, organisation_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
1	2	1	0	98	dc202943-8eb9-4c76-9b47-dabd9028287c	f	2	2	2	2023-06-19 03:13:40.843+00	2023-06-19 03:13:40.843+00
2	3	2	0	100	cd2dc02b-68f6-44d9-a81b-025ced86c198	f	2	2	2	2023-06-19 03:14:05.712+00	2023-06-19 03:14:05.712+00
3	4	3	0	102	4f7d05a8-e483-45ff-91a6-1de405519873	f	2	2	2	2023-06-19 03:14:24.875+00	2023-06-19 03:14:24.875+00
4	5	3	0	104	de8c5e8f-201b-409f-825f-66462e1c8d5c	f	2	2	2	2023-06-19 03:16:04.769+00	2023-06-19 03:16:04.769+00
\.


--
-- Data for Name: manual_message; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.manual_message (id, uuid, organisation_id, is_voided, message_template_id, parameters, version, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, next_trigger_details) FROM stdin;
\.


--
-- Data for Name: menu_item; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.menu_item (id, organisation_id, uuid, is_voided, version, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, display_key, type, menu_group, icon, link_function) FROM stdin;
\.


--
-- Data for Name: message_receiver; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.message_receiver (id, uuid, receiver_type, organisation_id, is_voided, external_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, version, receiver_id) FROM stdin;
\.


--
-- Data for Name: message_request_queue; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.message_request_queue (id, uuid, organisation_id, message_rule_id, message_receiver_id, scheduled_date_time, delivered_date_time, delivery_status, is_voided, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, version, entity_id, manual_message_id) FROM stdin;
\.


--
-- Data for Name: message_rule; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.message_rule (id, uuid, name, message_rule, schedule_rule, organisation_id, is_voided, entity_type, message_template_id, version, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, entity_type_id, receiver_type) FROM stdin;
\.


--
-- Data for Name: msg91_config; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.msg91_config (id, uuid, auth_key, otp_sms_template_id, otp_length, organisation_id, audit_id, is_voided, version, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: news; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.news (id, organisation_id, uuid, title, content, contenthtml, hero_image, published_date, is_voided, audit_id, version, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: non_applicable_form_element; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.non_applicable_form_element (id, organisation_id, form_element_id, is_voided, version, audit_id, uuid, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: operational_encounter_type; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.operational_encounter_type (id, uuid, organisation_id, encounter_type_id, version, audit_id, name, is_voided, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
1	4083e075-960a-46d6-8776-0aa1b436c56a	2	1	0	123	Vitals	f	2	2	2023-06-19 03:29:03.886+00	2023-06-19 03:29:03.886+00
2	6b5afb51-1039-4e3f-9237-f385028ab843	2	2	0	134	Bahmni Patient Registration	f	2	2	2023-06-19 03:30:37.748+00	2023-06-19 03:30:37.748+00
\.


--
-- Data for Name: operational_program; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.operational_program (id, uuid, organisation_id, program_id, version, audit_id, name, is_voided, program_subject_label, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: operational_subject_type; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.operational_subject_type (id, uuid, name, subject_type_id, organisation_id, is_voided, audit_id, version, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
1	468d21b5-927a-42dc-8fbb-a9ed0a799a90	Patient	2	2	f	109	0	2	2	2023-06-19 03:20:33.959+00	2023-06-19 03:20:33.959+00
\.


--
-- Data for Name: organisation; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.organisation (id, name, db_user, uuid, parent_organisation_id, is_voided, media_directory, username_suffix, account_id, schema_name, has_analytics_db) FROM stdin;
1	OpenCHS	openchs_impl	3539a906-dfae-4ec3-8fbb-1b08f35c3884	\N	f	openchs	\N	1	openchs_impl	f
2	Karnataka	gok	b9c74baf-e2dc-4b88-855c-c33a6a2e2a06	\N	f	gok	bahmni	1	gok	f
\.


--
-- Data for Name: organisation_config; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.organisation_config (id, uuid, organisation_id, settings, audit_id, version, is_voided, worklist_updation_rule, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, export_settings) FROM stdin;
1	1be387f3-353e-4caa-a1f2-56de1f3f4d6e	1	{"languages": ["en"], "useKeycloakAsIDP": true, "useMinioForStorage": "true"}	85	1	f	\N	1	1	2023-06-19 03:08:07.073+00	2023-06-19 03:08:07.073+00	{}
2	cb833268-4ead-4c08-8f59-27583d740978	2	{"languages": ["en"], "useKeycloakAsIDP": true, "useMinioForStorage": "true", "customRegistrationLocations": []}	90	0	f	\N	1	2	2023-06-19 03:09:02.523+00	2023-06-19 03:20:34.062+00	\N
\.


--
-- Data for Name: organisation_group; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.organisation_group (id, name, db_user, account_id, schema_name, has_analytics_db) FROM stdin;
\.


--
-- Data for Name: organisation_group_organisation; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.organisation_group_organisation (id, name, organisation_group_id, organisation_id) FROM stdin;
\.


--
-- Data for Name: platform_translation; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.platform_translation (id, uuid, translation_json, is_voided, platform, language, version, audit_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
1	6473c66e-042d-46a2-9c28-0cb502c5a637	{"No": "No", "do": "Do", "no": "No", "ok": "Ok", "or": "OR", "Yes": "Yes", "age": "Age", "and": " And ", "day": "Day", "due": "Due", "yes": "Yes", "Info": "Info", "Male": "Male", "Okay": "Okay", "Sync": "Sync", "Warn": "Warn", "call": "Call", "date": "Date", "days": "Days", "edit": "Edit", "exit": "EXIT", "home": "Home", "mark": "Mark", "menu": "Menu", "msg1": "Welcome to your personal highlight of 2021!", "msg2": "See your stats and totals (so far).", "name": "Name", "news": "News", "next": "NEXT", "role": "Role", "save": "SAVE", "type": "Type", "void": "Void", "week": "Week", "year": "Year", "CLOSE": "Close", "Debug": "Debug", "Enrol": "Enrol", "Error": "Error", "Hindi": "हिंदी", "Other": "Other", "Today": "Today", "apply": "Apply", "check": "Check", "close": "X", "draft": "Draft", "dueOn": "Due on {{dueOn}}", "enrol": "ENROL", "group": "Group", "hours": "Hour(s)", "month": "Month", "phone": "Phone", "saved": "Saved", "start": "Start", "total": "Total", "value": "Value", "weeks": "Weeks", "years": "Years", "Absent": "Absent", "Female": "Female", "cancel": "Cancel", "change": "Change", "delete": "Delete", "drafts": "Drafts", "filter": "FILTER", "gender": "Gender", "locale": "Language", "logout": "Logout", "months": "Months", "reject": "Reject", "remove": "Remove", "search": "Search", "status": "Status", "submit": "Submit", "unVoid": "Unvoid", "userId": "User ID", "English": "English", "Grade 1": "Grade 1", "Grade 2": "Grade 2", "Grade 3": "Grade 3", "Marathi": "मराठी", "Present": "Present", "actions": "Actions", "addMore": "Add more", "approve": "Approve", "between": "Between ", "confirm": "Confirm", "endDate": "End date", "enrolIn": "Enrol in {{program}}", "expired": "EXPIRED", "filters": "Filters", "general": "General", "members": "Members", "minutes": "Minute(s)", "overdue": "Overdue", "proceed": "Proceed", "profile": "Profile", "program": "Program", "resolve": "Resolve", "saveAnd": "Save and", "summary": "Summary", "syncNow": "Sync now", "viewAll": "VIEW ALL", "Gujarati": "ગુજરાતી", "Relation": "Relation", "Tomorrow": "Tomorrow", "asOnDate": "As on date", "enterOTP": "Please enter the OTP sent to", "exitDate": "Exit Date", "exitedOn": "Exited on:", "feedback": "Provide Feedback", "highRisk": "At Risk", "lastDate": "Last Date {{lastDate}}", "lastName": "Last Name", "location": "Location", "logLevel": "Log Level", "password": "Password", "previous": "PREVIOUS", "programs": "Programs", "readLess": "Read less...", "readMore": "Read more...", "register": "Register", "settings": "Settings", "syncData": "Sync Data", "taskName": "Task Name", "tryAgain": "Try Again", "undoExit": "Undo Exit", "Dashboard": "Dashboard", "PlayVideo": "Play", "Relatives": "Relatives", "VideoList": "Video List", "addMember": "Add Member", "cancelled": "Cancelled", "completed": "Completed on  {{completedOn}}", "displayed": "Displayed", "enterData": "Enter data", "enterDate": "Enter Date", "firstName": "First Name", "household": "household", "mandatory": "MANDATORY", "memberReg": "Member ", "openCases": "OPEN", "openTasks": "Open tasks", "overdueBy": "Overdue After", "scheduled": "Scheduled", "searchAll": "All registration and enrolment text fields", "serverURL": "Server URL", "startDate": "Start date", "syncError": "Sync Failed", "syncLater": "Sync later", "verifyOTP": "Verify OTP", "visitName": "Visit Name", "ageTooHigh": "Age is person is above 120 years", "cancelDate": "Cancel Date", "checklists": "Checklists", "closeModal": "Close", "dashboards": "Dashboards", "discussion": "Discussion", "enrolledOn": "Enrolled on:", "enrolments": "Enrolments", "entityName": "Entity Name", "isNotDueOn": "{{checklistItemName}} is not due yet on {{dueDate}}", "lastLoaded": "Last Loaded", "middleName": "Middle Name", "obsKeyword": "Other data", "reschedule": "Reschedule", "resendCode": "Resend code", "sonIsOlder": "son can not be older", "sortFilter": "Sort/Filter", "totalCases": "TOTAL", "yearInAvni": "Year 2021 in Avni", "yearReview": "Year 2021 review", "NotEnoughId": "Not Enough Identifiers available. Please goto Home screen and press Sync", "OTPVerified": "OTP verified", "addRelative": "Add Relative", "autoRefresh": "Dashboard Auto Refresh", "cancelVisit": "Cancel", "chooseADate": "Choose a date", "chooseATime": "Choose a time", "chooseVisit": "Choose Visit", "completedOn": "Completed", "dateOfBirth": "Date of Birth", "editProfile": "Edit Profile", "eligibility": "Eligibility", "exitProgram": "Exit", "getLocation": "Get GPS Location", "goToSummary": "SUMMARY", "loadedSince": "Loaded Since", "myDashboard": "My Dashboard", "programList": "Program List", "programName": "Program name:", "queuedCount": "Queued", "requestName": "{{entityName}} request", "restoringDb": "Restoring database", "syncingData": "Syncing Data", "unavailable": "Unavailable", "uploadMedia": "Uploading saved media files", "viewDetails": "View Details", "viewProfile": "View Profile", "voidedLabel": "(VOIDED)", "Growth Chart": "Growth Chart", "RecentVisits": "Visits", "addARelative": "Add a relative", "addNewMember": "Add new member", "addXHoursAgo": "added {{hrs}} hrs ago", "createThread": "Create Thread", "dueChecklist": "Due", "editSettings": "Edit Settings", "familyFolder": "Family Folder", "noEncounters": "No previous visits", "noEnrolments": "There are no enrolments in this program", "observations": "Observations", "openComments": "Open Comments", "overdueCases": "OVERDUE", "registeredOn": "Registration Date: ", "registration": "Registration", "removeMember": "Remove member", "sentMessages": "Sent Messages", "subjectsList": "Subject List", "syncComplete": "Sync Complete ", "syncRequired": "Sync Required", "totalMembers": "Total members", "vaccinations": "Vaccinations", "verifyNumber": "Verify number", "viewSchedule": "VIEW SCHEDULE", "visitDetails": "Visit Details", "Not Known Yet": "Not Known Yet", "addMemberRole": "Add {{role}}", "downloadForms": "Downloading new forms", "emptySentMsgs": "No Messages Sent", "encounterDate": "Visit Date", "enrolmentDate": "Enrolment Date", "enterDuration": "Enter Duration", "followupTypes": "Types", "includeVoided": "Include voided", "lastVisitDate": "Last Visited", "missedDueDate": "Was due on {{dueOn}}", "plannedVisits": "Planned Visits", "rejectionNote": "Rejection Note", "restoreFailed": "Restore failed, will sync from server", "restoreNoDump": "No dump present, will sync fully from server", "scheduledDate": "Scheduled", "schedulingFor": "Scheduling For", "searchResults": "Search Results", "selectProgram": "Select Program", "trackLocation": "Track Location", "upcomingCases": "UPCOMING", "visitsPlanned": "Visits Planned", "Height For Age": "Height For Age", "Weight For Age": "Weight For Age", "audioFileTitle": "Only audio file supported", "backPressTitle": "Go back", "changePassword": "Change Password", "commentThreads": "Comment Threads", "duplicateValue": "Another {{subjectTypeName}} has same value.", "endDateAndTime": "End date and time", "enrolInProgram": "Enrol in Program", "generalHistory": "General History", "gpsCoordinates": "GPS Coordinates", "homePressTitle": "Go to home screen", "isAfterMaxDate": "{{checklistItemName}} is after the MAX date allowed {{maxDate}}", "myDawaPrapatra": "My Dawa Prapatra", "percentageDone": "Percentage Done", "profilePicture": "Profile Picture", "resetSyncTitle": "Sync reset required", "restoreCheckDb": "Finding pre-existing database", "searchByTyping": "Search by typing ...", "searchExisting": "Search existing {{member}}", "selectRelative": "Please select relative", "showMoreVisits": "Load More", "startNewThread": "Write a comment to start new thread...", "subjectSummary": "Summary", "unplannedVisit": "Unplanned Visit", "upcomingVisits": "Upcoming Visits", "uploadDatabase": "Upload database", "OTPVerification": "OTP verification", "____COMMENT____": "English version for the application labels", "backupCompleted": "Backup completed", "backupUploading": "Uploading database backup to the secure location", "beneficiaryMode": "Beneficiary Mode", "chooseVisitType": "Choose Visit Type", "codeNotReceived": "Not received your code?", "commentOnThread": "Comment on this thread...", "completedVisits": "Completed", "daughterIsOlder": "daughter can not be older", "fatherIsYounger": "father can not be younger", "getAnotherOTPIn": "Get another OTP ( Wait for 00:{{seconds}} )", "grandsonIsOlder": "grandson can not be older", "headOfHousehold": "Head of household", "logoutCancelled": "Cancel", "logoutConfirmed": "Logout", "motherIsYounger": "mother can not be younger", "newGeneralVisit": "New Form", "newProgramVisit": "New Program Visit", "noRelativeAdded": "No Relative Added", "openCodedFilter": "may take few seconds to open", "restoreComplete": "Restore complete", "syncServerError": "An error has occurred. Please try after sometime.", "unplannedVisits": "Unplanned Visits", "visitsCompleted": "Completed Visits", "RecentEnrollment": "Enrolments", "addAnotherMember": "Add another member", "askIfNotComplete": "This checklist item is not complete", "backPressMessage": "Are you sure you want to go back? You will lose all the form changes.", "checkEligibility": "Check Eligibility", "checklistPreview": "Will create {{name}} and it's upcoming items are on {{date}}", "closeCodedFilter": "may speed up", "enrolIntoProgram": "enrol into {{program}}", "enrolmentDetails": "Enrolment Details", "enrolmentExitMsg": "Exited From {{programName}} Program", "entitySyncStatus": "Entity Sync Status", "exitDateInFuture": "Exit date cannot be in future", "forceSyncWarning": "Force Sync Warning", "groupInformation": "Group information", "homePressMessage": "Are you sure you want to go back to home screen? You will lose all the form changes.", "memberDeletedMsg": "Member removed", "noItemsToDisplay": "No items to display.", "noOpenEncounters": "There are no pending visits", "proceedEncounter": "proceed to {{enc}}", "programsEnrolled": "Programs", "registrationDate": "Date of Registration", "rejectRequestMsg": "Please mention the reason below:", "resetSyncDetails": "Due to some changes done by organisation admin reset of sync is required. This may take longer and will require good internet connection. Do you want to proceed now?", "saveAndAddMember": "proceed to add member {{household}}", "startDateAndTime": "Start date and time", "syncTimeoutError": "Sorry it's taking too long. Please check your internet connection.", "totalQueuedCount": "Total Queued", "validationResult": "Validation Error", "Weight For Height": "Weight For Height", "approveRequestMsg": "Do you confirm the registration details for the subject {{subjectName}} ?", "birthDateInFuture": "Birth date cannot be in future", "chooseDateAndTime": "Choose date and time", "clearDataAndLogin": "Delete data and login", "eligibilityReport": "Eligibility Report", "encounterSavedMsg": "{{encounterName}} Encounter Saved", "enrolmentSavedMsg": "{{programName}} Enrolment Saved", "failedToFetchMsgs": "Could not retrieve messages", "membershipEndDate": "Membership end date", "newMemberAddedMsg": "New member added", "performNormalSync": "Perform slow sync", "readNewsBroadcast": "Read news broadcast", "registerNewMember": "REGISTER NEW MEMBER", "removeMemberTitle": "Are you sure you want to the member from group?", "scheduledMessages": "Scheduled Messages", "GlificMessagesList": "Glific Messages List", "RecentRegistration": "Registrations", "deleteConfirmation": "Do you want to delete all saved sessions?", "deleteMessageTitle": "Delete the comment", "disableAutoRefresh": "Disable Dashboard Auto Refresh", "draftDeleteMessage": "Drafts will stay here for 30 days, after which they are deleted", "emptyScheduledMsgs": "No Messages Scheduled", "familyRegistration": "Family Registration", "headOfHouseholdReg": "Head of household ", "invalidPhoneNumber": "Invalid phone number", "lowestAddressLevel": "Village", "maxLimitReachedMsg": "Maximum limit reached for this role", "rejectRequestTitle": "Reject {{entityName}} request for the subject {{subjectName}} ?", "restoreFailedTitle": "Fast sync failed", "rolesNotConfigured": "Roles not configured", "withHighRiskMember": "member at risk", "ENCOUNTER_DATE_TIME": "Visit date", "anotherRegistration": "register another {{subject}}", "approveRequestTitle": "Approve {{entityName}} request?", "beneficiaryNotFound": "Unable to identify", "completedEncounters": "Completed Encounters", "dateOfBirthVerified": "Verified", "enrolmentAttributes": "Enrolment Attributes", "generalConsultation": "General Consultation", "groupRemovalMessage": "{{memberName}} will be removed from the {{groupSubjectTypeName}} {{groupSubjectName}}.", "individualDashboard": "Dashboard", "membershipStartDate": "Membership start date", "newRelativeAddedMsg": "New relative added", "noPlannedEncounters": "No planned visits", "pleaseChooseAOption": "Please choose an option", "proceedAddHousehold": "proceed to {{household}}", "proceedRegistration": "Register new {{member}}", "proceedRemoveMember": "proceed to remove from {{groupName}}", "resolveMessageTitle": "Resolve this thread", "skipOTPVerification": "Skip OTP verification", "timeValueValidation": "There is no value specified for time", "visitDetailsSection": "Visit details", "zeroNumberOfResults": "No result found", "FileSizeErrorMessage": "File size {{size}} MB increases the max file size {{allowedMaxSize}} MB", "FileTypeErrorMessage": "Selected file type {{type}} does not match with the required file type(s) {{allowedTypeNames}}", "approvalDetailsTitle": "{{subjectName}} {{entityName}} details", "audioFileDescription": "Please select an audio file.", "cannotChangeUserDesc": "'{{oldUser}}' user was previously logged in. Proceeding to login as '{{newUser}}' will delete un-synced data of '{{oldUser}}'. Do you want to delete and login?", "commentCannotBeEmpty": "Comment Cannot Be Empty", "deleteMessageDetails": "Are you sure you want to delete this comment? You will not be able to undo this operation.", "granddaughterIsOlder": "granddaughter can not be older", "grandfatherIsYounger": "grandfather can not be younger", "grandmotherIsYounger": "grandmother can not be younger", "groupAdditionMessage": "{{memberName}} will be added to the {{groupSubjectTypeName}} {{groupSubjectName}}.", "invalidLogoutAttempt": "Incorrect PIN ({{used}} out of {{max}} failed attempts)", "registerHeadOfFamily": "Register head of family", "registrationSavedMsg": "Registration Saved", "scrollToBottomToSave": "Scroll to Bottom to Save", "totalMatchingResults": "Total matching results", "undoExitProgramTitle": "Undo program exit", "uniqueAnswerConflict": "'{{answer}}' cannot be selected with other answers", "visitsBeingScheduled": "Visits Being Scheduled", "cannotChangeUserTitle": "Multiple users cannot login", "encounterCancelledMsg": "{{encounterName}} Encounter Canceled", "encounterDateInFuture": "Encounter date cannot be in future", "enrolmentDateInFuture": "Enrolment date cannot be in future", "noCompletedEncounters": "No completed visits", "numberAboveHiAbsolute": "Should be {{limit}}, or less than {{limit}}", "observationInProgress": "Observation in Progress ...", "phoneNumberUnverified": "Phone number unverified", "resolveMessageDetails": "Are you sure you want to resolve this comment thread? You can reopen it by adding a new comment.", "systemRecommendations": "System Recommendations", "videoListNotAvailable": "No video list available", "UnableToPlayVideoError": "Unable to play the video", "allEnrolmentsInProgram": "All enrolments in", "dashboardsNotAvailable": "No dashboard available", "eligibilityFailedTitle": "Eligibility Check Execution Failed", "empty-formelement-name": "", "emptyValidationMessage": "There is no value specified", "enrolInSpecificProgram": "{{program}} Enrolment", "moreThanOneBeneficiary": "More than one beneficiary", "noFileTypeErrorMessage": "File type not recognised, please select correct file.", "numberBelowLowAbsolute": "Should be {{limit}}, or more than {{limit}}", "numericValueValidation": "Is not a valid number", "refreshReminderMessage": "You may need to press refresh to get the latest counts", "uploadLocallySavedData": "Uploading saved data", "FetchingChangedResource": "Fetching changed resources from the server", "FileSelectionErrorTitle": "Error while selecting the file", "deleteSchemaNoticeTitle": "Delete Data?", "forceSyncWarningMessage": "Are you sure you want to go ahead with this action, this action will cause the Sync to take a long time to finish. It is advisable to only use this action when directed by the support team.", "giveLocationPermissions": "Click on Get Location button and give permissions when asked", "internetConnectionError": "No internet connection. Please connect to internet.", "logoutConfirmationTitle": "Are You Sure?", "notEnrolledInAnyProgram": "Not enrolled in any program", "recentStatisticsSection": "Last 24 hours statistics", "recordingStartedMessage": "Recording started, use stop button to stop it.", "registrationInformation": "Registration Details", "uploadCatchmentDatabase": "Setup fast sync", "changeStatusToPendingMsg": "An edit was made on the rejected form. Do you want to send it for the approval again?", "checklistOverviewSection": "Vaccination overview", "patientCountForVisitType": "{{subjectTypeName}} with {{visitType}} Visits: {{count}}", "registrationDateInFuture": "Registration date cannot be in future", "subjectsWithMobileNumber": "Subjects with mobile number {{number}}", "deleteRelativeNoticeTitle": "Delete a relative?", "downloadNewDataFromServer": "Downloading new data from server", "familyCountInThisCategory": "Total Families in this category : {{count}}", "logoutConfirmationMessage": "If you log out, you will need to login again with the internet to continue using the app.\\n", "memberAlreadyAddedMessage": "Member is already present in the group", "restoreDownloadPreparedDb": "Downloading prepared database", "summaryAndRecommendations": "Summary & Recommendations", "beneficiaryNotFoundMessage": "Unable to find a record with the given identification details.", "changeStatusToPendingTitle": "Send the form for approval?", "selfRelationshipNotAllowed": "Self relationship not allowed", "voidedIndividualAlertTitle": "Voided Individual", "RelationWithHeadOfHousehold": "Relationship with head of household", "exitDateBeforeEnrolmentDate": "Exit date cannot be before enrolment date", "registrationOverviewSection": "Registration overview", "relationshipAlreadyRecorded": "Relationship already recorded", "thisIndividualHasBeenVoided": "THIS INDIVIDUAL HAS BEEN VOIDED", "startDateGreaterThanEndError": "Start date cannot be greater than End date", "voidedIndividualAlertMessage": "Changes can not be made to voided individual", "bothDateShouldBeSelectedError": "Both start date and end date should be selected", "moreThanOneBeneficiaryMessage": "More than one record found with the given identification details.", "registrationBeforeDateOfBirth": "Registration cannot be before date of birth", "rolesNotConfiguredDescription": "Configure roles to add member.", "undoChecklistItemConfirmTitle": "Confirm Undo {{vaccinationName}}", "visitsBeingScheduledForOthers": "Visits Being Scheduled For Others", "relativeRelationGenderMismatch": "Relation does not match with relative gender", "deleteSchemaConfirmationMessage": "You will lose information that is not synced", "programSavedProceedEncounterMsg": "{{program}} Enrolment Saved", "removeMemberConfirmationMessage": "Remove member from this group", "undoChecklistItemConfirmMessage": "Are you sure you want to undo this vaccination?", "voidIndividualConfirmationTitle": "Void this individual?", "NotEnoughIdForAnotherRegistration": "Not Enough Identifiers available for another Registration. Please goto Home screen and press Sync", "deleteRelativeConfirmationMessage": "This will remove relationship between {{individualA}} and {{individualB}}", "encounterSavedProceedEncounterMsg": "{{encounter}} Encounter Saved", "unVoidIndividualConfirmationTitle": "Unvoid this individual", "uploadCatchmentDatabaseErrorTitle": "Cannot setup fast sync", "voidIndividualConfirmationMessage": "This individual will be voided", "giveLocationPermissionFromSettings": "Please give location permission to OpenCHS from Settings > Apps > OpenCHS", "undoExitProgramConfirmationMessage": "Do you want to undo program exit and join again?", "encounterDateBeforeRegistrationDate": "Encounter date cannot be before registration date", "enrolmentDateBeforeRegistrationDate": "Enrolment date cannot be before registration date", "unVoidIndividualConfirmationMessage": "Do you want to unvoid this individual?", "voidedChecklistItemDetailAlertTitle": "Cannot change because it has been discontinued", "genderDoesNotMatchWithRelativeGender": "Selected gender does not match with relative gender", "uploadCatchmentDatabaseLocalUnsavedData": "You have local unsaved data which should be saved to server.", "uploadCatchmentDatabaseActionRecommended": "Please perform a full sync, before trying this.", "systemRecommendationsTitleForRegistration": "Registration", "uploadCatchmentDatabaseLocalOneSyncNeeded": "You have not completed a full sync with server.", "uploadCatchmentDatabaseConfirmationMessage": "This will upload your entire Avni mobile database to the avni server. Do you want to continue?", "encounterDateNotInBetweenEnrolmentAndExitDate": "Encounter date not in between enrolment and exit dates"}	f	Android	en	0	141	1	1	2023-06-19 03:36:37.51+00	2023-06-19 03:36:37.51+00
2	a8348673-bd1a-4ac7-993f-c81d77ce1cff	{"No": "No", "do": "Do", "no": "No", "ok": "Ok", "or": "OR", "Yes": "Yes", "age": "Age", "and": " And ", "day": "Day", "dob": "Date of Birth", "due": "Due", "yes": "Yes", "Date": "Date", "Info": "Info", "Male": "Male", "Okay": "Okay", "Sync": "Sync", "Warn": "Warn", "back": "Back", "date": "Date", "days": "Days", "edit": "Edit", "exit": "EXIT", "home": "Home", "menu": "Menu", "name": "Name", "next": "NEXT", "role": "Role", "save": "Save", "void": "Void", "week": "Week", "year": "Year", "Debug": "Debug", "Enrol": "Enrol", "Error": "Error", "Hindi": "हिंदी", "Other": "Other", "apply": "Apply", "close": "X", "dueOn": "Due on {{dueOn}}", "enrol": "ENROL", "group": "Group", "hours": "Hour(s)", "month": "Month", "saved": "Saved", "total": "Total", "value": "Value", "visit": "Visit", "weeks": "Weeks", "years": "Years", "Absent": "Absent", "Cancel": "Cancel", "Female": "Female", "Member": "Member", "backup": "Backup Now", "cancel": "Cancel", "create": "Create", "filter": "FILTER", "gender": "Gender", "locale": "Language", "logout": "Logout", "member": "Member", "months": "Months", "remove": "Remove", "search": "Search", "sender": "Sender", "submit": "Submit", "unVoid": "Unvoid", "userId": "User ID", "Address": "Address", "English": "English", "General": "General", "Marathi": "मराठी", "Overdue": "Overdue", "Present": "Present", "Program": "Program", "Village": "Village", "actions": "Actions", "address": "Address", "between": "Between ", "confirm": "Confirm", "endDate": "End date", "expired": "EXPIRED", "general": "General", "members": "Members", "minutes": "Minute(s)", "msgBody": "Message Content", "newform": "New Form", "overdue": "Overdue", "proceed": "Proceed", "profile": "Profile", "saveAnd": "Save and", "summary": "Summary", "syncNow": "Sync now", "viewAll": "VIEW ALL", "Gujarati": "ગુજરાતી", "Question": "Question", "Relation": "Relation", "asOnDate": "As on date", "comments": "Comments", "do visit": "DO Visit", "exitDate": "Exit Date", "exitedOn": "Exited on:", "feedback": "Provide Feedback", "highRisk": "At Risk", "language": "Language", "lastDate": "Last Date {{lastDate}}", "lastName": "Last Name", "location": "Location", "logLevel": "Log Level", "password": "Password", "previous": "PREVIOUS", "programs": "Programs", "register": "Register", "resetAll": "Reset All", "settings": "Settings", "syncData": "Sync Data", "tryAgain": "Try Again", "undoExit": "Undo Exit", "verified": "Verified", "Completed": "Completed", "Dashboard": "Dashboard", "PlayVideo": "Play", "Relatives": "Relatives", "VideoList": "Video List", "ViewVisit": "View Visit", "addMember": "Add Member", "cancelled": "Cancelled", "displayed": "Displayed", "enterData": "Enter data", "enterDate": "Enter Date", "firstName": "First Name", "household": "household", "mandatory": "MANDATORY", "memberReg": "Member ", "openCases": "OPEN", "overdueBy": "Overdue After", "scheduled": "Scheduled", "searchAll": "All text fields within observations of registration and enrolment", "serverURL": "Server URL", "startDate": "Start date", "syncError": "Sync Failed", "syncLater": "Sync later", "visitDate": "Visit Date", "visitName": "Visit Name", "visitType": "Visit Type", "Individual": "Individual", "addComment": "Add comment", "ageTooHigh": "Age is person is above 120 years", "checklists": "Checklists", "edit visit": "Edit Visit", "enrolledOn": "Enrolled on:", "enrolments": "Enrolments", "entityName": "Entity Name", "insertedAt": "Sent At", "isNotDueOn": "{{checklistItemName}} is not due yet on {{dueDate}}", "lastLoaded": "Last Loaded", "middleName": "Middle Name", "obsKeyword": "Other data", "sonIsOlder": "son can not be older", "sortFilter": "Sort/Filter", "totalCases": "TOTAL", "NotEnoughId": "Not Enough Identifiers available. Please goto Home screen and press Sync", "Scheduledon": "Scheduled on", "addRelative": "Add Relative", "autoRefresh": "Dashboard Auto Refresh", "cancelVisit": "Cancel", "chooseADate": "Choose a date", "chooseATime": "Choose a time", "chooseVisit": "Choose Visit", "dateOfBirth": "Date of Birth", "editComment": "Edit comment", "editProfile": "Edit Profile", "editSubject": "Edit subject", "exitProgram": "Exit", "getLocation": "Get GPS Location", "loadedSince": "Loaded Since", "maskedPhone": "Masked phone number", "myDashboard": "My Dashboard", "postComment": "Post comment", "programList": "Program List", "queuedCount": "Queued", "ranOutOfIds": "Id not available. Please contact your administrator.", "resetFilter": "Reset Filter", "resultfound": "Result Found", "scheduledAt": "Scheduled At", "subjectType": "Subject Type", "syncingData": "Syncing Data", "unavailable": "Unavailable", "uploadMedia": "Uploading saved media files", "viewProfile": "View Profile", "voidedLabel": "(VOIDED)", "OBSERVATIONS": "OBSERVATIONS", "RecentVisits": "Last 24 hours Visits", "addARelative": "Add a relative", "addNewMember": "Add new member", "basicDetails": "Basic Details", "editSettings": "Edit Settings", "familyFolder": "Family Folder", "filterResult": "Filter Result", "noEncounters": "No previous visits", "noEnrolments": "There are no enrolments in this program", "observations": "Observations", "overdueCases": "OVERDUE", "registeredOn": "Registration Date: ", "registration": "Registration", "removeMember": "Remove member", "sentMessages": "Sent Messages", "syncComplete": "Sync Complete ", "syncRequired": "Sync Required", "totalMembers": "Total members", "vaccinations": "Vaccinations", "viewSchedule": "VIEW SCHEDULE", "visitDetails": "Visit Details", "Not Known Yet": "Not Known Yet", "addMemberRole": "Add {{role}}", "date of birth": "Date of Birth", "downloadForms": "Downloading new forms", "encounterDate": "Visit Date", "enrolmentDate": "Enrolment Date", "enterDuration": "Enter Duration", "exitedProgram": "Exited Program", "filterResults": "Filter results", "followupTypes": "Types", "includeVoided": "Include voided", "lastVisitDate": "Last Visited", "missedDueDate": "Was due on {{dueOn}}", "plannedVisits": "Planned Visits", "resolveThread": "Resolve thread", "scheduledDate": "Scheduled", "schedulingFor": "Scheduling For", "searchResults": "Search Results", "selectAddress": "Select Address", "selectProgram": "Select Program", "trackLocation": "Track Location", "upcomingCases": "UPCOMING", "viewAllVisits": "View All Visits", "visitsPlanned": "Visits Planned", "activeprograms": "Active Programs", "addressVillage": "Address/ Village", "changePassword": "Change Password", "commentThreads": "Comment threads", "endDateAndTime": "End date and time", "enrolInProgram": "Enrol in Program", "generalHistory": "General History", "gpsCoordinates": "GPS Coordinates", "isAfterMaxDate": "{{checklistItemName}} is after the MAX date allowed {{maxDate}}", "newThreadLabel": "Type message for new thread", "noSentMessages": "No sent messages", "percentageDone": "Percentage Done", "profilePicture": "Profile Picture", "programSummary": "Program summary", "programdetails": "Program Details", "searchExisting": "Search existing {{member}}", "searchHelpText": "Search is based on Name, SubjectType, Gender, Address, Observations", "searchRelative": "Search Relative", "selectRelative": "Please select relative", "showMoreVisits": "Load More", "subjectProfile": "Profile", "subjectSummary": "Summary", "unplannedVisit": "Unplanned Visit", "upcomingVisits": "Upcoming Visits", "____COMMENT____": "English version for the application labels", "beneficiaryMode": "Beneficiary Mode", "completedVisits": "Completed Visits", "daughterIsOlder": "daughter can not be older", "fatherIsYounger": "father can not be younger", "grandsonIsOlder": "grandson can not be older", "headOfHousehold": "Head of household", "logoutCancelled": "Cancel", "logoutConfirmed": "Logout", "motherIsYounger": "mother can not be younger", "newCommentLabel": "What's your response?", "newGeneralVisit": "New Form", "newProgramVisit": "New Program Visit", "noRelativeAdded": "No Relative Added", "summaryNotFound": "No summary found", "syncServerError": "An error has occurred. Please try after sometime.", "unplannedVisits": "Unplanned Visits", "visitCanceldate": "Visit Cancel Date", "visitsCompleted": "Completed Visits", "Enrol in program": "Enrol in program", "RecentEnrollment": "Last 24 hours Enrolments", "addAnotherMember": "Add another member", "askIfNotComplete": "This checklist item is not complete", "checklistPreview": "Will create {{name}} and it's upcoming items are on {{date}}", "enrolIntoProgram": "enrol into {{program}}", "enrolmentDetails": "Enrolment Details", "enrolmentExitMsg": "Exited From {{programName}} Program", "entitySyncStatus": "Entity Sync Status", "exitDateInFuture": "Exit date cannot be in future", "forceSyncWarning": "Force Sync Warning", "memberDeletedMsg": "Member removed", "noOpenEncounters": "There are no pending visits", "noRelativesAdded": "No Relatives Added", "proceedEncounter": "proceed to {{enc}}", "programsEnrolled": "Programs", "registrationDate": "Registration date", "reviewBannerText": "Click here to see your 2021 personal highlights", "saveAndAddMember": "proceed to add member {{household}}", "startDateAndTime": "Start date and time", "syncTimeoutError": "Sorry it's taking too long. Please check your internet connection.", "totalQueuedCount": "Total Queued", "typeNameToSearch": "Type name to search", "validationResult": "Validation Error", "Head of household": "Head of household", "SubjectErrorTitle": "Error while voiding this subject", "backupNoticeTitle": "Backup Data", "birthDateInFuture": "Birth date cannot be in future", "chooseDateAndTime": "Choose date and time", "clearDataAndLogin": "Delete data and login", "encounterSavedMsg": "{{encounterName}} Encounter Saved", "enrolmentSavedMsg": "{{programName}} Enrolment Saved", "invalidDateFormat": "Is not a valid date", "membershipEndDate": "Membership end date", "newMemberAddedMsg": "New member added", "registerNewMember": "REGISTER NEW MEMBER", "removeMemberTitle": "Are you sure you want to remove the member from group?", "scheduledMessages": "Scheduled Messages", "visitscheduledate": "Visit Scheduled Date", "RecentRegistration": "Last 24 hours Registrations", "deleteCommentTitle": "Delete this comment", "deleteConfirmation": "Do you want to delete all saved sessions?", "disableAutoRefresh": "Disable Dashboard Auto Refresh", "familyRegistration": "Family Registration", "headOfHouseholdReg": "Head of household ", "invalidPhoneNumber": "Invalid phone number", "lowestAddressLevel": "Village", "maxLimitReachedMsg": "Maximum limit reached for this role", "programExitDetails": "Program Exit Details", "selectRoleToEnable": "Select a role to enable", "threadResolveTitle": "Resolve this thread", "visitcompleteddate": "Visit Completed Date", "withHighRiskMember": "member at risk", "ENCOUNTER_DATE_TIME": "Visit date", "addGroupMemberTitle": "Add Group Member", "anotherRegistration": "register another {{subject}}", "beneficiaryNotFound": "Unable to identify", "completedEncounters": "Completed Encounters", "dateOfBirthVerified": "Verified", "editGroupMembership": "Edit Group Membership", "enrolmentAttributes": "Enrolment Attributes", "generalConsultation": "General Consultation", "individualDashboard": "Dashboard", "membershipStartDate": "Membership start date", "messageTemplateBody": "Message Template with values filled-in", "newRelativeAddedMsg": "New relative added", "noGroupMembersAdded": "No Group Members Added", "noPlannedEncounters": "No planned visits", "pleaseChooseAOption": "Please choose an option", "proceedAddHousehold": "proceed to {{household}}", "proceedRegistration": "Register new {{member}}", "registrationDetails": "Registration details", "timeValueValidation": "There is no value specified for time", "zeroNumberOfResults": "No result found", "Date of registration": "Date of registration", "cannotChangeUserDesc": "'{{oldUser}}' user was previously logged in. Proceeding to login as '{{newUser}}' will delete un-synced data of '{{oldUser}}'. Do you want to delete and login?", "deleteCommentMessage": "Are you sure you want to delete this comment?", "editGroupMemberTitle": "Edit Group Member", "granddaughterIsOlder": "granddaughter can not be older", "grandfatherIsYounger": "grandfather can not be younger", "grandmotherIsYounger": "grandmother can not be younger", "invalidLogoutAttempt": "Incorrect PIN ({{used}} out of {{max}} failed attempts)", "registerHeadOfFamily": "Register head of family", "registrationSavedMsg": "Registration Saved", "relativeAlreadyAdded": "Relative is already added", "threadResolveMessage": "Are you sure you want to resolve this? You can reopen it anytime by adding a new comment.", "totalMatchingResults": "Total matching results", "undoExitProgramTitle": "Undo program exit", "uniqueAnswerConflict": "'{{answer}}' cannot be selected with other answers", "visitsBeingScheduled": "Visits Being Scheduled", "SubjectVoidAlertTitle": "Void subject", "cannotChangeUserTitle": "Multiple users cannot login", "encounterCancelledMsg": "{{encounterName}} Encounter Canceled", "encounterDateInFuture": "Encounter date cannot be in future", "enrolmentDateInFuture": "Enrolment date cannot be in future", "noCompletedEncounters": "No completed visits", "noMessagesYetToBeSent": "No messages scheduled to be sent", "numberAboveHiAbsolute": "Should be {{limit}}, or less than {{limit}}", "phoneNumberUnverified": "Phone number not verified", "systemRecommendations": "System Recommendations", "videoListNotAvailable": "No video list available", "SYSTEM RECOMMENDATIONS": "SYSTEM RECOMMENDATIONS", "UnableToPlayVideoError": "Unable to play the video", "allEnrolmentsInProgram": "All enrolments in", "createNewCommentThread": "Create a new comment thread", "empty-formelement-name": "", "emptyValidationMessage": "There is no value specified", "enrolInSpecificProgram": "{{program}} Enrolment", "moreThanOneBeneficiary": "More than one beneficiary", "notEnroledInAnyProgram": "Not enroled in any program", "numberBelowLowAbsolute": "Should be {{limit}}, or more than {{limit}}", "numericValueValidation": "Is not a valid number", "uploadLocallySavedData": "Uploading saved data", "SubjectVoidAlertMessage": "Are you sure you want to void this subject?", "deleteSchemaNoticeTitle": "Delete Data?", "forceSyncWarningMessage": "Are you sure you want to go ahead with this action, this action will cause the Sync to take a long time to finish. It is advisable to only use this action when directed by the support team.", "giveLocationPermissions": "Click on Get Location button and give permissions when asked", "internetConnectionError": "No internet connection. Please connect to internet.", "logoutConfirmationTitle": "Are You Sure?", "notEnrolledInAnyProgram": "Not enrolled in any program", "registrationInformation": "Registration Details", "patientCountForVisitType": "{{subjectTypeName}} with {{visitType}} Visits: {{count}}", "registrationDateInFuture": "Registration date cannot be in future", "backupConfirmationMessage": "Are you sure you want to backup your data. Please make sure all your data is synced.", "deleteRelativeNoticeTitle": "Delete a relative?", "downloadNewDataFromServer": "Downloading new data from server", "familyCountInThisCategory": "Total Families in this category : {{count}}", "logoutConfirmationMessage": "If you log out, you will need to login again with the internet to continue using the app.\\n", "memberAlreadyAddedMessage": "Member is already present in the group", "summaryAndRecommendations": "Summary & Recommendations", "ProgramEnrolmentErrorTitle": "Error while deleting this program enrolment", "beneficiaryNotFoundMessage": "Unable to find a record with the given identification details.", "selfRelationshipNotAllowed": "Self relationship not allowed", "voidedIndividualAlertTitle": "Voided Individual", "RelationWithHeadOfHousehold": "Relationship with head of household", "exitDateBeforeEnrolmentDate": "Exit date cannot be before enrolment date", "relationshipAlreadyRecorded": "Relationship already recorded", "thisIndividualHasBeenVoided": "THIS INDIVIDUAL HAS BEEN VOIDED", "startDateGreaterThanEndError": "Start date cannot be greater than End date", "voidedIndividualAlertMessage": "Changes can not be made to voided individual", "bothDateShouldBeSelectedError": "Both start date and end date should be selected", "moreThanOneBeneficiaryMessage": "More than one record found with the given identification details.", "registrationBeforeDateOfBirth": "Registration cannot be before date of birth", "GeneralEncounterVoidAlertTitle": "Delete general encounter", "ProgramEncounterVoidAlertTitle": "Delete program encounter", "ProgramEnrolmentVoidAlertTitle": "Delete program enrolment", "relativeRelationGenderMismatch": "Relation does not match with relative gender", "deleteSchemaConfirmationMessage": "You will lose information that is not synced", "programSavedProceedEncounterMsg": "{{program}} Enrolment Saved", "removeMemberConfirmationMessage": "Remove member from this group", "voidIndividualConfirmationTitle": "Void this individual?", "GeneralEncounterVoidAlertMessage": "Are you sure you want to delete this general encounter? You will not be able to view this visit once deleted.", "ProgramEncounterVoidAlertMessage": "Are you sure you want to delete this program encounter? You will not be able to view this visit once deleted.", "ProgramEnrolmentVoidAlertMessage": "Are you sure you want to delete this program enrolment? You will not be able to view this enrolment once deleted.", "NotEnoughIdForAnotherRegistration": "Not Enough Identifiers available for another Registration. Please goto Home screen and press Sync", "deleteRelativeConfirmationMessage": "This will remove relationship between {{individualA}} and {{individualB}}", "encounterSavedProceedEncounterMsg": "{{encounter}} Encounter Saved", "unVoidIndividualConfirmationTitle": "Unvoid this individual", "voidIndividualConfirmationMessage": "This individual will be voided", "giveLocationPermissionFromSettings": "Please give location permission to OpenCHS from Settings > Apps > OpenCHS", "undoExitProgramConfirmationMessage": "Do you want to undo program exit and join again?", "encounterDateBeforeRegistrationDate": "Encounter date cannot be before registration date", "enrolmentDateBeforeRegistrationDate": "Enrolment date cannot be before registration date", "unVoidIndividualConfirmationMessage": "Do you want to unvoid this individual?", "voidedChecklistItemDetailAlertTitle": "Cannot change because it has been discontinued", "genderDoesNotMatchWithRelativeGender": "Selected gender does not match with relative gender", "systemRecommendationsTitleForRegistration": "Registration", "encounterDateNotInBetweenEnrolmentAndExitDate": "Encounter date not in between enrolment and exit dates", "Your details have been successfully registered.": "Your details have been succesfully registered"}	f	Web	en	0	142	1	1	2023-06-19 03:39:02.879+00	2023-06-19 03:39:02.879+00
\.


--
-- Data for Name: privilege; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.privilege (id, uuid, name, description, entity_type, is_voided, created_date_time, last_modified_date_time) FROM stdin;
1	67410e50-8b40-4735-bfb4-135b13580027	View subject	View subject	Subject	f	2023-06-19 03:05:13.596173+00	2023-06-19 03:05:14.938+00
2	46c3aa38-1ef5-4639-a406-d0b4f9bcb420	Register subject	Register subject	Subject	f	2023-06-19 03:05:13.596173+00	2023-06-19 03:05:14.939+00
3	db791f27-0c04-4060-8938-6f18fb4069ee	Edit subject	Edit subject	Subject	f	2023-06-19 03:05:13.596173+00	2023-06-19 03:05:14.94+00
4	088a30ca-9ce2-4ab3-a517-e249cc43a4bf	Void subject	Void subject	Subject	f	2023-06-19 03:05:13.596173+00	2023-06-19 03:05:14.941+00
5	020c5e18-01f0-469a-8a4a-e27cbc2a2292	Enrol subject	Enrol subject	Enrolment	f	2023-06-19 03:05:13.596173+00	2023-06-19 03:05:14.942+00
6	583188ff-cd10-4615-9e22-000ce0bc6d80	View enrolment details	View enrolment details	Enrolment	f	2023-06-19 03:05:13.596173+00	2023-06-19 03:05:14.943+00
7	a1dcc42f-eed4-4baf-807a-4f6e238f1cba	Edit enrolment details	Edit enrolment details	Enrolment	f	2023-06-19 03:05:13.596173+00	2023-06-19 03:05:14.944+00
8	bd419d1e-cfc6-4607-8cad-38871721115d	Exit enrolment	Exit enrolment	Enrolment	f	2023-06-19 03:05:13.596173+00	2023-06-19 03:05:14.945+00
9	9f2a3495-93b7-47c3-8560-d572b6a9fc61	View visit	View visit	Encounter	f	2023-06-19 03:05:13.596173+00	2023-06-19 03:05:14.946+00
10	867d5de9-0bf3-434c-9cb1-bd09a05250af	Schedule visit	Schedule visit	Encounter	f	2023-06-19 03:05:13.596173+00	2023-06-19 03:05:14.947+00
11	e3352a23-f478-4166-af11-e949cc69e1cc	Perform visit	Perform visit	Encounter	f	2023-06-19 03:05:13.596173+00	2023-06-19 03:05:14.948+00
12	85ce5ed4-1490-4980-8c64-63fb423b5f14	Edit visit	Edit visit	Encounter	f	2023-06-19 03:05:13.596173+00	2023-06-19 03:05:14.949+00
13	51fa8342-3228-4945-88eb-4b41970fa425	Cancel visit	Cancel visit	Encounter	f	2023-06-19 03:05:13.596173+00	2023-06-19 03:05:14.95+00
14	450a83ed-0e49-4b4c-8b8c-2dbfebcd7e5d	View checklist	View checklist	Checklist	f	2023-06-19 03:05:13.596173+00	2023-06-19 03:05:14.951+00
15	79bcebce-4177-471d-8f0d-5558fbd91b76	Edit checklist	Edit checklist	Checklist	f	2023-06-19 03:05:13.596173+00	2023-06-19 03:05:14.952+00
16	0843ee63-721c-49c5-8374-818b512caf82	Add member	Add member	Subject	f	2023-06-19 03:05:13.669518+00	2023-06-19 03:05:14.953+00
17	d9d7ae77-a67e-4644-8976-5b3551106a53	Edit member	Edit member	Subject	f	2023-06-19 03:05:13.669518+00	2023-06-19 03:05:14.954+00
18	f2915fc4-d2cb-492a-b9bc-88a7bae11b75	Remove member	Remove member	Subject	f	2023-06-19 03:05:13.669518+00	2023-06-19 03:05:14.955+00
19	37ae14f9-e6ac-4d24-951a-e457b0cdcf00	Approve Subject	Approve Subject	Subject	f	2023-06-19 03:05:14.431978+00	2023-06-19 03:05:14.956+00
21	31449500-4b8d-43db-855a-c9099600ee32	Approve Enrolment	Approve Enrolment	Enrolment	f	2023-06-19 03:05:14.431978+00	2023-06-19 03:05:14.958+00
23	7d725125-6b48-44d2-a53b-bf847ae8a3d0	Approve Encounter	Approve Encounter	Encounter	f	2023-06-19 03:05:14.431978+00	2023-06-19 03:05:14.96+00
25	9635465c-f0bb-4b10-8cf9-eda181fe7a4f	Approve ChecklistItem	Approve ChecklistItem	ChecklistItem	f	2023-06-19 03:05:14.431978+00	2023-06-19 03:05:14.962+00
20	8a2e92c2-8af2-4f1c-896e-317c0bb4095f	Reject Subject	Reject Subject	Subject	t	2023-06-19 03:05:14.431978+00	2023-06-19 03:05:14.957+00
22	8b0089f6-8c52-471c-bb89-8d4c1800dbcd	Reject Enrolment	Reject Enrolment	Enrolment	t	2023-06-19 03:05:14.431978+00	2023-06-19 03:05:14.959+00
24	ca4428e7-dc4c-4dad-8190-451d8ccd7402	Reject Encounter	Reject Encounter	Encounter	t	2023-06-19 03:05:14.431978+00	2023-06-19 03:05:14.961+00
26	54654e97-acb6-4a89-8754-82a56af93f37	Reject ChecklistItem	Reject ChecklistItem	ChecklistItem	t	2023-06-19 03:05:14.431978+00	2023-06-19 03:05:14.963+00
27	caf84aaf-efcc-4566-84bd-f64ca1b1ba95	Edit subject type	Edit subject type	Subject	f	2023-06-19 03:05:17.8114+00	2023-06-19 03:05:17.811+00
28	969901b1-a9f1-4438-91fd-77c538588aff	Edit program	Edit program	Program	f	2023-06-19 03:05:17.8114+00	2023-06-19 03:05:17.811+00
29	629f8e6e-ef23-474f-98e9-86a1cffd78bd	Edit encounter type	Edit encounter type	EncounterType	f	2023-06-19 03:05:17.8114+00	2023-06-19 03:05:17.811+00
30	c7060a50-b93c-449f-be29-f5e3ed219fb3	Edit form	Edit form	Form	f	2023-06-19 03:05:17.8114+00	2023-06-19 03:05:17.811+00
31	025d8cdd-e6b9-4eb2-9b7d-4cd6ab0dd845	Edit concept	Edit concept	Concept	f	2023-06-19 03:05:17.8114+00	2023-06-19 03:05:17.811+00
32	1e74f1d3-3e5b-4eb3-9100-5753df794d3a	Edit organisation configuration	Edit organisation configuration like filters, languages, etc.,	OrganisationConfig	f	2023-06-19 03:05:17.8114+00	2023-06-19 03:05:17.811+00
33	f03c66b0-be76-4d59-9626-af72db898f29	Delete organisation configuration	Delete organisation configuration like filters, languages, etc.,	OrganisationConfig	f	2023-06-19 03:05:17.8114+00	2023-06-19 03:05:17.811+00
34	8c624d73-c0ed-4268-98a4-de8d35698f36	Upload metadata and data	Upload metadata and data	Bundle	f	2023-06-19 03:05:17.8114+00	2023-06-19 03:05:17.811+00
35	2a3110e1-89a1-4e86-b510-9df98c9628f8	Download bundle	Download bundle	Bundle	f	2023-06-19 03:05:17.8114+00	2023-06-19 03:05:17.811+00
36	e5154032-7967-4d0c-949e-e4f8b84f17ee	Edit checklist configuration	Edit checklist configuration	ChecklistConfig	f	2023-06-19 03:05:17.8114+00	2023-06-19 03:05:17.811+00
37	85e4ee3c-5cb5-49a0-8e2d-d9072b182442	Edit relationship	Edit relationship and its types	Relationship	f	2023-06-19 03:05:17.8114+00	2023-06-19 03:05:17.811+00
38	44640843-6f86-4ddc-b451-b26870821333	Edit documentation	Edit documentation and video playlist	Documentation	f	2023-06-19 03:05:17.8114+00	2023-06-19 03:05:17.811+00
39	337ac291-8676-4ed9-a3c7-89e45f2c4d2e	Edit offline dashboard and report card	Edit offline dashboard and report card	OfflineView	f	2023-06-19 03:05:17.8114+00	2023-06-19 03:05:17.811+00
40	ff02ebe5-0983-4033-8b98-cd3ce23177d8	Edit application menu	Edit application menu	ApplicationMenu	f	2023-06-19 03:05:17.8114+00	2023-06-19 03:05:17.811+00
41	f8d423b1-a2ee-4898-92d5-8243f9c59cf7	Edit extension	Edit extension	Extension	f	2023-06-19 03:05:17.8114+00	2023-06-19 03:05:17.811+00
42	0fd2326c-586d-492b-980a-2d8a0f7331cd	Edit rule failure	Edit rule failure	RuleFailure	f	2023-06-19 03:05:17.8114+00	2023-06-19 03:05:17.811+00
43	578a41ff-2133-4ed3-b6ab-b373318ec20f	Edit location type	Edit location type	LocationType	f	2023-06-19 03:05:17.8114+00	2023-06-19 03:05:17.811+00
44	a9655b6c-8d7e-4a9e-a6b0-f5b928e6ffaf	Edit location	Edit location	Location	f	2023-06-19 03:05:17.8114+00	2023-06-19 03:05:17.811+00
45	7deaa2c2-c72a-424e-98c8-16dbc659d09a	Edit catchment	Edit catchment	Catchment	f	2023-06-19 03:05:17.8114+00	2023-06-19 03:05:17.811+00
46	38e57817-8efe-4f17-b027-d660b929a917	Edit user configuration	Edit identifier assignment, subject assignment, task assignment and group assignment	User	f	2023-06-19 03:05:17.8114+00	2023-06-19 03:05:17.811+00
47	1a8555cf-00d4-46bf-a2b1-85aa7e6495c4	Edit user group	Edit user group details	UserGroup	f	2023-06-19 03:05:17.8114+00	2023-06-19 03:05:17.811+00
48	8fe1c842-82c7-48b7-8918-d63b368d8479	Edit identifier source	Edit identifier source	IdentifierSource	f	2023-06-19 03:05:17.8114+00	2023-06-19 03:05:17.811+00
49	1bd7c859-7cda-4133-a23f-3fa0b5f6c3f0	Edit identifier user assignment	Edit identifier user assignment	IdentifierUserAssignment	f	2023-06-19 03:05:17.8114+00	2023-06-19 03:05:17.811+00
50	c1becb13-df4f-437f-9ba9-434444c01b31	Edit task	Edit task	Task	f	2023-06-19 03:05:17.8114+00	2023-06-19 03:05:17.811+00
51	87b8b6d0-fa23-43a7-b52f-8e592f4ceafc	Delete task	Delete task	Task	f	2023-06-19 03:05:17.8114+00	2023-06-19 03:05:17.811+00
\.


--
-- Data for Name: program; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.program (id, uuid, name, version, colour, organisation_id, audit_id, is_voided, enrolment_summary_rule, enrolment_eligibility_check_rule, active, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, enrolment_eligibility_check_declarative_rule, manual_eligibility_check_required, manual_enrolment_eligibility_check_rule, manual_enrolment_eligibility_check_declarative_rule, allow_multiple_enrolments) FROM stdin;
\.


--
-- Data for Name: program_encounter; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.program_encounter (id, observations, earliest_visit_date_time, encounter_date_time, program_enrolment_id, uuid, version, encounter_type_id, name, max_visit_date_time, organisation_id, cancel_date_time, cancel_observations, audit_id, is_voided, encounter_location, cancel_location, legacy_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, address_id, individual_id, sync_concept_1_value, sync_concept_2_value, manual_update_history) FROM stdin;
\.


--
-- Data for Name: program_enrolment; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.program_enrolment (id, program_id, individual_id, program_outcome_id, observations, program_exit_observations, enrolment_date_time, program_exit_date_time, uuid, version, organisation_id, audit_id, is_voided, enrolment_location, exit_location, legacy_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, address_id, sync_concept_1_value, sync_concept_2_value, manual_update_history) FROM stdin;
\.


--
-- Data for Name: program_organisation_config; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.program_organisation_config (id, uuid, program_id, organisation_id, visit_schedule, version, audit_id, is_voided, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: program_organisation_config_at_risk_concept; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.program_organisation_config_at_risk_concept (id, program_organisation_config_id, concept_id) FROM stdin;
\.


--
-- Data for Name: program_outcome; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.program_outcome (id, uuid, name, version, organisation_id, audit_id, is_voided, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: report_card; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.report_card (id, uuid, name, query, description, colour, is_voided, version, organisation_id, audit_id, standard_report_card_type_id, icon_file_s3_key, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: reset_sync; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.reset_sync (id, uuid, user_id, subject_type_id, organisation_id, is_voided, version, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
1	b5e3732f-87ed-4438-84e2-f149a3d9c282	2	\N	2	f	0	2	2	2023-06-19 03:19:47.866+00	2023-06-19 03:19:47.866+00
2	b5e8b724-0015-41fc-8ed2-9c5a0138ac86	3	\N	2	f	0	2	2	2023-06-19 03:19:58.386+00	2023-06-19 03:19:58.386+00
\.


--
-- Data for Name: rule; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.rule (id, uuid, version, audit_id, type, rule_dependency_id, name, fn_name, data, organisation_id, execution_order, is_voided, entity, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: rule_dependency; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.rule_dependency (id, uuid, version, audit_id, checksum, code, organisation_id, is_voided, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: rule_failure_log; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.rule_failure_log (id, uuid, form_id, rule_type, entity_type, entity_id, error_message, stacktrace, source, audit_id, is_voided, version, organisation_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: rule_failure_telemetry; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.rule_failure_telemetry (id, uuid, user_id, organisation_id, version, rule_uuid, individual_uuid, error_message, stacktrace, error_date_time, close_date_time, is_closed, audit_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: schema_version; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.schema_version (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	0.1	CreateTables	SQL	V0_1__CreateTables.sql	-1010778448	openchs	2023-06-19 03:05:07.302464	97	t
2	0.2	AdditionalUserColumns	SQL	V0_2__AdditionalUserColumns.sql	598335116	openchs	2023-06-19 03:05:07.4491	8	t
3	0.3	CreateOpenCHSUser	SQL	V0_3__CreateOpenCHSUser.sql	-1384118001	openchs	2023-06-19 03:05:07.480144	10	t
4	0.4	SetupGender	SQL	V0_4__SetupGender.sql	-1684826540	openchs	2023-06-19 03:05:07.512159	6	t
5	0.5	CreateProgramEncounterTables	SQL	V0_5__CreateProgramEncounterTables.sql	2126472639	openchs	2023-06-19 03:05:07.547342	38	t
6	0.6	ObservationsWithoutPrograms	SQL	V0_6__ObservationsWithoutPrograms.sql	554876676	openchs	2023-06-19 03:05:07.610818	39	t
7	0.7	FormTables	SQL	V0_7__FormTables.sql	-1468350519	openchs	2023-06-19 03:05:07.670318	85	t
8	0.8	RenameDateOfBirthEstimatedToVerified	SQL	V0_8__RenameDateOfBirthEstimatedToVerified.sql	1314036102	openchs	2023-06-19 03:05:07.772619	2	t
9	0.9	RenameColumnUsedInSummary	SQL	V0_9__RenameColumnUsedInSummary.sql	-423140476	openchs	2023-06-19 03:05:07.791956	3	t
10	0.10	CreateConceptAnswerTable	SQL	V0_10__CreateConceptAnswerTable.sql	-1142215842	openchs	2023-06-19 03:05:07.813382	25	t
11	0.11	DropColumnProfileFromIndividual	SQL	V0_11__DropColumnProfileFromIndividual.sql	1301592739	openchs	2023-06-19 03:05:07.860924	7	t
12	0.12	AddDisplayOrderToFormElementGroup	SQL	V0_12__AddDisplayOrderToFormElementGroup.sql	-1730594591	openchs	2023-06-19 03:05:07.89904	3	t
13	0.13	CreateTableForFormAssociation	SQL	V0_13__CreateTableForFormAssociation.sql	650093988	openchs	2023-06-19 03:05:07.927788	37	t
14	0.14	UniqueConstraints	SQL	V0_14__UniqueConstraints.sql	466108484	openchs	2023-06-19 03:05:08.006774	48	t
15	0.15	ChangeDataTypeOfRelatedEntity	SQL	V0_15__ChangeDataTypeOfRelatedEntity.sql	2099177607	openchs	2023-06-19 03:05:08.084352	6	t
16	0.16	ChangeSortOrderDataTypeAndAddUniqueConstraint	SQL	V0_16__ChangeSortOrderDataTypeAndAddUniqueConstraint.sql	1421640915	openchs	2023-06-19 03:05:08.115589	6	t
17	0.17	UniqueConstraintOnConceptName	SQL	V0_17__UniqueConstraintOnConceptName.sql	2068071747	openchs	2023-06-19 03:05:08.146819	6	t
18	0.18	CreateGenderConcepts	SQL	V0_18__CreateGenderConcepts.sql	624445853	openchs	2023-06-19 03:05:08.178682	14	t
19	0.19	CreateGenderConceptWithAnswers	SQL	V0_19__CreateGenderConceptWithAnswers.sql	-1501805504	openchs	2023-06-19 03:05:08.216982	12	t
20	0.20	UniqueConstraintOnGender	SQL	V0_20__UniqueConstraintOnGender.sql	-1214262700	openchs	2023-06-19 03:05:08.257452	8	t
21	0.21	RemoveFollowupTypeAndUseEncounterType	SQL	V0_21__RemoveFollowupTypeAndUseEncounterType.sql	-436069503	openchs	2023-06-19 03:05:08.289384	13	t
22	0.22	AddObservationsTypeEntityId	SQL	V0_22__AddObservationsTypeEntityId.sql	-1927448004	openchs	2023-06-19 03:05:08.326361	6	t
23	0.23	RenameProgramEncounterDateTime	SQL	V0_23__RenameProgramEncounterDateTime.sql	-2121432657	openchs	2023-06-19 03:05:08.35573	5	t
24	0.24	AddRegistrationDateToIndividual	SQL	V0_24__AddRegistrationDateToIndividual.sql	1230410355	openchs	2023-06-19 03:05:08.383558	6	t
25	0.25	AddNameToProgramEncounter	SQL	V0_25__AddNameToProgramEncounter.sql	418869244	openchs	2023-06-19 03:05:08.40987	4	t
26	0.26	AddMaxDateForProgramEncounter	SQL	V0_26__AddMaxDateForProgramEncounter.sql	-1453668778	openchs	2023-06-19 03:05:08.439547	9	t
27	0.27	HealthMetaDataVersion	SQL	V0_27__HealthMetaDataVersion.sql	-1199562630	openchs	2023-06-19 03:05:08.474115	15	t
28	0.28	RenameSpellingMistakeInTableName	SQL	V0_28__RenameSpellingMistakeInTableName.sql	-520504467	openchs	2023-06-19 03:05:08.510428	3	t
29	0.29	CreateChecklistTables	SQL	V0_29__CreateChecklistTables.sql	1735055931	openchs	2023-06-19 03:05:08.538854	35	t
30	0.30	MakingUniqueConstraintsDeferred	SQL	V0_30__MakingUniqueConstraintsDeferred.sql	1842893321	openchs	2023-06-19 03:05:08.594875	18	t
31	0.31	CreateBaseDate	SQL	V0_31__CreateBaseDate.sql	1101091756	openchs	2023-06-19 03:05:08.6283	3	t
32	0.32	RenameObservationColumns	SQL	V0_32__RenameObservationColumns.sql	1180023750	openchs	2023-06-19 03:05:08.648407	2	t
33	0.33	AddUnitToConcept	SQL	V0_33__AddUnitToConcept.sql	176295804	openchs	2023-06-19 03:05:08.668459	2	t
34	0.34	CreateCatchmentAndMappingTable	SQL	V0_34__CreateCatchmentAndMappingTable.sql	-1566624789	openchs	2023-06-19 03:05:08.687456	36	t
35	0.35	DropCatchmentFromIndividual	SQL	V0_35__DropCatchmentFromIndividual.sql	-903838888	openchs	2023-06-19 03:05:08.744331	5	t
36	0.36	AddColumnDisplayToFormElementGroup	SQL	V0_36__AddColumnDisplayToFormElementGroup.sql	-141629419	openchs	2023-06-19 03:05:08.76225	4	t
37	0.37	AddColumnColourToProgram	SQL	V0_37__AddColumnColourToProgram.sql	1917154220	openchs	2023-06-19 03:05:08.782917	3	t
38	0.38	DropMetaColumnsFromCatchmentAddressMapping	SQL	V0_38__DropMetaColumnsFromCatchmentAddressMapping.sql	1049144005	openchs	2023-06-19 03:05:08.797354	3	t
39	0.39	AddUniqueConstaintWhereItIsMissing	SQL	V0_39__AddUniqueConstaintWhereItIsMissing.sql	1553509046	openchs	2023-06-19 03:05:08.81887	44	t
40	0.40	AddingAddressLevelAttributes	SQL	V0_40__AddingAddressLevelAttributes.sql	-997896356	openchs	2023-06-19 03:05:08.8798	3	t
41	0.41	Organisations	SQL	V0_41__Organisations.sql	-698994054	openchs	2023-06-19 03:05:08.895877	41	t
42	0.42	Multitenancy	SQL	V0_42__Multitenancy.sql	886526685	openchs	2023-06-19 03:05:08.948811	30	t
43	0.43	AddAbnormalToConceptAnswer	SQL	V0_43__AddAbnormalToConceptAnswer.sql	1978512101	openchs	2023-06-19 03:05:08.994193	6	t
44	0.44	ProgramsSpecificToACustomer	SQL	V0_44__ProgramsSpecificToACustomer.sql	-1257243972	openchs	2023-06-19 03:05:09.014133	12	t
45	0.45	AddMultitenancy ProgramsSpecificToACustomer	SQL	V0_45__AddMultitenancy_ProgramsSpecificToACustomer.sql	1688167973	openchs	2023-06-19 03:05:09.040153	7	t
46	0.46	ReplaceNameWithFirstAndLastNames	SQL	V0_46__ReplaceNameWithFirstAndLastNames.sql	2115534139	openchs	2023-06-19 03:05:09.061204	4	t
47	0.47	AddingFormElementType	SQL	V0_47__AddingFormElementType.sql	-1524900904	openchs	2023-06-19 03:05:09.077685	4	t
48	0.48	SplitScheduledDateIntoMinAndMaxDates	SQL	V0_48__SplitScheduledDateIntoMinAndMaxDates.sql	-1370947884	openchs	2023-06-19 03:05:09.095542	2	t
49	0.49	AddValidFormatRegexAndMessageKeyToFormElement	SQL	V0_49__AddValidFormatRegexAndMessageKeyToFormElement.sql	1988385366	openchs	2023-06-19 03:05:09.110542	4	t
50	0.50	AddingTypeToCatchments	SQL	V0_50__AddingTypeToCatchments.sql	-533065888	openchs	2023-06-19 03:05:09.130224	4	t
51	0.51	AddingTypeToAddressLevel	SQL	V0_51__AddingTypeToAddressLevel.sql	-1147025983	openchs	2023-06-19 03:05:09.152244	3	t
52	0.52	AddressLevelOnIndividualIsMandatory	SQL	V0_52__AddressLevelOnIndividualIsMandatory.sql	1531868730	openchs	2023-06-19 03:05:09.169102	2	t
53	0.53	AddUniqueConstraintToOrganisation	SQL	V0_53__AddUniqueConstraintToOrganisation.sql	-40365443	openchs	2023-06-19 03:05:09.189403	15	t
54	0.54	AddCancelToProgramEncounter	SQL	V0_54__AddCancelToProgramEncounter.sql	-441902374	openchs	2023-06-19 03:05:09.214988	22	t
55	1.01	AddVoidingToConcepts	SQL	V1_01__AddVoidingToConcepts.sql	250061624	openchs	2023-06-19 03:05:09.253837	4	t
56	1.02	AddVoidedToEncounters	SQL	V1_02__AddVoidedToEncounters.sql	-60830572	openchs	2023-06-19 03:05:09.269564	4	t
57	1.03	AddGinIndexForObservations	SQL	V1_03__AddGinIndexForObservations.sql	-861966596	openchs	2023-06-19 03:05:09.286635	5	t
58	1.04	AddVoidedToIndividual	SQL	V1_04__AddVoidedToIndividual.sql	-403634913	openchs	2023-06-19 03:05:09.308659	2	t
59	1.04.5	AddHierarchyToOrganisations	SQL	V1_04.5__AddHierarchyToOrganisations.sql	2036376580	openchs	2023-06-19 03:05:09.324505	4	t
60	1.04.6	RevisitPoliciesForMultitenancy	SQL	V1_04.6__RevisitPoliciesForMultitenancy.sql	258035259	openchs	2023-06-19 03:05:09.346275	47	t
61	1.05	DisplayOrderToFloat	SQL	V1_05__DisplayOrderToFloat.sql	-1836162603	openchs	2023-06-19 03:05:09.408597	30	t
62	1.06	DropIsUsedInSummaryColumnInFormElement	SQL	V1_06__DropIsUsedInSummaryColumnInFormElement.sql	-7965232	openchs	2023-06-19 03:05:09.448636	4	t
63	1.07	DropIsGeneratedColumnInFormElement	SQL	V1_07__DropIsGeneratedColumnInFormElement.sql	1878290041	openchs	2023-06-19 03:05:09.466656	4	t
64	1.08	NonApplicableOrganisationEntityMapping	SQL	V1_08__NonApplicableOrganisationEntityMapping.sql	93775699	openchs	2023-06-19 03:05:09.491509	11	t
65	1.09	MigrateConceptDataType	SQL	V1_09__MigrateConceptDataType.sql	663754657	openchs	2023-06-19 03:05:09.515085	3	t
66	1.10	AddPolicyToNonApplicableFormElementTable	SQL	V1_10__AddPolicyToNonApplicableFormElementTable.sql	1160209650	openchs	2023-06-19 03:05:09.530002	5	t
67	1.11	RevisitPoliciesForMultitenancy	SQL	V1_11__RevisitPoliciesForMultitenancy.sql	2018671290	openchs	2023-06-19 03:05:09.54755	4	t
68	1.12	ProgramOrganisationConfigTable	SQL	V1_12__ProgramOrganisationConfigTable.sql	-1677454136	openchs	2023-06-19 03:05:09.5651	20	t
69	1.13	AddSoloFieldToConceptAnswer	SQL	V1_13__AddSoloFieldToConceptAnswer.sql	1784600157	openchs	2023-06-19 03:05:09.605404	2	t
70	1.14	DisableChildrenFromUpdatingParent	SQL	V1_14__DisableChildrenFromUpdatingParent.sql	37126482	openchs	2023-06-19 03:05:09.618794	40	t
71	1.15	ActualSqlForV1 14	SQL	V1_15__ActualSqlForV1_14.sql	-1197563688	openchs	2023-06-19 03:05:09.674208	28	t
72	1.16	DeletingOrgIDFromCatchmentAddressMapping	SQL	V1_16__DeletingOrgIDFromCatchmentAddressMapping.sql	-562767235	openchs	2023-06-19 03:05:09.713687	4	t
73	1.17	MoveAuditToNewTable	SQL	V1_17__MoveAuditToNewTable.sql	201601109	openchs	2023-06-19 03:05:09.73274	97	t
74	1.18	DisableRowLevelSecurityForCatchmentAddressMapping	SQL	V1_18__DisableRowLevelSecurityForCatchmentAddressMapping.sql	-209752374	openchs	2023-06-19 03:05:09.842177	1	t
75	1.19	RemoveStrictPolicieForFormElement	SQL	V1_19__RemoveStrictPolicieForFormElement.sql	962987074	openchs	2023-06-19 03:05:09.851714	2	t
76	1.20	AddVoidedToFormElementAndFormElementGroup	SQL	V1_20__AddVoidedToFormElementAndFormElementGroup.sql	717328699	openchs	2023-06-19 03:05:09.866093	4	t
77	1.21	RemoveConceptIdFromProgram	SQL	V1_21__RemoveConceptIdFromProgram.sql	-1967176069	openchs	2023-06-19 03:05:09.881283	3	t
78	1.22	AddForeignKeyConstraintsToAuditedTables	SQL	V1_22__AddForeignKeyConstraintsToAuditedTables.sql	-741297534	openchs	2023-06-19 03:05:09.898753	36	t
79	1.23	AddOrganisationIdToFormElementDisplayOrderUniqueConstraint	SQL	V1_23__AddOrganisationIdToFormElementDisplayOrderUniqueConstraint.sql	-1001383089	openchs	2023-06-19 03:05:09.95737	15	t
80	1.24	AddVoidedToEncounterTypesAndFormMapping	SQL	V1_24__AddVoidedToEncounterTypesAndFormMapping.sql	-1070689411	openchs	2023-06-19 03:05:09.984611	7	t
81	1.25	AddRelationAndRelative	SQL	V1_25__AddRelationAndRelative.sql	-2103441582	openchs	2023-06-19 03:05:10.007109	32	t
82	1.26	AddReverseRelation	SQL	V1_26__AddReverseRelation.sql	1892977804	openchs	2023-06-19 03:05:10.052485	30	t
83	1.27	AddRelationshipTables	SQL	V1_27__AddRelationshipTables.sql	2112942025	openchs	2023-06-19 03:05:10.097021	69	t
84	1.28	UpdateLastModifiedDateTimeForNumericConcepts	SQL	V1_28__UpdateLastModifiedDateTimeForNumericConcepts.sql	441081105	openchs	2023-06-19 03:05:10.179066	2	t
85	1.29	RemoveRLSFromUsers	SQL	V1_29__RemoveRLSFromUsers.sql	-1272706063	openchs	2023-06-19 03:05:10.194416	4	t
86	1.30	RevertPolicyRelaxingInFormElement Users Catchment	SQL	V1_30__RevertPolicyRelaxingInFormElement_Users_Catchment.sql	-1905327745	openchs	2023-06-19 03:05:10.211328	8	t
87	1.31	AddRuleRelatedTables	SQL	V1_31__AddRuleRelatedTables.sql	-1112075058	openchs	2023-06-19 03:05:10.231624	22	t
88	1.40	RenamingOpenCHSUserToAdmin	SQL	V1_40__RenamingOpenCHSUserToAdmin.sql	435465816	openchs	2023-06-19 03:05:10.269887	2	t
89	1.41	AddAuditColumnsToUser	SQL	V1_41__AddAuditColumnsToUser.sql	-1540216253	openchs	2023-06-19 03:05:10.287666	7	t
90	1.42	DropColumnVersionFromUsers	SQL	V1_42__DropColumnVersionFromUsers.sql	-1736278593	openchs	2023-06-19 03:05:10.310072	5	t
91	1.43	DropColumnAuditIdFromUsers	SQL	V1_43__DropColumnAuditIdFromUsers.sql	2048999647	openchs	2023-06-19 03:05:10.32715	3	t
92	1.44	AddingOrganisationLevelUniqueConstraintToRuleNames	SQL	V1_44__AddingOrganisationLevelUniqueConstraintToRuleNames.sql	-205710553	openchs	2023-06-19 03:05:10.341618	13	t
93	1.45	DefaultingExecutionOrderToMax	SQL	V1_45__DefaultingExecutionOrderToMax.sql	-1515613199	openchs	2023-06-19 03:05:10.365937	3	t
94	1.46	DroppingNotNullConstraintOnRules	SQL	V1_46__DroppingNotNullConstraintOnRules.sql	-1460305777	openchs	2023-06-19 03:05:10.381364	2	t
95	1.47	AddNameToOperationProgramsAndEncounterTypes	SQL	V1_47__AddNameToOperationProgramsAndEncounterTypes.sql	-1768305558	openchs	2023-06-19 03:05:10.396046	12	t
96	1.48	AddingVoidingCapabilityToRules	SQL	V1_48__AddingVoidingCapabilityToRules.sql	-724654493	openchs	2023-06-19 03:05:10.420173	1	t
97	1.49	AddingVoidingCapabilityToRemainingEntities	SQL	V1_49__AddingVoidingCapabilityToRemainingEntities.sql	-384782867	openchs	2023-06-19 03:05:10.43585	17	t
98	1.50	AddVoidingToProgramEnrolment	SQL	V1_50__AddVoidingToProgramEnrolment.sql	-149556715	openchs	2023-06-19 03:05:10.468811	2	t
99	1.51	AddVoidingToChecklistItem	SQL	V1_51__AddVoidingToChecklistItem.sql	2039923730	openchs	2023-06-19 03:05:10.486309	2	t
100	1.52	AnswerOrderInConceptAnswerIsDouble	SQL	V1_52__AnswerOrderInConceptAnswerIsDouble.sql	1719161713	openchs	2023-06-19 03:05:10.503253	14	t
101	1.53	AddMultiTenancyToRuleTables	SQL	V1_53__AddMultiTenancyToRuleTables.sql	-960742974	openchs	2023-06-19 03:05:10.536432	5	t
102	1.54	EnableRLSOnNewTables	SQL	V1_54__EnableRLSOnNewTables.sql	406108909	openchs	2023-06-19 03:05:10.557287	5	t
103	1.55	ModifyingChecklistItemSchema	SQL	V1_55__ModifyingChecklistItemSchema.sql	-1648484371	openchs	2023-06-19 03:05:10.578401	9	t
104	1.56	ModifyingChecklistItemSchema	SQL	V1_56__ModifyingChecklistItemSchema.sql	-749679445	openchs	2023-06-19 03:05:10.601804	5	t
105	1.57	AddingChecklistReferenceTables	SQL	V1_57__AddingChecklistReferenceTables.sql	-1847469194	openchs	2023-06-19 03:05:10.620895	38	t
106	1.58	AllowVoidingOfNonApplicableFormElements	SQL	V1_58__AllowVoidingOfNonApplicableFormElements.sql	-876113176	openchs	2023-06-19 03:05:10.676271	8	t
107	1.59	AddingMultiTenancyToChecklistTables	SQL	V1_59__AddingMultiTenancyToChecklistTables.sql	-1268487144	openchs	2023-06-19 03:05:10.697796	9	t
108	1.59.1	UpdateConceptUniqueKeyConstraintToIncludeOrg	SQL	V1_59.1__UpdateConceptUniqueKeyConstraintToIncludeOrg.sql	-519108521	openchs	2023-06-19 03:05:10.718696	10	t
109	1.60	CreateLocationToLocationParentMapping	SQL	V1_60__CreateLocationToLocationParentMapping.sql	-1047050298	openchs	2023-06-19 03:05:10.743796	22	t
110	1.61	CreateFacility	SQL	V1_61__CreateFacility.sql	-1898188175	openchs	2023-06-19 03:05:10.781805	16	t
111	1.62	UserFacilityIndividualMapping	SQL	V1_62__UserFacilityIndividualMapping.sql	1057518812	openchs	2023-06-19 03:05:10.81629	15	t
112	1.63	RemoveInvalidFormElementTypes	SQL	V1_63__RemoveInvalidFormElementTypes.sql	-519375708	openchs	2023-06-19 03:05:10.848409	5	t
113	1.64	MigrateLevelToADouble	SQL	V1_64__MigrateLevelToADouble.sql	-354153816	openchs	2023-06-19 03:05:10.871604	19	t
114	1.64.5	CreateNecessaryViewsForAddressLevel	SQL	V1_64.5__CreateNecessaryViewsForAddressLevel.sql	-1284912256	openchs	2023-06-19 03:05:10.908903	32	t
115	1.65	CreateAddressLevelType	SQL	V1_65__CreateAddressLevelType.sql	-773824940	openchs	2023-06-19 03:05:10.95659	10	t
116	1.66	AssociateRLSPoliciesToAddressLevelType	SQL	V1_66__AssociateRLSPoliciesToAddressLevelType.sql	-1935992107	openchs	2023-06-19 03:05:10.981151	7	t
117	1.67	AddUserColumns	SQL	V1_67__AddUserColumns.sql	-1813909293	openchs	2023-06-19 03:05:10.999538	5	t
118	1.68	MakeUserColumnsNotNullable	SQL	V1_68__MakeUserColumnsNotNullable.sql	-829109358	openchs	2023-06-19 03:05:11.020212	4	t
119	1.69	UserFacilityMappingNotNullColumns	SQL	V1_69__UserFacilityMappingNotNullColumns.sql	-686386027	openchs	2023-06-19 03:05:11.041026	3	t
120	1.70	ProgramOrganisationConfigConcept	SQL	V1_70__ProgramOrganisationConfigConcept.sql	1175588546	openchs	2023-06-19 03:05:11.062789	12	t
121	1.71	AddOperatingIndividualScopeToUsers	SQL	V1_71__AddOperatingIndividualScopeToUsers.sql	1278385804	openchs	2023-06-19 03:05:11.086367	8	t
122	1.72	CatchmentIsMandatoryConditionally	SQL	V1_72__CatchmentIsMandatoryConditionally.sql	-866874235	openchs	2023-06-19 03:05:11.108501	12	t
123	1.73	SetAdminUserRoles	SQL	V1_73__SetAdminUserRoles.sql	-2085906778	openchs	2023-06-19 03:05:11.134586	4	t
124	1.73.1	ChangeTypeTimestampToTimestampTZForAuditCreatedDateTimeAndLastModifiedDateTime	SQL	V1_73_1__ChangeTypeTimestampToTimestampTZForAuditCreatedDateTimeAndLastModifiedDateTime.sql	1549749339	openchs	2023-06-19 03:05:11.153463	12	t
125	1.74	AddingChecklistItemInterdependency	SQL	V1_74__AddingChecklistItemInterdependency.sql	867864144	openchs	2023-06-19 03:05:11.17912	5	t
126	1.75	UpdateAuditWhenLastModifiedDateTimeIsInFuture	SQL	V1_75__UpdateAuditWhenLastModifiedDateTimeIsInFuture.sql	-1437880031	openchs	2023-06-19 03:05:11.202848	2	t
127	1.76	CreateProgramRule	SQL	V1_76__CreateProgramRule.sql	-1553662238	openchs	2023-06-19 03:05:11.223607	23	t
128	1.77	CreateVideoTable	SQL	V1_77__CreateVideoTable.sql	667556661	openchs	2023-06-19 03:05:11.26297	19	t
129	1.78	CreateVideoTelemetricTable	SQL	V1_78__CreateVideoTelemetricTable.sql	1433562913	openchs	2023-06-19 03:05:11.296684	15	t
130	1.79	AddUniqueConstraintOn AddressLevel title and level	SQL	V1_79__AddUniqueConstraintOn_AddressLevel_title_and_level.sql	-1646303530	openchs	2023-06-19 03:05:11.32843	8	t
131	1.80	AddScheduleOnExpiryOfDependencyToChecklistItemDetail	SQL	V1_80__AddScheduleOnExpiryOfDependencyToChecklistItemDetail.sql	-2019739920	openchs	2023-06-19 03:05:11.354624	5	t
132	1.81	AddMediaDirectoryToOrganisation	SQL	V1_81__AddMediaDirectoryToOrganisation.sql	-933221874	openchs	2023-06-19 03:05:11.374497	14	t
133	1.82	AddMinDaysFromStartDateToChecklistItemDetail	SQL	V1_82__AddMinDaysFromStartDateToChecklistItemDetail.sql	1110824284	openchs	2023-06-19 03:05:11.405948	6	t
134	1.83	AddRegistrationLocationToIndividual	SQL	V1_83__AddRegistrationLocationToIndividual.sql	-367031038	openchs	2023-06-19 03:05:11.429498	6	t
135	1.84	AddLocationFieldsToProgramEnrolment	SQL	V1_84__AddLocationFieldsToProgramEnrolment.sql	1744711160	openchs	2023-06-19 03:05:11.452974	5	t
136	1.85	AddLocationFieldsToProgramEncounter	SQL	V1_85__AddLocationFieldsToProgramEncounter.sql	998632110	openchs	2023-06-19 03:05:11.477815	7	t
137	1.86	AddLocationFieldsToEncounter	SQL	V1_86__AddLocationFieldsToEncounter.sql	-1413895738	openchs	2023-06-19 03:05:11.503088	3	t
138	1.87	AddSubjectTypes	SQL	V1_87__AddSubjectTypes.sql	-101792742	openchs	2023-06-19 03:05:11.525418	49	t
139	1.88	IndividualToPointToSubjectType	SQL	V1_88__IndividualToPointToSubjectType.sql	-447763604	openchs	2023-06-19 03:05:11.594377	13	t
140	1.89	UpdateUniqueConstraintAs Title Level OrgId On AddressLevel	SQL	V1_89__UpdateUniqueConstraintAs_Title_Level_OrgId_On_AddressLevel.sql	1350705938	openchs	2023-06-19 03:05:11.623297	3	t
141	1.90	EnableRowLevelSecurityOnProgramOrganisationConfig	SQL	V1_90__EnableRowLevelSecurityOnProgramOrganisationConfig.sql	-546268704	openchs	2023-06-19 03:05:11.639583	2	t
142	1.91	CreateUserSettingsTable	SQL	V1_91__CreateUserSettingsTable.sql	-1943088164	openchs	2023-06-19 03:05:11.65675	15	t
143	1.92	AddSettingsColumnToUsersTable	SQL	V1_92__AddSettingsColumnToUsersTable.sql	1899078484	openchs	2023-06-19 03:05:11.683321	3	t
144	1.93	DropUserSettingsTable	SQL	V1_93__DropUserSettingsTable.sql	2042306745	openchs	2023-06-19 03:05:11.701627	8	t
145	1.93.1	AddOrganisationIdToGenderTable	SQL	V1_93_1__AddOrganisationIdToGenderTable.sql	-1818688013	openchs	2023-06-19 03:05:11.723619	7	t
146	1.93.2	EnableRLS OnAllTables	SQL	V1_93_2__EnableRLS_OnAllTables.sql	1051847878	openchs	2023-06-19 03:05:11.742983	24	t
147	1.93.3	Create openchs impl	SQL	V1_93_3__Create_openchs_impl.sql	1822757547	openchs	2023-06-19 03:05:11.779921	5	t
148	1.93.4	SetPolicyForUsersTable	SQL	V1_93_4__SetPolicyForUsersTable.sql	-1248590332	openchs	2023-06-19 03:05:11.798168	8	t
149	1.93.5	AddIndicesToOrganisationId	SQL	V1_93_5__AddIndicesToOrganisationId.sql	-880506410	openchs	2023-06-19 03:05:11.821954	210	t
150	1.94	FunctionToCreateOrgDBUser	SQL	V1_94__FunctionToCreateOrgDBUser.sql	345745916	openchs	2023-06-19 03:05:12.04471	4	t
151	1.95	AddEmailAndPhoneToUser	SQL	V1_95__AddEmailAndPhoneToUser.sql	-1769939210	openchs	2023-06-19 03:05:12.063209	6	t
152	1.96	CreateSyncTelemetryTable	SQL	V1_96__CreateSyncTelemetryTable.sql	-1720066759	openchs	2023-06-19 03:05:12.083603	18	t
153	1.97	AddColumnsToSyncTelemetryTable	SQL	V1_97__AddColumnsToSyncTelemetryTable.sql	-90397670	openchs	2023-06-19 03:05:12.116869	3	t
154	1.98	RenameUsernameAndAddNameInUserTable	SQL	V1_98__RenameUsernameAndAddNameInUserTable.sql	-444810637	openchs	2023-06-19 03:05:12.132169	4	t
155	1.99	CreateIdentifierTables	SQL	V1_99__CreateIdentifierTables.sql	-562392561	openchs	2023-06-19 03:05:12.148196	59	t
156	1.100	AddColumnsToChecklistItemDetail	SQL	V1_100__AddColumnsToChecklistItemDetail.sql	-419766127	openchs	2023-06-19 03:05:12.22007	3	t
157	1.101	EnableRLS OnAddressLevelType	SQL	V1_101__EnableRLS_OnAddressLevelType.sql	-1598449286	openchs	2023-06-19 03:05:12.23841	3	t
158	1.102	AddIndicesToOrganisationId	SQL	V1_102__AddIndicesToOrganisationId.sql	1125452490	openchs	2023-06-19 03:05:12.255406	148	t
159	1.103	AddMissingIndices	SQL	V1_103__AddMissingIndices.sql	1311458220	openchs	2023-06-19 03:05:12.417785	37	t
160	1.104	AddColumnsToIdntifierSourceTable	SQL	V1_104__AddColumnsToIdntifierSourceTable.sql	73487457	openchs	2023-06-19 03:05:12.467556	4	t
161	1.105	DropSchedulingConstraintOnProgramEncounter	SQL	V1_105__DropSchedulingConstraintOnProgramEncounter.sql	739346240	openchs	2023-06-19 03:05:12.484099	2	t
162	1.107	DropAndModifyRLSPolicies	SQL	V1_107__DropAndModifyRLSPolicies.sql	317002761	openchs	2023-06-19 03:05:12.506612	36	t
163	1.108	ConvertTimestampTypeColumnsToTimestampWithTimeZoneType	SQL	V1_108__ConvertTimestampTypeColumnsToTimestampWithTimeZoneType.sql	1080401303	openchs	2023-06-19 03:05:12.559047	25	t
164	1.109	AddProgramSubjectLabelColumnToOperationalProgram	SQL	V1_109__AddProgramSubjectLabelColumnToOperationalProgram.sql	-363354595	openchs	2023-06-19 03:05:12.598018	4	t
165	1.111	AddLevelColumnToAddressLevelType	SQL	V1_111__AddLevelColumnToAddressLevelType.sql	1505441354	openchs	2023-06-19 03:05:12.617668	7	t
166	1.112	AddParentIdColumnToAddressLevelType	SQL	V1_112__AddParentIdColumnToAddressLevelType.sql	-1141440053	openchs	2023-06-19 03:05:12.640447	5	t
167	1.113	AddSubjectTypeToFormMapping	SQL	V1_113__AddSubjectTypeToFormMapping.sql	2123410715	openchs	2023-06-19 03:05:12.660435	12	t
168	1.114	AddParentColumnAndAlterLineageInLocation	SQL	V1_114__AddParentColumnAndAlterLineageInLocation.sql	-1496853378	openchs	2023-06-19 03:05:12.682682	11	t
169	1.115	AddEntityColumnToRuleTable	SQL	V1_115__AddEntityColumnToRuleTable.sql	52218720	openchs	2023-06-19 03:05:12.703846	22	t
170	1.116	AddNameParentUniqueConstraintToLocation	SQL	V1_116__AddNameParentUniqueConstraintToLocation.sql	196811631	openchs	2023-06-19 03:05:12.738601	5	t
171	1.117	AddUsernameSuffixToOrganisationTable	SQL	V1_117__AddUsernameSuffixToOrganisationTable.sql	1063295939	openchs	2023-06-19 03:05:12.760439	4	t
172	1.118	AddUniqueUUIDConstraintToVideo	SQL	V1_118__AddUniqueUUIDConstraintToVideo.sql	-708229522	openchs	2023-06-19 03:05:12.780189	6	t
173	1.119	CreateRuleFailureTelemetryTable	SQL	V1_119__CreateRuleFailureTelemetryTable.sql	-589057985	openchs	2023-06-19 03:05:12.798281	15	t
174	1.120	AddSchedulingRelatedColumnsToEncounterTable	SQL	V1_120__AddSchedulingRelatedColumnsToEncounterTable.sql	-272911783	openchs	2023-06-19 03:05:12.832978	4	t
175	1.121	AddDateTimeColumnToRuleFailureTelemetry	SQL	V1_121__AddDateTimeColumnToRuleFailureTelemetry.sql	88262135	openchs	2023-06-19 03:05:12.85132	8	t
176	1.122	CreateOrganisationConfigTable	SQL	V1_122__CreateOrganisationConfigTable.sql	496491893	openchs	2023-06-19 03:05:12.875454	20	t
177	1.123	AddAuditToOrganisationConfigTable	SQL	V1_123__AddAuditToOrganisationConfigTable.sql	1290806006	openchs	2023-06-19 03:05:12.911205	8	t
178	1.124	CreateTranslationTable	SQL	V1_124__CreateTranslationTable.sql	1130811360	openchs	2023-06-19 03:05:12.932192	14	t
179	1.125	CreatePlatformTranslationTable	SQL	V1_125__CreatePlatformTranslationTable.sql	1957335093	openchs	2023-06-19 03:05:12.956596	12	t
180	1.126	AddLanguageToTranslationTable	SQL	V1_126__AddLanguageToTranslationTable.sql	1279181139	openchs	2023-06-19 03:05:12.981393	5	t
181	1.127	AddLanguageToPlatformTranslationTable	SQL	V1_127__AddLanguageToPlatformTranslationTable.sql	2106552388	openchs	2023-06-19 03:05:12.999763	2	t
182	1.128	AddOrganisationIdToPlatformTranslationTable	SQL	V1_128__AddOrganisationIdToPlatformTranslationTable.sql	-1806730880	openchs	2023-06-19 03:05:13.014708	10	t
183	1.129	RemoveAuditFromPlatformTranslationTable	SQL	V1_129__RemoveAuditFromPlatformTranslationTable.sql	1075501879	openchs	2023-06-19 03:05:13.038824	7	t
184	1.130	CreateTablesForRulesFromUI	SQL	V1_130__CreateTablesForRulesFromUI.sql	-531458997	openchs	2023-06-19 03:05:13.055866	2	t
185	1.131	AddColulmsForRulesFromUI	SQL	V1_131__AddColulmsForRulesFromUI.sql	-1539591806	openchs	2023-06-19 03:05:13.076128	6	t
186	1.132	AddColulmsForRulesFromUI	SQL	V1_132__AddColulmsForRulesFromUI.sql	1816943734	openchs	2023-06-19 03:05:13.093526	3	t
187	1.133	UpdateOpenchsImplUserCreateScript	SQL	V1_133__UpdateOpenchsImplUserCreateScript.sql	1197713233	openchs	2023-06-19 03:05:13.113159	3	t
188	1.134	UpdateUniqueConstraintOnReferenceTables	SQL	V1_134__UpdateUniqueConstraintOnReferenceTables.sql	-1732538485	openchs	2023-06-19 03:05:13.128419	84	t
189	1.135	Openchs impl  userCanCreateRoles	SQL	V1_135__Openchs_impl__userCanCreateRoles.sql	-696814054	openchs	2023-06-19 03:05:13.224777	1	t
190	1.136	addKeyValuesToConcept	SQL	V1_136__addKeyValuesToConcept.sql	-2135200862	openchs	2023-06-19 03:05:13.239988	6	t
191	1.137	UpdateUniqueConstraintOnChecklistItemDetailTable	SQL	V1_137__UpdateUniqueConstraintOnChecklistItemDetailTable.sql	-1986431216	openchs	2023-06-19 03:05:13.268019	13	t
192	1.138	UpdateEncounterNameType	SQL	V1_138__UpdateEncounterNameType.sql	-1469604988	openchs	2023-06-19 03:05:13.301236	28	t
193	1.139	UpdateCreateDbUser	SQL	V1_139__UpdateCreateDbUser.sql	2072624922	openchs	2023-06-19 03:05:13.345466	10	t
194	1.140	DropChecklistRuleColumnFromProgramAddToForm	SQL	V1_140__DropChecklistRuleColumnFromProgramAddToForm.sql	2081702934	openchs	2023-06-19 03:05:13.367896	5	t
195	1.141	CreateWorkupdationRuleColumnInOrgConfig	SQL	V1_141__CreateWorkupdationRuleColumnInOrgConfig.sql	1076139085	openchs	2023-06-19 03:05:13.386423	3	t
196	1.142.1	CreateEntitiesForOrganisationGroup	SQL	V1_142.1__CreateEntitiesForOrganisationGroup.sql	1474847627	openchs	2023-06-19 03:05:13.400356	33	t
197	1.142.2	CreateNewRLSForAccount	SQL	V1_142.2__CreateNewRLSForAccount.sql	270333458	openchs	2023-06-19 03:05:13.449734	62	t
198	1.143	DropOrganisationNotNullConstraintFromUser	SQL	V1_143__DropOrganisationNotNullConstraintFromUser.sql	-1495802286	openchs	2023-06-19 03:05:13.525918	3	t
199	1.144	ChangeUserTableRLS	SQL	V1_144__ChangeUserTableRLS.sql	-235571865	openchs	2023-06-19 03:05:13.539305	4	t
200	1.145	UpdateDbUserFunction	SQL	V1_145__UpdateDbUserFunction.sql	-1806357283	openchs	2023-06-19 03:05:13.554818	2	t
201	1.146	DropFormIdNotNullConstraint	SQL	V1_146__DropFormIdNotNullConstraint.sql	833681352	openchs	2023-06-19 03:05:13.56939	2	t
202	1.147	CreateRolesAndPrivilegeTables	SQL	V1_147__CreateRolesAndPrivilegeTables.sql	1775959127	openchs	2023-06-19 03:05:13.582953	63	t
203	1.148	CreateSubjectGroupsRelatedTables	SQL	V1_148__CreateSubjectGroupsRelatedTables.sql	61224039	openchs	2023-06-19 03:05:13.660781	30	t
204	1.149	AddColumnIsHouseholdInSubjectType	SQL	V1_149__AddColumnIsHouseholdInSubjectType.sql	-48028424	openchs	2023-06-19 03:05:13.703721	4	t
205	1.150	DropFormNameNotNullConstraint	SQL	V1_150__DropFormNameNotNullConstraint.sql	1296356908	openchs	2023-06-19 03:05:13.724316	2	t
206	1.151	AddLegacyId	SQL	V1_151__AddLegacyId.sql	111842711	openchs	2023-06-19 03:05:13.739251	9	t
207	1.152	AddLegacyIdToProgramEnrolment	SQL	V1_152__AddLegacyIdToProgramEnrolment.sql	-2019471133	openchs	2023-06-19 03:05:13.759149	6	t
208	1.153	AddLegacyIdToEncounterTables	SQL	V1_153__AddLegacyIdToEncounterTables.sql	-1224193127	openchs	2023-06-19 03:05:13.778127	13	t
209	1.154	UpdateRolesAndPrivilegeTables	SQL	V1_154__UpdateRolesAndPrivilegeTables.sql	-1302719325	openchs	2023-06-19 03:05:13.802643	3	t
210	1.155	AddRuleColumnToFormElementGroup	SQL	V1_155__AddRuleColumnToFormElementGroup.sql	-2051288522	openchs	2023-06-19 03:05:13.821891	3	t
211	1.156	RuleFailureLogTable	SQL	V1_156__RuleFailureLogTable.sql	-748011860	openchs	2023-06-19 03:05:13.846812	21	t
212	1.157	AddActiveFlag	SQL	V1_157__AddActiveFlag.sql	-14920397	openchs	2023-06-19 03:05:13.883528	5	t
213	1.158	DropLevelColumnFromAddressLevel	SQL	V1_158__DropLevelColumnFromAddressLevel.sql	619023453	openchs	2023-06-19 03:05:13.906327	2	t
214	1.159	CreateIndexesOnForeignKeys	SQL	V1_159__CreateIndexesOnForeignKeys.sql	727175537	openchs	2023-06-19 03:05:13.924207	177	t
215	1.160	AddTypeToSubjectType	SQL	V1_160__AddTypeToSubjectType.sql	599065489	openchs	2023-06-19 03:05:14.115696	3	t
216	1.161	AlterIndividualRelationshipIdType	SQL	V1_161__AlterIndividualRelationshipIdType.sql	-1801330727	openchs	2023-06-19 03:05:14.134879	20	t
217	1.162	AddAuditToPlatformTranslations	SQL	V1_162__AddAuditToPlatformTranslations.sql	-1331722438	openchs	2023-06-19 03:05:14.170483	5	t
218	1.163	CreateSubjectSummaryRuleColumnInSubjectType	SQL	V1_163__CreateSubjectSummaryRuleColumnInSubjectType.sql	-745693715	openchs	2023-06-19 03:05:14.191523	5	t
219	1.164	RemoveRegisterSubjectPrivilegeWhereUserSettingIsHiderRegister	SQL	V1_164__RemoveRegisterSubjectPrivilegeWhereUserSettingIsHiderRegister.sql	-1065793363	openchs	2023-06-19 03:05:14.21311	5	t
220	1.165	CreateDashboardCardTables	SQL	V1_165__CreateDashboardCardTables.sql	-362652407	openchs	2023-06-19 03:05:14.235408	103	t
221	1.166	RenameCardToReportCard	SQL	V1_166__RenameCardToReportCard.sql	113683853	openchs	2023-06-19 03:05:14.351859	2	t
222	1.167	AddDeviceInfoColumnToSyncTelemetry	SQL	V1_167__AddDeviceInfoColumnToSyncTelemetry.sql	-983826135	openchs	2023-06-19 03:05:14.364862	2	t
223	1.168	CreateMsg91ConfigTable	SQL	V1_168__CreateMsg91ConfigTable.sql	-956879297	openchs	2023-06-19 03:05:14.378719	11	t
224	1.169	AddSchemaNameToOrganisation	SQL	V1_169__AddSchemaNameToOrganisation.sql	-1187694363	openchs	2023-06-19 03:05:14.399601	5	t
225	1.170	AddTablesForApprovalWorkflow	SQL	V1_170__AddTablesForApprovalWorkflow.sql	235607798	openchs	2023-06-19 03:05:14.41957	48	t
226	1.171	DecisionConcept	SQL	V1_171__DecisionConcept.sql	2109312080	openchs	2023-06-19 03:05:14.482253	9	t
227	1.172	AddIconColumnToReportCardTable	SQL	V1_172__AddIconColumnToReportCardTable.sql	-2100936328	openchs	2023-06-19 03:05:14.503338	2	t
228	1.173	AddStatusDateTimeColumnToEntityApprovalStatus	SQL	V1_173__AddStatusDateTimeColumnToEntityApprovalStatus.sql	-1622809580	openchs	2023-06-19 03:05:14.515791	4	t
229	1.173.1	AddDashboardSection	SQL	V1_173_1__AddDashboardSection.sql	-1895021098	openchs	2023-06-19 03:05:14.535617	39	t
230	1.174	AddMoreStandardReportCardTypes	SQL	V1_174__AddMoreStandardReportCardTypes.sql	232772714	openchs	2023-06-19 03:05:14.58507	4	t
231	1.175	VoidRejectPrivileges	SQL	V1_175__VoidRejectPrivileges.sql	-278880277	openchs	2023-06-19 03:05:14.602344	2	t
232	1.176	CreateNewsTables	SQL	V1_176__CreateNewsTables.sql	1810702970	openchs	2023-06-19 03:05:14.616903	18	t
233	1.177	AddGPSCordinatesAndLocationPropertiesToAddressLevel	SQL	V1_177__AddGPSCordinatesAndLocationPropertiesToAddressLevel.sql	-1524232625	openchs	2023-06-19 03:05:14.647859	2	t
234	1.178	CreateCommentTable	SQL	V1_178__CreateCommentTable.sql	1400423952	openchs	2023-06-19 03:05:14.663214	18	t
235	1.179	AllowRegistrationWithoutLocation	SQL	V1_179__AllowRegistrationWithoutLocation.sql	-2112911679	openchs	2023-06-19 03:05:14.694412	5	t
236	1.180	AddUniqueNameColumnToSubjectType	SQL	V1_180__AddUniqueNameColumnToSubjectType.sql	-987668377	openchs	2023-06-19 03:05:14.710286	6	t
237	1.181	AddNameRegExColumnsToSubjectType	SQL	V1_181__AddNameRegExColumnsToSubjectType.sql	-2144001562	openchs	2023-06-19 03:05:14.728443	5	t
238	1.182	AddCommentStandardReportCardType	SQL	V1_182__AddCommentStandardReportCardType.sql	-204897504	openchs	2023-06-19 03:05:14.747211	2	t
239	1.183	CreateCommentThreadTable	SQL	V1_183__CreateCommentThreadTable.sql	718987178	openchs	2023-06-19 03:05:14.763771	18	t
240	1.184	AddEnableApprovalToFormMapping	SQL	V1_184__AddEnableApprovalToFormMapping.sql	-1385491952	openchs	2023-06-19 03:05:14.793739	6	t
241	1.185	ReplaceRLSForOrganisationConfig	SQL	V1_185__ReplaceRLSForOrganisationConfig.sql	1872179045	openchs	2023-06-19 03:05:14.811719	6	t
242	1.186	RemovePrintSettingsFromOrgConfig	SQL	V1_186__RemovePrintSettingsFromOrgConfig.sql	-1219546178	openchs	2023-06-19 03:05:14.83312	2	t
243	1.187	ReplaceRLSForGroupDashboard	SQL	V1_187__ReplaceRLSForGroupDashboard.sql	1029226065	openchs	2023-06-19 03:05:14.8482	5	t
244	1.188	AddIconColumnToSubjectType	SQL	V1_188__AddIconColumnToSubjectType.sql	205896299	openchs	2023-06-19 03:05:14.866841	3	t
245	1.189	AddSyncSourceToSyncTelemetry	SQL	V1_189__AddSyncSourceToSyncTelemetry.sql	-392587034	openchs	2023-06-19 03:05:14.884914	2	t
246	1.190	AddUniqueConstraintForUuidAndOrganisationid	SQL	V1_190__AddUniqueConstraintForUuidAndOrganisationid.sql	1343776163	openchs	2023-06-19 03:05:14.901116	6	t
247	1.191	UpdateLastModifiedMillisecondToThreeDigits	SQL	V1_191__UpdateLastModifiedMillisecondToThreeDigits.sql	1162135556	openchs	2023-06-19 03:05:14.926157	8	t
248	1.192	CreateSubjectMigrationTable	SQL	V1_192__CreateSubjectMigrationTable.sql	2017976330	openchs	2023-06-19 03:05:14.949793	15	t
249	1.193	Make LastUpdatedDateTimeTo3DigitPrecision	SQL	V1_193__Make_LastUpdatedDateTimeTo3DigitPrecision.sql	-189480069	openchs	2023-06-19 03:05:14.980273	50	t
250	1.194	CreateAuditMigrateProcedure	SQL	V1_194__CreateAuditMigrateProcedure.sql	-873109702	openchs	2023-06-19 03:05:15.045639	5	t
251	1.195	MoveAuditColumnsToTables	SQL	V1_195__MoveAuditColumnsToTables.sql	1629054694	openchs	2023-06-19 03:05:15.063422	184	t
252	1.196	UpdateAuditValuesInAllTables	SQL	V1_196__UpdateAuditValuesInAllTables.sql	-1443535661	openchs	2023-06-19 03:05:15.265753	184	t
253	1.197	SolidifyAuditColumnsInTables	SQL	V1_197__SolidifyAuditColumnsInTables.sql	114835380	openchs	2023-06-19 03:05:15.467348	420	t
254	1.198	MoveAuditColumnsToSubjectMigrationTable	SQL	V1_198__MoveAuditColumnsToSubjectMigrationTable.sql	-516894264	openchs	2023-06-19 03:05:15.899756	15	t
255	1.199	CreateYearReviewTable	SQL	V1_199__CreateYearReviewTable.sql	847555589	openchs	2023-06-19 03:05:15.934475	17	t
256	1.200	SetErrorMessageFieldToText	SQL	V1_200__SetErrorMessageFieldToText.sql	-611720603	openchs	2023-06-19 03:05:15.965661	2	t
257	1.201	AddDeclarativeRuleToFormElement	SQL	V1_201__AddDeclarativeRuleToFormElement.sql	-1268439471	openchs	2023-06-19 03:05:15.982426	5	t
258	1.202	AddIndicesOnSyncTelemetry	SQL	V1_202__AddIndicesOnSyncTelemetry.sql	1317176643	openchs	2023-06-19 03:05:16.001108	7	t
259	1.203	AddDeclarativeRuleToFormElementGroup	SQL	V1_203__AddDeclarativeRuleToFormElementGroup.sql	1303498055	openchs	2023-06-19 03:05:16.01778	2	t
260	1.204	AddDeclarativeRuleForEligibility	SQL	V1_204__AddDeclarativeRuleForEligibility.sql	843212814	openchs	2023-06-19 03:05:16.032729	3	t
261	1.205	AddDeclarativeRuleInForm	SQL	V1_205__AddDeclarativeRuleInForm.sql	1291463961	openchs	2023-06-19 03:05:16.049104	4	t
262	1.206	AddGroupInFormElement	SQL	V1_206__AddGroupInFormElement.sql	-1665191202	openchs	2023-06-19 03:05:16.066525	4	t
263	1.208	NewColumnsForMultipleSyncStrategies	SQL	V1_208__NewColumnsForMultipleSyncStrategies.sql	695738839	openchs	2023-06-19 03:05:16.086529	20	t
264	1.209	DeleteFacilityTable	SQL	V1_209__DeleteFacilityTable.sql	1951402493	openchs	2023-06-19 03:05:16.122358	9	t
265	1.210	DropNullConstraintOnAddressIds	SQL	V1_210__DropNullConstraintOnAddressIds.sql	517163827	openchs	2023-06-19 03:05:16.145985	9	t
266	1.211	DropDefaultOnSyncAttributeUsablity	SQL	V1_211__DropDefaultOnSyncAttributeUsablity.sql	-487498243	openchs	2023-06-19 03:05:16.167825	4	t
267	1.212	AddSchemaNameToOrganisationGroup	SQL	V1_212__AddSchemaNameToOrganisationGroup.sql	-965515547	openchs	2023-06-19 03:05:16.182937	5	t
268	1.213	AddAnalyticsDBFeatureToggle	SQL	V1_213__AddAnalyticsDBFeatureToggle.sql	48625229	openchs	2023-06-19 03:05:16.201106	5	t
269	1.214	AddAnalyticsRelatedTabled	SQL	V1_214__AddAnalyticsRelatedTabled.sql	1878199862	openchs	2023-06-19 03:05:16.218632	44	t
270	1.215	AddIndexToEntityApprovalStatus	SQL	V1_215__AddIndexToEntityApprovalStatus.sql	-1045080517	openchs	2023-06-19 03:05:16.279859	12	t
271	1.216	CreateAnswerConceptMigrationTable	SQL	V1_216__CreateAnswerConceptMigrationTable.sql	343768500	openchs	2023-06-19 03:05:16.304386	15	t
272	1.217	AddSchemaNameToTableMetadata	SQL	V1_217__AddSchemaNameToTableMetadata.sql	1361643080	openchs	2023-06-19 03:05:16.333387	3	t
273	1.218	ChangeIdColumnsToUuids	SQL	V1_218__ChangeIdColumnsToUuids.sql	-1784966653	openchs	2023-06-19 03:05:16.348877	8	t
274	1.219	AddNotNullConstraintToAddressIdIndividualId	SQL	V1_219__AddNotNullConstraintToAddressIdIndividualId.sql	-807625869	openchs	2023-06-19 03:05:16.370807	5	t
275	1.220	AddIndexMetadataTable	SQL	V1_220__AddIndexMetadataTable.sql	-173246310	openchs	2023-06-19 03:05:16.388528	10	t
276	1.221	AddParentConceptUuidToColumnMetadata	SQL	V1_221__AddParentConceptUuidToColumnMetadata.sql	-1823839981	openchs	2023-06-19 03:05:16.414411	4	t
277	1.222	CreateUserSubjectAssignmentTable	SQL	V1_222__CreateUserSubjectAssignmentTable.sql	-588308583	openchs	2023-06-19 03:05:16.43317	26	t
278	1.223	AddNameHelpTextToSubjectType	SQL	V1_223__AddNameHelpTextToSubjectType.sql	-613516642	openchs	2023-06-19 03:05:16.470264	2	t
279	1.224	AddLegacyIdToAddressLevel	SQL	V1_224__AddLegacyIdToAddressLevel.sql	-1747962642	openchs	2023-06-19 03:05:16.483863	10	t
280	1.226	AddProfilePictureInfoToTables	SQL	V1_226__AddProfilePictureInfoToTables.sql	790001700	openchs	2023-06-19 03:05:16.509769	2	t
281	1.227	AddSchemaColumnToEntitySyncStatus	SQL	V1_227__AddSchemaColumnToEntitySyncStatus.sql	1321682638	openchs	2023-06-19 03:05:16.52816	2	t
282	1.227.4	AddSchemaColumnToEntitySyncStatus	SQL	V1_227.4__AddSchemaColumnToEntitySyncStatus.sql	-2055395260	openchs	2023-06-19 03:05:16.540744	13	t
283	1.227.5	AddLegacyIdIndexes	SQL	V1_227.5__AddLegacyIdIndexes.sql	1573719500	openchs	2023-06-19 03:05:16.56609	14	t
284	1.228	CreateResetSyncTable	SQL	V1_228__CreateResetSyncTable.sql	-136648558	openchs	2023-06-19 03:05:16.591488	20	t
285	1.229	CreateDocumentationTables	SQL	V1_229__CreateDocumentationTables.sql	-134325756	openchs	2023-06-19 03:05:16.628375	55	t
286	1.230	MergeDocumentationAndDocumentationNodeTables	SQL	V1_230__MergeDocumentationAndDocumentationNodeTables.sql	153794238	openchs	2023-06-19 03:05:16.698514	10	t
287	1.231	AddTimedQuestionRelatedColumns	SQL	V1_231__AddTimedQuestionRelatedColumns.sql	-1621725371	openchs	2023-06-19 03:05:16.724777	4	t
288	1.232	MoveIsTimedFromFormToFormElementGroup	SQL	V1_232__MoveIsTimedFromFormToFormElementGroup.sql	2016963094	openchs	2023-06-19 03:05:16.742103	3	t
289	1.233	AddColourColumnsToFormElementGroup	SQL	V1_233__AddColourColumnsToFormElementGroup.sql	-2116396768	openchs	2023-06-19 03:05:16.757304	2	t
290	1.234	AddMiddleNameRelatedColumns	SQL	V1_234__AddMiddleNameRelatedColumns.sql	-1882050195	openchs	2023-06-19 03:05:16.774556	4	t
291	1.235	ChangeSubjectUserAssignmentApproach	SQL	V1_235__ChangeSubjectUserAssignmentApproach.sql	1352280529	openchs	2023-06-19 03:05:16.792492	10	t
292	1.236	TaskTables	SQL	V1_236__TaskTables.sql	-384338098	openchs	2023-06-19 03:05:16.819052	64	t
293	1.237	AddTaskTypeToTask	SQL	V1_237__AddTaskTypeToTask.sql	-1760751343	openchs	2023-06-19 03:05:16.893951	1	t
294	1.238	AddRLSToTaskAndAddStandardReportCard	SQL	V1_238__AddRLSToTaskAndAddStandardReportCard.sql	-2121881398	openchs	2023-06-19 03:05:16.907005	6	t
295	1.239	DropTaskMigrationAndCreateTaskUnAssignmet	SQL	V1_239__DropTaskMigrationAndCreateTaskUnAssignmet.sql	-1228223473	openchs	2023-06-19 03:05:16.928055	32	t
296	1.240	DropNotNullForSubjectInTask	SQL	V1_240__DropNotNullForSubjectInTask.sql	-228427762	openchs	2023-06-19 03:05:16.973043	4	t
297	1.241	SubjectTypeOptionalInFormMapping	SQL	V1_241__SubjectTypeOptionalInFormMapping.sql	-1766659851	openchs	2023-06-19 03:05:16.991692	6	t
298	1.242	AddNotNullToTaskScheduleOn	SQL	V1_242__AddNotNullToTaskScheduleOn.sql	-1666384408	openchs	2023-06-19 03:05:17.011296	3	t
299	1.243	ChangeSyncSttingsForImplementation	SQL	V1_243__ChangeSyncSttingsForImplementation.sql	-838550554	openchs	2023-06-19 03:05:17.026886	2	t
300	1.244	AddStandardCardsForTaskTypes	SQL	V1_244__AddStandardCardsForTaskTypes.sql	-224305181	openchs	2023-06-19 03:05:17.042182	2	t
301	1.245	DropNotNullForAssignedToInTask	SQL	V1_245__DropNotNullForAssignedToInTask.sql	-2048179237	openchs	2023-06-19 03:05:17.057948	2	t
302	1.246	ProgramEligibilty	SQL	V1_246__ProgramEligibilty.sql	384571648	openchs	2023-06-19 03:05:17.075191	16	t
303	1.247	ProgramEligibiltyColumnNameChanges	SQL	V1_247__ProgramEligibiltyColumnNameChanges.sql	-1009556931	openchs	2023-06-19 03:05:17.108399	3	t
304	1.248	ChangeRLSAndAddObservationsInSubjectProgramEligibility	SQL	V1_248__ChangeRLSAndAddObservationsInSubjectProgramEligibility.sql	427099330	openchs	2023-06-19 03:05:17.128561	10	t
305	1.249	MenuItem	SQL	V1_249__MenuItem.sql	1093827495	openchs	2023-06-19 03:05:17.152675	48	t
306	1.250	AlterMenuItem	SQL	V1_250__AlterMenuItem.sql	-1944484989	openchs	2023-06-19 03:05:17.216399	6	t
307	1.251	AlterMenuItemLinkToLinkFunction	SQL	V1_251__AlterMenuItemLinkToLinkFunction.sql	-194549599	openchs	2023-06-19 03:05:17.236923	3	t
308	1.252	ExternalSystemConfig	SQL	V1_252__ExternalSystemConfig.sql	173690418	openchs	2023-06-19 03:05:17.254861	18	t
309	1.253	CreateUserSubjectAssignmentTable	SQL	V1_253__CreateUserSubjectAssignmentTable.sql	-764936943	openchs	2023-06-19 03:05:17.287305	29	t
310	1.254	AddImmutableColumnInEncounter	SQL	V1_254__AddImmutableColumnInEncounter.sql	1717663588	openchs	2023-06-19 03:05:17.332845	3	t
311	1.255	AddCustomQueryTable	SQL	V1_255__AddCustomQueryTable.sql	-1285769908	openchs	2023-06-19 03:05:17.348046	19	t
312	1.256	AddExportJobParameters	SQL	V1_256__AddExportJobParameters.sql	-472781204	openchs	2023-06-19 03:05:17.380526	23	t
313	1.257	AddMessageRule	SQL	V1_257__AddMessageRule.sql	1891240917	openchs	2023-06-19 03:05:17.417339	17	t
314	1.258	AddMessageReceiver	SQL	V1_258__AddMessageReceiver.sql	1584808702	openchs	2023-06-19 03:05:17.448732	21	t
315	1.259	AddMessageRequestQueue	SQL	V1_259__AddMessageRequestQueue.sql	277165921	openchs	2023-06-19 03:05:17.483366	24	t
316	1.260	AlterMessageReceiverAndMessageRequestQueueDropNotNullOnExternalIdAndDeliveredTime	SQL	V1_260__AlterMessageReceiverAndMessageRequestQueueDropNotNullOnExternalIdAndDeliveredTime.sql	-1679570323	openchs	2023-06-19 03:05:17.522709	3	t
317	1.261	AddVersionColumnToMessageReceiverAndRequestQueue	SQL	V1_261__AddVersionColumnToMessageReceiverAndRequestQueue.sql	-606352878	openchs	2023-06-19 03:05:17.541571	2	t
318	1.262	AlterMessageRuleReceiverEntityIdToInt	SQL	V1_262__AlterMessageRuleReceiverEntityIdToInt.sql	1991016331	openchs	2023-06-19 03:05:17.557362	3	t
319	1.263	RenameMessageRequestQueueTimeColumns	SQL	V1_263__RenameMessageRequestQueueTimeColumns.sql	-1210278057	openchs	2023-06-19 03:05:17.575328	2	t
320	1.263.1	AddressIdNullOnOtherTxnTables	SQL	V1_263.1__AddressIdNullOnOtherTxnTables.sql	721813361	openchs	2023-06-19 03:05:17.592111	3	t
321	1.264	OnlyOneOrgConfigPerOrganisation	SQL	V1_264__OnlyOneOrgConfigPerOrganisation.sql	-927974042	openchs	2023-06-19 03:05:17.609985	7	t
322	1.265	AlterMessageReceiverAndMessageRequestQueue	SQL	V1_265__AlterMessageReceiverAndMessageRequestQueue.sql	925499838	openchs	2023-06-19 03:05:17.629778	5	t
323	1.266	AddUniqueContraintToMessageReceiver	SQL	V1_266__AddUniqueContraintToMessageReceiver.sql	258555657	openchs	2023-06-19 03:05:17.652002	4	t
324	1.267	AddReceiverTypeToMessageRule	SQL	V1_267__AddReceiverTypeToMessageRule.sql	1210257214	openchs	2023-06-19 03:05:17.668641	3	t
325	1.268	CreateManualBroadcastMessageTable	SQL	V1_268__CreateManualBroadcastMessageTable.sql	-1514578951	openchs	2023-06-19 03:05:17.688367	22	t
326	1.269	AlterTablesToAccommodateManualBroadcastMessageId	SQL	V1_269__AlterTablesToAccommodateManualBroadcastMessageId.sql	1904023312	openchs	2023-06-19 03:05:17.726423	7	t
327	1.270	AllowActiveProgramEnrolments	SQL	V1_270__AllowActiveProgramEnrolments.sql	1505988287	openchs	2023-06-19 03:05:17.751332	3	t
328	1.271	AddNextTriggerDetailsToManualBroadcastMessage	SQL	V1_271__AddNextTriggerDetailsToManualBroadcastMessage.sql	-1252768687	openchs	2023-06-19 03:05:17.768671	8	t
329	1.272	AddNewRolesAndPrivileges	SQL	V1_272__AddNewRolesAndPrivileges.sql	1647256229	openchs	2023-06-19 03:05:17.797109	8	t
330	1.273	ReplaceUniqueConstraintsOnDisplayOrder	SQL	V1_273__ReplaceUniqueConstraintsOnDisplayOrder.sql	274436782	openchs	2023-06-19 03:05:17.824362	20	t
331	1.274	AddEntityTypeToApprovalStatus	SQL	V1_274__AddEntityTypeToApprovalStatus.sql	215330710	openchs	2023-06-19 03:05:17.859322	44	t
332	1.275	RemoveApprovalStatusFromOrgSettings	SQL	V1_275__RemoveApprovalStatusFromOrgSettings.sql	1044849442	openchs	2023-06-19 03:05:17.930857	2	t
333	1.276	AddManualUpdateHistoryColumn	SQL	V1_276__AddManualUpdateHistoryColumn.sql	-2068047800	openchs	2023-06-19 03:05:17.947305	13	t
334	1.277	RemoveUserReviewMatrix	SQL	V1_277__RemoveUserReviewMatrix.sql	2134299675	openchs	2023-06-19 03:05:17.971194	11	t
335	1.278	RenameManualBroadcastMessageToManualMessage	SQL	V1_278__RenameManualBroadcastMessageToManualMessage.sql	-1752951433	openchs	2023-06-19 03:05:17.996163	9	t
336	1.279	AddUniqueUUIDConstraintToGroupSubject	SQL	V1_279__AddUniqueUUIDConstraintToGroupSubject.sql	-1488679724	openchs	2023-06-19 03:05:18.019727	7	t
337	1.280	AddingDashboardFilter	SQL	V1_280__AddingDashboardFilter.sql	-453155170	openchs	2023-06-19 03:05:18.043748	31	t
338	1.281	AddNameToDashboardFilter	SQL	V1_281__AddNameToDashboardFilter.sql	-1454849611	openchs	2023-06-19 03:05:18.094804	6	t
339	1.282	AddUniqueConstraintToTransactionalDataTables	SQL	V1_282__AddUniqueConstraintToTransactionalDataTables.sql	1576932710	openchs	2023-06-19 03:05:18.119335	79	t
340	1.283	AddUniqueConstraintToReferenceDataTables	SQL	V1_283__AddUniqueConstraintToReferenceDataTables.sql	328247703	openchs	2023-06-19 03:05:18.215458	111	t
341	1.284	FixDashboardFilterDefinition	SQL	V1_284__FixDashboardFilterDefinition.sql	-1536482220	openchs	2023-06-19 03:05:18.341396	4	t
342	1.285	AddDueChecklistInDefaultDashboard	SQL	V1_285__AddDueChecklistInDefaultDashboard.sql	397854226	openchs	2023-06-19 03:05:18.364933	2	t
343	\N	Functions	SQL	R__Functions.sql	1351707694	openchs	2023-06-19 03:05:18.381585	13	t
344	\N	UtilityViews	SQL	R__UtilityViews.sql	-968204608	openchs	2023-06-19 03:05:18.408975	37	t
345	\N	Views	SQL	R__Views.sql	-308326634	openchs	2023-06-19 03:05:18.466451	19	t
\.


--
-- Data for Name: standard_report_card_type; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.standard_report_card_type (id, uuid, name, description, is_voided, created_date_time, last_modified_date_time) FROM stdin;
1	7726476c-fb91-4c28-8afc-9782714c1d8c	Pending approval	Pending approval	f	2023-06-19 03:05:14.431978+00	2023-06-19 03:05:14.938+00
2	84d6c349-9fbb-41d3-85fe-1d34521a0d45	Approved	Approved	f	2023-06-19 03:05:14.431978+00	2023-06-19 03:05:14.939+00
3	9e584c8d-b31d-4e5a-9161-baf4f369d02d	Rejected	Rejected	f	2023-06-19 03:05:14.431978+00	2023-06-19 03:05:14.94+00
4	27020b32-c21b-43a4-81bd-7b88ad3a6ef0	Scheduled visits	Scheduled visits	f	2023-06-19 03:05:14.595746+00	2023-06-19 03:05:14.941+00
5	9f88bee5-2ab9-4ac4-ae19-d07e9715bdb5	Overdue visits	Overdue visits	f	2023-06-19 03:05:14.595746+00	2023-06-19 03:05:14.942+00
6	88a7514c-48c0-4d5d-a421-d074e43bb36c	Last 24 hours registrations	Last 24 hours registrations	f	2023-06-19 03:05:14.595746+00	2023-06-19 03:05:14.943+00
7	a5efc04c-317a-4823-a203-e62603454a65	Last 24 hours enrolments	Last 24 hours enrolments	f	2023-06-19 03:05:14.595746+00	2023-06-19 03:05:14.944+00
8	77b5b3fa-de35-4f24-996b-2842492ea6e0	Last 24 hours visits	Last 24 hours visits	f	2023-06-19 03:05:14.595746+00	2023-06-19 03:05:14.945+00
9	1fbcadf3-bf1a-439e-9e13-24adddfbf6c0	Total	Total	f	2023-06-19 03:05:14.595746+00	2023-06-19 03:05:14.946+00
10	a65c064b-db32-408b-aceb-d15acfebca1e	Comments	Comments	f	2023-06-19 03:05:14.754559+00	2023-06-19 03:05:14.947+00
11	6be95028-1e1f-4d29-93a7-d4e562e0615a	Tasks	Tasks	f	2023-06-19 03:05:16.917966+00	2023-06-19 03:05:16.918+00
12	3e287567-3b1d-450b-a877-d4f87a31ce83	Call tasks	Call tasks	f	2023-06-19 03:05:17.050273+00	2023-06-19 03:05:17.05+00
13	26176da9-ea2b-4469-9bd5-ac7639a64d81	Open subject tasks	Open subject tasks	f	2023-06-19 03:05:17.050273+00	2023-06-19 03:05:17.05+00
14	6cdf9ef4-18e6-476f-8ebf-084edfb97f8b	Due checklist	Due checklist	f	2023-06-19 03:05:18.374125+00	2023-06-19 03:05:18.374+00
\.


--
-- Data for Name: subject_migration; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.subject_migration (id, uuid, individual_id, old_address_level_id, new_address_level_id, organisation_id, audit_id, is_voided, version, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, old_sync_concept_1_value, new_sync_concept_1_value, old_sync_concept_2_value, new_sync_concept_2_value, subject_type_id, manual_update_history) FROM stdin;
\.


--
-- Data for Name: subject_program_eligibility; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.subject_program_eligibility (id, organisation_id, uuid, is_voided, version, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, subject_id, program_id, is_eligible, check_date, observations) FROM stdin;
\.


--
-- Data for Name: subject_type; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.subject_type (id, uuid, name, organisation_id, is_voided, audit_id, version, is_group, is_household, active, type, subject_summary_rule, allow_empty_location, unique_name, valid_first_name_regex, valid_first_name_description_key, valid_last_name_regex, valid_last_name_description_key, icon_file_s3_key, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, directly_assignable, should_sync_by_location, sync_registration_concept_1, sync_registration_concept_2, sync_registration_concept_1_usable, sync_registration_concept_2_usable, name_help_text, allow_profile_picture, valid_middle_name_regex, valid_middle_name_description_key, allow_middle_name, program_eligibility_check_rule, program_eligibility_check_declarative_rule) FROM stdin;
1	9f2af1f9-e150-4f8e-aad3-40bb7eb05aa3	Individual	1	f	82	1	f	f	t	\N	\N	f	f	\N	\N	\N	\N	\N	1	1	2023-06-19 03:05:11.539+00	2023-06-19 03:05:11.539+00	f	t	\N	\N	f	f	\N	f	\N	\N	f	\N	\N
2	0a725062-d17c-4b17-8bf3-6cdba1ea2f5b	Patient	2	f	108	0	f	f	t	Person		f	f	\N	\N	\N	\N	\N	2	2	2023-06-19 03:20:33.937+00	2023-06-19 03:20:33.937+00	f	t	\N	\N	\N	\N	\N	f	\N	\N	f		\N
\.


--
-- Data for Name: sync_telemetry; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.sync_telemetry (id, uuid, user_id, organisation_id, version, sync_status, sync_start_time, sync_end_time, entity_status, device_name, android_version, app_version, device_info, sync_source) FROM stdin;
\.


--
-- Data for Name: table_metadata; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.table_metadata (id, name, type, schema_name, subject_type_uuid, program_uuid, encounter_type_uuid, form_uuid) FROM stdin;
\.


--
-- Data for Name: task; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.task (id, organisation_id, uuid, is_voided, version, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, legacy_id, name, task_status_id, scheduled_on, completed_on, assigned_user_id, metadata, subject_id, observations, task_type_id, manual_update_history) FROM stdin;
\.


--
-- Data for Name: task_status; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.task_status (id, organisation_id, uuid, is_voided, version, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, name, task_type_id, is_terminal) FROM stdin;
\.


--
-- Data for Name: task_type; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.task_type (id, organisation_id, uuid, is_voided, version, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, name, type, metadata_search_fields) FROM stdin;
\.


--
-- Data for Name: task_unassignment; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.task_unassignment (id, organisation_id, uuid, is_voided, version, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, task_id, unassigned_user_id) FROM stdin;
\.


--
-- Data for Name: translation; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.translation (id, uuid, organisation_id, audit_id, version, translation_json, is_voided, language, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: user_group; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.user_group (id, uuid, user_id, group_id, is_voided, version, organisation_id, audit_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, manual_update_history) FROM stdin;
1	a2d0a915-cb47-4215-8937-a2b76169a2a0	1	1	f	0	1	84	1	1	2023-06-19 03:05:13.596+00	2023-06-19 03:05:13.596+00	\N
2	1964e688-7558-45f6-9c0a-01ebe86010f1	2	2	f	0	2	91	1	1	2023-06-19 03:10:53.16+00	2023-06-19 03:10:53.16+00	\N
3	acfd0f6d-6e18-4f67-9aa4-02532e242736	3	2	f	0	2	105	2	2	2023-06-19 03:17:32.449+00	2023-06-19 03:17:32.449+00	\N
\.


--
-- Data for Name: user_subject_assignment; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.user_subject_assignment (id, uuid, user_id, subject_id, organisation_id, is_voided, version, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.users (id, uuid, username, organisation_id, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time, is_voided, catchment_id, is_org_admin, operating_individual_scope, settings, email, phone_number, disabled_in_cognito, name, sync_settings) FROM stdin;
1	5fed2907-df3a-4867-aef5-c87f4c78a31a	admin	1	1	1	2023-06-19 03:05:10.298433+00	2023-06-19 03:05:10.298+00	f	\N	f	None	\N	\N	\N	f	\N	{}
2	c003963f-0596-49dc-b8bf-04121a94f157	admin@bahmni	2	2	2	2023-06-19 03:10:52.854+00	2023-06-19 03:19:47.871+00	f	2	t	ByCatchment	\N	bahmniadmin@example.com	+919876543210	f	Administrator	{"subjectTypeSyncSettings": []}
3	4c410f18-8d8e-4b6e-a5b2-96ab8377d997	integration@bahmni	2	3	3	2023-06-19 03:17:32.255+00	2023-06-19 03:19:58.39+00	f	2	t	ByCatchment	\N	bahmniintegration@example.com	+919876543211	f	Integration	{"subjectTypeSyncSettings": []}
\.


--
-- Data for Name: video; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.video (id, version, audit_id, uuid, organisation_id, title, file_path, description, duration, is_voided, created_by_id, last_modified_by_id, created_date_time, last_modified_date_time) FROM stdin;
\.


--
-- Data for Name: video_telemetric; Type: TABLE DATA; Schema: public; Owner: openchs
--

COPY public.video_telemetric (id, uuid, video_start_time, video_end_time, player_open_time, player_close_time, video_id, user_id, created_datetime, organisation_id, is_voided) FROM stdin;
\.


--
-- Name: account_admin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.account_admin_id_seq', 1, true);


--
-- Name: account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.account_id_seq', 1, true);


--
-- Name: address_level_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.address_level_id_seq', 5, true);


--
-- Name: address_level_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.address_level_type_id_seq', 4, true);


--
-- Name: answer_concept_migration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.answer_concept_migration_id_seq', 1, false);


--
-- Name: approval_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.approval_status_id_seq', 3, true);


--
-- Name: audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.audit_id_seq', 152, true);


--
-- Name: batch_job_execution_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.batch_job_execution_seq', 1, false);


--
-- Name: batch_job_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.batch_job_seq', 1, false);


--
-- Name: batch_step_execution_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.batch_step_execution_seq', 1, false);


--
-- Name: catchment_address_mapping_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.catchment_address_mapping_id_seq', 2, true);


--
-- Name: catchment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.catchment_id_seq', 2, true);


--
-- Name: checklist_detail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.checklist_detail_id_seq', 1, false);


--
-- Name: checklist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.checklist_id_seq', 1, false);


--
-- Name: checklist_item_detail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.checklist_item_detail_id_seq', 1, false);


--
-- Name: checklist_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.checklist_item_id_seq', 1, false);


--
-- Name: column_metadata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.column_metadata_id_seq', 1, false);


--
-- Name: comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.comment_id_seq', 1, false);


--
-- Name: comment_thread_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.comment_thread_id_seq', 1, false);


--
-- Name: concept_answer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.concept_answer_id_seq', 3, true);


--
-- Name: concept_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.concept_id_seq', 14, true);


--
-- Name: custom_query_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.custom_query_id_seq', 1, false);


--
-- Name: dashboard_card_mapping_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.dashboard_card_mapping_id_seq', 1, false);


--
-- Name: dashboard_filter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.dashboard_filter_id_seq', 1, false);


--
-- Name: dashboard_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.dashboard_id_seq', 1, false);


--
-- Name: dashboard_section_card_mapping_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.dashboard_section_card_mapping_id_seq', 1, false);


--
-- Name: dashboard_section_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.dashboard_section_id_seq', 1, false);


--
-- Name: decision_concept_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.decision_concept_id_seq', 1, false);


--
-- Name: deps_saved_ddl_deps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.deps_saved_ddl_deps_id_seq', 1, false);


--
-- Name: documentation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.documentation_id_seq', 1, false);


--
-- Name: documentation_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.documentation_item_id_seq', 1, false);


--
-- Name: encounter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.encounter_id_seq', 1, false);


--
-- Name: encounter_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.encounter_type_id_seq', 2, true);


--
-- Name: entity_approval_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.entity_approval_status_id_seq', 1, false);


--
-- Name: entity_sync_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.entity_sync_status_id_seq', 1, false);


--
-- Name: export_job_parameters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.export_job_parameters_id_seq', 1, false);


--
-- Name: external_system_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.external_system_config_id_seq', 1, false);


--
-- Name: facility_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.facility_id_seq', 1, false);


--
-- Name: form_element_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.form_element_group_id_seq', 3, true);


--
-- Name: form_element_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.form_element_id_seq', 10, true);


--
-- Name: form_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.form_id_seq', 5, true);


--
-- Name: form_mapping_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.form_mapping_id_seq', 5, true);


--
-- Name: gender_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.gender_id_seq', 6, true);


--
-- Name: group_dashboard_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.group_dashboard_id_seq', 1, false);


--
-- Name: group_privilege_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.group_privilege_id_seq', 1, false);


--
-- Name: group_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.group_role_id_seq', 1, false);


--
-- Name: group_subject_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.group_subject_id_seq', 1, false);


--
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.groups_id_seq', 2, true);


--
-- Name: identifier_assignment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.identifier_assignment_id_seq', 1, false);


--
-- Name: identifier_source_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.identifier_source_id_seq', 1, false);


--
-- Name: identifier_user_assignment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.identifier_user_assignment_id_seq', 1, false);


--
-- Name: index_metadata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.index_metadata_id_seq', 1, false);


--
-- Name: individual_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.individual_id_seq', 1, false);


--
-- Name: individual_relation_gender_mapping_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.individual_relation_gender_mapping_id_seq', 12, true);


--
-- Name: individual_relation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.individual_relation_id_seq', 12, true);


--
-- Name: individual_relationship_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.individual_relationship_id_seq', 1, false);


--
-- Name: individual_relationship_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.individual_relationship_type_id_seq', 12, true);


--
-- Name: individual_relative_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.individual_relative_id_seq', 1, false);


--
-- Name: location_location_mapping_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.location_location_mapping_id_seq', 4, true);


--
-- Name: manual_message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.manual_message_id_seq', 1, false);


--
-- Name: menu_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.menu_item_id_seq', 1, false);


--
-- Name: message_receiver_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.message_receiver_id_seq', 1, false);


--
-- Name: message_request_queue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.message_request_queue_id_seq', 1, false);


--
-- Name: message_rule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.message_rule_id_seq', 1, false);


--
-- Name: msg91_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.msg91_config_id_seq', 1, false);


--
-- Name: news_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.news_id_seq', 1, false);


--
-- Name: non_applicable_form_element_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.non_applicable_form_element_id_seq', 1, false);


--
-- Name: operational_encounter_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.operational_encounter_type_id_seq', 2, true);


--
-- Name: operational_program_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.operational_program_id_seq', 1, false);


--
-- Name: operational_subject_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.operational_subject_type_id_seq', 1, true);


--
-- Name: organisation_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.organisation_config_id_seq', 2, true);


--
-- Name: organisation_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.organisation_group_id_seq', 1, false);


--
-- Name: organisation_group_organisation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.organisation_group_organisation_id_seq', 1, false);


--
-- Name: organisation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.organisation_id_seq', 2, true);


--
-- Name: platform_translation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.platform_translation_id_seq', 2, true);


--
-- Name: privilege_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.privilege_id_seq', 51, true);


--
-- Name: program_encounter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.program_encounter_id_seq', 1, false);


--
-- Name: program_enrolment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.program_enrolment_id_seq', 1, false);


--
-- Name: program_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.program_id_seq', 1, false);


--
-- Name: program_organisation_config_at_risk_concept_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.program_organisation_config_at_risk_concept_id_seq', 1, false);


--
-- Name: program_organisation_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.program_organisation_config_id_seq', 1, false);


--
-- Name: program_outcome_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.program_outcome_id_seq', 1, false);


--
-- Name: report_card_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.report_card_id_seq', 1, false);


--
-- Name: reset_sync_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.reset_sync_id_seq', 2, true);


--
-- Name: rule_dependency_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.rule_dependency_id_seq', 1, false);


--
-- Name: rule_failure_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.rule_failure_log_id_seq', 4, true);


--
-- Name: rule_failure_telemetry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.rule_failure_telemetry_id_seq', 1, false);


--
-- Name: rule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.rule_id_seq', 1, false);


--
-- Name: standard_report_card_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.standard_report_card_type_id_seq', 14, true);


--
-- Name: subject_migration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.subject_migration_id_seq', 1, false);


--
-- Name: subject_program_eligibility_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.subject_program_eligibility_id_seq', 1, false);


--
-- Name: subject_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.subject_type_id_seq', 2, true);


--
-- Name: sync_telemetry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.sync_telemetry_id_seq', 1, false);


--
-- Name: table_metadata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.table_metadata_id_seq', 1, false);


--
-- Name: task_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.task_id_seq', 1, false);


--
-- Name: task_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.task_status_id_seq', 1, false);


--
-- Name: task_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.task_type_id_seq', 1, false);


--
-- Name: task_unassignment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.task_unassignment_id_seq', 1, false);


--
-- Name: translation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.translation_id_seq', 1, false);


--
-- Name: user_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.user_group_id_seq', 3, true);


--
-- Name: user_subject_assignment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.user_subject_assignment_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.users_id_seq', 3, true);


--
-- Name: video_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.video_id_seq', 1, false);


--
-- Name: video_telemetric_id_seq; Type: SEQUENCE SET; Schema: public; Owner: openchs
--

SELECT pg_catalog.setval('public.video_telemetric_id_seq', 1, false);


--
-- Name: account_admin account_admin_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.account_admin
    ADD CONSTRAINT account_admin_pkey PRIMARY KEY (id);


--
-- Name: account account_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_pkey PRIMARY KEY (id);


--
-- Name: address_level address_level_legacy_id_organisation_id_uniq_idx; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.address_level
    ADD CONSTRAINT address_level_legacy_id_organisation_id_uniq_idx UNIQUE (legacy_id, organisation_id);


--
-- Name: address_level address_level_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.address_level
    ADD CONSTRAINT address_level_pkey PRIMARY KEY (id);


--
-- Name: address_level_type address_level_type_name_organisation_id_unique; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.address_level_type
    ADD CONSTRAINT address_level_type_name_organisation_id_unique UNIQUE (name, organisation_id);


--
-- Name: address_level_type address_level_type_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.address_level_type
    ADD CONSTRAINT address_level_type_pkey PRIMARY KEY (id);


--
-- Name: address_level address_level_uuid_org_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.address_level
    ADD CONSTRAINT address_level_uuid_org_id_key UNIQUE (uuid, organisation_id);


--
-- Name: answer_concept_migration answer_concept_migration_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.answer_concept_migration
    ADD CONSTRAINT answer_concept_migration_pkey PRIMARY KEY (id);


--
-- Name: answer_concept_migration answer_concept_migration_uuid_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.answer_concept_migration
    ADD CONSTRAINT answer_concept_migration_uuid_organisation_id_key UNIQUE (uuid, organisation_id);


--
-- Name: approval_status approval_status_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.approval_status
    ADD CONSTRAINT approval_status_pkey PRIMARY KEY (id);


--
-- Name: audit audit_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.audit
    ADD CONSTRAINT audit_pkey PRIMARY KEY (id);


--
-- Name: batch_job_execution_context batch_job_execution_context_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.batch_job_execution_context
    ADD CONSTRAINT batch_job_execution_context_pkey PRIMARY KEY (job_execution_id);


--
-- Name: batch_job_execution batch_job_execution_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.batch_job_execution
    ADD CONSTRAINT batch_job_execution_pkey PRIMARY KEY (job_execution_id);


--
-- Name: batch_job_instance batch_job_instance_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.batch_job_instance
    ADD CONSTRAINT batch_job_instance_pkey PRIMARY KEY (job_instance_id);


--
-- Name: batch_step_execution_context batch_step_execution_context_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.batch_step_execution_context
    ADD CONSTRAINT batch_step_execution_context_pkey PRIMARY KEY (step_execution_id);


--
-- Name: batch_step_execution batch_step_execution_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.batch_step_execution
    ADD CONSTRAINT batch_step_execution_pkey PRIMARY KEY (step_execution_id);


--
-- Name: report_card card_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.report_card
    ADD CONSTRAINT card_pkey PRIMARY KEY (id);


--
-- Name: report_card card_uuid_org_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.report_card
    ADD CONSTRAINT card_uuid_org_id_key UNIQUE (uuid, organisation_id);


--
-- Name: catchment_address_mapping catchment_address_mapping_catchment_id_address_level_id_unique; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.catchment_address_mapping
    ADD CONSTRAINT catchment_address_mapping_catchment_id_address_level_id_unique UNIQUE (catchment_id, addresslevel_id);


--
-- Name: catchment_address_mapping catchment_address_mapping_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.catchment_address_mapping
    ADD CONSTRAINT catchment_address_mapping_pkey PRIMARY KEY (id);


--
-- Name: catchment catchment_name_organisation_id_unique; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.catchment
    ADD CONSTRAINT catchment_name_organisation_id_unique UNIQUE (name, organisation_id);


--
-- Name: catchment catchment_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.catchment
    ADD CONSTRAINT catchment_pkey PRIMARY KEY (id);


--
-- Name: catchment catchment_uuid_org_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.catchment
    ADD CONSTRAINT catchment_uuid_org_id_key UNIQUE (uuid, organisation_id);


--
-- Name: checklist checklist_checklist_detail_id_program_enrolment_id_unique; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.checklist
    ADD CONSTRAINT checklist_checklist_detail_id_program_enrolment_id_unique UNIQUE (checklist_detail_id, program_enrolment_id);


--
-- Name: checklist_detail checklist_detail_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.checklist_detail
    ADD CONSTRAINT checklist_detail_pkey PRIMARY KEY (id);


--
-- Name: checklist_detail checklist_detail_uuid_org_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.checklist_detail
    ADD CONSTRAINT checklist_detail_uuid_org_id_key UNIQUE (uuid, organisation_id);


--
-- Name: checklist_item_detail checklist_item_detail_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.checklist_item_detail
    ADD CONSTRAINT checklist_item_detail_pkey PRIMARY KEY (id);


--
-- Name: checklist_item_detail checklist_item_detail_uuid_org_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.checklist_item_detail
    ADD CONSTRAINT checklist_item_detail_uuid_org_id_key UNIQUE (uuid, organisation_id);


--
-- Name: checklist_item checklist_item_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.checklist_item
    ADD CONSTRAINT checklist_item_pkey PRIMARY KEY (id);


--
-- Name: checklist_item checklist_item_uuid_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.checklist_item
    ADD CONSTRAINT checklist_item_uuid_key UNIQUE (uuid);


--
-- Name: checklist checklist_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.checklist
    ADD CONSTRAINT checklist_pkey PRIMARY KEY (id);


--
-- Name: checklist checklist_uuid_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.checklist
    ADD CONSTRAINT checklist_uuid_key UNIQUE (uuid);


--
-- Name: column_metadata column_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.column_metadata
    ADD CONSTRAINT column_metadata_pkey PRIMARY KEY (id);


--
-- Name: comment comment_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_pkey PRIMARY KEY (id);


--
-- Name: comment_thread comment_thread_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.comment_thread
    ADD CONSTRAINT comment_thread_pkey PRIMARY KEY (id);


--
-- Name: comment_thread comment_thread_uuid_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.comment_thread
    ADD CONSTRAINT comment_thread_uuid_key UNIQUE (uuid);


--
-- Name: comment comment_uuid_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_uuid_key UNIQUE (uuid);


--
-- Name: concept_answer concept_answer_concept_id_answer_concept_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.concept_answer
    ADD CONSTRAINT concept_answer_concept_id_answer_concept_id_key UNIQUE (concept_id, answer_concept_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: concept_answer concept_answer_concept_id_answer_concept_id_organisation_id_uni; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.concept_answer
    ADD CONSTRAINT concept_answer_concept_id_answer_concept_id_organisation_id_uni UNIQUE (concept_id, answer_concept_id, organisation_id);


--
-- Name: concept_answer concept_answer_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.concept_answer
    ADD CONSTRAINT concept_answer_pkey PRIMARY KEY (id);


--
-- Name: concept_answer concept_answer_uuid_org_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.concept_answer
    ADD CONSTRAINT concept_answer_uuid_org_id_key UNIQUE (uuid, organisation_id);


--
-- Name: concept concept_name_orgid; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.concept
    ADD CONSTRAINT concept_name_orgid UNIQUE (name, organisation_id);


--
-- Name: concept concept_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.concept
    ADD CONSTRAINT concept_pkey PRIMARY KEY (id);


--
-- Name: concept concept_uuid_org_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.concept
    ADD CONSTRAINT concept_uuid_org_id_key UNIQUE (uuid, organisation_id);


--
-- Name: custom_query custom_query_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.custom_query
    ADD CONSTRAINT custom_query_pkey PRIMARY KEY (id);


--
-- Name: custom_query custom_query_uuid_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.custom_query
    ADD CONSTRAINT custom_query_uuid_organisation_id_key UNIQUE (uuid, organisation_id);


--
-- Name: dashboard_card_mapping dashboard_card_mapping_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard_card_mapping
    ADD CONSTRAINT dashboard_card_mapping_pkey PRIMARY KEY (id);


--
-- Name: dashboard_card_mapping dashboard_card_uuid_org_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard_card_mapping
    ADD CONSTRAINT dashboard_card_uuid_org_id_key UNIQUE (uuid, organisation_id);


--
-- Name: dashboard_filter dashboard_filter_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard_filter
    ADD CONSTRAINT dashboard_filter_pkey PRIMARY KEY (id);


--
-- Name: dashboard_filter dashboard_filter_uuid_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard_filter
    ADD CONSTRAINT dashboard_filter_uuid_organisation_id_key UNIQUE (uuid, organisation_id);


--
-- Name: dashboard dashboard_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard
    ADD CONSTRAINT dashboard_pkey PRIMARY KEY (id);


--
-- Name: dashboard_section_card_mapping dashboard_section_card_mapping_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard_section_card_mapping
    ADD CONSTRAINT dashboard_section_card_mapping_pkey PRIMARY KEY (id);


--
-- Name: dashboard_section_card_mapping dashboard_section_card_mapping_uuid_org_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard_section_card_mapping
    ADD CONSTRAINT dashboard_section_card_mapping_uuid_org_id_key UNIQUE (uuid, organisation_id);


--
-- Name: dashboard_section dashboard_section_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard_section
    ADD CONSTRAINT dashboard_section_pkey PRIMARY KEY (id);


--
-- Name: dashboard_section dashboard_section_uuid_org_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard_section
    ADD CONSTRAINT dashboard_section_uuid_org_id_key UNIQUE (uuid, organisation_id);


--
-- Name: dashboard dashboard_uuid_org_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard
    ADD CONSTRAINT dashboard_uuid_org_id_key UNIQUE (uuid, organisation_id);


--
-- Name: decision_concept decision_concept_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.decision_concept
    ADD CONSTRAINT decision_concept_pkey PRIMARY KEY (id);


--
-- Name: deps_saved_ddl deps_saved_ddl_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.deps_saved_ddl
    ADD CONSTRAINT deps_saved_ddl_pkey PRIMARY KEY (deps_id);


--
-- Name: documentation_item documentation_item_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.documentation_item
    ADD CONSTRAINT documentation_item_pkey PRIMARY KEY (id);


--
-- Name: documentation_item documentation_item_uuid_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.documentation_item
    ADD CONSTRAINT documentation_item_uuid_organisation_id_key UNIQUE (uuid, organisation_id);


--
-- Name: documentation documentation_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.documentation
    ADD CONSTRAINT documentation_pkey PRIMARY KEY (id);


--
-- Name: documentation documentation_uuid_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.documentation
    ADD CONSTRAINT documentation_uuid_organisation_id_key UNIQUE (uuid, organisation_id);


--
-- Name: encounter encounter_legacy_id_organisation_id_uniq_idx; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.encounter
    ADD CONSTRAINT encounter_legacy_id_organisation_id_uniq_idx UNIQUE (legacy_id, organisation_id);


--
-- Name: encounter encounter_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.encounter
    ADD CONSTRAINT encounter_pkey PRIMARY KEY (id);


--
-- Name: encounter_type encounter_type_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.encounter_type
    ADD CONSTRAINT encounter_type_pkey PRIMARY KEY (id);


--
-- Name: encounter_type encounter_type_uuid_org_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.encounter_type
    ADD CONSTRAINT encounter_type_uuid_org_id_key UNIQUE (uuid, organisation_id);


--
-- Name: encounter encounter_uuid_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.encounter
    ADD CONSTRAINT encounter_uuid_key UNIQUE (uuid);


--
-- Name: entity_approval_status entity_approval_status_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.entity_approval_status
    ADD CONSTRAINT entity_approval_status_pkey PRIMARY KEY (id);


--
-- Name: entity_approval_status entity_approval_status_uuid_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.entity_approval_status
    ADD CONSTRAINT entity_approval_status_uuid_organisation_id_key UNIQUE (uuid, organisation_id);


--
-- Name: entity_sync_status entity_sync_status_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.entity_sync_status
    ADD CONSTRAINT entity_sync_status_pkey PRIMARY KEY (id);


--
-- Name: export_job_parameters export_job_parameters_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.export_job_parameters
    ADD CONSTRAINT export_job_parameters_pkey PRIMARY KEY (id);


--
-- Name: export_job_parameters export_job_parameters_uuid_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.export_job_parameters
    ADD CONSTRAINT export_job_parameters_uuid_organisation_id_key UNIQUE (uuid, organisation_id);


--
-- Name: external_system_config external_system_config_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.external_system_config
    ADD CONSTRAINT external_system_config_pkey PRIMARY KEY (id);


--
-- Name: external_system_config external_system_config_uuid_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.external_system_config
    ADD CONSTRAINT external_system_config_uuid_organisation_id_key UNIQUE (uuid, organisation_id);


--
-- Name: facility facility_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.facility
    ADD CONSTRAINT facility_pkey PRIMARY KEY (id);


--
-- Name: form_element fe_feg_id_display_order_org_id_is_voided_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form_element
    ADD CONSTRAINT fe_feg_id_display_order_org_id_is_voided_key UNIQUE (form_element_group_id, display_order, organisation_id, is_voided) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: form_element_group feg_f_id_display_order_org_id_is_voided_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form_element_group
    ADD CONSTRAINT feg_f_id_display_order_org_id_is_voided_key UNIQUE (form_id, display_order, organisation_id, is_voided) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: form_element_group form_element_group_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form_element_group
    ADD CONSTRAINT form_element_group_pkey PRIMARY KEY (id);


--
-- Name: form_element_group form_element_group_uuid_org_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form_element_group
    ADD CONSTRAINT form_element_group_uuid_org_id_key UNIQUE (uuid, organisation_id);


--
-- Name: form_element form_element_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form_element
    ADD CONSTRAINT form_element_pkey PRIMARY KEY (id);


--
-- Name: form_element form_element_uuid_org_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form_element
    ADD CONSTRAINT form_element_uuid_org_id_key UNIQUE (uuid, organisation_id);


--
-- Name: form_mapping form_mapping_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form_mapping
    ADD CONSTRAINT form_mapping_pkey PRIMARY KEY (id);


--
-- Name: form_mapping form_mapping_uuid_org_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form_mapping
    ADD CONSTRAINT form_mapping_uuid_org_id_key UNIQUE (uuid, organisation_id);


--
-- Name: form form_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form
    ADD CONSTRAINT form_pkey PRIMARY KEY (id);


--
-- Name: form form_uuid_org_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form
    ADD CONSTRAINT form_uuid_org_id_key UNIQUE (uuid, organisation_id);


--
-- Name: gender gender_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.gender
    ADD CONSTRAINT gender_pkey PRIMARY KEY (id);


--
-- Name: gender gender_uuid_org_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.gender
    ADD CONSTRAINT gender_uuid_org_id_key UNIQUE (uuid, organisation_id);


--
-- Name: group_dashboard group_dashboard_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_dashboard
    ADD CONSTRAINT group_dashboard_pkey PRIMARY KEY (id);


--
-- Name: group_dashboard group_dashboard_uuid_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_dashboard
    ADD CONSTRAINT group_dashboard_uuid_organisation_id_key UNIQUE (uuid, organisation_id);


--
-- Name: group_privilege group_privilege_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_privilege
    ADD CONSTRAINT group_privilege_pkey PRIMARY KEY (id);


--
-- Name: group_privilege group_privilege_uuid_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_privilege
    ADD CONSTRAINT group_privilege_uuid_organisation_id_key UNIQUE (uuid, organisation_id);


--
-- Name: group_role group_role_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_role
    ADD CONSTRAINT group_role_pkey PRIMARY KEY (id);


--
-- Name: group_role group_role_uuid_org_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_role
    ADD CONSTRAINT group_role_uuid_org_id_key UNIQUE (uuid, organisation_id);


--
-- Name: group_subject group_subject_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_subject
    ADD CONSTRAINT group_subject_pkey PRIMARY KEY (id);


--
-- Name: group_subject group_subject_uuid_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_subject
    ADD CONSTRAINT group_subject_uuid_organisation_id_key UNIQUE (uuid, organisation_id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: groups groups_uuid_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_uuid_organisation_id_key UNIQUE (uuid, organisation_id);


--
-- Name: identifier_assignment identifier_assignment_identifier_source_id_identifier_organ_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.identifier_assignment
    ADD CONSTRAINT identifier_assignment_identifier_source_id_identifier_organ_key UNIQUE (identifier_source_id, identifier, organisation_id);


--
-- Name: identifier_assignment identifier_assignment_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.identifier_assignment
    ADD CONSTRAINT identifier_assignment_pkey PRIMARY KEY (id);


--
-- Name: identifier_assignment identifier_assignment_uuid_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.identifier_assignment
    ADD CONSTRAINT identifier_assignment_uuid_key UNIQUE (uuid);


--
-- Name: identifier_source identifier_source_name_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.identifier_source
    ADD CONSTRAINT identifier_source_name_organisation_id_key UNIQUE (name, organisation_id);


--
-- Name: identifier_source identifier_source_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.identifier_source
    ADD CONSTRAINT identifier_source_pkey PRIMARY KEY (id);


--
-- Name: identifier_source identifier_source_uuid_org_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.identifier_source
    ADD CONSTRAINT identifier_source_uuid_org_id_key UNIQUE (uuid, organisation_id);


--
-- Name: identifier_user_assignment identifier_user_assignment_identifier_source_id_assigned_to_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.identifier_user_assignment
    ADD CONSTRAINT identifier_user_assignment_identifier_source_id_assigned_to_key UNIQUE (identifier_source_id, assigned_to_user_id, identifier_start);


--
-- Name: identifier_user_assignment identifier_user_assignment_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.identifier_user_assignment
    ADD CONSTRAINT identifier_user_assignment_pkey PRIMARY KEY (id);


--
-- Name: identifier_user_assignment identifier_user_assignment_uuid_org_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.identifier_user_assignment
    ADD CONSTRAINT identifier_user_assignment_uuid_org_id_key UNIQUE (uuid, organisation_id);


--
-- Name: index_metadata index_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.index_metadata
    ADD CONSTRAINT index_metadata_pkey PRIMARY KEY (id);


--
-- Name: individual individual_legacy_id_organisation_id_uniq_idx; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual
    ADD CONSTRAINT individual_legacy_id_organisation_id_uniq_idx UNIQUE (legacy_id, organisation_id);


--
-- Name: individual individual_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual
    ADD CONSTRAINT individual_pkey PRIMARY KEY (id);


--
-- Name: individual_relation_gender_mapping individual_relation_gender_mapping_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual_relation_gender_mapping
    ADD CONSTRAINT individual_relation_gender_mapping_pkey PRIMARY KEY (id);


--
-- Name: individual_relation_gender_mapping individual_relation_gender_mapping_uuid_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual_relation_gender_mapping
    ADD CONSTRAINT individual_relation_gender_mapping_uuid_organisation_id_key UNIQUE (uuid, organisation_id);


--
-- Name: individual_relation individual_relation_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual_relation
    ADD CONSTRAINT individual_relation_pkey PRIMARY KEY (id);


--
-- Name: individual_relation individual_relation_uuid_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual_relation
    ADD CONSTRAINT individual_relation_uuid_organisation_id_key UNIQUE (uuid, organisation_id);


--
-- Name: individual_relationship individual_relationship_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual_relationship
    ADD CONSTRAINT individual_relationship_pkey PRIMARY KEY (id);


--
-- Name: individual_relationship_type individual_relationship_type_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual_relationship_type
    ADD CONSTRAINT individual_relationship_type_pkey PRIMARY KEY (id);


--
-- Name: individual_relationship_type individual_relationship_type_uuid_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual_relationship_type
    ADD CONSTRAINT individual_relationship_type_uuid_organisation_id_key UNIQUE (uuid, organisation_id);


--
-- Name: individual_relationship individual_relationship_uuid_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual_relationship
    ADD CONSTRAINT individual_relationship_uuid_key UNIQUE (uuid);


--
-- Name: individual_relative individual_relative_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual_relative
    ADD CONSTRAINT individual_relative_pkey PRIMARY KEY (id);


--
-- Name: individual individual_uuid_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual
    ADD CONSTRAINT individual_uuid_key UNIQUE (uuid);


--
-- Name: batch_job_instance job_inst_un; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.batch_job_instance
    ADD CONSTRAINT job_inst_un UNIQUE (job_name, job_key);


--
-- Name: location_location_mapping location_location_mapping_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.location_location_mapping
    ADD CONSTRAINT location_location_mapping_pkey PRIMARY KEY (id);


--
-- Name: location_location_mapping location_location_mapping_uuid_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.location_location_mapping
    ADD CONSTRAINT location_location_mapping_uuid_organisation_id_key UNIQUE (uuid, organisation_id);


--
-- Name: manual_message manual_broadcast_message_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.manual_message
    ADD CONSTRAINT manual_broadcast_message_pkey PRIMARY KEY (id);


--
-- Name: manual_message manual_broadcast_message_uuid_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.manual_message
    ADD CONSTRAINT manual_broadcast_message_uuid_organisation_id_key UNIQUE (uuid, organisation_id);


--
-- Name: menu_item menu_item_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.menu_item
    ADD CONSTRAINT menu_item_pkey PRIMARY KEY (id);


--
-- Name: menu_item menu_item_uuid_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.menu_item
    ADD CONSTRAINT menu_item_uuid_organisation_id_key UNIQUE (uuid, organisation_id);


--
-- Name: message_receiver message_receiver_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.message_receiver
    ADD CONSTRAINT message_receiver_pkey PRIMARY KEY (id);


--
-- Name: message_receiver message_receiver_receiver_id_receiver_type_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.message_receiver
    ADD CONSTRAINT message_receiver_receiver_id_receiver_type_organisation_id_key UNIQUE (receiver_id, receiver_type, organisation_id);


--
-- Name: message_receiver message_receiver_uuid_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.message_receiver
    ADD CONSTRAINT message_receiver_uuid_organisation_id_key UNIQUE (uuid, organisation_id);


--
-- Name: message_request_queue message_request_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.message_request_queue
    ADD CONSTRAINT message_request_queue_pkey PRIMARY KEY (id);


--
-- Name: message_request_queue message_request_queue_uuid_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.message_request_queue
    ADD CONSTRAINT message_request_queue_uuid_organisation_id_key UNIQUE (uuid, organisation_id);


--
-- Name: message_rule message_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.message_rule
    ADD CONSTRAINT message_rule_pkey PRIMARY KEY (id);


--
-- Name: message_rule message_rule_uuid_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.message_rule
    ADD CONSTRAINT message_rule_uuid_organisation_id_key UNIQUE (uuid, organisation_id);


--
-- Name: msg91_config msg91_config_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.msg91_config
    ADD CONSTRAINT msg91_config_pkey PRIMARY KEY (id);


--
-- Name: msg91_config msg91_config_uuid_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.msg91_config
    ADD CONSTRAINT msg91_config_uuid_organisation_id_key UNIQUE (uuid, organisation_id);


--
-- Name: news news_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.news
    ADD CONSTRAINT news_pkey PRIMARY KEY (id);


--
-- Name: news news_uuid_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.news
    ADD CONSTRAINT news_uuid_key UNIQUE (uuid);


--
-- Name: non_applicable_form_element non_applicable_form_element_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.non_applicable_form_element
    ADD CONSTRAINT non_applicable_form_element_pkey PRIMARY KEY (id);


--
-- Name: operational_encounter_type operational_encounter_type_encounter_type_organisation_id_uniqu; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.operational_encounter_type
    ADD CONSTRAINT operational_encounter_type_encounter_type_organisation_id_uniqu UNIQUE (encounter_type_id, organisation_id);


--
-- Name: operational_encounter_type operational_encounter_type_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.operational_encounter_type
    ADD CONSTRAINT operational_encounter_type_pkey PRIMARY KEY (id);


--
-- Name: operational_program operational_program_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.operational_program
    ADD CONSTRAINT operational_program_pkey PRIMARY KEY (id);


--
-- Name: operational_program operational_program_program_id_organisation_id_unique; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.operational_program
    ADD CONSTRAINT operational_program_program_id_organisation_id_unique UNIQUE (program_id, organisation_id);


--
-- Name: operational_subject_type operational_subject_type_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.operational_subject_type
    ADD CONSTRAINT operational_subject_type_pkey PRIMARY KEY (id);


--
-- Name: operational_subject_type operational_subject_type_uuid_org_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.operational_subject_type
    ADD CONSTRAINT operational_subject_type_uuid_org_id_key UNIQUE (uuid, organisation_id);


--
-- Name: organisation_config organisation_config_organisation_id_is_voided_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.organisation_config
    ADD CONSTRAINT organisation_config_organisation_id_is_voided_key UNIQUE (organisation_id, is_voided);


--
-- Name: organisation_config organisation_config_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.organisation_config
    ADD CONSTRAINT organisation_config_pkey PRIMARY KEY (id);


--
-- Name: organisation_config organisation_config_uuid_org_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.organisation_config
    ADD CONSTRAINT organisation_config_uuid_org_id_key UNIQUE (uuid, organisation_id);


--
-- Name: organisation organisation_db_user_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.organisation
    ADD CONSTRAINT organisation_db_user_key UNIQUE (db_user);


--
-- Name: organisation_group_organisation organisation_group_organisation_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.organisation_group_organisation
    ADD CONSTRAINT organisation_group_organisation_pkey PRIMARY KEY (id);


--
-- Name: organisation_group organisation_group_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.organisation_group
    ADD CONSTRAINT organisation_group_pkey PRIMARY KEY (id);


--
-- Name: organisation organisation_media_directory_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.organisation
    ADD CONSTRAINT organisation_media_directory_key UNIQUE (media_directory);


--
-- Name: organisation organisation_name_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.organisation
    ADD CONSTRAINT organisation_name_key UNIQUE (name);


--
-- Name: organisation organisation_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.organisation
    ADD CONSTRAINT organisation_pkey PRIMARY KEY (id);


--
-- Name: organisation organisation_uuid_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.organisation
    ADD CONSTRAINT organisation_uuid_key UNIQUE (uuid);


--
-- Name: platform_translation platform_translation_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.platform_translation
    ADD CONSTRAINT platform_translation_pkey PRIMARY KEY (id);


--
-- Name: privilege privilege_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.privilege
    ADD CONSTRAINT privilege_pkey PRIMARY KEY (id);


--
-- Name: program_encounter program_encounter_legacy_id_organisation_id_uniq_idx; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_encounter
    ADD CONSTRAINT program_encounter_legacy_id_organisation_id_uniq_idx UNIQUE (legacy_id, organisation_id);


--
-- Name: program_encounter program_encounter_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_encounter
    ADD CONSTRAINT program_encounter_pkey PRIMARY KEY (id);


--
-- Name: program_encounter program_encounter_uuid_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_encounter
    ADD CONSTRAINT program_encounter_uuid_key UNIQUE (uuid);


--
-- Name: program_enrolment program_enrolment_legacy_id_organisation_id_uniq_idx; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_enrolment
    ADD CONSTRAINT program_enrolment_legacy_id_organisation_id_uniq_idx UNIQUE (legacy_id, organisation_id);


--
-- Name: program_enrolment program_enrolment_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_enrolment
    ADD CONSTRAINT program_enrolment_pkey PRIMARY KEY (id);


--
-- Name: program_enrolment program_enrolment_uuid_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_enrolment
    ADD CONSTRAINT program_enrolment_uuid_key UNIQUE (uuid);


--
-- Name: program_organisation_config_at_risk_concept program_organisation_config_at_risk_concept_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_organisation_config_at_risk_concept
    ADD CONSTRAINT program_organisation_config_at_risk_concept_pkey PRIMARY KEY (id);


--
-- Name: program_organisation_config program_organisation_config_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_organisation_config
    ADD CONSTRAINT program_organisation_config_pkey PRIMARY KEY (id);


--
-- Name: program_organisation_config program_organisation_config_uuid_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_organisation_config
    ADD CONSTRAINT program_organisation_config_uuid_key UNIQUE (uuid);


--
-- Name: program_organisation_config program_organisation_unique_constraint; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_organisation_config
    ADD CONSTRAINT program_organisation_unique_constraint UNIQUE (program_id, organisation_id);


--
-- Name: program_outcome program_outcome_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_outcome
    ADD CONSTRAINT program_outcome_pkey PRIMARY KEY (id);


--
-- Name: program_outcome program_outcome_uuid_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_outcome
    ADD CONSTRAINT program_outcome_uuid_key UNIQUE (uuid);


--
-- Name: program program_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT program_pkey PRIMARY KEY (id);


--
-- Name: program program_uuid_org_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT program_uuid_org_id_key UNIQUE (uuid, organisation_id);


--
-- Name: reset_sync reset_sync_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.reset_sync
    ADD CONSTRAINT reset_sync_pkey PRIMARY KEY (id);


--
-- Name: reset_sync reset_sync_uuid_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.reset_sync
    ADD CONSTRAINT reset_sync_uuid_organisation_id_key UNIQUE (uuid, organisation_id);


--
-- Name: rule_dependency rule_dependency_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.rule_dependency
    ADD CONSTRAINT rule_dependency_pkey PRIMARY KEY (id);


--
-- Name: rule_dependency rule_dependency_uuid_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.rule_dependency
    ADD CONSTRAINT rule_dependency_uuid_key UNIQUE (uuid);


--
-- Name: rule_failure_log rule_failure_log_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.rule_failure_log
    ADD CONSTRAINT rule_failure_log_pkey PRIMARY KEY (id);


--
-- Name: rule_failure_log rule_failure_log_uuid_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.rule_failure_log
    ADD CONSTRAINT rule_failure_log_uuid_key UNIQUE (uuid);


--
-- Name: rule_failure_telemetry rule_failure_telemetry_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.rule_failure_telemetry
    ADD CONSTRAINT rule_failure_telemetry_pkey PRIMARY KEY (id);


--
-- Name: rule_failure_telemetry rule_failure_telemetry_uuid_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.rule_failure_telemetry
    ADD CONSTRAINT rule_failure_telemetry_uuid_key UNIQUE (uuid);


--
-- Name: rule rule_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.rule
    ADD CONSTRAINT rule_pkey PRIMARY KEY (id);


--
-- Name: rule rule_uuid_org_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.rule
    ADD CONSTRAINT rule_uuid_org_id_key UNIQUE (uuid, organisation_id);


--
-- Name: schema_version schema_version_pk; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.schema_version
    ADD CONSTRAINT schema_version_pk PRIMARY KEY (installed_rank);


--
-- Name: standard_report_card_type standard_report_card_type_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.standard_report_card_type
    ADD CONSTRAINT standard_report_card_type_pkey PRIMARY KEY (id);


--
-- Name: subject_migration subject_migration_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.subject_migration
    ADD CONSTRAINT subject_migration_pkey PRIMARY KEY (id);


--
-- Name: subject_migration subject_migration_uuid_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.subject_migration
    ADD CONSTRAINT subject_migration_uuid_organisation_id_key UNIQUE (uuid, organisation_id);


--
-- Name: subject_program_eligibility subject_program_eligibility_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.subject_program_eligibility
    ADD CONSTRAINT subject_program_eligibility_pkey PRIMARY KEY (id);


--
-- Name: subject_program_eligibility subject_program_eligibility_uuid_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.subject_program_eligibility
    ADD CONSTRAINT subject_program_eligibility_uuid_key UNIQUE (uuid);


--
-- Name: subject_type subject_type_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.subject_type
    ADD CONSTRAINT subject_type_pkey PRIMARY KEY (id);


--
-- Name: subject_type subject_type_uuid_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.subject_type
    ADD CONSTRAINT subject_type_uuid_organisation_id_key UNIQUE (uuid, organisation_id);


--
-- Name: sync_telemetry sync_telemetry_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.sync_telemetry
    ADD CONSTRAINT sync_telemetry_pkey PRIMARY KEY (id);


--
-- Name: table_metadata table_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.table_metadata
    ADD CONSTRAINT table_metadata_pkey PRIMARY KEY (id);


--
-- Name: task task_legacy_id_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_legacy_id_organisation_id_key UNIQUE (legacy_id, organisation_id);


--
-- Name: task task_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_pkey PRIMARY KEY (id);


--
-- Name: task_status task_status_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task_status
    ADD CONSTRAINT task_status_pkey PRIMARY KEY (id);


--
-- Name: task_status task_status_uuid_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task_status
    ADD CONSTRAINT task_status_uuid_organisation_id_key UNIQUE (uuid, organisation_id);


--
-- Name: task_type task_type_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task_type
    ADD CONSTRAINT task_type_pkey PRIMARY KEY (id);


--
-- Name: task_type task_type_uuid_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task_type
    ADD CONSTRAINT task_type_uuid_organisation_id_key UNIQUE (uuid, organisation_id);


--
-- Name: task_unassignment task_unassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task_unassignment
    ADD CONSTRAINT task_unassignment_pkey PRIMARY KEY (id);


--
-- Name: task_unassignment task_unassignment_uuid_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task_unassignment
    ADD CONSTRAINT task_unassignment_uuid_key UNIQUE (uuid);


--
-- Name: task task_uuid_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_uuid_key UNIQUE (uuid);


--
-- Name: translation translation_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.translation
    ADD CONSTRAINT translation_pkey PRIMARY KEY (id);


--
-- Name: translation translation_uuid_org_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.translation
    ADD CONSTRAINT translation_uuid_org_id_key UNIQUE (uuid, organisation_id);


--
-- Name: rule unique_fn_rule_name; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.rule
    ADD CONSTRAINT unique_fn_rule_name UNIQUE (organisation_id, fn_name);


--
-- Name: address_level unique_name_per_level; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.address_level
    ADD CONSTRAINT unique_name_per_level UNIQUE (title, type_id, parent_id, organisation_id);


--
-- Name: rule unique_rule_name; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.rule
    ADD CONSTRAINT unique_rule_name UNIQUE (organisation_id, name);


--
-- Name: user_group user_group_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.user_group
    ADD CONSTRAINT user_group_pkey PRIMARY KEY (id);


--
-- Name: user_group user_group_uuid_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.user_group
    ADD CONSTRAINT user_group_uuid_key UNIQUE (uuid);


--
-- Name: user_subject_assignment user_subject_assignment_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.user_subject_assignment
    ADD CONSTRAINT user_subject_assignment_pkey PRIMARY KEY (id);


--
-- Name: user_subject_assignment user_subject_assignment_uuid_organisation_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.user_subject_assignment
    ADD CONSTRAINT user_subject_assignment_uuid_organisation_id_key UNIQUE (uuid, organisation_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_uuid_org_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_uuid_org_id_key UNIQUE (uuid, organisation_id);


--
-- Name: video video_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.video
    ADD CONSTRAINT video_pkey PRIMARY KEY (id);


--
-- Name: video_telemetric video_telemetric_pkey; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.video_telemetric
    ADD CONSTRAINT video_telemetric_pkey PRIMARY KEY (id);


--
-- Name: video video_uuid_org_id_key; Type: CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.video
    ADD CONSTRAINT video_uuid_org_id_key UNIQUE (uuid, organisation_id);


--
-- Name: address_level_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX address_level_last_modified_time_idx ON public.address_level USING btree (last_modified_date_time);


--
-- Name: address_level_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX address_level_organisation_id__index ON public.address_level USING btree (organisation_id);


--
-- Name: address_level_type_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX address_level_type_last_modified_time_idx ON public.address_level_type USING btree (last_modified_date_time);


--
-- Name: address_level_type_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX address_level_type_organisation_id__index ON public.address_level_type USING btree (organisation_id);


--
-- Name: catchment_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX catchment_last_modified_time_idx ON public.catchment USING btree (last_modified_date_time);


--
-- Name: catchment_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX catchment_organisation_id__index ON public.catchment USING btree (organisation_id);


--
-- Name: checklist_checklist_detail_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX checklist_checklist_detail_id_index ON public.checklist USING btree (checklist_detail_id);


--
-- Name: checklist_detail_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX checklist_detail_last_modified_time_idx ON public.checklist_detail USING btree (last_modified_date_time);


--
-- Name: checklist_detail_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX checklist_detail_organisation_id__index ON public.checklist_detail USING btree (organisation_id);


--
-- Name: checklist_item_checklist_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX checklist_item_checklist_id_index ON public.checklist_item USING btree (checklist_id);


--
-- Name: checklist_item_checklist_item_detail_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX checklist_item_checklist_item_detail_id_index ON public.checklist_item USING btree (checklist_item_detail_id);


--
-- Name: checklist_item_detail_checklist_detail_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX checklist_item_detail_checklist_detail_id_index ON public.checklist_item_detail USING btree (checklist_detail_id);


--
-- Name: checklist_item_detail_concept_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX checklist_item_detail_concept_id_index ON public.checklist_item_detail USING btree (concept_id);


--
-- Name: checklist_item_detail_dependent_on_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX checklist_item_detail_dependent_on_index ON public.checklist_item_detail USING btree (dependent_on);


--
-- Name: checklist_item_detail_form_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX checklist_item_detail_form_id_index ON public.checklist_item_detail USING btree (form_id);


--
-- Name: checklist_item_detail_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX checklist_item_detail_last_modified_time_idx ON public.checklist_item_detail USING btree (last_modified_date_time);


--
-- Name: checklist_item_detail_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX checklist_item_detail_organisation_id__index ON public.checklist_item_detail USING btree (organisation_id);


--
-- Name: checklist_item_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX checklist_item_last_modified_time_idx ON public.checklist_item USING btree (last_modified_date_time);


--
-- Name: checklist_item_obs_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX checklist_item_obs_idx ON public.checklist_item USING gin (observations jsonb_path_ops);


--
-- Name: checklist_item_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX checklist_item_organisation_id__index ON public.checklist_item USING btree (organisation_id);


--
-- Name: checklist_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX checklist_last_modified_time_idx ON public.checklist USING btree (last_modified_date_time);


--
-- Name: checklist_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX checklist_organisation_id__index ON public.checklist USING btree (organisation_id);


--
-- Name: checklist_program_enrolment_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX checklist_program_enrolment_id_index ON public.checklist USING btree (program_enrolment_id);


--
-- Name: comment_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX comment_last_modified_time_idx ON public.comment USING btree (last_modified_date_time);


--
-- Name: comment_subject_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX comment_subject_id_index ON public.comment USING btree (subject_id);


--
-- Name: comment_thread_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX comment_thread_last_modified_time_idx ON public.comment_thread USING btree (last_modified_date_time);


--
-- Name: comment_thread_uuid_organisation_id_uniq_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE UNIQUE INDEX comment_thread_uuid_organisation_id_uniq_idx ON public.comment USING btree (uuid, organisation_id);


--
-- Name: comment_uuid_organisation_id_uniq_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE UNIQUE INDEX comment_uuid_organisation_id_uniq_idx ON public.comment USING btree (uuid, organisation_id);


--
-- Name: concept_answer_answer_concept_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX concept_answer_answer_concept_id_index ON public.concept_answer USING btree (answer_concept_id);


--
-- Name: concept_answer_concept_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX concept_answer_concept_id_index ON public.concept_answer USING btree (concept_id);


--
-- Name: concept_answer_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX concept_answer_last_modified_time_idx ON public.concept_answer USING btree (last_modified_date_time);


--
-- Name: concept_answer_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX concept_answer_organisation_id__index ON public.concept_answer USING btree (organisation_id);


--
-- Name: concept_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX concept_last_modified_time_idx ON public.concept USING btree (last_modified_date_time);


--
-- Name: concept_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX concept_organisation_id__index ON public.concept USING btree (organisation_id);


--
-- Name: dashboard_card_mapping_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX dashboard_card_mapping_last_modified_time_idx ON public.dashboard_card_mapping USING btree (last_modified_date_time);


--
-- Name: dashboard_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX dashboard_last_modified_time_idx ON public.dashboard USING btree (last_modified_date_time);


--
-- Name: dashboard_section_card_mapping_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX dashboard_section_card_mapping_last_modified_time_idx ON public.dashboard_section_card_mapping USING btree (last_modified_date_time);


--
-- Name: dashboard_section_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX dashboard_section_last_modified_time_idx ON public.dashboard_section USING btree (last_modified_date_time);


--
-- Name: documentation_item_documentation_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX documentation_item_documentation_id_index ON public.documentation_item USING btree (documentation_id);


--
-- Name: documentation_item_organisation_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX documentation_item_organisation_id_index ON public.documentation_item USING btree (organisation_id);


--
-- Name: documentation_organisation_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX documentation_organisation_id_index ON public.documentation USING btree (organisation_id);


--
-- Name: encounter_cancel_obs_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX encounter_cancel_obs_idx ON public.encounter USING gin (cancel_observations jsonb_path_ops);


--
-- Name: encounter_encounter_type_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX encounter_encounter_type_id_index ON public.encounter USING btree (encounter_type_id);


--
-- Name: encounter_individual_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX encounter_individual_id_index ON public.encounter USING btree (individual_id);


--
-- Name: encounter_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX encounter_last_modified_time_idx ON public.encounter USING btree (last_modified_date_time);


--
-- Name: encounter_legacy_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX encounter_legacy_id_index ON public.encounter USING btree (legacy_id);


--
-- Name: encounter_obs_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX encounter_obs_idx ON public.encounter USING gin (observations jsonb_path_ops);


--
-- Name: encounter_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX encounter_organisation_id__index ON public.encounter USING btree (organisation_id);


--
-- Name: encounter_type_concept_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX encounter_type_concept_id_index ON public.encounter_type USING btree (concept_id);


--
-- Name: encounter_type_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX encounter_type_last_modified_time_idx ON public.encounter_type USING btree (last_modified_date_time);


--
-- Name: encounter_type_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX encounter_type_organisation_id__index ON public.encounter_type USING btree (organisation_id);


--
-- Name: entity_approval_status_approval_status_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX entity_approval_status_approval_status_id_index ON public.entity_approval_status USING btree (approval_status_id);


--
-- Name: entity_approval_status_entity_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX entity_approval_status_entity_id_index ON public.entity_approval_status USING btree (entity_id);


--
-- Name: entity_approval_status_entity_type_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX entity_approval_status_entity_type_index ON public.entity_approval_status USING btree (entity_type);


--
-- Name: entity_approval_status_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX entity_approval_status_last_modified_time_idx ON public.entity_approval_status USING btree (last_modified_date_time);


--
-- Name: entity_approval_status_sync_1_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX entity_approval_status_sync_1_index ON public.entity_approval_status USING btree (address_id, last_modified_date_time, organisation_id, entity_type, entity_type_uuid);


--
-- Name: entity_approval_status_sync_2_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX entity_approval_status_sync_2_index ON public.entity_approval_status USING btree (individual_id, last_modified_date_time, organisation_id, entity_type, entity_type_uuid);


--
-- Name: entity_approval_status_sync_3_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX entity_approval_status_sync_3_index ON public.entity_approval_status USING btree (sync_concept_1_value, last_modified_date_time, organisation_id, entity_type, entity_type_uuid);


--
-- Name: entity_approval_status_sync_4_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX entity_approval_status_sync_4_index ON public.entity_approval_status USING btree (sync_concept_1_value, sync_concept_2_value, last_modified_date_time, organisation_id, entity_type, entity_type_uuid);


--
-- Name: entity_approval_status_sync_5_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX entity_approval_status_sync_5_index ON public.entity_approval_status USING btree (address_id, individual_id, sync_concept_1_value, sync_concept_2_value, last_modified_date_time, organisation_id, entity_type, entity_type_uuid);


--
-- Name: facility_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX facility_last_modified_time_idx ON public.facility USING btree (last_modified_date_time);


--
-- Name: facility_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX facility_organisation_id__index ON public.facility USING btree (organisation_id);


--
-- Name: form_element_concept_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX form_element_concept_id_index ON public.form_element USING btree (concept_id);


--
-- Name: form_element_form_element_group_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX form_element_form_element_group_id_index ON public.form_element USING btree (form_element_group_id);


--
-- Name: form_element_group_form_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX form_element_group_form_id_index ON public.form_element_group USING btree (form_id);


--
-- Name: form_element_group_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX form_element_group_last_modified_time_idx ON public.form_element_group USING btree (last_modified_date_time);


--
-- Name: form_element_group_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX form_element_group_organisation_id__index ON public.form_element_group USING btree (organisation_id);


--
-- Name: form_element_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX form_element_last_modified_time_idx ON public.form_element USING btree (last_modified_date_time);


--
-- Name: form_element_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX form_element_organisation_id__index ON public.form_element USING btree (organisation_id);


--
-- Name: form_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX form_last_modified_time_idx ON public.form USING btree (last_modified_date_time);


--
-- Name: form_mapping_form_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX form_mapping_form_id_index ON public.form_mapping USING btree (form_id);


--
-- Name: form_mapping_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX form_mapping_last_modified_time_idx ON public.form_mapping USING btree (last_modified_date_time);


--
-- Name: form_mapping_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX form_mapping_organisation_id__index ON public.form_mapping USING btree (organisation_id);


--
-- Name: form_mapping_subject_type_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX form_mapping_subject_type_id_index ON public.form_mapping USING btree (subject_type_id);


--
-- Name: form_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX form_organisation_id__index ON public.form USING btree (organisation_id);


--
-- Name: gender_concept_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX gender_concept_id_index ON public.gender USING btree (concept_id);


--
-- Name: gender_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX gender_last_modified_time_idx ON public.gender USING btree (last_modified_date_time);


--
-- Name: gender_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX gender_organisation_id__index ON public.gender USING btree (organisation_id);


--
-- Name: group_dashboard_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX group_dashboard_last_modified_time_idx ON public.group_dashboard USING btree (last_modified_date_time);


--
-- Name: group_privilege_checklist_detail_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX group_privilege_checklist_detail_id_index ON public.group_privilege USING btree (checklist_detail_id);


--
-- Name: group_privilege_encounter_type_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX group_privilege_encounter_type_id_index ON public.group_privilege USING btree (encounter_type_id);


--
-- Name: group_privilege_group_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX group_privilege_group_id_index ON public.group_privilege USING btree (group_id);


--
-- Name: group_privilege_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX group_privilege_last_modified_time_idx ON public.group_privilege USING btree (last_modified_date_time);


--
-- Name: group_privilege_program_encounter_type_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX group_privilege_program_encounter_type_id_index ON public.group_privilege USING btree (program_encounter_type_id);


--
-- Name: group_privilege_program_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX group_privilege_program_id_index ON public.group_privilege USING btree (program_id);


--
-- Name: group_privilege_subject_type_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX group_privilege_subject_type_id_index ON public.group_privilege USING btree (subject_type_id);


--
-- Name: group_role_group_subject_type_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX group_role_group_subject_type_id_index ON public.group_role USING btree (group_subject_type_id);


--
-- Name: group_role_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX group_role_last_modified_time_idx ON public.group_role USING btree (last_modified_date_time);


--
-- Name: group_role_member_subject_type_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX group_role_member_subject_type_id_index ON public.group_role USING btree (member_subject_type_id);


--
-- Name: group_subject_group_role_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX group_subject_group_role_id_index ON public.group_subject USING btree (group_role_id);


--
-- Name: group_subject_group_subject_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX group_subject_group_subject_id_index ON public.group_subject USING btree (group_subject_id);


--
-- Name: group_subject_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX group_subject_last_modified_time_idx ON public.group_subject USING btree (last_modified_date_time);


--
-- Name: group_subject_member_subject_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX group_subject_member_subject_id_index ON public.group_subject USING btree (member_subject_id);


--
-- Name: groups_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX groups_last_modified_time_idx ON public.groups USING btree (last_modified_date_time);


--
-- Name: identifier_assignment_identifier_source_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX identifier_assignment_identifier_source_id_index ON public.identifier_assignment USING btree (identifier_source_id);


--
-- Name: identifier_assignment_individual_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX identifier_assignment_individual_id_index ON public.identifier_assignment USING btree (individual_id);


--
-- Name: identifier_assignment_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX identifier_assignment_last_modified_time_idx ON public.identifier_assignment USING btree (last_modified_date_time);


--
-- Name: identifier_assignment_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX identifier_assignment_organisation_id__index ON public.identifier_assignment USING btree (organisation_id);


--
-- Name: identifier_assignment_program_enrolment_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX identifier_assignment_program_enrolment_id_index ON public.identifier_assignment USING btree (program_enrolment_id);


--
-- Name: identifier_source_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX identifier_source_last_modified_time_idx ON public.identifier_source USING btree (last_modified_date_time);


--
-- Name: identifier_source_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX identifier_source_organisation_id__index ON public.identifier_source USING btree (organisation_id);


--
-- Name: identifier_user_assignment_identifier_source_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX identifier_user_assignment_identifier_source_id_index ON public.identifier_user_assignment USING btree (identifier_source_id);


--
-- Name: identifier_user_assignment_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX identifier_user_assignment_last_modified_time_idx ON public.identifier_user_assignment USING btree (last_modified_date_time);


--
-- Name: identifier_user_assignment_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX identifier_user_assignment_organisation_id__index ON public.identifier_user_assignment USING btree (organisation_id);


--
-- Name: idx_individual_obs; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX idx_individual_obs ON public.individual USING gin (observations jsonb_path_ops);


--
-- Name: idx_program_encounter_obs; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX idx_program_encounter_obs ON public.program_encounter USING gin (observations jsonb_path_ops);


--
-- Name: idx_program_enrolment_obs; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX idx_program_enrolment_obs ON public.program_enrolment USING gin (observations jsonb_path_ops);


--
-- Name: individual_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX individual_last_modified_time_idx ON public.individual USING btree (last_modified_date_time);


--
-- Name: individual_legacy_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX individual_legacy_id_index ON public.individual USING btree (legacy_id);


--
-- Name: individual_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX individual_organisation_id__index ON public.individual USING btree (organisation_id);


--
-- Name: individual_relation_gender_mapping_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX individual_relation_gender_mapping_last_modified_time_idx ON public.individual_relation_gender_mapping USING btree (last_modified_date_time);


--
-- Name: individual_relation_gender_mapping_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX individual_relation_gender_mapping_organisation_id__index ON public.individual_relation_gender_mapping USING btree (organisation_id);


--
-- Name: individual_relation_gender_mapping_relation_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX individual_relation_gender_mapping_relation_id_index ON public.individual_relation_gender_mapping USING btree (relation_id);


--
-- Name: individual_relation_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX individual_relation_last_modified_time_idx ON public.individual_relation USING btree (last_modified_date_time);


--
-- Name: individual_relation_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX individual_relation_organisation_id__index ON public.individual_relation USING btree (organisation_id);


--
-- Name: individual_relationship_individual_a_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX individual_relationship_individual_a_id_index ON public.individual_relationship USING btree (individual_a_id);


--
-- Name: individual_relationship_individual_b_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX individual_relationship_individual_b_id_index ON public.individual_relationship USING btree (individual_b_id);


--
-- Name: individual_relationship_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX individual_relationship_last_modified_time_idx ON public.individual_relationship USING btree (last_modified_date_time);


--
-- Name: individual_relationship_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX individual_relationship_organisation_id__index ON public.individual_relationship USING btree (organisation_id);


--
-- Name: individual_relationship_relationship_type_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX individual_relationship_relationship_type_id_index ON public.individual_relationship USING btree (relationship_type_id);


--
-- Name: individual_relationship_type_individual_a_is_to_b_relation_id_i; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX individual_relationship_type_individual_a_is_to_b_relation_id_i ON public.individual_relationship_type USING btree (individual_a_is_to_b_relation_id);


--
-- Name: individual_relationship_type_individual_b_is_to_a_relation_id_i; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX individual_relationship_type_individual_b_is_to_a_relation_id_i ON public.individual_relationship_type USING btree (individual_b_is_to_a_relation_id);


--
-- Name: individual_relationship_type_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX individual_relationship_type_last_modified_time_idx ON public.individual_relationship_type USING btree (last_modified_date_time);


--
-- Name: individual_relationship_type_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX individual_relationship_type_organisation_id__index ON public.individual_relationship_type USING btree (organisation_id);


--
-- Name: individual_relative_individual_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX individual_relative_individual_id_index ON public.individual_relative USING btree (individual_id);


--
-- Name: individual_relative_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX individual_relative_last_modified_time_idx ON public.individual_relative USING btree (last_modified_date_time);


--
-- Name: individual_relative_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX individual_relative_organisation_id__index ON public.individual_relative USING btree (organisation_id);


--
-- Name: individual_relative_relative_individual_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX individual_relative_relative_individual_id_index ON public.individual_relative USING btree (relative_individual_id);


--
-- Name: individual_subject_type_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX individual_subject_type_id_index ON public.individual USING btree (subject_type_id);


--
-- Name: location_location_mapping_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX location_location_mapping_last_modified_time_idx ON public.location_location_mapping USING btree (last_modified_date_time);


--
-- Name: location_location_mapping_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX location_location_mapping_organisation_id__index ON public.location_location_mapping USING btree (organisation_id);


--
-- Name: msg91_config_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX msg91_config_last_modified_time_idx ON public.msg91_config USING btree (last_modified_date_time);


--
-- Name: news_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX news_last_modified_time_idx ON public.news USING btree (last_modified_date_time);


--
-- Name: news_published_date_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX news_published_date_idx ON public.news USING btree (organisation_id, published_date);


--
-- Name: news_uuid_organisation_id_uniq_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE UNIQUE INDEX news_uuid_organisation_id_uniq_idx ON public.news USING btree (uuid, organisation_id);


--
-- Name: non_applicable_form_element_form_element_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX non_applicable_form_element_form_element_id_index ON public.non_applicable_form_element USING btree (form_element_id);


--
-- Name: non_applicable_form_element_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX non_applicable_form_element_last_modified_time_idx ON public.non_applicable_form_element USING btree (last_modified_date_time);


--
-- Name: non_applicable_form_element_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX non_applicable_form_element_organisation_id__index ON public.non_applicable_form_element USING btree (organisation_id);


--
-- Name: operational_encounter_type_encounter_type_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX operational_encounter_type_encounter_type_id_index ON public.operational_encounter_type USING btree (encounter_type_id);


--
-- Name: operational_encounter_type_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX operational_encounter_type_last_modified_time_idx ON public.operational_encounter_type USING btree (last_modified_date_time);


--
-- Name: operational_encounter_type_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX operational_encounter_type_organisation_id__index ON public.operational_encounter_type USING btree (organisation_id);


--
-- Name: operational_program_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX operational_program_last_modified_time_idx ON public.operational_program USING btree (last_modified_date_time);


--
-- Name: operational_program_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX operational_program_organisation_id__index ON public.operational_program USING btree (organisation_id);


--
-- Name: operational_program_program_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX operational_program_program_id_index ON public.operational_program USING btree (program_id);


--
-- Name: operational_subject_type_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX operational_subject_type_last_modified_time_idx ON public.operational_subject_type USING btree (last_modified_date_time);


--
-- Name: operational_subject_type_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX operational_subject_type_organisation_id__index ON public.operational_subject_type USING btree (organisation_id);


--
-- Name: operational_subject_type_subject_type_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX operational_subject_type_subject_type_id_index ON public.operational_subject_type USING btree (subject_type_id);


--
-- Name: organisation_config_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX organisation_config_last_modified_time_idx ON public.organisation_config USING btree (last_modified_date_time);


--
-- Name: platform_translation_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX platform_translation_last_modified_time_idx ON public.platform_translation USING btree (last_modified_date_time);


--
-- Name: program_encounter_cancel_obs_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX program_encounter_cancel_obs_idx ON public.program_encounter USING gin (cancel_observations jsonb_path_ops);


--
-- Name: program_encounter_encounter_type_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX program_encounter_encounter_type_id_index ON public.program_encounter USING btree (encounter_type_id);


--
-- Name: program_encounter_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX program_encounter_last_modified_time_idx ON public.program_encounter USING btree (last_modified_date_time);


--
-- Name: program_encounter_legacy_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX program_encounter_legacy_id_index ON public.program_encounter USING btree (legacy_id);


--
-- Name: program_encounter_obs_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX program_encounter_obs_idx ON public.program_encounter USING gin (observations jsonb_path_ops);


--
-- Name: program_encounter_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX program_encounter_organisation_id__index ON public.program_encounter USING btree (organisation_id);


--
-- Name: program_encounter_program_enrolment_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX program_encounter_program_enrolment_id_index ON public.program_encounter USING btree (program_enrolment_id);


--
-- Name: program_enrolment_exit_obs_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX program_enrolment_exit_obs_idx ON public.program_enrolment USING gin (program_exit_observations jsonb_path_ops);


--
-- Name: program_enrolment_individual_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX program_enrolment_individual_id_index ON public.program_enrolment USING btree (individual_id);


--
-- Name: program_enrolment_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX program_enrolment_last_modified_time_idx ON public.program_enrolment USING btree (last_modified_date_time);


--
-- Name: program_enrolment_legacy_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX program_enrolment_legacy_id_index ON public.program_enrolment USING btree (legacy_id);


--
-- Name: program_enrolment_obs_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX program_enrolment_obs_idx ON public.program_enrolment USING gin (observations jsonb_path_ops);


--
-- Name: program_enrolment_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX program_enrolment_organisation_id__index ON public.program_enrolment USING btree (organisation_id);


--
-- Name: program_enrolment_program_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX program_enrolment_program_id_index ON public.program_enrolment USING btree (program_id);


--
-- Name: program_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX program_last_modified_time_idx ON public.program USING btree (last_modified_date_time);


--
-- Name: program_organisation_config_at_risk_concept_concept_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX program_organisation_config_at_risk_concept_concept_id_index ON public.program_organisation_config_at_risk_concept USING btree (concept_id);


--
-- Name: program_organisation_config_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX program_organisation_config_last_modified_time_idx ON public.program_organisation_config USING btree (last_modified_date_time);


--
-- Name: program_organisation_config_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX program_organisation_config_organisation_id__index ON public.program_organisation_config USING btree (organisation_id);


--
-- Name: program_organisation_config_program_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX program_organisation_config_program_id_index ON public.program_organisation_config USING btree (program_id);


--
-- Name: program_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX program_organisation_id__index ON public.program USING btree (organisation_id);


--
-- Name: program_outcome_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX program_outcome_last_modified_time_idx ON public.program_outcome USING btree (last_modified_date_time);


--
-- Name: program_outcome_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX program_outcome_organisation_id__index ON public.program_outcome USING btree (organisation_id);


--
-- Name: report_card_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX report_card_last_modified_time_idx ON public.report_card USING btree (last_modified_date_time);


--
-- Name: reset_sync_subject_type_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX reset_sync_subject_type_id_index ON public.reset_sync USING btree (subject_type_id);


--
-- Name: reset_sync_user_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX reset_sync_user_id_index ON public.reset_sync USING btree (user_id);


--
-- Name: rule_dependency_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX rule_dependency_last_modified_time_idx ON public.rule_dependency USING btree (last_modified_date_time);


--
-- Name: rule_dependency_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX rule_dependency_organisation_id__index ON public.rule_dependency USING btree (organisation_id);


--
-- Name: rule_failure_log_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX rule_failure_log_last_modified_time_idx ON public.rule_failure_log USING btree (last_modified_date_time);


--
-- Name: rule_failure_telemetry_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX rule_failure_telemetry_last_modified_time_idx ON public.rule_failure_telemetry USING btree (last_modified_date_time);


--
-- Name: rule_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX rule_last_modified_time_idx ON public.rule USING btree (last_modified_date_time);


--
-- Name: rule_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX rule_organisation_id__index ON public.rule USING btree (organisation_id);


--
-- Name: schema_version_s_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX schema_version_s_idx ON public.schema_version USING btree (success);


--
-- Name: subject_migration_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX subject_migration_last_modified_time_idx ON public.subject_migration USING btree (last_modified_date_time);


--
-- Name: subject_type_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX subject_type_last_modified_time_idx ON public.subject_type USING btree (last_modified_date_time);


--
-- Name: subject_type_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX subject_type_organisation_id__index ON public.subject_type USING btree (organisation_id);


--
-- Name: sync_telemetry_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX sync_telemetry_organisation_id__index ON public.sync_telemetry USING btree (organisation_id);


--
-- Name: sync_telemetry_sync_start_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX sync_telemetry_sync_start_time_idx ON public.sync_telemetry USING btree (sync_start_time);


--
-- Name: sync_telemetry_user_id_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX sync_telemetry_user_id_idx ON public.sync_telemetry USING btree (user_id);


--
-- Name: table_metadata_table_id_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX table_metadata_table_id_idx ON public.column_metadata USING btree (table_id);


--
-- Name: task_metadata_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX task_metadata_idx ON public.task USING gin (metadata jsonb_path_ops);


--
-- Name: task_observations_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX task_observations_idx ON public.task USING gin (observations jsonb_path_ops);


--
-- Name: translation_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX translation_last_modified_time_idx ON public.translation USING btree (last_modified_date_time);


--
-- Name: user_group_group_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX user_group_group_id_index ON public.user_group USING btree (group_id);


--
-- Name: user_group_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX user_group_last_modified_time_idx ON public.user_group USING btree (last_modified_date_time);


--
-- Name: user_subject_assignment_subject_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX user_subject_assignment_subject_id_index ON public.user_subject_assignment USING btree (subject_id);


--
-- Name: user_subject_assignment_user_id_index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX user_subject_assignment_user_id_index ON public.user_subject_assignment USING btree (user_id);


--
-- Name: users_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX users_organisation_id__index ON public.users USING btree (organisation_id);


--
-- Name: users_username_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE UNIQUE INDEX users_username_idx ON public.users USING btree (username);


--
-- Name: video_last_modified_time_idx; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX video_last_modified_time_idx ON public.video USING btree (last_modified_date_time);


--
-- Name: video_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX video_organisation_id__index ON public.video USING btree (organisation_id);


--
-- Name: video_telemetric_organisation_id__index; Type: INDEX; Schema: public; Owner: openchs
--

CREATE INDEX video_telemetric_organisation_id__index ON public.video_telemetric USING btree (organisation_id);


--
-- Name: address_level_type address_level_type_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER address_level_type_update_audit_before_insert BEFORE INSERT ON public.address_level_type FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: address_level_type address_level_type_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER address_level_type_update_audit_before_update BEFORE UPDATE ON public.address_level_type FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: address_level address_level_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER address_level_update_audit_before_insert BEFORE INSERT ON public.address_level FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: address_level address_level_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER address_level_update_audit_before_update BEFORE UPDATE ON public.address_level FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: catchment catchment_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER catchment_update_audit_before_insert BEFORE INSERT ON public.catchment FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: catchment catchment_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER catchment_update_audit_before_update BEFORE UPDATE ON public.catchment FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: checklist_detail checklist_detail_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER checklist_detail_update_audit_before_insert BEFORE INSERT ON public.checklist_detail FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: checklist_detail checklist_detail_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER checklist_detail_update_audit_before_update BEFORE UPDATE ON public.checklist_detail FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: checklist_item_detail checklist_item_detail_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER checklist_item_detail_update_audit_before_insert BEFORE INSERT ON public.checklist_item_detail FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: checklist_item_detail checklist_item_detail_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER checklist_item_detail_update_audit_before_update BEFORE UPDATE ON public.checklist_item_detail FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: checklist_item checklist_item_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER checklist_item_update_audit_before_insert BEFORE INSERT ON public.checklist_item FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: checklist_item checklist_item_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER checklist_item_update_audit_before_update BEFORE UPDATE ON public.checklist_item FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: checklist checklist_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER checklist_update_audit_before_insert BEFORE INSERT ON public.checklist FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: checklist checklist_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER checklist_update_audit_before_update BEFORE UPDATE ON public.checklist FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: comment_thread comment_thread_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER comment_thread_update_audit_before_insert BEFORE INSERT ON public.comment_thread FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: comment_thread comment_thread_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER comment_thread_update_audit_before_update BEFORE UPDATE ON public.comment_thread FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: comment comment_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER comment_update_audit_before_insert BEFORE INSERT ON public.comment FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: comment comment_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER comment_update_audit_before_update BEFORE UPDATE ON public.comment FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: concept_answer concept_answer_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER concept_answer_update_audit_before_insert BEFORE INSERT ON public.concept_answer FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: concept_answer concept_answer_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER concept_answer_update_audit_before_update BEFORE UPDATE ON public.concept_answer FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: concept concept_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER concept_update_audit_before_insert BEFORE INSERT ON public.concept FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: concept concept_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER concept_update_audit_before_update BEFORE UPDATE ON public.concept FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: dashboard_card_mapping dashboard_card_mapping_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER dashboard_card_mapping_update_audit_before_insert BEFORE INSERT ON public.dashboard_card_mapping FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: dashboard_card_mapping dashboard_card_mapping_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER dashboard_card_mapping_update_audit_before_update BEFORE UPDATE ON public.dashboard_card_mapping FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: dashboard_section_card_mapping dashboard_section_card_mapping_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER dashboard_section_card_mapping_update_audit_before_insert BEFORE INSERT ON public.dashboard_section_card_mapping FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: dashboard_section_card_mapping dashboard_section_card_mapping_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER dashboard_section_card_mapping_update_audit_before_update BEFORE UPDATE ON public.dashboard_section_card_mapping FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: dashboard_section dashboard_section_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER dashboard_section_update_audit_before_insert BEFORE INSERT ON public.dashboard_section FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: dashboard_section dashboard_section_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER dashboard_section_update_audit_before_update BEFORE UPDATE ON public.dashboard_section FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: dashboard dashboard_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER dashboard_update_audit_before_insert BEFORE INSERT ON public.dashboard FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: dashboard dashboard_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER dashboard_update_audit_before_update BEFORE UPDATE ON public.dashboard FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: encounter_type encounter_type_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER encounter_type_update_audit_before_insert BEFORE INSERT ON public.encounter_type FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: encounter_type encounter_type_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER encounter_type_update_audit_before_update BEFORE UPDATE ON public.encounter_type FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: encounter encounter_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER encounter_update_audit_before_insert BEFORE INSERT ON public.encounter FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: encounter encounter_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER encounter_update_audit_before_update BEFORE UPDATE ON public.encounter FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: entity_approval_status entity_approval_status_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER entity_approval_status_update_audit_before_insert BEFORE INSERT ON public.entity_approval_status FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: entity_approval_status entity_approval_status_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER entity_approval_status_update_audit_before_update BEFORE UPDATE ON public.entity_approval_status FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: facility facility_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER facility_update_audit_before_insert BEFORE INSERT ON public.facility FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: facility facility_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER facility_update_audit_before_update BEFORE UPDATE ON public.facility FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: form_element_group form_element_group_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER form_element_group_update_audit_before_insert BEFORE INSERT ON public.form_element_group FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: form_element_group form_element_group_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER form_element_group_update_audit_before_update BEFORE UPDATE ON public.form_element_group FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: form_element form_element_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER form_element_update_audit_before_insert BEFORE INSERT ON public.form_element FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: form_element form_element_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER form_element_update_audit_before_update BEFORE UPDATE ON public.form_element FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: form_mapping form_mapping_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER form_mapping_update_audit_before_insert BEFORE INSERT ON public.form_mapping FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: form_mapping form_mapping_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER form_mapping_update_audit_before_update BEFORE UPDATE ON public.form_mapping FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: form form_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER form_update_audit_before_insert BEFORE INSERT ON public.form FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: form form_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER form_update_audit_before_update BEFORE UPDATE ON public.form FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: gender gender_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER gender_update_audit_before_insert BEFORE INSERT ON public.gender FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: gender gender_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER gender_update_audit_before_update BEFORE UPDATE ON public.gender FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: group_dashboard group_dashboard_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER group_dashboard_update_audit_before_insert BEFORE INSERT ON public.group_dashboard FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: group_dashboard group_dashboard_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER group_dashboard_update_audit_before_update BEFORE UPDATE ON public.group_dashboard FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: group_privilege group_privilege_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER group_privilege_update_audit_before_insert BEFORE INSERT ON public.group_privilege FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: group_privilege group_privilege_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER group_privilege_update_audit_before_update BEFORE UPDATE ON public.group_privilege FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: group_role group_role_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER group_role_update_audit_before_insert BEFORE INSERT ON public.group_role FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: group_role group_role_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER group_role_update_audit_before_update BEFORE UPDATE ON public.group_role FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: group_subject group_subject_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER group_subject_update_audit_before_insert BEFORE INSERT ON public.group_subject FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: group_subject group_subject_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER group_subject_update_audit_before_update BEFORE UPDATE ON public.group_subject FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: groups groups_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER groups_update_audit_before_insert BEFORE INSERT ON public.groups FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: groups groups_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER groups_update_audit_before_update BEFORE UPDATE ON public.groups FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: identifier_assignment identifier_assignment_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER identifier_assignment_update_audit_before_insert BEFORE INSERT ON public.identifier_assignment FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: identifier_assignment identifier_assignment_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER identifier_assignment_update_audit_before_update BEFORE UPDATE ON public.identifier_assignment FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: identifier_source identifier_source_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER identifier_source_update_audit_before_insert BEFORE INSERT ON public.identifier_source FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: identifier_source identifier_source_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER identifier_source_update_audit_before_update BEFORE UPDATE ON public.identifier_source FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: identifier_user_assignment identifier_user_assignment_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER identifier_user_assignment_update_audit_before_insert BEFORE INSERT ON public.identifier_user_assignment FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: identifier_user_assignment identifier_user_assignment_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER identifier_user_assignment_update_audit_before_update BEFORE UPDATE ON public.identifier_user_assignment FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: individual_relation_gender_mapping individual_relation_gender_mapping_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER individual_relation_gender_mapping_update_audit_before_insert BEFORE INSERT ON public.individual_relation_gender_mapping FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: individual_relation_gender_mapping individual_relation_gender_mapping_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER individual_relation_gender_mapping_update_audit_before_update BEFORE UPDATE ON public.individual_relation_gender_mapping FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: individual_relation individual_relation_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER individual_relation_update_audit_before_insert BEFORE INSERT ON public.individual_relation FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: individual_relation individual_relation_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER individual_relation_update_audit_before_update BEFORE UPDATE ON public.individual_relation FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: individual_relationship_type individual_relationship_type_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER individual_relationship_type_update_audit_before_insert BEFORE INSERT ON public.individual_relationship_type FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: individual_relationship_type individual_relationship_type_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER individual_relationship_type_update_audit_before_update BEFORE UPDATE ON public.individual_relationship_type FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: individual_relationship individual_relationship_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER individual_relationship_update_audit_before_insert BEFORE INSERT ON public.individual_relationship FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: individual_relationship individual_relationship_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER individual_relationship_update_audit_before_update BEFORE UPDATE ON public.individual_relationship FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: individual_relative individual_relative_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER individual_relative_update_audit_before_insert BEFORE INSERT ON public.individual_relative FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: individual_relative individual_relative_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER individual_relative_update_audit_before_update BEFORE UPDATE ON public.individual_relative FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: individual individual_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER individual_update_audit_before_insert BEFORE INSERT ON public.individual FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: individual individual_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER individual_update_audit_before_update BEFORE UPDATE ON public.individual FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: location_location_mapping location_location_mapping_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER location_location_mapping_update_audit_before_insert BEFORE INSERT ON public.location_location_mapping FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: location_location_mapping location_location_mapping_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER location_location_mapping_update_audit_before_update BEFORE UPDATE ON public.location_location_mapping FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: msg91_config msg91_config_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER msg91_config_update_audit_before_insert BEFORE INSERT ON public.msg91_config FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: msg91_config msg91_config_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER msg91_config_update_audit_before_update BEFORE UPDATE ON public.msg91_config FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: news news_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER news_update_audit_before_insert BEFORE INSERT ON public.news FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: news news_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER news_update_audit_before_update BEFORE UPDATE ON public.news FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: non_applicable_form_element non_applicable_form_element_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER non_applicable_form_element_update_audit_before_insert BEFORE INSERT ON public.non_applicable_form_element FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: non_applicable_form_element non_applicable_form_element_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER non_applicable_form_element_update_audit_before_update BEFORE UPDATE ON public.non_applicable_form_element FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: operational_encounter_type operational_encounter_type_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER operational_encounter_type_update_audit_before_insert BEFORE INSERT ON public.operational_encounter_type FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: operational_encounter_type operational_encounter_type_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER operational_encounter_type_update_audit_before_update BEFORE UPDATE ON public.operational_encounter_type FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: operational_program operational_program_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER operational_program_update_audit_before_insert BEFORE INSERT ON public.operational_program FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: operational_program operational_program_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER operational_program_update_audit_before_update BEFORE UPDATE ON public.operational_program FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: operational_subject_type operational_subject_type_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER operational_subject_type_update_audit_before_insert BEFORE INSERT ON public.operational_subject_type FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: operational_subject_type operational_subject_type_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER operational_subject_type_update_audit_before_update BEFORE UPDATE ON public.operational_subject_type FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: organisation_config organisation_config_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER organisation_config_update_audit_before_insert BEFORE INSERT ON public.organisation_config FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: organisation_config organisation_config_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER organisation_config_update_audit_before_update BEFORE UPDATE ON public.organisation_config FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: platform_translation platform_translation_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER platform_translation_update_audit_before_insert BEFORE INSERT ON public.platform_translation FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: platform_translation platform_translation_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER platform_translation_update_audit_before_update BEFORE UPDATE ON public.platform_translation FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: program_encounter program_encounter_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER program_encounter_update_audit_before_insert BEFORE INSERT ON public.program_encounter FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: program_encounter program_encounter_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER program_encounter_update_audit_before_update BEFORE UPDATE ON public.program_encounter FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: program_enrolment program_enrolment_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER program_enrolment_update_audit_before_insert BEFORE INSERT ON public.program_enrolment FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: program_enrolment program_enrolment_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER program_enrolment_update_audit_before_update BEFORE UPDATE ON public.program_enrolment FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: program_organisation_config program_organisation_config_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER program_organisation_config_update_audit_before_insert BEFORE INSERT ON public.program_organisation_config FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: program_organisation_config program_organisation_config_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER program_organisation_config_update_audit_before_update BEFORE UPDATE ON public.program_organisation_config FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: program_outcome program_outcome_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER program_outcome_update_audit_before_insert BEFORE INSERT ON public.program_outcome FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: program_outcome program_outcome_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER program_outcome_update_audit_before_update BEFORE UPDATE ON public.program_outcome FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: program program_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER program_update_audit_before_insert BEFORE INSERT ON public.program FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: program program_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER program_update_audit_before_update BEFORE UPDATE ON public.program FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: report_card report_card_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER report_card_update_audit_before_insert BEFORE INSERT ON public.report_card FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: report_card report_card_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER report_card_update_audit_before_update BEFORE UPDATE ON public.report_card FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: rule_dependency rule_dependency_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER rule_dependency_update_audit_before_insert BEFORE INSERT ON public.rule_dependency FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: rule_dependency rule_dependency_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER rule_dependency_update_audit_before_update BEFORE UPDATE ON public.rule_dependency FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: rule_failure_log rule_failure_log_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER rule_failure_log_update_audit_before_insert BEFORE INSERT ON public.rule_failure_log FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: rule_failure_log rule_failure_log_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER rule_failure_log_update_audit_before_update BEFORE UPDATE ON public.rule_failure_log FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: rule_failure_telemetry rule_failure_telemetry_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER rule_failure_telemetry_update_audit_before_insert BEFORE INSERT ON public.rule_failure_telemetry FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: rule_failure_telemetry rule_failure_telemetry_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER rule_failure_telemetry_update_audit_before_update BEFORE UPDATE ON public.rule_failure_telemetry FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: rule rule_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER rule_update_audit_before_insert BEFORE INSERT ON public.rule FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: rule rule_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER rule_update_audit_before_update BEFORE UPDATE ON public.rule FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: subject_migration subject_migration_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER subject_migration_update_audit_before_insert BEFORE INSERT ON public.subject_migration FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: subject_migration subject_migration_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER subject_migration_update_audit_before_update BEFORE UPDATE ON public.subject_migration FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: subject_type subject_type_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER subject_type_update_audit_before_insert BEFORE INSERT ON public.subject_type FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: subject_type subject_type_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER subject_type_update_audit_before_update BEFORE UPDATE ON public.subject_type FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: translation translation_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER translation_update_audit_before_insert BEFORE INSERT ON public.translation FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: translation translation_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER translation_update_audit_before_update BEFORE UPDATE ON public.translation FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: user_group user_group_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER user_group_update_audit_before_insert BEFORE INSERT ON public.user_group FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: user_group user_group_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER user_group_update_audit_before_update BEFORE UPDATE ON public.user_group FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: video video_update_audit_before_insert; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER video_update_audit_before_insert BEFORE INSERT ON public.video FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: video video_update_audit_before_update; Type: TRIGGER; Schema: public; Owner: openchs
--

CREATE TRIGGER video_update_audit_before_update BEFORE UPDATE ON public.video FOR EACH ROW EXECUTE FUNCTION public.audit_table_trigger();


--
-- Name: account_admin account_admin_account; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.account_admin
    ADD CONSTRAINT account_admin_account FOREIGN KEY (account_id) REFERENCES public.account(id);


--
-- Name: account_admin account_admin_user; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.account_admin
    ADD CONSTRAINT account_admin_user FOREIGN KEY (admin_id) REFERENCES public.users(id);


--
-- Name: address_level address_level_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.address_level
    ADD CONSTRAINT address_level_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: address_level address_level_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.address_level
    ADD CONSTRAINT address_level_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: address_level address_level_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.address_level
    ADD CONSTRAINT address_level_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.address_level(id);


--
-- Name: address_level address_level_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.address_level
    ADD CONSTRAINT address_level_type_id_fkey FOREIGN KEY (type_id) REFERENCES public.address_level_type(id);


--
-- Name: address_level_type address_level_type_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.address_level_type
    ADD CONSTRAINT address_level_type_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.address_level_type(id);


--
-- Name: answer_concept_migration answer_concept_migration_concept_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.answer_concept_migration
    ADD CONSTRAINT answer_concept_migration_concept_id_fkey FOREIGN KEY (concept_id) REFERENCES public.concept(id);


--
-- Name: report_card card_master_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.report_card
    ADD CONSTRAINT card_master_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: report_card card_organisation; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.report_card
    ADD CONSTRAINT card_organisation FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: catchment_address_mapping catchment_address_mapping_address; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.catchment_address_mapping
    ADD CONSTRAINT catchment_address_mapping_address FOREIGN KEY (addresslevel_id) REFERENCES public.address_level(id);


--
-- Name: catchment_address_mapping catchment_address_mapping_catchment; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.catchment_address_mapping
    ADD CONSTRAINT catchment_address_mapping_catchment FOREIGN KEY (catchment_id) REFERENCES public.catchment(id);


--
-- Name: catchment catchment_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.catchment
    ADD CONSTRAINT catchment_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: catchment catchment_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.catchment
    ADD CONSTRAINT catchment_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: checklist checklist_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.checklist
    ADD CONSTRAINT checklist_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: checklist checklist_checklist_detail_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.checklist
    ADD CONSTRAINT checklist_checklist_detail_id_fkey FOREIGN KEY (checklist_detail_id) REFERENCES public.checklist_detail(id);


--
-- Name: checklist_detail checklist_detail_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.checklist_detail
    ADD CONSTRAINT checklist_detail_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: checklist_item checklist_item_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.checklist_item
    ADD CONSTRAINT checklist_item_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: checklist_item checklist_item_checklist; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.checklist_item
    ADD CONSTRAINT checklist_item_checklist FOREIGN KEY (checklist_id) REFERENCES public.checklist(id);


--
-- Name: checklist_item checklist_item_checklist_item_detail_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.checklist_item
    ADD CONSTRAINT checklist_item_checklist_item_detail_id_fkey FOREIGN KEY (checklist_item_detail_id) REFERENCES public.checklist_item_detail(id);


--
-- Name: checklist_item_detail checklist_item_detail_audit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.checklist_item_detail
    ADD CONSTRAINT checklist_item_detail_audit_id_fkey FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: checklist_item_detail checklist_item_detail_checklist_detail_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.checklist_item_detail
    ADD CONSTRAINT checklist_item_detail_checklist_detail_id_fkey FOREIGN KEY (checklist_detail_id) REFERENCES public.checklist_detail(id);


--
-- Name: checklist_item_detail checklist_item_detail_concept_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.checklist_item_detail
    ADD CONSTRAINT checklist_item_detail_concept_id_fkey FOREIGN KEY (concept_id) REFERENCES public.concept(id);


--
-- Name: checklist_item_detail checklist_item_detail_dependent_on_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.checklist_item_detail
    ADD CONSTRAINT checklist_item_detail_dependent_on_fkey FOREIGN KEY (dependent_on) REFERENCES public.checklist_item_detail(id);


--
-- Name: checklist_item_detail checklist_item_detail_form_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.checklist_item_detail
    ADD CONSTRAINT checklist_item_detail_form_id_fkey FOREIGN KEY (form_id) REFERENCES public.form(id);


--
-- Name: checklist_item_detail checklist_item_detail_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.checklist_item_detail
    ADD CONSTRAINT checklist_item_detail_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: checklist_item checklist_item_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.checklist_item
    ADD CONSTRAINT checklist_item_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: checklist checklist_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.checklist
    ADD CONSTRAINT checklist_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: checklist checklist_program_enrolment; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.checklist
    ADD CONSTRAINT checklist_program_enrolment FOREIGN KEY (program_enrolment_id) REFERENCES public.program_enrolment(id);


--
-- Name: column_metadata column_metadata_concept_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.column_metadata
    ADD CONSTRAINT column_metadata_concept_id_fkey FOREIGN KEY (concept_id) REFERENCES public.concept(id);


--
-- Name: column_metadata column_metadata_table_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.column_metadata
    ADD CONSTRAINT column_metadata_table_id_fkey FOREIGN KEY (table_id) REFERENCES public.table_metadata(id);


--
-- Name: comment comment_audit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_audit_id_fkey FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: comment comment_comment_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_comment_thread_id_fkey FOREIGN KEY (comment_thread_id) REFERENCES public.comment_thread(id);


--
-- Name: comment comment_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: comment comment_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.individual(id);


--
-- Name: comment_thread comment_thread_audit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.comment_thread
    ADD CONSTRAINT comment_thread_audit_id_fkey FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: comment_thread comment_thread_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.comment_thread
    ADD CONSTRAINT comment_thread_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: concept_answer concept_answer_answer_concept; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.concept_answer
    ADD CONSTRAINT concept_answer_answer_concept FOREIGN KEY (answer_concept_id) REFERENCES public.concept(id);


--
-- Name: concept_answer concept_answer_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.concept_answer
    ADD CONSTRAINT concept_answer_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: concept_answer concept_answer_concept; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.concept_answer
    ADD CONSTRAINT concept_answer_concept FOREIGN KEY (concept_id) REFERENCES public.concept(id);


--
-- Name: concept_answer concept_answer_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.concept_answer
    ADD CONSTRAINT concept_answer_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: concept concept_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.concept
    ADD CONSTRAINT concept_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: concept concept_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.concept
    ADD CONSTRAINT concept_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: custom_query custom_query_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.custom_query
    ADD CONSTRAINT custom_query_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: custom_query custom_query_last_modified_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.custom_query
    ADD CONSTRAINT custom_query_last_modified_by_id_fkey FOREIGN KEY (last_modified_by_id) REFERENCES public.users(id);


--
-- Name: custom_query custom_query_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.custom_query
    ADD CONSTRAINT custom_query_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: dashboard_card_mapping dashboard_card_card; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard_card_mapping
    ADD CONSTRAINT dashboard_card_card FOREIGN KEY (card_id) REFERENCES public.report_card(id);


--
-- Name: dashboard_card_mapping dashboard_card_dashboard; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard_card_mapping
    ADD CONSTRAINT dashboard_card_dashboard FOREIGN KEY (dashboard_id) REFERENCES public.dashboard(id);


--
-- Name: dashboard_card_mapping dashboard_card_master_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard_card_mapping
    ADD CONSTRAINT dashboard_card_master_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: dashboard_card_mapping dashboard_card_organisation; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard_card_mapping
    ADD CONSTRAINT dashboard_card_organisation FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: dashboard_filter dashboard_filter_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard_filter
    ADD CONSTRAINT dashboard_filter_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: dashboard_filter dashboard_filter_dashboard_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard_filter
    ADD CONSTRAINT dashboard_filter_dashboard_id_fkey FOREIGN KEY (dashboard_id) REFERENCES public.dashboard(id);


--
-- Name: dashboard_filter dashboard_filter_last_modified_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard_filter
    ADD CONSTRAINT dashboard_filter_last_modified_by_id_fkey FOREIGN KEY (last_modified_by_id) REFERENCES public.users(id);


--
-- Name: dashboard_filter dashboard_filter_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard_filter
    ADD CONSTRAINT dashboard_filter_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: dashboard dashboard_master_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard
    ADD CONSTRAINT dashboard_master_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: dashboard dashboard_organisation; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard
    ADD CONSTRAINT dashboard_organisation FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: dashboard_section dashboard_section_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard_section
    ADD CONSTRAINT dashboard_section_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: dashboard_section_card_mapping dashboard_section_card_mapping_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard_section_card_mapping
    ADD CONSTRAINT dashboard_section_card_mapping_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: dashboard_section_card_mapping dashboard_section_card_mapping_card; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard_section_card_mapping
    ADD CONSTRAINT dashboard_section_card_mapping_card FOREIGN KEY (card_id) REFERENCES public.report_card(id);


--
-- Name: dashboard_section_card_mapping dashboard_section_card_mapping_dashboard; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard_section_card_mapping
    ADD CONSTRAINT dashboard_section_card_mapping_dashboard FOREIGN KEY (dashboard_section_id) REFERENCES public.dashboard_section(id);


--
-- Name: dashboard_section_card_mapping dashboard_section_card_mapping_organisation; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard_section_card_mapping
    ADD CONSTRAINT dashboard_section_card_mapping_organisation FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: dashboard_section dashboard_section_dashboard; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard_section
    ADD CONSTRAINT dashboard_section_dashboard FOREIGN KEY (dashboard_id) REFERENCES public.dashboard(id);


--
-- Name: dashboard_section dashboard_section_organisation; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.dashboard_section
    ADD CONSTRAINT dashboard_section_organisation FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: decision_concept decision_concept_concept; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.decision_concept
    ADD CONSTRAINT decision_concept_concept FOREIGN KEY (concept_id) REFERENCES public.concept(id);


--
-- Name: decision_concept decision_concept_form; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.decision_concept
    ADD CONSTRAINT decision_concept_form FOREIGN KEY (form_id) REFERENCES public.form(id);


--
-- Name: documentation_item documentation_item_documentation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.documentation_item
    ADD CONSTRAINT documentation_item_documentation_id_fkey FOREIGN KEY (documentation_id) REFERENCES public.documentation(id);


--
-- Name: documentation_item documentation_item_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.documentation_item
    ADD CONSTRAINT documentation_item_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: documentation documentation_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.documentation
    ADD CONSTRAINT documentation_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: documentation documentation_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.documentation
    ADD CONSTRAINT documentation_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.documentation(id);


--
-- Name: encounter encounter_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.encounter
    ADD CONSTRAINT encounter_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: encounter encounter_encounter_type; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.encounter
    ADD CONSTRAINT encounter_encounter_type FOREIGN KEY (encounter_type_id) REFERENCES public.encounter_type(id);


--
-- Name: encounter encounter_individual; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.encounter
    ADD CONSTRAINT encounter_individual FOREIGN KEY (individual_id) REFERENCES public.individual(id);


--
-- Name: encounter encounter_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.encounter
    ADD CONSTRAINT encounter_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: encounter_type encounter_type_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.encounter_type
    ADD CONSTRAINT encounter_type_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: encounter_type encounter_type_concept; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.encounter_type
    ADD CONSTRAINT encounter_type_concept FOREIGN KEY (concept_id) REFERENCES public.concept(id);


--
-- Name: encounter_type encounter_type_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.encounter_type
    ADD CONSTRAINT encounter_type_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: entity_approval_status entity_approval_status_address_id; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.entity_approval_status
    ADD CONSTRAINT entity_approval_status_address_id FOREIGN KEY (address_id) REFERENCES public.address_level(id);


--
-- Name: entity_approval_status entity_approval_status_approval_status; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.entity_approval_status
    ADD CONSTRAINT entity_approval_status_approval_status FOREIGN KEY (approval_status_id) REFERENCES public.approval_status(id);


--
-- Name: entity_approval_status entity_approval_status_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.entity_approval_status
    ADD CONSTRAINT entity_approval_status_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: entity_approval_status entity_approval_status_individual_id; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.entity_approval_status
    ADD CONSTRAINT entity_approval_status_individual_id FOREIGN KEY (individual_id) REFERENCES public.individual(id);


--
-- Name: entity_approval_status entity_approval_status_organisation; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.entity_approval_status
    ADD CONSTRAINT entity_approval_status_organisation FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: entity_sync_status entity_sync_status_table_metadata_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.entity_sync_status
    ADD CONSTRAINT entity_sync_status_table_metadata_id_fkey FOREIGN KEY (table_metadata_id) REFERENCES public.table_metadata(id);


--
-- Name: export_job_parameters export_job_parameters_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.export_job_parameters
    ADD CONSTRAINT export_job_parameters_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: export_job_parameters export_job_parameters_last_modified_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.export_job_parameters
    ADD CONSTRAINT export_job_parameters_last_modified_by_id_fkey FOREIGN KEY (last_modified_by_id) REFERENCES public.users(id);


--
-- Name: export_job_parameters export_job_parameters_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.export_job_parameters
    ADD CONSTRAINT export_job_parameters_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: export_job_parameters export_job_parameters_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.export_job_parameters
    ADD CONSTRAINT export_job_parameters_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: external_system_config external_system_config_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.external_system_config
    ADD CONSTRAINT external_system_config_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: external_system_config external_system_config_last_modified_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.external_system_config
    ADD CONSTRAINT external_system_config_last_modified_by_id_fkey FOREIGN KEY (last_modified_by_id) REFERENCES public.users(id);


--
-- Name: external_system_config external_system_config_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.external_system_config
    ADD CONSTRAINT external_system_config_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: facility facility_address; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.facility
    ADD CONSTRAINT facility_address FOREIGN KEY (address_id) REFERENCES public.address_level(id);


--
-- Name: form form_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form
    ADD CONSTRAINT form_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: form_element form_element_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form_element
    ADD CONSTRAINT form_element_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: form_element form_element_concept; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form_element
    ADD CONSTRAINT form_element_concept FOREIGN KEY (concept_id) REFERENCES public.concept(id);


--
-- Name: form_element form_element_documentation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form_element
    ADD CONSTRAINT form_element_documentation_id_fkey FOREIGN KEY (documentation_id) REFERENCES public.documentation(id);


--
-- Name: form_element form_element_form_element_group; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form_element
    ADD CONSTRAINT form_element_form_element_group FOREIGN KEY (form_element_group_id) REFERENCES public.form_element_group(id);


--
-- Name: form_element_group form_element_group_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form_element_group
    ADD CONSTRAINT form_element_group_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: form_element_group form_element_group_form; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form_element_group
    ADD CONSTRAINT form_element_group_form FOREIGN KEY (form_id) REFERENCES public.form(id);


--
-- Name: form_element form_element_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form_element
    ADD CONSTRAINT form_element_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.form_element(id);


--
-- Name: form_element_group form_element_group_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form_element_group
    ADD CONSTRAINT form_element_group_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: form_element form_element_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form_element
    ADD CONSTRAINT form_element_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: form_mapping form_mapping_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form_mapping
    ADD CONSTRAINT form_mapping_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: form_mapping form_mapping_form; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form_mapping
    ADD CONSTRAINT form_mapping_form FOREIGN KEY (form_id) REFERENCES public.form(id);


--
-- Name: form_mapping form_mapping_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form_mapping
    ADD CONSTRAINT form_mapping_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: form_mapping form_mapping_subject_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form_mapping
    ADD CONSTRAINT form_mapping_subject_type_id_fkey FOREIGN KEY (subject_type_id) REFERENCES public.subject_type(id);


--
-- Name: form_mapping form_mapping_task_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form_mapping
    ADD CONSTRAINT form_mapping_task_type_id_fkey FOREIGN KEY (task_type_id) REFERENCES public.task_type(id);


--
-- Name: form form_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.form
    ADD CONSTRAINT form_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: gender gender_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.gender
    ADD CONSTRAINT gender_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: gender gender_concept; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.gender
    ADD CONSTRAINT gender_concept FOREIGN KEY (concept_id) REFERENCES public.concept(id);


--
-- Name: gender gender_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.gender
    ADD CONSTRAINT gender_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: group_dashboard group_dashboard_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_dashboard
    ADD CONSTRAINT group_dashboard_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: group_dashboard group_dashboard_dashboard; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_dashboard
    ADD CONSTRAINT group_dashboard_dashboard FOREIGN KEY (dashboard_id) REFERENCES public.dashboard(id);


--
-- Name: group_dashboard group_dashboard_group; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_dashboard
    ADD CONSTRAINT group_dashboard_group FOREIGN KEY (group_id) REFERENCES public.groups(id);


--
-- Name: group_dashboard group_dashboard_organisation; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_dashboard
    ADD CONSTRAINT group_dashboard_organisation FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: groups group_master_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT group_master_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: groups group_organisation; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT group_organisation FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: group_privilege group_privilege_checklist_detail_id; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_privilege
    ADD CONSTRAINT group_privilege_checklist_detail_id FOREIGN KEY (checklist_detail_id) REFERENCES public.checklist_detail(id);


--
-- Name: group_privilege group_privilege_encounter_type_id; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_privilege
    ADD CONSTRAINT group_privilege_encounter_type_id FOREIGN KEY (encounter_type_id) REFERENCES public.encounter_type(id);


--
-- Name: group_privilege group_privilege_group_id; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_privilege
    ADD CONSTRAINT group_privilege_group_id FOREIGN KEY (group_id) REFERENCES public.groups(id);


--
-- Name: group_privilege group_privilege_master_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_privilege
    ADD CONSTRAINT group_privilege_master_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: group_privilege group_privilege_organisation; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_privilege
    ADD CONSTRAINT group_privilege_organisation FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: group_privilege group_privilege_program_encounter_type_id; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_privilege
    ADD CONSTRAINT group_privilege_program_encounter_type_id FOREIGN KEY (program_encounter_type_id) REFERENCES public.encounter_type(id);


--
-- Name: group_privilege group_privilege_program_id; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_privilege
    ADD CONSTRAINT group_privilege_program_id FOREIGN KEY (program_id) REFERENCES public.program(id);


--
-- Name: group_privilege group_privilege_subject_id; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_privilege
    ADD CONSTRAINT group_privilege_subject_id FOREIGN KEY (subject_type_id) REFERENCES public.subject_type(id);


--
-- Name: group_role group_role_group_subject_type; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_role
    ADD CONSTRAINT group_role_group_subject_type FOREIGN KEY (group_subject_type_id) REFERENCES public.subject_type(id);


--
-- Name: group_role group_role_master_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_role
    ADD CONSTRAINT group_role_master_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: group_role group_role_member_subject_type; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_role
    ADD CONSTRAINT group_role_member_subject_type FOREIGN KEY (member_subject_type_id) REFERENCES public.subject_type(id);


--
-- Name: group_role group_role_organisation; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_role
    ADD CONSTRAINT group_role_organisation FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: group_subject group_subject_group_role; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_subject
    ADD CONSTRAINT group_subject_group_role FOREIGN KEY (group_role_id) REFERENCES public.group_role(id);


--
-- Name: group_subject group_subject_group_subject; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_subject
    ADD CONSTRAINT group_subject_group_subject FOREIGN KEY (group_subject_id) REFERENCES public.individual(id);


--
-- Name: group_subject group_subject_master_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_subject
    ADD CONSTRAINT group_subject_master_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: group_subject group_subject_member_subject; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_subject
    ADD CONSTRAINT group_subject_member_subject FOREIGN KEY (member_subject_id) REFERENCES public.individual(id);


--
-- Name: group_subject group_subject_organisation; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.group_subject
    ADD CONSTRAINT group_subject_organisation FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: identifier_assignment identifier_assignment_assigned_to_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.identifier_assignment
    ADD CONSTRAINT identifier_assignment_assigned_to_user_id_fkey FOREIGN KEY (assigned_to_user_id) REFERENCES public.users(id);


--
-- Name: identifier_assignment identifier_assignment_audit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.identifier_assignment
    ADD CONSTRAINT identifier_assignment_audit_id_fkey FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: identifier_assignment identifier_assignment_identifier_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.identifier_assignment
    ADD CONSTRAINT identifier_assignment_identifier_source_id_fkey FOREIGN KEY (identifier_source_id) REFERENCES public.identifier_source(id);


--
-- Name: identifier_assignment identifier_assignment_individual_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.identifier_assignment
    ADD CONSTRAINT identifier_assignment_individual_id_fkey FOREIGN KEY (individual_id) REFERENCES public.individual(id);


--
-- Name: identifier_assignment identifier_assignment_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.identifier_assignment
    ADD CONSTRAINT identifier_assignment_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: identifier_assignment identifier_assignment_program_enrolment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.identifier_assignment
    ADD CONSTRAINT identifier_assignment_program_enrolment_id_fkey FOREIGN KEY (program_enrolment_id) REFERENCES public.program_enrolment(id);


--
-- Name: identifier_source identifier_source_audit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.identifier_source
    ADD CONSTRAINT identifier_source_audit_id_fkey FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: identifier_source identifier_source_catchment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.identifier_source
    ADD CONSTRAINT identifier_source_catchment_id_fkey FOREIGN KEY (catchment_id) REFERENCES public.catchment(id);


--
-- Name: identifier_source identifier_source_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.identifier_source
    ADD CONSTRAINT identifier_source_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: identifier_user_assignment identifier_user_assignment_assigned_to_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.identifier_user_assignment
    ADD CONSTRAINT identifier_user_assignment_assigned_to_user_id_fkey FOREIGN KEY (assigned_to_user_id) REFERENCES public.users(id);


--
-- Name: identifier_user_assignment identifier_user_assignment_audit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.identifier_user_assignment
    ADD CONSTRAINT identifier_user_assignment_audit_id_fkey FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: identifier_user_assignment identifier_user_assignment_identifier_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.identifier_user_assignment
    ADD CONSTRAINT identifier_user_assignment_identifier_source_id_fkey FOREIGN KEY (identifier_source_id) REFERENCES public.identifier_source(id);


--
-- Name: identifier_user_assignment identifier_user_assignment_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.identifier_user_assignment
    ADD CONSTRAINT identifier_user_assignment_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: index_metadata index_metadata_column_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.index_metadata
    ADD CONSTRAINT index_metadata_column_id_fkey FOREIGN KEY (column_id) REFERENCES public.column_metadata(id);


--
-- Name: index_metadata index_metadata_table_metadata_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.index_metadata
    ADD CONSTRAINT index_metadata_table_metadata_id_fkey FOREIGN KEY (table_metadata_id) REFERENCES public.table_metadata(id);


--
-- Name: individual individual_address; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual
    ADD CONSTRAINT individual_address FOREIGN KEY (address_id) REFERENCES public.address_level(id);


--
-- Name: individual individual_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual
    ADD CONSTRAINT individual_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: individual individual_facility; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual
    ADD CONSTRAINT individual_facility FOREIGN KEY (facility_id) REFERENCES public.facility(id);


--
-- Name: individual individual_gender; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual
    ADD CONSTRAINT individual_gender FOREIGN KEY (gender_id) REFERENCES public.gender(id);


--
-- Name: individual individual_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual
    ADD CONSTRAINT individual_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: individual_relative individual_relation_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual_relative
    ADD CONSTRAINT individual_relation_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: individual_relation individual_relation_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual_relation
    ADD CONSTRAINT individual_relation_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: individual_relation_gender_mapping individual_relation_gender_mapping_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual_relation_gender_mapping
    ADD CONSTRAINT individual_relation_gender_mapping_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: individual_relation_gender_mapping individual_relation_gender_mapping_gender; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual_relation_gender_mapping
    ADD CONSTRAINT individual_relation_gender_mapping_gender FOREIGN KEY (gender_id) REFERENCES public.gender(id);


--
-- Name: individual_relation_gender_mapping individual_relation_gender_mapping_relation; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual_relation_gender_mapping
    ADD CONSTRAINT individual_relation_gender_mapping_relation FOREIGN KEY (relation_id) REFERENCES public.individual_relation(id);


--
-- Name: individual_relationship individual_relationship_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual_relationship
    ADD CONSTRAINT individual_relationship_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: individual_relationship individual_relationship_individual_a; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual_relationship
    ADD CONSTRAINT individual_relationship_individual_a FOREIGN KEY (individual_a_id) REFERENCES public.individual(id);


--
-- Name: individual_relationship individual_relationship_individual_b; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual_relationship
    ADD CONSTRAINT individual_relationship_individual_b FOREIGN KEY (individual_b_id) REFERENCES public.individual(id);


--
-- Name: individual_relationship individual_relationship_relation_type; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual_relationship
    ADD CONSTRAINT individual_relationship_relation_type FOREIGN KEY (relationship_type_id) REFERENCES public.individual_relationship_type(id);


--
-- Name: individual_relationship_type individual_relationship_type_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual_relationship_type
    ADD CONSTRAINT individual_relationship_type_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: individual_relationship_type individual_relationship_type_individual_a_relation; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual_relationship_type
    ADD CONSTRAINT individual_relationship_type_individual_a_relation FOREIGN KEY (individual_a_is_to_b_relation_id) REFERENCES public.individual_relation(id);


--
-- Name: individual_relationship_type individual_relationship_type_individual_b_relation; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual_relationship_type
    ADD CONSTRAINT individual_relationship_type_individual_b_relation FOREIGN KEY (individual_b_is_to_a_relation_id) REFERENCES public.individual_relation(id);


--
-- Name: individual_relative individual_relative_individual; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual_relative
    ADD CONSTRAINT individual_relative_individual FOREIGN KEY (individual_id) REFERENCES public.individual(id);


--
-- Name: individual_relative individual_relative_relative_individual; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual_relative
    ADD CONSTRAINT individual_relative_relative_individual FOREIGN KEY (relative_individual_id) REFERENCES public.individual(id);


--
-- Name: individual individual_subject_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.individual
    ADD CONSTRAINT individual_subject_type_id_fkey FOREIGN KEY (subject_type_id) REFERENCES public.subject_type(id);


--
-- Name: batch_job_execution_context job_exec_ctx_fk; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.batch_job_execution_context
    ADD CONSTRAINT job_exec_ctx_fk FOREIGN KEY (job_execution_id) REFERENCES public.batch_job_execution(job_execution_id);


--
-- Name: batch_job_execution_params job_exec_params_fk; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.batch_job_execution_params
    ADD CONSTRAINT job_exec_params_fk FOREIGN KEY (job_execution_id) REFERENCES public.batch_job_execution(job_execution_id);


--
-- Name: batch_step_execution job_exec_step_fk; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.batch_step_execution
    ADD CONSTRAINT job_exec_step_fk FOREIGN KEY (job_execution_id) REFERENCES public.batch_job_execution(job_execution_id);


--
-- Name: batch_job_execution job_inst_exec_fk; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.batch_job_execution
    ADD CONSTRAINT job_inst_exec_fk FOREIGN KEY (job_instance_id) REFERENCES public.batch_job_instance(job_instance_id);


--
-- Name: location_location_mapping location_location_mapping_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.location_location_mapping
    ADD CONSTRAINT location_location_mapping_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: location_location_mapping location_location_mapping_location; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.location_location_mapping
    ADD CONSTRAINT location_location_mapping_location FOREIGN KEY (location_id) REFERENCES public.address_level(id);


--
-- Name: location_location_mapping location_location_mapping_organisation; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.location_location_mapping
    ADD CONSTRAINT location_location_mapping_organisation FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: location_location_mapping location_location_mapping_parent_location; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.location_location_mapping
    ADD CONSTRAINT location_location_mapping_parent_location FOREIGN KEY (parent_location_id) REFERENCES public.address_level(id);


--
-- Name: manual_message manual_broadcast_message_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.manual_message
    ADD CONSTRAINT manual_broadcast_message_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: manual_message manual_broadcast_message_last_modified_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.manual_message
    ADD CONSTRAINT manual_broadcast_message_last_modified_by_id_fkey FOREIGN KEY (last_modified_by_id) REFERENCES public.users(id);


--
-- Name: manual_message manual_broadcast_message_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.manual_message
    ADD CONSTRAINT manual_broadcast_message_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: menu_item menu_item_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.menu_item
    ADD CONSTRAINT menu_item_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: menu_item menu_item_last_modified_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.menu_item
    ADD CONSTRAINT menu_item_last_modified_by_id_fkey FOREIGN KEY (last_modified_by_id) REFERENCES public.users(id);


--
-- Name: menu_item menu_item_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.menu_item
    ADD CONSTRAINT menu_item_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: message_receiver message_receiver_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.message_receiver
    ADD CONSTRAINT message_receiver_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: message_receiver message_receiver_last_modified_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.message_receiver
    ADD CONSTRAINT message_receiver_last_modified_by_id_fkey FOREIGN KEY (last_modified_by_id) REFERENCES public.users(id);


--
-- Name: message_receiver message_receiver_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.message_receiver
    ADD CONSTRAINT message_receiver_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: message_request_queue message_request_queue_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.message_request_queue
    ADD CONSTRAINT message_request_queue_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: message_request_queue message_request_queue_last_modified_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.message_request_queue
    ADD CONSTRAINT message_request_queue_last_modified_by_id_fkey FOREIGN KEY (last_modified_by_id) REFERENCES public.users(id);


--
-- Name: message_request_queue message_request_queue_manual_broadcast_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.message_request_queue
    ADD CONSTRAINT message_request_queue_manual_broadcast_message_id_fkey FOREIGN KEY (manual_message_id) REFERENCES public.manual_message(id);


--
-- Name: message_request_queue message_request_queue_message_receiver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.message_request_queue
    ADD CONSTRAINT message_request_queue_message_receiver_id_fkey FOREIGN KEY (message_receiver_id) REFERENCES public.message_receiver(id);


--
-- Name: message_request_queue message_request_queue_message_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.message_request_queue
    ADD CONSTRAINT message_request_queue_message_rule_id_fkey FOREIGN KEY (message_rule_id) REFERENCES public.message_rule(id);


--
-- Name: message_request_queue message_request_queue_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.message_request_queue
    ADD CONSTRAINT message_request_queue_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: message_rule message_rule_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.message_rule
    ADD CONSTRAINT message_rule_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: message_rule message_rule_last_modified_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.message_rule
    ADD CONSTRAINT message_rule_last_modified_by_id_fkey FOREIGN KEY (last_modified_by_id) REFERENCES public.users(id);


--
-- Name: message_rule message_rule_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.message_rule
    ADD CONSTRAINT message_rule_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: msg91_config msg91_config_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.msg91_config
    ADD CONSTRAINT msg91_config_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: msg91_config msg91_config_organisation; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.msg91_config
    ADD CONSTRAINT msg91_config_organisation FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: news news_audit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.news
    ADD CONSTRAINT news_audit_id_fkey FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: news news_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.news
    ADD CONSTRAINT news_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: non_applicable_form_element non_applicable_form_element_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.non_applicable_form_element
    ADD CONSTRAINT non_applicable_form_element_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: non_applicable_form_element non_applicable_form_element_form_element_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.non_applicable_form_element
    ADD CONSTRAINT non_applicable_form_element_form_element_id_fkey FOREIGN KEY (form_element_id) REFERENCES public.form_element(id);


--
-- Name: non_applicable_form_element non_applicable_form_element_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.non_applicable_form_element
    ADD CONSTRAINT non_applicable_form_element_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: operational_encounter_type operational_encounter_type_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.operational_encounter_type
    ADD CONSTRAINT operational_encounter_type_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: operational_encounter_type operational_encounter_type_encounter_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.operational_encounter_type
    ADD CONSTRAINT operational_encounter_type_encounter_type_id_fkey FOREIGN KEY (encounter_type_id) REFERENCES public.encounter_type(id);


--
-- Name: operational_encounter_type operational_encounter_type_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.operational_encounter_type
    ADD CONSTRAINT operational_encounter_type_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: operational_program operational_program_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.operational_program
    ADD CONSTRAINT operational_program_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: operational_program operational_program_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.operational_program
    ADD CONSTRAINT operational_program_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: operational_program operational_program_program_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.operational_program
    ADD CONSTRAINT operational_program_program_id_fkey FOREIGN KEY (program_id) REFERENCES public.program(id);


--
-- Name: operational_subject_type operational_subject_type_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.operational_subject_type
    ADD CONSTRAINT operational_subject_type_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: operational_subject_type operational_subject_type_organisation; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.operational_subject_type
    ADD CONSTRAINT operational_subject_type_organisation FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: operational_subject_type operational_subject_type_subject_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.operational_subject_type
    ADD CONSTRAINT operational_subject_type_subject_type_id_fkey FOREIGN KEY (subject_type_id) REFERENCES public.subject_type(id);


--
-- Name: organisation organisation_account; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.organisation
    ADD CONSTRAINT organisation_account FOREIGN KEY (account_id) REFERENCES public.account(id);


--
-- Name: organisation_config organisation_config_master_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.organisation_config
    ADD CONSTRAINT organisation_config_master_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: organisation_config organisation_config_organisation; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.organisation_config
    ADD CONSTRAINT organisation_config_organisation FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: organisation_group organisation_group_account; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.organisation_group
    ADD CONSTRAINT organisation_group_account FOREIGN KEY (account_id) REFERENCES public.account(id);


--
-- Name: organisation_group_organisation organisation_group_organisation_organisation; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.organisation_group_organisation
    ADD CONSTRAINT organisation_group_organisation_organisation FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: organisation_group_organisation organisation_group_organisation_organisation_group; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.organisation_group_organisation
    ADD CONSTRAINT organisation_group_organisation_organisation_group FOREIGN KEY (organisation_group_id) REFERENCES public.organisation_group(id);


--
-- Name: organisation organisation_parent_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.organisation
    ADD CONSTRAINT organisation_parent_organisation_id_fkey FOREIGN KEY (parent_organisation_id) REFERENCES public.organisation(id);


--
-- Name: platform_translation platform_translation_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.platform_translation
    ADD CONSTRAINT platform_translation_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: program program_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT program_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: program_encounter program_encounter_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_encounter
    ADD CONSTRAINT program_encounter_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: program_encounter program_encounter_encounter_type; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_encounter
    ADD CONSTRAINT program_encounter_encounter_type FOREIGN KEY (encounter_type_id) REFERENCES public.encounter_type(id);


--
-- Name: program_encounter program_encounter_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_encounter
    ADD CONSTRAINT program_encounter_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: program_encounter program_encounter_program_enrolment; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_encounter
    ADD CONSTRAINT program_encounter_program_enrolment FOREIGN KEY (program_enrolment_id) REFERENCES public.program_enrolment(id);


--
-- Name: program_enrolment program_enrolment_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_enrolment
    ADD CONSTRAINT program_enrolment_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: program_enrolment program_enrolment_individual; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_enrolment
    ADD CONSTRAINT program_enrolment_individual FOREIGN KEY (individual_id) REFERENCES public.individual(id);


--
-- Name: program_enrolment program_enrolment_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_enrolment
    ADD CONSTRAINT program_enrolment_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: program_enrolment program_enrolment_program; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_enrolment
    ADD CONSTRAINT program_enrolment_program FOREIGN KEY (program_id) REFERENCES public.program(id);


--
-- Name: program_enrolment program_enrolment_program_outcome; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_enrolment
    ADD CONSTRAINT program_enrolment_program_outcome FOREIGN KEY (program_outcome_id) REFERENCES public.program_outcome(id);


--
-- Name: program_organisation_config_at_risk_concept program_organisation_config_a_program_organisation_config__fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_organisation_config_at_risk_concept
    ADD CONSTRAINT program_organisation_config_a_program_organisation_config__fkey FOREIGN KEY (program_organisation_config_id) REFERENCES public.program_organisation_config(id);


--
-- Name: program_organisation_config_at_risk_concept program_organisation_config_at_risk_concept_concept_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_organisation_config_at_risk_concept
    ADD CONSTRAINT program_organisation_config_at_risk_concept_concept_id_fkey FOREIGN KEY (concept_id) REFERENCES public.concept(id);


--
-- Name: program_organisation_config program_organisation_config_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_organisation_config
    ADD CONSTRAINT program_organisation_config_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: program_organisation_config program_organisation_config_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_organisation_config
    ADD CONSTRAINT program_organisation_config_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: program_organisation_config program_organisation_config_program_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_organisation_config
    ADD CONSTRAINT program_organisation_config_program_id_fkey FOREIGN KEY (program_id) REFERENCES public.program(id);


--
-- Name: program program_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT program_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: program_outcome program_outcome_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_outcome
    ADD CONSTRAINT program_outcome_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: program_outcome program_outcome_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.program_outcome
    ADD CONSTRAINT program_outcome_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: report_card report_card_standard_report_card_type; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.report_card
    ADD CONSTRAINT report_card_standard_report_card_type FOREIGN KEY (standard_report_card_type_id) REFERENCES public.standard_report_card_type(id);


--
-- Name: reset_sync reset_sync_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.reset_sync
    ADD CONSTRAINT reset_sync_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: reset_sync reset_sync_subject_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.reset_sync
    ADD CONSTRAINT reset_sync_subject_type_id_fkey FOREIGN KEY (subject_type_id) REFERENCES public.subject_type(id);


--
-- Name: reset_sync reset_sync_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.reset_sync
    ADD CONSTRAINT reset_sync_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: rule rule_audit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.rule
    ADD CONSTRAINT rule_audit_id_fkey FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: rule_dependency rule_dependency_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.rule_dependency
    ADD CONSTRAINT rule_dependency_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: rule_failure_telemetry rule_failure_telemetry_master_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.rule_failure_telemetry
    ADD CONSTRAINT rule_failure_telemetry_master_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: rule_failure_telemetry rule_failure_telemetry_organisation; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.rule_failure_telemetry
    ADD CONSTRAINT rule_failure_telemetry_organisation FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: rule_failure_telemetry rule_failure_telemetry_user; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.rule_failure_telemetry
    ADD CONSTRAINT rule_failure_telemetry_user FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: rule rule_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.rule
    ADD CONSTRAINT rule_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: rule rule_rule_dependency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.rule
    ADD CONSTRAINT rule_rule_dependency_id_fkey FOREIGN KEY (rule_dependency_id) REFERENCES public.rule_dependency(id);


--
-- Name: batch_step_execution_context step_exec_ctx_fk; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.batch_step_execution_context
    ADD CONSTRAINT step_exec_ctx_fk FOREIGN KEY (step_execution_id) REFERENCES public.batch_step_execution(step_execution_id);


--
-- Name: subject_migration subject_migration_audit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.subject_migration
    ADD CONSTRAINT subject_migration_audit_id_fkey FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: subject_migration subject_migration_individual_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.subject_migration
    ADD CONSTRAINT subject_migration_individual_id_fkey FOREIGN KEY (individual_id) REFERENCES public.individual(id);


--
-- Name: subject_migration subject_migration_new_address_level_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.subject_migration
    ADD CONSTRAINT subject_migration_new_address_level_id_fkey FOREIGN KEY (new_address_level_id) REFERENCES public.address_level(id);


--
-- Name: subject_migration subject_migration_old_address_level_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.subject_migration
    ADD CONSTRAINT subject_migration_old_address_level_id_fkey FOREIGN KEY (old_address_level_id) REFERENCES public.address_level(id);


--
-- Name: subject_migration subject_migration_subject_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.subject_migration
    ADD CONSTRAINT subject_migration_subject_type_id_fkey FOREIGN KEY (subject_type_id) REFERENCES public.subject_type(id);


--
-- Name: subject_program_eligibility subject_program_eligibility_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.subject_program_eligibility
    ADD CONSTRAINT subject_program_eligibility_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: subject_program_eligibility subject_program_eligibility_last_modified_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.subject_program_eligibility
    ADD CONSTRAINT subject_program_eligibility_last_modified_by_id_fkey FOREIGN KEY (last_modified_by_id) REFERENCES public.users(id);


--
-- Name: subject_program_eligibility subject_program_eligibility_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.subject_program_eligibility
    ADD CONSTRAINT subject_program_eligibility_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: subject_program_eligibility subject_program_eligibility_program_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.subject_program_eligibility
    ADD CONSTRAINT subject_program_eligibility_program_id_fkey FOREIGN KEY (program_id) REFERENCES public.program(id);


--
-- Name: subject_program_eligibility subject_program_eligibility_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.subject_program_eligibility
    ADD CONSTRAINT subject_program_eligibility_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.individual(id);


--
-- Name: subject_type subject_type_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.subject_type
    ADD CONSTRAINT subject_type_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: subject_type subject_type_organisation; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.subject_type
    ADD CONSTRAINT subject_type_organisation FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: sync_telemetry sync_telemetry_organisation; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.sync_telemetry
    ADD CONSTRAINT sync_telemetry_organisation FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: sync_telemetry sync_telemetry_user; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.sync_telemetry
    ADD CONSTRAINT sync_telemetry_user FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: task task_assigned_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_assigned_user_id_fkey FOREIGN KEY (assigned_user_id) REFERENCES public.users(id);


--
-- Name: task task_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: task task_last_modified_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_last_modified_by_id_fkey FOREIGN KEY (last_modified_by_id) REFERENCES public.users(id);


--
-- Name: task task_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: task_status task_status_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task_status
    ADD CONSTRAINT task_status_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: task_status task_status_last_modified_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task_status
    ADD CONSTRAINT task_status_last_modified_by_id_fkey FOREIGN KEY (last_modified_by_id) REFERENCES public.users(id);


--
-- Name: task_status task_status_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task_status
    ADD CONSTRAINT task_status_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: task_status task_status_task_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task_status
    ADD CONSTRAINT task_status_task_type_id_fkey FOREIGN KEY (task_type_id) REFERENCES public.task_type(id);


--
-- Name: task task_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.individual(id);


--
-- Name: task task_task_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_task_status_id_fkey FOREIGN KEY (task_status_id) REFERENCES public.task_status(id);


--
-- Name: task task_task_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_task_type_id_fkey FOREIGN KEY (task_type_id) REFERENCES public.task_type(id);


--
-- Name: task_type task_type_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task_type
    ADD CONSTRAINT task_type_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: task_type task_type_last_modified_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task_type
    ADD CONSTRAINT task_type_last_modified_by_id_fkey FOREIGN KEY (last_modified_by_id) REFERENCES public.users(id);


--
-- Name: task_type task_type_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task_type
    ADD CONSTRAINT task_type_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: task_unassignment task_unassignment_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task_unassignment
    ADD CONSTRAINT task_unassignment_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: task_unassignment task_unassignment_last_modified_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task_unassignment
    ADD CONSTRAINT task_unassignment_last_modified_by_id_fkey FOREIGN KEY (last_modified_by_id) REFERENCES public.users(id);


--
-- Name: task_unassignment task_unassignment_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task_unassignment
    ADD CONSTRAINT task_unassignment_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: task_unassignment task_unassignment_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task_unassignment
    ADD CONSTRAINT task_unassignment_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.task(id);


--
-- Name: task_unassignment task_unassignment_unassigned_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.task_unassignment
    ADD CONSTRAINT task_unassignment_unassigned_user_id_fkey FOREIGN KEY (unassigned_user_id) REFERENCES public.users(id);


--
-- Name: translation translation_master_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.translation
    ADD CONSTRAINT translation_master_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: translation translation_organisation; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.translation
    ADD CONSTRAINT translation_organisation FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: user_group user_group_group_id; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.user_group
    ADD CONSTRAINT user_group_group_id FOREIGN KEY (group_id) REFERENCES public.groups(id);


--
-- Name: user_group user_group_master_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.user_group
    ADD CONSTRAINT user_group_master_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: user_group user_group_organisation; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.user_group
    ADD CONSTRAINT user_group_organisation FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: user_group user_group_user_id; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.user_group
    ADD CONSTRAINT user_group_user_id FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_subject_assignment user_subject_assignment_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.user_subject_assignment
    ADD CONSTRAINT user_subject_assignment_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: user_subject_assignment user_subject_assignment_last_modified_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.user_subject_assignment
    ADD CONSTRAINT user_subject_assignment_last_modified_by_id_fkey FOREIGN KEY (last_modified_by_id) REFERENCES public.users(id);


--
-- Name: user_subject_assignment user_subject_assignment_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.user_subject_assignment
    ADD CONSTRAINT user_subject_assignment_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: user_subject_assignment user_subject_assignment_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.user_subject_assignment
    ADD CONSTRAINT user_subject_assignment_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.individual(id);


--
-- Name: user_subject_assignment user_subject_assignment_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.user_subject_assignment
    ADD CONSTRAINT user_subject_assignment_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: users users_organisation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_organisation_id_fkey FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: video video_audit; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.video
    ADD CONSTRAINT video_audit FOREIGN KEY (audit_id) REFERENCES public.audit(id);


--
-- Name: video video_organisation; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.video
    ADD CONSTRAINT video_organisation FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: video_telemetric video_telemetric_organisation; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.video_telemetric
    ADD CONSTRAINT video_telemetric_organisation FOREIGN KEY (organisation_id) REFERENCES public.organisation(id);


--
-- Name: video_telemetric video_telemetric_user; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.video_telemetric
    ADD CONSTRAINT video_telemetric_user FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: video_telemetric video_telemetric_video; Type: FK CONSTRAINT; Schema: public; Owner: openchs
--

ALTER TABLE ONLY public.video_telemetric
    ADD CONSTRAINT video_telemetric_video FOREIGN KEY (video_id) REFERENCES public.video(id);


--
-- Name: address_level; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.address_level ENABLE ROW LEVEL SECURITY;

--
-- Name: address_level address_level_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY address_level_orgs ON public.address_level USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: address_level_type; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.address_level_type ENABLE ROW LEVEL SECURITY;

--
-- Name: address_level_type address_level_type_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY address_level_type_orgs ON public.address_level_type USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: answer_concept_migration; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.answer_concept_migration ENABLE ROW LEVEL SECURITY;

--
-- Name: answer_concept_migration answer_concept_migration_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY answer_concept_migration_orgs ON public.answer_concept_migration USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: report_card card_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY card_orgs ON public.report_card USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: catchment; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.catchment ENABLE ROW LEVEL SECURITY;

--
-- Name: catchment catchment_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY catchment_orgs ON public.catchment USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: checklist; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.checklist ENABLE ROW LEVEL SECURITY;

--
-- Name: checklist_detail; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.checklist_detail ENABLE ROW LEVEL SECURITY;

--
-- Name: checklist_detail checklist_detail_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY checklist_detail_orgs ON public.checklist_detail USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: checklist_item; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.checklist_item ENABLE ROW LEVEL SECURITY;

--
-- Name: checklist_item_detail; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.checklist_item_detail ENABLE ROW LEVEL SECURITY;

--
-- Name: checklist_item_detail checklist_item_detail_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY checklist_item_detail_orgs ON public.checklist_item_detail USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: checklist_item checklist_item_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY checklist_item_orgs ON public.checklist_item USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: checklist checklist_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY checklist_orgs ON public.checklist USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: column_metadata; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.column_metadata ENABLE ROW LEVEL SECURITY;

--
-- Name: column_metadata column_metadata_rls_policy; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY column_metadata_rls_policy ON public.column_metadata USING ((schema_name IN ( SELECT s.schema_name
   FROM ( SELECT organisation.db_user,
            organisation.schema_name
           FROM public.organisation
        UNION ALL
         SELECT organisation_group.db_user,
            organisation_group.schema_name
           FROM public.organisation_group) s
  WHERE ((s.db_user)::text = CURRENT_USER)))) WITH CHECK ((schema_name IN ( SELECT s.schema_name
   FROM ( SELECT organisation.db_user,
            organisation.schema_name
           FROM public.organisation
        UNION ALL
         SELECT organisation_group.db_user,
            organisation_group.schema_name
           FROM public.organisation_group) s
  WHERE ((s.db_user)::text = CURRENT_USER))));


--
-- Name: comment; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.comment ENABLE ROW LEVEL SECURITY;

--
-- Name: comment comment_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY comment_orgs ON public.comment USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: comment_thread; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.comment_thread ENABLE ROW LEVEL SECURITY;

--
-- Name: comment_thread comment_thread_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY comment_thread_orgs ON public.comment_thread USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: concept; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.concept ENABLE ROW LEVEL SECURITY;

--
-- Name: concept_answer; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.concept_answer ENABLE ROW LEVEL SECURITY;

--
-- Name: concept_answer concept_answer_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY concept_answer_orgs ON public.concept_answer USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: concept concept_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY concept_orgs ON public.concept USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: custom_query; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.custom_query ENABLE ROW LEVEL SECURITY;

--
-- Name: custom_query custom_query_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY custom_query_orgs ON public.custom_query USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: dashboard; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.dashboard ENABLE ROW LEVEL SECURITY;

--
-- Name: dashboard_card_mapping; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.dashboard_card_mapping ENABLE ROW LEVEL SECURITY;

--
-- Name: dashboard_card_mapping dashboard_card_mapping_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY dashboard_card_mapping_orgs ON public.dashboard_card_mapping USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: dashboard_filter; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.dashboard_filter ENABLE ROW LEVEL SECURITY;

--
-- Name: dashboard_filter dashboard_filter_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY dashboard_filter_orgs ON public.dashboard_filter USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: dashboard dashboard_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY dashboard_orgs ON public.dashboard USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: dashboard_section; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.dashboard_section ENABLE ROW LEVEL SECURITY;

--
-- Name: dashboard_section_card_mapping; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.dashboard_section_card_mapping ENABLE ROW LEVEL SECURITY;

--
-- Name: dashboard_section_card_mapping dashboard_section_card_mapping_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY dashboard_section_card_mapping_orgs ON public.dashboard_section_card_mapping USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: dashboard_section dashboard_section_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY dashboard_section_orgs ON public.dashboard_section USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: documentation; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.documentation ENABLE ROW LEVEL SECURITY;

--
-- Name: documentation_item; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.documentation_item ENABLE ROW LEVEL SECURITY;

--
-- Name: documentation_item documentation_item_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY documentation_item_orgs ON public.documentation_item USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: documentation documentation_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY documentation_orgs ON public.documentation USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: encounter; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.encounter ENABLE ROW LEVEL SECURITY;

--
-- Name: encounter encounter_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY encounter_orgs ON public.encounter USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: encounter_type; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.encounter_type ENABLE ROW LEVEL SECURITY;

--
-- Name: encounter_type encounter_type_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY encounter_type_orgs ON public.encounter_type USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: entity_approval_status; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.entity_approval_status ENABLE ROW LEVEL SECURITY;

--
-- Name: entity_approval_status entity_approval_status_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY entity_approval_status_orgs ON public.entity_approval_status USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: entity_sync_status; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.entity_sync_status ENABLE ROW LEVEL SECURITY;

--
-- Name: entity_sync_status entity_sync_status_rls_policy; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY entity_sync_status_rls_policy ON public.entity_sync_status USING ((db_user = CURRENT_USER)) WITH CHECK ((db_user = CURRENT_USER));


--
-- Name: export_job_parameters; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.export_job_parameters ENABLE ROW LEVEL SECURITY;

--
-- Name: export_job_parameters export_job_parameters_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY export_job_parameters_orgs ON public.export_job_parameters USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: external_system_config; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.external_system_config ENABLE ROW LEVEL SECURITY;

--
-- Name: external_system_config external_system_config_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY external_system_config_orgs ON public.external_system_config USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: facility; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.facility ENABLE ROW LEVEL SECURITY;

--
-- Name: facility facility_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY facility_orgs ON public.facility USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: form; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.form ENABLE ROW LEVEL SECURITY;

--
-- Name: form_element; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.form_element ENABLE ROW LEVEL SECURITY;

--
-- Name: form_element_group; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.form_element_group ENABLE ROW LEVEL SECURITY;

--
-- Name: form_element_group form_element_group_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY form_element_group_orgs ON public.form_element_group USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: form_element form_element_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY form_element_orgs ON public.form_element USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: form_mapping; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.form_mapping ENABLE ROW LEVEL SECURITY;

--
-- Name: form_mapping form_mapping_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY form_mapping_orgs ON public.form_mapping USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: form form_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY form_orgs ON public.form USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: gender; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.gender ENABLE ROW LEVEL SECURITY;

--
-- Name: gender gender_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY gender_orgs ON public.gender USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: group_dashboard; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.group_dashboard ENABLE ROW LEVEL SECURITY;

--
-- Name: group_dashboard group_dashboard_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY group_dashboard_orgs ON public.group_dashboard USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: group_privilege; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.group_privilege ENABLE ROW LEVEL SECURITY;

--
-- Name: group_privilege group_privilege_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY group_privilege_orgs ON public.group_privilege USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: group_role; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.group_role ENABLE ROW LEVEL SECURITY;

--
-- Name: group_role group_role_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY group_role_orgs ON public.group_role USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: group_subject; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.group_subject ENABLE ROW LEVEL SECURITY;

--
-- Name: group_subject group_subject_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY group_subject_orgs ON public.group_subject USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: groups; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.groups ENABLE ROW LEVEL SECURITY;

--
-- Name: groups groups_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY groups_orgs ON public.groups USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: identifier_assignment; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.identifier_assignment ENABLE ROW LEVEL SECURITY;

--
-- Name: identifier_assignment identifier_assignment_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY identifier_assignment_orgs ON public.identifier_assignment USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: identifier_source; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.identifier_source ENABLE ROW LEVEL SECURITY;

--
-- Name: identifier_source identifier_source_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY identifier_source_orgs ON public.identifier_source USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: identifier_user_assignment; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.identifier_user_assignment ENABLE ROW LEVEL SECURITY;

--
-- Name: identifier_user_assignment identifier_user_assignment_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY identifier_user_assignment_orgs ON public.identifier_user_assignment USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: individual; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.individual ENABLE ROW LEVEL SECURITY;

--
-- Name: individual individual_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY individual_orgs ON public.individual USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: individual_relation; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.individual_relation ENABLE ROW LEVEL SECURITY;

--
-- Name: individual_relation_gender_mapping; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.individual_relation_gender_mapping ENABLE ROW LEVEL SECURITY;

--
-- Name: individual_relation_gender_mapping individual_relation_gender_mapping_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY individual_relation_gender_mapping_orgs ON public.individual_relation_gender_mapping USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: individual_relation individual_relation_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY individual_relation_orgs ON public.individual_relation USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: individual_relationship; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.individual_relationship ENABLE ROW LEVEL SECURITY;

--
-- Name: individual_relationship individual_relationship_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY individual_relationship_orgs ON public.individual_relationship USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: individual_relationship_type; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.individual_relationship_type ENABLE ROW LEVEL SECURITY;

--
-- Name: individual_relationship_type individual_relationship_type_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY individual_relationship_type_orgs ON public.individual_relationship_type USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: location_location_mapping; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.location_location_mapping ENABLE ROW LEVEL SECURITY;

--
-- Name: location_location_mapping location_location_mapping_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY location_location_mapping_orgs ON public.location_location_mapping USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: manual_message manual_broadcast_message_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY manual_broadcast_message_orgs ON public.manual_message USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: manual_message; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.manual_message ENABLE ROW LEVEL SECURITY;

--
-- Name: menu_item; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.menu_item ENABLE ROW LEVEL SECURITY;

--
-- Name: menu_item menu_item_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY menu_item_orgs ON public.menu_item USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: message_receiver; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.message_receiver ENABLE ROW LEVEL SECURITY;

--
-- Name: message_receiver message_receiver_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY message_receiver_orgs ON public.message_receiver USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: message_request_queue; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.message_request_queue ENABLE ROW LEVEL SECURITY;

--
-- Name: message_request_queue message_request_queue_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY message_request_queue_orgs ON public.message_request_queue USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: message_rule; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.message_rule ENABLE ROW LEVEL SECURITY;

--
-- Name: message_rule message_rule_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY message_rule_orgs ON public.message_rule USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: msg91_config; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.msg91_config ENABLE ROW LEVEL SECURITY;

--
-- Name: msg91_config msg91_config_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY msg91_config_orgs ON public.msg91_config USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: news; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.news ENABLE ROW LEVEL SECURITY;

--
-- Name: news news_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY news_orgs ON public.news USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: non_applicable_form_element; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.non_applicable_form_element ENABLE ROW LEVEL SECURITY;

--
-- Name: non_applicable_form_element non_applicable_form_element_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY non_applicable_form_element_orgs ON public.non_applicable_form_element USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: operational_encounter_type; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.operational_encounter_type ENABLE ROW LEVEL SECURITY;

--
-- Name: operational_encounter_type operational_encounter_type_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY operational_encounter_type_orgs ON public.operational_encounter_type USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: operational_program; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.operational_program ENABLE ROW LEVEL SECURITY;

--
-- Name: operational_program operational_program_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY operational_program_orgs ON public.operational_program USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: operational_subject_type; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.operational_subject_type ENABLE ROW LEVEL SECURITY;

--
-- Name: operational_subject_type operational_subject_type_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY operational_subject_type_orgs ON public.operational_subject_type USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: organisation; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.organisation ENABLE ROW LEVEL SECURITY;

--
-- Name: organisation_config; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.organisation_config ENABLE ROW LEVEL SECURITY;

--
-- Name: organisation_config organisation_config_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY organisation_config_orgs ON public.organisation_config USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: organisation_group; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.organisation_group ENABLE ROW LEVEL SECURITY;

--
-- Name: organisation_group_organisation; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.organisation_group_organisation ENABLE ROW LEVEL SECURITY;

--
-- Name: organisation_group_organisation organisation_group_organisation_policy; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY organisation_group_organisation_policy ON public.organisation_group_organisation USING ((organisation_group_id IN ( SELECT organisation_group.id
   FROM public.organisation_group
  WHERE ((organisation_group.db_user)::text = CURRENT_USER))));


--
-- Name: organisation_group organisation_group_policy; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY organisation_group_policy ON public.organisation_group USING ((CURRENT_USER = (db_user)::text));


--
-- Name: organisation organisation_policy; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY organisation_policy ON public.organisation USING (((CURRENT_USER = ANY (ARRAY['openchs'::name, 'openchs_impl'::name])) OR (id IN ( SELECT org_ids.id
   FROM public.org_ids)) OR (id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation))));


--
-- Name: program; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.program ENABLE ROW LEVEL SECURITY;

--
-- Name: program_encounter; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.program_encounter ENABLE ROW LEVEL SECURITY;

--
-- Name: program_encounter program_encounter_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY program_encounter_orgs ON public.program_encounter USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: program_enrolment; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.program_enrolment ENABLE ROW LEVEL SECURITY;

--
-- Name: program_enrolment program_enrolment_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY program_enrolment_orgs ON public.program_enrolment USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: program_organisation_config; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.program_organisation_config ENABLE ROW LEVEL SECURITY;

--
-- Name: program_organisation_config program_organisation_config_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY program_organisation_config_orgs ON public.program_organisation_config USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: program program_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY program_orgs ON public.program USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: program_outcome; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.program_outcome ENABLE ROW LEVEL SECURITY;

--
-- Name: program_outcome program_outcome_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY program_outcome_orgs ON public.program_outcome USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: report_card; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.report_card ENABLE ROW LEVEL SECURITY;

--
-- Name: reset_sync; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.reset_sync ENABLE ROW LEVEL SECURITY;

--
-- Name: reset_sync reset_sync_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY reset_sync_orgs ON public.reset_sync USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: rule; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.rule ENABLE ROW LEVEL SECURITY;

--
-- Name: rule_dependency; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.rule_dependency ENABLE ROW LEVEL SECURITY;

--
-- Name: rule_dependency rule_dependency_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY rule_dependency_orgs ON public.rule_dependency USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: rule_failure_telemetry; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.rule_failure_telemetry ENABLE ROW LEVEL SECURITY;

--
-- Name: rule_failure_telemetry rule_failure_telemetry_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY rule_failure_telemetry_orgs ON public.rule_failure_telemetry USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: rule rule_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY rule_orgs ON public.rule USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: subject_migration; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.subject_migration ENABLE ROW LEVEL SECURITY;

--
-- Name: subject_migration subject_migration_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY subject_migration_orgs ON public.subject_migration USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: subject_program_eligibility; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.subject_program_eligibility ENABLE ROW LEVEL SECURITY;

--
-- Name: subject_program_eligibility subject_program_eligibility_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY subject_program_eligibility_orgs ON public.subject_program_eligibility USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: subject_type; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.subject_type ENABLE ROW LEVEL SECURITY;

--
-- Name: subject_type subject_type_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY subject_type_orgs ON public.subject_type USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: sync_telemetry; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.sync_telemetry ENABLE ROW LEVEL SECURITY;

--
-- Name: sync_telemetry sync_telemetry_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY sync_telemetry_orgs ON public.sync_telemetry USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: table_metadata; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.table_metadata ENABLE ROW LEVEL SECURITY;

--
-- Name: table_metadata table_metadata_rls_policy; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY table_metadata_rls_policy ON public.table_metadata USING ((schema_name IN ( SELECT s.schema_name
   FROM ( SELECT organisation.db_user,
            organisation.schema_name
           FROM public.organisation
        UNION ALL
         SELECT organisation_group.db_user,
            organisation_group.schema_name
           FROM public.organisation_group) s
  WHERE ((s.db_user)::text = CURRENT_USER)))) WITH CHECK ((schema_name IN ( SELECT s.schema_name
   FROM ( SELECT organisation.db_user,
            organisation.schema_name
           FROM public.organisation
        UNION ALL
         SELECT organisation_group.db_user,
            organisation_group.schema_name
           FROM public.organisation_group) s
  WHERE ((s.db_user)::text = CURRENT_USER))));


--
-- Name: task; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.task ENABLE ROW LEVEL SECURITY;

--
-- Name: task task_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY task_orgs ON public.task USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: task_status; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.task_status ENABLE ROW LEVEL SECURITY;

--
-- Name: task_status task_status_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY task_status_orgs ON public.task_status USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: task_type; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.task_type ENABLE ROW LEVEL SECURITY;

--
-- Name: task_type task_type_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY task_type_orgs ON public.task_type USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: task_unassignment; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.task_unassignment ENABLE ROW LEVEL SECURITY;

--
-- Name: task_unassignment task_unassignment_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY task_unassignment_orgs ON public.task_unassignment USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: translation; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.translation ENABLE ROW LEVEL SECURITY;

--
-- Name: translation translation_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY translation_orgs ON public.translation USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: user_group; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.user_group ENABLE ROW LEVEL SECURITY;

--
-- Name: user_group user_group_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY user_group_orgs ON public.user_group USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: user_subject_assignment; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.user_subject_assignment ENABLE ROW LEVEL SECURITY;

--
-- Name: user_subject_assignment user_subject_assignment_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY user_subject_assignment_orgs ON public.user_subject_assignment USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: users; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

--
-- Name: users users_policy; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY users_policy ON public.users USING ((organisation_id IN ( WITH RECURSIVE children(id, parent_organisation_id) AS (
         SELECT organisation.id,
            organisation.parent_organisation_id
           FROM public.organisation
          WHERE ((organisation.db_user)::text = CURRENT_USER)
        UNION ALL
         SELECT grand_children.id,
            grand_children.parent_organisation_id
           FROM public.organisation grand_children,
            children
          WHERE (grand_children.parent_organisation_id = children.id)
        )
(
         SELECT children.id
           FROM children
        UNION
        ( WITH RECURSIVE parents(id, parent_organisation_id) AS (
                 SELECT organisation.id,
                    organisation.parent_organisation_id
                   FROM public.organisation
                  WHERE ((organisation.db_user)::text = CURRENT_USER)
                UNION ALL
                 SELECT grand_parents.id,
                    grand_parents.parent_organisation_id
                   FROM public.organisation grand_parents,
                    parents parents_1
                  WHERE (grand_parents.id = parents_1.parent_organisation_id)
                )
         SELECT parents.id
           FROM parents)
) UNION ALL
 SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.parent_organisation_id IS NULL) AND (CURRENT_USER = 'openchs_impl'::name))))) WITH CHECK ((organisation_id IN ( WITH RECURSIVE children(id, parent_organisation_id) AS (
         SELECT organisation.id,
            organisation.parent_organisation_id
           FROM public.organisation
          WHERE ((organisation.db_user)::text = CURRENT_USER)
        UNION ALL
         SELECT grand_children.id,
            grand_children.parent_organisation_id
           FROM public.organisation grand_children,
            children
          WHERE (grand_children.parent_organisation_id = children.id)
        )
 SELECT children.id
   FROM children
UNION ALL
 SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.parent_organisation_id IS NULL) AND (CURRENT_USER = 'openchs_impl'::name)))));


--
-- Name: users users_user; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY users_user ON public.users USING (((organisation_id IN ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = ANY (ARRAY['openchs'::name, CURRENT_USER])))) OR (id IN ( SELECT account_admin.admin_id
   FROM public.account_admin
  WHERE (account_admin.account_id IN ( SELECT organisation.account_id
           FROM public.organisation
          WHERE ((organisation.db_user)::text = ANY (ARRAY['openchs'::name, CURRENT_USER])))))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id IN ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = ANY (ARRAY['openchs'::name, CURRENT_USER])))));


--
-- Name: video; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.video ENABLE ROW LEVEL SECURITY;

--
-- Name: video video_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY video_orgs ON public.video USING (((organisation_id IN ( SELECT org_ids.id
   FROM public.org_ids
UNION
 SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: video_telemetric; Type: ROW SECURITY; Schema: public; Owner: openchs
--

ALTER TABLE public.video_telemetric ENABLE ROW LEVEL SECURITY;

--
-- Name: video_telemetric video_telemetric_orgs; Type: POLICY; Schema: public; Owner: openchs
--

CREATE POLICY video_telemetric_orgs ON public.video_telemetric USING (((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))) OR (organisation_id IN ( SELECT organisation_group_organisation.organisation_id
   FROM public.organisation_group_organisation)))) WITH CHECK ((organisation_id = ( SELECT organisation.id
   FROM public.organisation
  WHERE ((organisation.db_user)::text = CURRENT_USER))));


--
-- Name: FUNCTION append_manual_update_history(current_value text, text_to_be_added text); Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON FUNCTION public.append_manual_update_history(current_value text, text_to_be_added text) TO pg_database_owner;
GRANT ALL ON FUNCTION public.append_manual_update_history(current_value text, text_to_be_added text) TO openchs_impl;
GRANT ALL ON FUNCTION public.append_manual_update_history(current_value text, text_to_be_added text) TO gok;


--
-- Name: FUNCTION audit_table_trigger(); Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON FUNCTION public.audit_table_trigger() TO pg_database_owner;
GRANT ALL ON FUNCTION public.audit_table_trigger() TO openchs_impl;
GRANT ALL ON FUNCTION public.audit_table_trigger() TO gok;


--
-- Name: FUNCTION concept_name(text); Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON FUNCTION public.concept_name(text) TO pg_database_owner;
GRANT ALL ON FUNCTION public.concept_name(text) TO openchs_impl;
GRANT ALL ON FUNCTION public.concept_name(text) TO gok;


--
-- Name: FUNCTION create_audit(); Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON FUNCTION public.create_audit() TO pg_database_owner;
GRANT ALL ON FUNCTION public.create_audit() TO openchs_impl;
GRANT ALL ON FUNCTION public.create_audit() TO gok;


--
-- Name: FUNCTION create_audit(user_id numeric); Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON FUNCTION public.create_audit(user_id numeric) TO pg_database_owner;
GRANT ALL ON FUNCTION public.create_audit(user_id numeric) TO openchs_impl;
GRANT ALL ON FUNCTION public.create_audit(user_id numeric) TO gok;


--
-- Name: FUNCTION create_audit_columns(table_name text); Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON FUNCTION public.create_audit_columns(table_name text) TO pg_database_owner;
GRANT ALL ON FUNCTION public.create_audit_columns(table_name text) TO openchs_impl;
GRANT ALL ON FUNCTION public.create_audit_columns(table_name text) TO gok;


--
-- Name: FUNCTION create_db_user(inrolname text, inpassword text); Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON FUNCTION public.create_db_user(inrolname text, inpassword text) TO pg_database_owner;
GRANT ALL ON FUNCTION public.create_db_user(inrolname text, inpassword text) TO openchs_impl;
GRANT ALL ON FUNCTION public.create_db_user(inrolname text, inpassword text) TO gok;


--
-- Name: FUNCTION create_implementation_schema(schema_name text, db_user text); Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON FUNCTION public.create_implementation_schema(schema_name text, db_user text) TO pg_database_owner;
GRANT ALL ON FUNCTION public.create_implementation_schema(schema_name text, db_user text) TO openchs_impl;
GRANT ALL ON FUNCTION public.create_implementation_schema(schema_name text, db_user text) TO gok;


--
-- Name: FUNCTION create_view(schema_name text, view_name text, sql_query text); Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON FUNCTION public.create_view(schema_name text, view_name text, sql_query text) TO pg_database_owner;
GRANT ALL ON FUNCTION public.create_view(schema_name text, view_name text, sql_query text) TO openchs_impl;
GRANT ALL ON FUNCTION public.create_view(schema_name text, view_name text, sql_query text) TO gok;


--
-- Name: FUNCTION delete_etl_metadata_for_org(in_impl_schema text, in_db_user text); Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON FUNCTION public.delete_etl_metadata_for_org(in_impl_schema text, in_db_user text) TO pg_database_owner;
GRANT ALL ON FUNCTION public.delete_etl_metadata_for_org(in_impl_schema text, in_db_user text) TO openchs_impl;
GRANT ALL ON FUNCTION public.delete_etl_metadata_for_org(in_impl_schema text, in_db_user text) TO gok;


--
-- Name: FUNCTION delete_etl_metadata_for_schema(in_impl_schema text, in_db_user text); Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON FUNCTION public.delete_etl_metadata_for_schema(in_impl_schema text, in_db_user text) TO pg_database_owner;
GRANT ALL ON FUNCTION public.delete_etl_metadata_for_schema(in_impl_schema text, in_db_user text) TO openchs_impl;
GRANT ALL ON FUNCTION public.delete_etl_metadata_for_schema(in_impl_schema text, in_db_user text) TO gok;


--
-- Name: FUNCTION deps_restore_dependencies(p_view_schema character varying, p_view_name character varying); Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON FUNCTION public.deps_restore_dependencies(p_view_schema character varying, p_view_name character varying) TO pg_database_owner;
GRANT ALL ON FUNCTION public.deps_restore_dependencies(p_view_schema character varying, p_view_name character varying) TO openchs_impl;
GRANT ALL ON FUNCTION public.deps_restore_dependencies(p_view_schema character varying, p_view_name character varying) TO gok;


--
-- Name: FUNCTION deps_save_and_drop_dependencies(p_view_schema character varying, p_view_name character varying); Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON FUNCTION public.deps_save_and_drop_dependencies(p_view_schema character varying, p_view_name character varying) TO pg_database_owner;
GRANT ALL ON FUNCTION public.deps_save_and_drop_dependencies(p_view_schema character varying, p_view_name character varying) TO openchs_impl;
GRANT ALL ON FUNCTION public.deps_save_and_drop_dependencies(p_view_schema character varying, p_view_name character varying) TO gok;


--
-- Name: FUNCTION drop_view(schema_name text, view_name text); Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON FUNCTION public.drop_view(schema_name text, view_name text) TO pg_database_owner;
GRANT ALL ON FUNCTION public.drop_view(schema_name text, view_name text) TO openchs_impl;
GRANT ALL ON FUNCTION public.drop_view(schema_name text, view_name text) TO gok;


--
-- Name: FUNCTION enable_rls_on_ref_table(tablename text); Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON FUNCTION public.enable_rls_on_ref_table(tablename text) TO pg_database_owner;
GRANT ALL ON FUNCTION public.enable_rls_on_ref_table(tablename text) TO openchs_impl;
GRANT ALL ON FUNCTION public.enable_rls_on_ref_table(tablename text) TO gok;


--
-- Name: FUNCTION enable_rls_on_tx_table(tablename text); Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON FUNCTION public.enable_rls_on_tx_table(tablename text) TO pg_database_owner;
GRANT ALL ON FUNCTION public.enable_rls_on_tx_table(tablename text) TO openchs_impl;
GRANT ALL ON FUNCTION public.enable_rls_on_tx_table(tablename text) TO gok;


--
-- Name: FUNCTION frequency_and_percentage(frequency_query text); Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON FUNCTION public.frequency_and_percentage(frequency_query text) TO pg_database_owner;
GRANT ALL ON FUNCTION public.frequency_and_percentage(frequency_query text) TO openchs_impl;
GRANT ALL ON FUNCTION public.frequency_and_percentage(frequency_query text) TO gok;


--
-- Name: FUNCTION frequency_and_percentage(frequency_query text, denominator_query text); Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON FUNCTION public.frequency_and_percentage(frequency_query text, denominator_query text) TO pg_database_owner;
GRANT ALL ON FUNCTION public.frequency_and_percentage(frequency_query text, denominator_query text) TO openchs_impl;
GRANT ALL ON FUNCTION public.frequency_and_percentage(frequency_query text, denominator_query text) TO gok;


--
-- Name: FUNCTION get_coded_string_value(obs jsonb, obs_store public.hstore); Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON FUNCTION public.get_coded_string_value(obs jsonb, obs_store public.hstore) TO pg_database_owner;
GRANT ALL ON FUNCTION public.get_coded_string_value(obs jsonb, obs_store public.hstore) TO openchs_impl;
GRANT ALL ON FUNCTION public.get_coded_string_value(obs jsonb, obs_store public.hstore) TO gok;


--
-- Name: FUNCTION grant_all_on_all(rolename text); Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON FUNCTION public.grant_all_on_all(rolename text) TO pg_database_owner;
GRANT ALL ON FUNCTION public.grant_all_on_all(rolename text) TO openchs_impl;
GRANT ALL ON FUNCTION public.grant_all_on_all(rolename text) TO gok;


--
-- Name: FUNCTION grant_all_on_views(view_names text[], role text); Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON FUNCTION public.grant_all_on_views(view_names text[], role text) TO pg_database_owner;
GRANT ALL ON FUNCTION public.grant_all_on_views(view_names text[], role text) TO openchs_impl;
GRANT ALL ON FUNCTION public.grant_all_on_views(view_names text[], role text) TO gok;


--
-- Name: FUNCTION grant_permission_on_account_admin(rolename text); Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON FUNCTION public.grant_permission_on_account_admin(rolename text) TO pg_database_owner;
GRANT ALL ON FUNCTION public.grant_permission_on_account_admin(rolename text) TO openchs_impl;
GRANT ALL ON FUNCTION public.grant_permission_on_account_admin(rolename text) TO gok;


--
-- Name: FUNCTION jsonb_object_values_contain(obs jsonb, pattern text); Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON FUNCTION public.jsonb_object_values_contain(obs jsonb, pattern text) TO pg_database_owner;
GRANT ALL ON FUNCTION public.jsonb_object_values_contain(obs jsonb, pattern text) TO openchs_impl;
GRANT ALL ON FUNCTION public.jsonb_object_values_contain(obs jsonb, pattern text) TO gok;


--
-- Name: FUNCTION revoke_permissions_on_account(rolename text); Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON FUNCTION public.revoke_permissions_on_account(rolename text) TO gok;
GRANT ALL ON FUNCTION public.revoke_permissions_on_account(rolename text) TO pg_database_owner;
GRANT ALL ON FUNCTION public.revoke_permissions_on_account(rolename text) TO openchs_impl;


--
-- Name: FUNCTION solidify_audit_columns(table_name text); Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON FUNCTION public.solidify_audit_columns(table_name text) TO pg_database_owner;
GRANT ALL ON FUNCTION public.solidify_audit_columns(table_name text) TO openchs_impl;
GRANT ALL ON FUNCTION public.solidify_audit_columns(table_name text) TO gok;


--
-- Name: FUNCTION title_lineage_locations_function(addressid bigint); Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON FUNCTION public.title_lineage_locations_function(addressid bigint) TO pg_database_owner;
GRANT ALL ON FUNCTION public.title_lineage_locations_function(addressid bigint) TO openchs_impl;
GRANT ALL ON FUNCTION public.title_lineage_locations_function(addressid bigint) TO gok;


--
-- Name: FUNCTION virtual_catchment_address_mapping_table_function(); Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON FUNCTION public.virtual_catchment_address_mapping_table_function() TO pg_database_owner;
GRANT ALL ON FUNCTION public.virtual_catchment_address_mapping_table_function() TO openchs_impl;
GRANT ALL ON FUNCTION public.virtual_catchment_address_mapping_table_function() TO gok;


--
-- Name: TABLE account_admin; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.account_admin TO pg_database_owner;
GRANT ALL ON TABLE public.account_admin TO openchs_impl;
GRANT ALL ON TABLE public.account_admin TO gok;


--
-- Name: SEQUENCE account_admin_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.account_admin_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.account_admin_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.account_admin_id_seq TO gok;


--
-- Name: SEQUENCE account_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.account_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.account_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.account_id_seq TO gok;


--
-- Name: TABLE address_level; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.address_level TO pg_database_owner;
GRANT ALL ON TABLE public.address_level TO openchs_impl;
GRANT ALL ON TABLE public.address_level TO gok;


--
-- Name: SEQUENCE address_level_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.address_level_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.address_level_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.address_level_id_seq TO gok;


--
-- Name: TABLE address_level_type; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.address_level_type TO pg_database_owner;
GRANT ALL ON TABLE public.address_level_type TO openchs_impl;
GRANT ALL ON TABLE public.address_level_type TO gok;


--
-- Name: SEQUENCE address_level_type_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.address_level_type_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.address_level_type_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.address_level_type_id_seq TO gok;


--
-- Name: TABLE organisation; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.organisation TO pg_database_owner;
GRANT ALL ON TABLE public.organisation TO openchs_impl;
GRANT ALL ON TABLE public.organisation TO gok;


--
-- Name: TABLE address_level_type_view; Type: ACL; Schema: public; Owner: openchs
--

GRANT SELECT ON TABLE public.address_level_type_view TO pg_database_owner;
GRANT SELECT ON TABLE public.address_level_type_view TO openchs_impl;
GRANT SELECT ON TABLE public.address_level_type_view TO gok;


--
-- Name: TABLE form; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.form TO pg_database_owner;
GRANT ALL ON TABLE public.form TO openchs_impl;
GRANT ALL ON TABLE public.form TO gok;


--
-- Name: TABLE form_mapping; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.form_mapping TO pg_database_owner;
GRANT ALL ON TABLE public.form_mapping TO openchs_impl;
GRANT ALL ON TABLE public.form_mapping TO gok;


--
-- Name: TABLE operational_encounter_type; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.operational_encounter_type TO pg_database_owner;
GRANT ALL ON TABLE public.operational_encounter_type TO openchs_impl;
GRANT ALL ON TABLE public.operational_encounter_type TO gok;


--
-- Name: TABLE operational_program; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.operational_program TO pg_database_owner;
GRANT ALL ON TABLE public.operational_program TO openchs_impl;
GRANT ALL ON TABLE public.operational_program TO gok;


--
-- Name: TABLE all_forms; Type: ACL; Schema: public; Owner: openchs
--

GRANT SELECT ON TABLE public.all_forms TO pg_database_owner;
GRANT SELECT ON TABLE public.all_forms TO openchs_impl;
GRANT SELECT ON TABLE public.all_forms TO gok;


--
-- Name: TABLE concept; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.concept TO pg_database_owner;
GRANT ALL ON TABLE public.concept TO openchs_impl;
GRANT ALL ON TABLE public.concept TO gok;


--
-- Name: TABLE concept_answer; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.concept_answer TO pg_database_owner;
GRANT ALL ON TABLE public.concept_answer TO openchs_impl;
GRANT ALL ON TABLE public.concept_answer TO gok;


--
-- Name: TABLE form_element; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.form_element TO pg_database_owner;
GRANT ALL ON TABLE public.form_element TO openchs_impl;
GRANT ALL ON TABLE public.form_element TO gok;


--
-- Name: TABLE form_element_group; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.form_element_group TO pg_database_owner;
GRANT ALL ON TABLE public.form_element_group TO openchs_impl;
GRANT ALL ON TABLE public.form_element_group TO gok;


--
-- Name: TABLE all_concept_answers; Type: ACL; Schema: public; Owner: openchs
--

GRANT SELECT ON TABLE public.all_concept_answers TO pg_database_owner;
GRANT SELECT ON TABLE public.all_concept_answers TO openchs_impl;
GRANT SELECT ON TABLE public.all_concept_answers TO gok;


--
-- Name: TABLE all_concepts; Type: ACL; Schema: public; Owner: openchs
--

GRANT SELECT ON TABLE public.all_concepts TO pg_database_owner;
GRANT SELECT ON TABLE public.all_concepts TO openchs_impl;
GRANT SELECT ON TABLE public.all_concepts TO gok;


--
-- Name: TABLE encounter_type; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.encounter_type TO pg_database_owner;
GRANT ALL ON TABLE public.encounter_type TO openchs_impl;
GRANT ALL ON TABLE public.encounter_type TO gok;


--
-- Name: TABLE all_encounter_types; Type: ACL; Schema: public; Owner: openchs
--

GRANT SELECT ON TABLE public.all_encounter_types TO pg_database_owner;
GRANT SELECT ON TABLE public.all_encounter_types TO openchs_impl;
GRANT SELECT ON TABLE public.all_encounter_types TO gok;


--
-- Name: TABLE all_form_element_groups; Type: ACL; Schema: public; Owner: openchs
--

GRANT SELECT ON TABLE public.all_form_element_groups TO pg_database_owner;
GRANT SELECT ON TABLE public.all_form_element_groups TO openchs_impl;
GRANT SELECT ON TABLE public.all_form_element_groups TO gok;


--
-- Name: TABLE all_form_elements; Type: ACL; Schema: public; Owner: openchs
--

GRANT SELECT ON TABLE public.all_form_elements TO pg_database_owner;
GRANT SELECT ON TABLE public.all_form_elements TO openchs_impl;
GRANT SELECT ON TABLE public.all_form_elements TO gok;


--
-- Name: TABLE all_operational_encounter_types; Type: ACL; Schema: public; Owner: openchs
--

GRANT SELECT ON TABLE public.all_operational_encounter_types TO pg_database_owner;
GRANT SELECT ON TABLE public.all_operational_encounter_types TO openchs_impl;
GRANT SELECT ON TABLE public.all_operational_encounter_types TO gok;


--
-- Name: TABLE program; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.program TO pg_database_owner;
GRANT ALL ON TABLE public.program TO openchs_impl;
GRANT ALL ON TABLE public.program TO gok;


--
-- Name: TABLE all_operational_programs; Type: ACL; Schema: public; Owner: openchs
--

GRANT SELECT ON TABLE public.all_operational_programs TO pg_database_owner;
GRANT SELECT ON TABLE public.all_operational_programs TO openchs_impl;
GRANT SELECT ON TABLE public.all_operational_programs TO gok;


--
-- Name: TABLE all_programs; Type: ACL; Schema: public; Owner: openchs
--

GRANT SELECT ON TABLE public.all_programs TO pg_database_owner;
GRANT SELECT ON TABLE public.all_programs TO openchs_impl;
GRANT SELECT ON TABLE public.all_programs TO gok;


--
-- Name: TABLE answer_concept_migration; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.answer_concept_migration TO pg_database_owner;
GRANT ALL ON TABLE public.answer_concept_migration TO openchs_impl;
GRANT ALL ON TABLE public.answer_concept_migration TO gok;


--
-- Name: SEQUENCE answer_concept_migration_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.answer_concept_migration_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.answer_concept_migration_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.answer_concept_migration_id_seq TO gok;


--
-- Name: TABLE approval_status; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.approval_status TO pg_database_owner;
GRANT ALL ON TABLE public.approval_status TO openchs_impl;
GRANT ALL ON TABLE public.approval_status TO gok;


--
-- Name: SEQUENCE approval_status_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.approval_status_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.approval_status_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.approval_status_id_seq TO gok;


--
-- Name: TABLE audit; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.audit TO pg_database_owner;
GRANT ALL ON TABLE public.audit TO openchs_impl;
GRANT ALL ON TABLE public.audit TO gok;


--
-- Name: SEQUENCE audit_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.audit_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.audit_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.audit_id_seq TO gok;


--
-- Name: TABLE batch_job_execution; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.batch_job_execution TO gok;
GRANT ALL ON TABLE public.batch_job_execution TO pg_database_owner;
GRANT ALL ON TABLE public.batch_job_execution TO openchs_impl;


--
-- Name: TABLE batch_job_execution_context; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.batch_job_execution_context TO gok;
GRANT ALL ON TABLE public.batch_job_execution_context TO pg_database_owner;
GRANT ALL ON TABLE public.batch_job_execution_context TO openchs_impl;


--
-- Name: TABLE batch_job_execution_params; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.batch_job_execution_params TO gok;
GRANT ALL ON TABLE public.batch_job_execution_params TO pg_database_owner;
GRANT ALL ON TABLE public.batch_job_execution_params TO openchs_impl;


--
-- Name: SEQUENCE batch_job_execution_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.batch_job_execution_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.batch_job_execution_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.batch_job_execution_seq TO gok;


--
-- Name: TABLE batch_job_instance; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.batch_job_instance TO gok;
GRANT ALL ON TABLE public.batch_job_instance TO pg_database_owner;
GRANT ALL ON TABLE public.batch_job_instance TO openchs_impl;


--
-- Name: SEQUENCE batch_job_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.batch_job_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.batch_job_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.batch_job_seq TO gok;


--
-- Name: TABLE batch_step_execution; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.batch_step_execution TO gok;
GRANT ALL ON TABLE public.batch_step_execution TO pg_database_owner;
GRANT ALL ON TABLE public.batch_step_execution TO openchs_impl;


--
-- Name: TABLE batch_step_execution_context; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.batch_step_execution_context TO gok;
GRANT ALL ON TABLE public.batch_step_execution_context TO pg_database_owner;
GRANT ALL ON TABLE public.batch_step_execution_context TO openchs_impl;


--
-- Name: SEQUENCE batch_step_execution_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.batch_step_execution_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.batch_step_execution_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.batch_step_execution_seq TO gok;


--
-- Name: TABLE catchment; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.catchment TO pg_database_owner;
GRANT ALL ON TABLE public.catchment TO openchs_impl;
GRANT ALL ON TABLE public.catchment TO gok;


--
-- Name: TABLE catchment_address_mapping; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.catchment_address_mapping TO pg_database_owner;
GRANT ALL ON TABLE public.catchment_address_mapping TO openchs_impl;
GRANT ALL ON TABLE public.catchment_address_mapping TO gok;


--
-- Name: SEQUENCE catchment_address_mapping_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.catchment_address_mapping_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.catchment_address_mapping_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.catchment_address_mapping_id_seq TO gok;


--
-- Name: SEQUENCE catchment_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.catchment_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.catchment_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.catchment_id_seq TO gok;


--
-- Name: TABLE checklist; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.checklist TO pg_database_owner;
GRANT ALL ON TABLE public.checklist TO openchs_impl;
GRANT ALL ON TABLE public.checklist TO gok;


--
-- Name: TABLE checklist_detail; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.checklist_detail TO pg_database_owner;
GRANT ALL ON TABLE public.checklist_detail TO openchs_impl;
GRANT ALL ON TABLE public.checklist_detail TO gok;


--
-- Name: SEQUENCE checklist_detail_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.checklist_detail_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.checklist_detail_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.checklist_detail_id_seq TO gok;


--
-- Name: SEQUENCE checklist_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.checklist_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.checklist_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.checklist_id_seq TO gok;


--
-- Name: TABLE checklist_item; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.checklist_item TO pg_database_owner;
GRANT ALL ON TABLE public.checklist_item TO openchs_impl;
GRANT ALL ON TABLE public.checklist_item TO gok;


--
-- Name: TABLE checklist_item_detail; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.checklist_item_detail TO pg_database_owner;
GRANT ALL ON TABLE public.checklist_item_detail TO openchs_impl;
GRANT ALL ON TABLE public.checklist_item_detail TO gok;


--
-- Name: SEQUENCE checklist_item_detail_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.checklist_item_detail_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.checklist_item_detail_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.checklist_item_detail_id_seq TO gok;


--
-- Name: SEQUENCE checklist_item_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.checklist_item_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.checklist_item_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.checklist_item_id_seq TO gok;


--
-- Name: TABLE column_metadata; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.column_metadata TO pg_database_owner;
GRANT ALL ON TABLE public.column_metadata TO openchs_impl;
GRANT ALL ON TABLE public.column_metadata TO gok;


--
-- Name: SEQUENCE column_metadata_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.column_metadata_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.column_metadata_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.column_metadata_id_seq TO gok;


--
-- Name: TABLE comment; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.comment TO pg_database_owner;
GRANT ALL ON TABLE public.comment TO openchs_impl;
GRANT ALL ON TABLE public.comment TO gok;


--
-- Name: SEQUENCE comment_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.comment_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.comment_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.comment_id_seq TO gok;


--
-- Name: TABLE comment_thread; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.comment_thread TO pg_database_owner;
GRANT ALL ON TABLE public.comment_thread TO openchs_impl;
GRANT ALL ON TABLE public.comment_thread TO gok;


--
-- Name: SEQUENCE comment_thread_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.comment_thread_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.comment_thread_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.comment_thread_id_seq TO gok;


--
-- Name: SEQUENCE concept_answer_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.concept_answer_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.concept_answer_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.concept_answer_id_seq TO gok;


--
-- Name: SEQUENCE concept_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.concept_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.concept_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.concept_id_seq TO gok;


--
-- Name: TABLE custom_query; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.custom_query TO pg_database_owner;
GRANT ALL ON TABLE public.custom_query TO openchs_impl;
GRANT ALL ON TABLE public.custom_query TO gok;


--
-- Name: SEQUENCE custom_query_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.custom_query_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.custom_query_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.custom_query_id_seq TO gok;


--
-- Name: TABLE dashboard; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.dashboard TO pg_database_owner;
GRANT ALL ON TABLE public.dashboard TO openchs_impl;
GRANT ALL ON TABLE public.dashboard TO gok;


--
-- Name: TABLE dashboard_card_mapping; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.dashboard_card_mapping TO pg_database_owner;
GRANT ALL ON TABLE public.dashboard_card_mapping TO openchs_impl;
GRANT ALL ON TABLE public.dashboard_card_mapping TO gok;


--
-- Name: SEQUENCE dashboard_card_mapping_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.dashboard_card_mapping_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.dashboard_card_mapping_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.dashboard_card_mapping_id_seq TO gok;


--
-- Name: TABLE dashboard_filter; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.dashboard_filter TO pg_database_owner;
GRANT ALL ON TABLE public.dashboard_filter TO openchs_impl;
GRANT ALL ON TABLE public.dashboard_filter TO gok;


--
-- Name: SEQUENCE dashboard_filter_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.dashboard_filter_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.dashboard_filter_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.dashboard_filter_id_seq TO gok;


--
-- Name: SEQUENCE dashboard_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.dashboard_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.dashboard_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.dashboard_id_seq TO gok;


--
-- Name: TABLE dashboard_section; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.dashboard_section TO pg_database_owner;
GRANT ALL ON TABLE public.dashboard_section TO openchs_impl;
GRANT ALL ON TABLE public.dashboard_section TO gok;


--
-- Name: TABLE dashboard_section_card_mapping; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.dashboard_section_card_mapping TO pg_database_owner;
GRANT ALL ON TABLE public.dashboard_section_card_mapping TO openchs_impl;
GRANT ALL ON TABLE public.dashboard_section_card_mapping TO gok;


--
-- Name: SEQUENCE dashboard_section_card_mapping_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.dashboard_section_card_mapping_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.dashboard_section_card_mapping_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.dashboard_section_card_mapping_id_seq TO gok;


--
-- Name: SEQUENCE dashboard_section_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.dashboard_section_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.dashboard_section_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.dashboard_section_id_seq TO gok;


--
-- Name: TABLE decision_concept; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.decision_concept TO pg_database_owner;
GRANT ALL ON TABLE public.decision_concept TO openchs_impl;
GRANT ALL ON TABLE public.decision_concept TO gok;


--
-- Name: SEQUENCE decision_concept_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.decision_concept_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.decision_concept_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.decision_concept_id_seq TO gok;


--
-- Name: TABLE deps_saved_ddl; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.deps_saved_ddl TO pg_database_owner;
GRANT ALL ON TABLE public.deps_saved_ddl TO openchs_impl;
GRANT ALL ON TABLE public.deps_saved_ddl TO gok;


--
-- Name: SEQUENCE deps_saved_ddl_deps_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.deps_saved_ddl_deps_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.deps_saved_ddl_deps_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.deps_saved_ddl_deps_id_seq TO gok;


--
-- Name: TABLE documentation; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.documentation TO pg_database_owner;
GRANT ALL ON TABLE public.documentation TO openchs_impl;
GRANT ALL ON TABLE public.documentation TO gok;


--
-- Name: SEQUENCE documentation_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.documentation_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.documentation_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.documentation_id_seq TO gok;


--
-- Name: TABLE documentation_item; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.documentation_item TO pg_database_owner;
GRANT ALL ON TABLE public.documentation_item TO openchs_impl;
GRANT ALL ON TABLE public.documentation_item TO gok;


--
-- Name: SEQUENCE documentation_item_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.documentation_item_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.documentation_item_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.documentation_item_id_seq TO gok;


--
-- Name: TABLE encounter; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.encounter TO pg_database_owner;
GRANT ALL ON TABLE public.encounter TO openchs_impl;
GRANT ALL ON TABLE public.encounter TO gok;


--
-- Name: SEQUENCE encounter_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.encounter_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.encounter_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.encounter_id_seq TO gok;


--
-- Name: SEQUENCE encounter_type_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.encounter_type_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.encounter_type_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.encounter_type_id_seq TO gok;


--
-- Name: TABLE entity_approval_status; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.entity_approval_status TO pg_database_owner;
GRANT ALL ON TABLE public.entity_approval_status TO openchs_impl;
GRANT ALL ON TABLE public.entity_approval_status TO gok;


--
-- Name: SEQUENCE entity_approval_status_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.entity_approval_status_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.entity_approval_status_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.entity_approval_status_id_seq TO gok;


--
-- Name: TABLE entity_sync_status; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.entity_sync_status TO pg_database_owner;
GRANT ALL ON TABLE public.entity_sync_status TO openchs_impl;
GRANT ALL ON TABLE public.entity_sync_status TO gok;


--
-- Name: SEQUENCE entity_sync_status_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.entity_sync_status_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.entity_sync_status_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.entity_sync_status_id_seq TO gok;


--
-- Name: TABLE export_job_parameters; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.export_job_parameters TO pg_database_owner;
GRANT ALL ON TABLE public.export_job_parameters TO openchs_impl;
GRANT ALL ON TABLE public.export_job_parameters TO gok;


--
-- Name: SEQUENCE export_job_parameters_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.export_job_parameters_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.export_job_parameters_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.export_job_parameters_id_seq TO gok;


--
-- Name: TABLE external_system_config; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.external_system_config TO pg_database_owner;
GRANT ALL ON TABLE public.external_system_config TO openchs_impl;
GRANT ALL ON TABLE public.external_system_config TO gok;


--
-- Name: SEQUENCE external_system_config_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.external_system_config_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.external_system_config_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.external_system_config_id_seq TO gok;


--
-- Name: TABLE facility; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.facility TO pg_database_owner;
GRANT ALL ON TABLE public.facility TO openchs_impl;
GRANT ALL ON TABLE public.facility TO gok;


--
-- Name: SEQUENCE facility_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.facility_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.facility_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.facility_id_seq TO gok;


--
-- Name: SEQUENCE form_element_group_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.form_element_group_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.form_element_group_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.form_element_group_id_seq TO gok;


--
-- Name: SEQUENCE form_element_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.form_element_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.form_element_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.form_element_id_seq TO gok;


--
-- Name: SEQUENCE form_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.form_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.form_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.form_id_seq TO gok;


--
-- Name: SEQUENCE form_mapping_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.form_mapping_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.form_mapping_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.form_mapping_id_seq TO gok;


--
-- Name: TABLE gender; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.gender TO pg_database_owner;
GRANT ALL ON TABLE public.gender TO openchs_impl;
GRANT ALL ON TABLE public.gender TO gok;


--
-- Name: SEQUENCE gender_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.gender_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.gender_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.gender_id_seq TO gok;


--
-- Name: TABLE group_dashboard; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.group_dashboard TO pg_database_owner;
GRANT ALL ON TABLE public.group_dashboard TO openchs_impl;
GRANT ALL ON TABLE public.group_dashboard TO gok;


--
-- Name: SEQUENCE group_dashboard_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.group_dashboard_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.group_dashboard_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.group_dashboard_id_seq TO gok;


--
-- Name: TABLE group_privilege; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.group_privilege TO pg_database_owner;
GRANT ALL ON TABLE public.group_privilege TO openchs_impl;
GRANT ALL ON TABLE public.group_privilege TO gok;


--
-- Name: SEQUENCE group_privilege_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.group_privilege_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.group_privilege_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.group_privilege_id_seq TO gok;


--
-- Name: TABLE group_role; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.group_role TO pg_database_owner;
GRANT ALL ON TABLE public.group_role TO openchs_impl;
GRANT ALL ON TABLE public.group_role TO gok;


--
-- Name: SEQUENCE group_role_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.group_role_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.group_role_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.group_role_id_seq TO gok;


--
-- Name: TABLE group_subject; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.group_subject TO pg_database_owner;
GRANT ALL ON TABLE public.group_subject TO openchs_impl;
GRANT ALL ON TABLE public.group_subject TO gok;


--
-- Name: SEQUENCE group_subject_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.group_subject_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.group_subject_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.group_subject_id_seq TO gok;


--
-- Name: TABLE groups; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.groups TO pg_database_owner;
GRANT ALL ON TABLE public.groups TO openchs_impl;
GRANT ALL ON TABLE public.groups TO gok;


--
-- Name: SEQUENCE groups_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.groups_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.groups_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.groups_id_seq TO gok;


--
-- Name: TABLE identifier_assignment; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.identifier_assignment TO pg_database_owner;
GRANT ALL ON TABLE public.identifier_assignment TO openchs_impl;
GRANT ALL ON TABLE public.identifier_assignment TO gok;


--
-- Name: SEQUENCE identifier_assignment_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.identifier_assignment_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.identifier_assignment_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.identifier_assignment_id_seq TO gok;


--
-- Name: TABLE identifier_source; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.identifier_source TO pg_database_owner;
GRANT ALL ON TABLE public.identifier_source TO openchs_impl;
GRANT ALL ON TABLE public.identifier_source TO gok;


--
-- Name: SEQUENCE identifier_source_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.identifier_source_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.identifier_source_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.identifier_source_id_seq TO gok;


--
-- Name: TABLE identifier_user_assignment; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.identifier_user_assignment TO pg_database_owner;
GRANT ALL ON TABLE public.identifier_user_assignment TO openchs_impl;
GRANT ALL ON TABLE public.identifier_user_assignment TO gok;


--
-- Name: SEQUENCE identifier_user_assignment_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.identifier_user_assignment_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.identifier_user_assignment_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.identifier_user_assignment_id_seq TO gok;


--
-- Name: TABLE index_metadata; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.index_metadata TO pg_database_owner;
GRANT ALL ON TABLE public.index_metadata TO openchs_impl;
GRANT ALL ON TABLE public.index_metadata TO gok;


--
-- Name: SEQUENCE index_metadata_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.index_metadata_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.index_metadata_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.index_metadata_id_seq TO gok;


--
-- Name: TABLE individual; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.individual TO pg_database_owner;
GRANT ALL ON TABLE public.individual TO openchs_impl;
GRANT ALL ON TABLE public.individual TO gok;


--
-- Name: SEQUENCE individual_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.individual_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.individual_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.individual_id_seq TO gok;


--
-- Name: TABLE program_enrolment; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.program_enrolment TO pg_database_owner;
GRANT ALL ON TABLE public.program_enrolment TO openchs_impl;
GRANT ALL ON TABLE public.program_enrolment TO gok;


--
-- Name: TABLE individual_program_enrolment_search_view; Type: ACL; Schema: public; Owner: openchs
--

GRANT SELECT ON TABLE public.individual_program_enrolment_search_view TO pg_database_owner;
GRANT SELECT ON TABLE public.individual_program_enrolment_search_view TO openchs_impl;
GRANT SELECT ON TABLE public.individual_program_enrolment_search_view TO gok;


--
-- Name: TABLE individual_relation; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.individual_relation TO pg_database_owner;
GRANT ALL ON TABLE public.individual_relation TO openchs_impl;
GRANT ALL ON TABLE public.individual_relation TO gok;


--
-- Name: TABLE individual_relation_gender_mapping; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.individual_relation_gender_mapping TO pg_database_owner;
GRANT ALL ON TABLE public.individual_relation_gender_mapping TO openchs_impl;
GRANT ALL ON TABLE public.individual_relation_gender_mapping TO gok;


--
-- Name: SEQUENCE individual_relation_gender_mapping_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.individual_relation_gender_mapping_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.individual_relation_gender_mapping_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.individual_relation_gender_mapping_id_seq TO gok;


--
-- Name: SEQUENCE individual_relation_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.individual_relation_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.individual_relation_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.individual_relation_id_seq TO gok;


--
-- Name: TABLE individual_relationship; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.individual_relationship TO pg_database_owner;
GRANT ALL ON TABLE public.individual_relationship TO openchs_impl;
GRANT ALL ON TABLE public.individual_relationship TO gok;


--
-- Name: SEQUENCE individual_relationship_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.individual_relationship_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.individual_relationship_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.individual_relationship_id_seq TO gok;


--
-- Name: TABLE individual_relationship_type; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.individual_relationship_type TO pg_database_owner;
GRANT ALL ON TABLE public.individual_relationship_type TO openchs_impl;
GRANT ALL ON TABLE public.individual_relationship_type TO gok;


--
-- Name: SEQUENCE individual_relationship_type_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.individual_relationship_type_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.individual_relationship_type_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.individual_relationship_type_id_seq TO gok;


--
-- Name: TABLE individual_relative; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.individual_relative TO pg_database_owner;
GRANT ALL ON TABLE public.individual_relative TO openchs_impl;
GRANT ALL ON TABLE public.individual_relative TO gok;


--
-- Name: SEQUENCE individual_relative_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.individual_relative_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.individual_relative_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.individual_relative_id_seq TO gok;


--
-- Name: TABLE location_location_mapping; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.location_location_mapping TO pg_database_owner;
GRANT ALL ON TABLE public.location_location_mapping TO openchs_impl;
GRANT ALL ON TABLE public.location_location_mapping TO gok;


--
-- Name: SEQUENCE location_location_mapping_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.location_location_mapping_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.location_location_mapping_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.location_location_mapping_id_seq TO gok;


--
-- Name: TABLE manual_message; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.manual_message TO pg_database_owner;
GRANT ALL ON TABLE public.manual_message TO openchs_impl;
GRANT ALL ON TABLE public.manual_message TO gok;


--
-- Name: SEQUENCE manual_message_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.manual_message_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.manual_message_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.manual_message_id_seq TO gok;


--
-- Name: TABLE menu_item; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.menu_item TO pg_database_owner;
GRANT ALL ON TABLE public.menu_item TO openchs_impl;
GRANT ALL ON TABLE public.menu_item TO gok;


--
-- Name: SEQUENCE menu_item_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.menu_item_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.menu_item_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.menu_item_id_seq TO gok;


--
-- Name: TABLE message_receiver; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.message_receiver TO pg_database_owner;
GRANT ALL ON TABLE public.message_receiver TO openchs_impl;
GRANT ALL ON TABLE public.message_receiver TO gok;


--
-- Name: SEQUENCE message_receiver_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.message_receiver_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.message_receiver_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.message_receiver_id_seq TO gok;


--
-- Name: TABLE message_request_queue; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.message_request_queue TO pg_database_owner;
GRANT ALL ON TABLE public.message_request_queue TO openchs_impl;
GRANT ALL ON TABLE public.message_request_queue TO gok;


--
-- Name: SEQUENCE message_request_queue_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.message_request_queue_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.message_request_queue_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.message_request_queue_id_seq TO gok;


--
-- Name: TABLE message_rule; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.message_rule TO pg_database_owner;
GRANT ALL ON TABLE public.message_rule TO openchs_impl;
GRANT ALL ON TABLE public.message_rule TO gok;


--
-- Name: SEQUENCE message_rule_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.message_rule_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.message_rule_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.message_rule_id_seq TO gok;


--
-- Name: TABLE msg91_config; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.msg91_config TO pg_database_owner;
GRANT ALL ON TABLE public.msg91_config TO openchs_impl;
GRANT ALL ON TABLE public.msg91_config TO gok;


--
-- Name: SEQUENCE msg91_config_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.msg91_config_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.msg91_config_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.msg91_config_id_seq TO gok;


--
-- Name: TABLE news; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.news TO pg_database_owner;
GRANT ALL ON TABLE public.news TO openchs_impl;
GRANT ALL ON TABLE public.news TO gok;


--
-- Name: SEQUENCE news_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.news_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.news_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.news_id_seq TO gok;


--
-- Name: TABLE non_applicable_form_element; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.non_applicable_form_element TO pg_database_owner;
GRANT ALL ON TABLE public.non_applicable_form_element TO openchs_impl;
GRANT ALL ON TABLE public.non_applicable_form_element TO gok;


--
-- Name: SEQUENCE non_applicable_form_element_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.non_applicable_form_element_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.non_applicable_form_element_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.non_applicable_form_element_id_seq TO gok;


--
-- Name: SEQUENCE operational_encounter_type_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.operational_encounter_type_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.operational_encounter_type_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.operational_encounter_type_id_seq TO gok;


--
-- Name: SEQUENCE operational_program_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.operational_program_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.operational_program_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.operational_program_id_seq TO gok;


--
-- Name: TABLE operational_subject_type; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.operational_subject_type TO pg_database_owner;
GRANT ALL ON TABLE public.operational_subject_type TO openchs_impl;
GRANT ALL ON TABLE public.operational_subject_type TO gok;


--
-- Name: SEQUENCE operational_subject_type_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.operational_subject_type_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.operational_subject_type_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.operational_subject_type_id_seq TO gok;


--
-- Name: TABLE org_ids; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.org_ids TO pg_database_owner;
GRANT ALL ON TABLE public.org_ids TO openchs_impl;
GRANT ALL ON TABLE public.org_ids TO gok;


--
-- Name: TABLE organisation_config; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.organisation_config TO pg_database_owner;
GRANT ALL ON TABLE public.organisation_config TO openchs_impl;
GRANT ALL ON TABLE public.organisation_config TO gok;


--
-- Name: SEQUENCE organisation_config_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.organisation_config_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.organisation_config_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.organisation_config_id_seq TO gok;


--
-- Name: TABLE organisation_group; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.organisation_group TO pg_database_owner;
GRANT ALL ON TABLE public.organisation_group TO openchs_impl;
GRANT ALL ON TABLE public.organisation_group TO gok;


--
-- Name: SEQUENCE organisation_group_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.organisation_group_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.organisation_group_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.organisation_group_id_seq TO gok;


--
-- Name: TABLE organisation_group_organisation; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.organisation_group_organisation TO pg_database_owner;
GRANT ALL ON TABLE public.organisation_group_organisation TO openchs_impl;
GRANT ALL ON TABLE public.organisation_group_organisation TO gok;


--
-- Name: SEQUENCE organisation_group_organisation_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.organisation_group_organisation_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.organisation_group_organisation_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.organisation_group_organisation_id_seq TO gok;


--
-- Name: SEQUENCE organisation_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.organisation_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.organisation_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.organisation_id_seq TO gok;


--
-- Name: TABLE platform_translation; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.platform_translation TO pg_database_owner;
GRANT ALL ON TABLE public.platform_translation TO openchs_impl;
GRANT ALL ON TABLE public.platform_translation TO gok;


--
-- Name: SEQUENCE platform_translation_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.platform_translation_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.platform_translation_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.platform_translation_id_seq TO gok;


--
-- Name: TABLE privilege; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.privilege TO pg_database_owner;
GRANT ALL ON TABLE public.privilege TO openchs_impl;
GRANT ALL ON TABLE public.privilege TO gok;


--
-- Name: SEQUENCE privilege_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.privilege_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.privilege_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.privilege_id_seq TO gok;


--
-- Name: TABLE program_encounter; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.program_encounter TO pg_database_owner;
GRANT ALL ON TABLE public.program_encounter TO openchs_impl;
GRANT ALL ON TABLE public.program_encounter TO gok;


--
-- Name: SEQUENCE program_encounter_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.program_encounter_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.program_encounter_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.program_encounter_id_seq TO gok;


--
-- Name: SEQUENCE program_enrolment_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.program_enrolment_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.program_enrolment_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.program_enrolment_id_seq TO gok;


--
-- Name: SEQUENCE program_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.program_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.program_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.program_id_seq TO gok;


--
-- Name: TABLE program_organisation_config; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.program_organisation_config TO pg_database_owner;
GRANT ALL ON TABLE public.program_organisation_config TO openchs_impl;
GRANT ALL ON TABLE public.program_organisation_config TO gok;


--
-- Name: TABLE program_organisation_config_at_risk_concept; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.program_organisation_config_at_risk_concept TO pg_database_owner;
GRANT ALL ON TABLE public.program_organisation_config_at_risk_concept TO openchs_impl;
GRANT ALL ON TABLE public.program_organisation_config_at_risk_concept TO gok;


--
-- Name: SEQUENCE program_organisation_config_at_risk_concept_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.program_organisation_config_at_risk_concept_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.program_organisation_config_at_risk_concept_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.program_organisation_config_at_risk_concept_id_seq TO gok;


--
-- Name: SEQUENCE program_organisation_config_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.program_organisation_config_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.program_organisation_config_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.program_organisation_config_id_seq TO gok;


--
-- Name: TABLE program_outcome; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.program_outcome TO pg_database_owner;
GRANT ALL ON TABLE public.program_outcome TO openchs_impl;
GRANT ALL ON TABLE public.program_outcome TO gok;


--
-- Name: SEQUENCE program_outcome_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.program_outcome_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.program_outcome_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.program_outcome_id_seq TO gok;


--
-- Name: TABLE report_card; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.report_card TO pg_database_owner;
GRANT ALL ON TABLE public.report_card TO openchs_impl;
GRANT ALL ON TABLE public.report_card TO gok;


--
-- Name: SEQUENCE report_card_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.report_card_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.report_card_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.report_card_id_seq TO gok;


--
-- Name: TABLE reset_sync; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.reset_sync TO pg_database_owner;
GRANT ALL ON TABLE public.reset_sync TO openchs_impl;
GRANT ALL ON TABLE public.reset_sync TO gok;


--
-- Name: SEQUENCE reset_sync_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.reset_sync_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.reset_sync_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.reset_sync_id_seq TO gok;


--
-- Name: TABLE rule; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.rule TO pg_database_owner;
GRANT ALL ON TABLE public.rule TO openchs_impl;
GRANT ALL ON TABLE public.rule TO gok;


--
-- Name: TABLE rule_dependency; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.rule_dependency TO pg_database_owner;
GRANT ALL ON TABLE public.rule_dependency TO openchs_impl;
GRANT ALL ON TABLE public.rule_dependency TO gok;


--
-- Name: SEQUENCE rule_dependency_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.rule_dependency_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.rule_dependency_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.rule_dependency_id_seq TO gok;


--
-- Name: TABLE rule_failure_log; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.rule_failure_log TO pg_database_owner;
GRANT ALL ON TABLE public.rule_failure_log TO openchs_impl;
GRANT ALL ON TABLE public.rule_failure_log TO gok;


--
-- Name: SEQUENCE rule_failure_log_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.rule_failure_log_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.rule_failure_log_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.rule_failure_log_id_seq TO gok;


--
-- Name: TABLE rule_failure_telemetry; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.rule_failure_telemetry TO pg_database_owner;
GRANT ALL ON TABLE public.rule_failure_telemetry TO openchs_impl;
GRANT ALL ON TABLE public.rule_failure_telemetry TO gok;


--
-- Name: SEQUENCE rule_failure_telemetry_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.rule_failure_telemetry_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.rule_failure_telemetry_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.rule_failure_telemetry_id_seq TO gok;


--
-- Name: SEQUENCE rule_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.rule_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.rule_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.rule_id_seq TO gok;


--
-- Name: TABLE schema_version; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.schema_version TO pg_database_owner;
GRANT ALL ON TABLE public.schema_version TO openchs_impl;
GRANT ALL ON TABLE public.schema_version TO gok;


--
-- Name: TABLE standard_report_card_type; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.standard_report_card_type TO pg_database_owner;
GRANT ALL ON TABLE public.standard_report_card_type TO openchs_impl;
GRANT ALL ON TABLE public.standard_report_card_type TO gok;


--
-- Name: SEQUENCE standard_report_card_type_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.standard_report_card_type_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.standard_report_card_type_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.standard_report_card_type_id_seq TO gok;


--
-- Name: TABLE subject_migration; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.subject_migration TO pg_database_owner;
GRANT ALL ON TABLE public.subject_migration TO openchs_impl;
GRANT ALL ON TABLE public.subject_migration TO gok;


--
-- Name: SEQUENCE subject_migration_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.subject_migration_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.subject_migration_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.subject_migration_id_seq TO gok;


--
-- Name: TABLE subject_program_eligibility; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.subject_program_eligibility TO pg_database_owner;
GRANT ALL ON TABLE public.subject_program_eligibility TO openchs_impl;
GRANT ALL ON TABLE public.subject_program_eligibility TO gok;


--
-- Name: SEQUENCE subject_program_eligibility_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.subject_program_eligibility_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.subject_program_eligibility_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.subject_program_eligibility_id_seq TO gok;


--
-- Name: TABLE subject_type; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.subject_type TO pg_database_owner;
GRANT ALL ON TABLE public.subject_type TO openchs_impl;
GRANT ALL ON TABLE public.subject_type TO gok;


--
-- Name: SEQUENCE subject_type_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.subject_type_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.subject_type_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.subject_type_id_seq TO gok;


--
-- Name: TABLE sync_telemetry; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.sync_telemetry TO pg_database_owner;
GRANT ALL ON TABLE public.sync_telemetry TO openchs_impl;
GRANT ALL ON TABLE public.sync_telemetry TO gok;


--
-- Name: SEQUENCE sync_telemetry_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.sync_telemetry_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.sync_telemetry_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.sync_telemetry_id_seq TO gok;


--
-- Name: TABLE table_metadata; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.table_metadata TO pg_database_owner;
GRANT ALL ON TABLE public.table_metadata TO openchs_impl;
GRANT ALL ON TABLE public.table_metadata TO gok;


--
-- Name: SEQUENCE table_metadata_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.table_metadata_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.table_metadata_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.table_metadata_id_seq TO gok;


--
-- Name: TABLE task; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.task TO pg_database_owner;
GRANT ALL ON TABLE public.task TO openchs_impl;
GRANT ALL ON TABLE public.task TO gok;


--
-- Name: SEQUENCE task_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.task_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.task_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.task_id_seq TO gok;


--
-- Name: TABLE task_status; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.task_status TO pg_database_owner;
GRANT ALL ON TABLE public.task_status TO openchs_impl;
GRANT ALL ON TABLE public.task_status TO gok;


--
-- Name: SEQUENCE task_status_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.task_status_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.task_status_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.task_status_id_seq TO gok;


--
-- Name: TABLE task_type; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.task_type TO pg_database_owner;
GRANT ALL ON TABLE public.task_type TO openchs_impl;
GRANT ALL ON TABLE public.task_type TO gok;


--
-- Name: SEQUENCE task_type_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.task_type_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.task_type_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.task_type_id_seq TO gok;


--
-- Name: TABLE task_unassignment; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.task_unassignment TO pg_database_owner;
GRANT ALL ON TABLE public.task_unassignment TO openchs_impl;
GRANT ALL ON TABLE public.task_unassignment TO gok;


--
-- Name: SEQUENCE task_unassignment_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.task_unassignment_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.task_unassignment_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.task_unassignment_id_seq TO gok;


--
-- Name: TABLE title_lineage_locations_view; Type: ACL; Schema: public; Owner: openchs
--

GRANT SELECT ON TABLE public.title_lineage_locations_view TO pg_database_owner;
GRANT SELECT ON TABLE public.title_lineage_locations_view TO openchs_impl;
GRANT SELECT ON TABLE public.title_lineage_locations_view TO gok;


--
-- Name: TABLE translation; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.translation TO pg_database_owner;
GRANT ALL ON TABLE public.translation TO openchs_impl;
GRANT ALL ON TABLE public.translation TO gok;


--
-- Name: SEQUENCE translation_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.translation_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.translation_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.translation_id_seq TO gok;


--
-- Name: TABLE user_group; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.user_group TO pg_database_owner;
GRANT ALL ON TABLE public.user_group TO openchs_impl;
GRANT ALL ON TABLE public.user_group TO gok;


--
-- Name: SEQUENCE user_group_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.user_group_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.user_group_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.user_group_id_seq TO gok;


--
-- Name: TABLE user_subject_assignment; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.user_subject_assignment TO pg_database_owner;
GRANT ALL ON TABLE public.user_subject_assignment TO openchs_impl;
GRANT ALL ON TABLE public.user_subject_assignment TO gok;


--
-- Name: SEQUENCE user_subject_assignment_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.user_subject_assignment_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.user_subject_assignment_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.user_subject_assignment_id_seq TO gok;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.users TO pg_database_owner;
GRANT ALL ON TABLE public.users TO openchs_impl;
GRANT ALL ON TABLE public.users TO gok;


--
-- Name: SEQUENCE users_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.users_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.users_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.users_id_seq TO gok;


--
-- Name: TABLE video; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.video TO pg_database_owner;
GRANT ALL ON TABLE public.video TO openchs_impl;
GRANT ALL ON TABLE public.video TO gok;


--
-- Name: SEQUENCE video_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.video_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.video_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.video_id_seq TO gok;


--
-- Name: TABLE video_telemetric; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON TABLE public.video_telemetric TO pg_database_owner;
GRANT ALL ON TABLE public.video_telemetric TO openchs_impl;
GRANT ALL ON TABLE public.video_telemetric TO gok;


--
-- Name: SEQUENCE video_telemetric_id_seq; Type: ACL; Schema: public; Owner: openchs
--

GRANT ALL ON SEQUENCE public.video_telemetric_id_seq TO pg_database_owner;
GRANT ALL ON SEQUENCE public.video_telemetric_id_seq TO openchs_impl;
GRANT ALL ON SEQUENCE public.video_telemetric_id_seq TO gok;


--
-- Name: TABLE virtual_catchment_address_mapping_table; Type: ACL; Schema: public; Owner: openchs
--

GRANT SELECT ON TABLE public.virtual_catchment_address_mapping_table TO pg_database_owner;
GRANT SELECT ON TABLE public.virtual_catchment_address_mapping_table TO openchs_impl;
GRANT SELECT ON TABLE public.virtual_catchment_address_mapping_table TO gok;


--
-- PostgreSQL database dump complete
--

--
-- Database "postgres" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.3 (Debian 15.3-1.pgdg120+1)
-- Dumped by pg_dump version 15.3 (Debian 15.3-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database cluster dump complete
--

