--
-- PostgreSQL database dump
--

-- Dumped from database version 15.3 (Debian 15.3-1.pgdg120+1)
-- Dumped by pg_dump version 15.3 (Debian 15.3-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_event_entity; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.admin_event_entity (
    id character varying(36) NOT NULL,
    admin_event_time bigint,
    realm_id character varying(255),
    operation_type character varying(255),
    auth_realm_id character varying(255),
    auth_client_id character varying(255),
    auth_user_id character varying(255),
    ip_address character varying(255),
    resource_path character varying(2550),
    representation text,
    error character varying(255),
    resource_type character varying(64)
);


ALTER TABLE public.admin_event_entity OWNER TO keycloak;

--
-- Name: associated_policy; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.associated_policy (
    policy_id character varying(36) NOT NULL,
    associated_policy_id character varying(36) NOT NULL
);


ALTER TABLE public.associated_policy OWNER TO keycloak;

--
-- Name: authentication_execution; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.authentication_execution (
    id character varying(36) NOT NULL,
    alias character varying(255),
    authenticator character varying(36),
    realm_id character varying(36),
    flow_id character varying(36),
    requirement integer,
    priority integer,
    authenticator_flow boolean DEFAULT false NOT NULL,
    auth_flow_id character varying(36),
    auth_config character varying(36)
);


ALTER TABLE public.authentication_execution OWNER TO keycloak;

--
-- Name: authentication_flow; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.authentication_flow (
    id character varying(36) NOT NULL,
    alias character varying(255),
    description character varying(255),
    realm_id character varying(36),
    provider_id character varying(36) DEFAULT 'basic-flow'::character varying NOT NULL,
    top_level boolean DEFAULT false NOT NULL,
    built_in boolean DEFAULT false NOT NULL
);


ALTER TABLE public.authentication_flow OWNER TO keycloak;

--
-- Name: authenticator_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.authenticator_config (
    id character varying(36) NOT NULL,
    alias character varying(255),
    realm_id character varying(36)
);


ALTER TABLE public.authenticator_config OWNER TO keycloak;

--
-- Name: authenticator_config_entry; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.authenticator_config_entry (
    authenticator_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.authenticator_config_entry OWNER TO keycloak;

--
-- Name: broker_link; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.broker_link (
    identity_provider character varying(255) NOT NULL,
    storage_provider_id character varying(255),
    realm_id character varying(36) NOT NULL,
    broker_user_id character varying(255),
    broker_username character varying(255),
    token text,
    user_id character varying(255) NOT NULL
);


ALTER TABLE public.broker_link OWNER TO keycloak;

--
-- Name: client; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client (
    id character varying(36) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    full_scope_allowed boolean DEFAULT false NOT NULL,
    client_id character varying(255),
    not_before integer,
    public_client boolean DEFAULT false NOT NULL,
    secret character varying(255),
    base_url character varying(255),
    bearer_only boolean DEFAULT false NOT NULL,
    management_url character varying(255),
    surrogate_auth_required boolean DEFAULT false NOT NULL,
    realm_id character varying(36),
    protocol character varying(255),
    node_rereg_timeout integer DEFAULT 0,
    frontchannel_logout boolean DEFAULT false NOT NULL,
    consent_required boolean DEFAULT false NOT NULL,
    name character varying(255),
    service_accounts_enabled boolean DEFAULT false NOT NULL,
    client_authenticator_type character varying(255),
    root_url character varying(255),
    description character varying(255),
    registration_token character varying(255),
    standard_flow_enabled boolean DEFAULT true NOT NULL,
    implicit_flow_enabled boolean DEFAULT false NOT NULL,
    direct_access_grants_enabled boolean DEFAULT false NOT NULL,
    always_display_in_console boolean DEFAULT false NOT NULL
);


ALTER TABLE public.client OWNER TO keycloak;

--
-- Name: client_attributes; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_attributes (
    client_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


ALTER TABLE public.client_attributes OWNER TO keycloak;

--
-- Name: client_auth_flow_bindings; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_auth_flow_bindings (
    client_id character varying(36) NOT NULL,
    flow_id character varying(36),
    binding_name character varying(255) NOT NULL
);


ALTER TABLE public.client_auth_flow_bindings OWNER TO keycloak;

--
-- Name: client_initial_access; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_initial_access (
    id character varying(36) NOT NULL,
    realm_id character varying(36) NOT NULL,
    "timestamp" integer,
    expiration integer,
    count integer,
    remaining_count integer
);


ALTER TABLE public.client_initial_access OWNER TO keycloak;

--
-- Name: client_node_registrations; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_node_registrations (
    client_id character varying(36) NOT NULL,
    value integer,
    name character varying(255) NOT NULL
);


ALTER TABLE public.client_node_registrations OWNER TO keycloak;

--
-- Name: client_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_scope (
    id character varying(36) NOT NULL,
    name character varying(255),
    realm_id character varying(36),
    description character varying(255),
    protocol character varying(255)
);


ALTER TABLE public.client_scope OWNER TO keycloak;

--
-- Name: client_scope_attributes; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_scope_attributes (
    scope_id character varying(36) NOT NULL,
    value character varying(2048),
    name character varying(255) NOT NULL
);


ALTER TABLE public.client_scope_attributes OWNER TO keycloak;

--
-- Name: client_scope_client; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_scope_client (
    client_id character varying(255) NOT NULL,
    scope_id character varying(255) NOT NULL,
    default_scope boolean DEFAULT false NOT NULL
);


ALTER TABLE public.client_scope_client OWNER TO keycloak;

--
-- Name: client_scope_role_mapping; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_scope_role_mapping (
    scope_id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL
);


ALTER TABLE public.client_scope_role_mapping OWNER TO keycloak;

--
-- Name: client_session; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_session (
    id character varying(36) NOT NULL,
    client_id character varying(36),
    redirect_uri character varying(255),
    state character varying(255),
    "timestamp" integer,
    session_id character varying(36),
    auth_method character varying(255),
    realm_id character varying(255),
    auth_user_id character varying(36),
    current_action character varying(36)
);


ALTER TABLE public.client_session OWNER TO keycloak;

--
-- Name: client_session_auth_status; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_session_auth_status (
    authenticator character varying(36) NOT NULL,
    status integer,
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_session_auth_status OWNER TO keycloak;

--
-- Name: client_session_note; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_session_note (
    name character varying(255) NOT NULL,
    value character varying(255),
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_session_note OWNER TO keycloak;

--
-- Name: client_session_prot_mapper; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_session_prot_mapper (
    protocol_mapper_id character varying(36) NOT NULL,
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_session_prot_mapper OWNER TO keycloak;

--
-- Name: client_session_role; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_session_role (
    role_id character varying(255) NOT NULL,
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_session_role OWNER TO keycloak;

--
-- Name: client_user_session_note; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_user_session_note (
    name character varying(255) NOT NULL,
    value character varying(2048),
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_user_session_note OWNER TO keycloak;

--
-- Name: component; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.component (
    id character varying(36) NOT NULL,
    name character varying(255),
    parent_id character varying(36),
    provider_id character varying(36),
    provider_type character varying(255),
    realm_id character varying(36),
    sub_type character varying(255)
);


ALTER TABLE public.component OWNER TO keycloak;

--
-- Name: component_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.component_config (
    id character varying(36) NOT NULL,
    component_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(4000)
);


ALTER TABLE public.component_config OWNER TO keycloak;

--
-- Name: composite_role; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.composite_role (
    composite character varying(36) NOT NULL,
    child_role character varying(36) NOT NULL
);


ALTER TABLE public.composite_role OWNER TO keycloak;

--
-- Name: credential; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.credential (
    id character varying(36) NOT NULL,
    salt bytea,
    type character varying(255),
    user_id character varying(36),
    created_date bigint,
    user_label character varying(255),
    secret_data text,
    credential_data text,
    priority integer
);


ALTER TABLE public.credential OWNER TO keycloak;

--
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255),
    deployment_id character varying(10)
);


ALTER TABLE public.databasechangelog OWNER TO keycloak;

--
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE public.databasechangeloglock OWNER TO keycloak;

--
-- Name: default_client_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.default_client_scope (
    realm_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL,
    default_scope boolean DEFAULT false NOT NULL
);


ALTER TABLE public.default_client_scope OWNER TO keycloak;

--
-- Name: event_entity; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.event_entity (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    details_json character varying(2550),
    error character varying(255),
    ip_address character varying(255),
    realm_id character varying(255),
    session_id character varying(255),
    event_time bigint,
    type character varying(255),
    user_id character varying(255)
);


ALTER TABLE public.event_entity OWNER TO keycloak;

--
-- Name: fed_user_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_attribute (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    value character varying(2024)
);


ALTER TABLE public.fed_user_attribute OWNER TO keycloak;

--
-- Name: fed_user_consent; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_consent (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    created_date bigint,
    last_updated_date bigint,
    client_storage_provider character varying(36),
    external_client_id character varying(255)
);


ALTER TABLE public.fed_user_consent OWNER TO keycloak;

--
-- Name: fed_user_consent_cl_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_consent_cl_scope (
    user_consent_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.fed_user_consent_cl_scope OWNER TO keycloak;

--
-- Name: fed_user_credential; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_credential (
    id character varying(36) NOT NULL,
    salt bytea,
    type character varying(255),
    created_date bigint,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    user_label character varying(255),
    secret_data text,
    credential_data text,
    priority integer
);


ALTER TABLE public.fed_user_credential OWNER TO keycloak;

--
-- Name: fed_user_group_membership; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_group_membership (
    group_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_group_membership OWNER TO keycloak;

--
-- Name: fed_user_required_action; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_required_action (
    required_action character varying(255) DEFAULT ' '::character varying NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_required_action OWNER TO keycloak;

--
-- Name: fed_user_role_mapping; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_role_mapping (
    role_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_role_mapping OWNER TO keycloak;

--
-- Name: federated_identity; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.federated_identity (
    identity_provider character varying(255) NOT NULL,
    realm_id character varying(36),
    federated_user_id character varying(255),
    federated_username character varying(255),
    token text,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.federated_identity OWNER TO keycloak;

--
-- Name: federated_user; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.federated_user (
    id character varying(255) NOT NULL,
    storage_provider_id character varying(255),
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.federated_user OWNER TO keycloak;

--
-- Name: group_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.group_attribute (
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255),
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.group_attribute OWNER TO keycloak;

--
-- Name: group_role_mapping; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.group_role_mapping (
    role_id character varying(36) NOT NULL,
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.group_role_mapping OWNER TO keycloak;

--
-- Name: identity_provider; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.identity_provider (
    internal_id character varying(36) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    provider_alias character varying(255),
    provider_id character varying(255),
    store_token boolean DEFAULT false NOT NULL,
    authenticate_by_default boolean DEFAULT false NOT NULL,
    realm_id character varying(36),
    add_token_role boolean DEFAULT true NOT NULL,
    trust_email boolean DEFAULT false NOT NULL,
    first_broker_login_flow_id character varying(36),
    post_broker_login_flow_id character varying(36),
    provider_display_name character varying(255),
    link_only boolean DEFAULT false NOT NULL
);


ALTER TABLE public.identity_provider OWNER TO keycloak;

--
-- Name: identity_provider_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.identity_provider_config (
    identity_provider_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.identity_provider_config OWNER TO keycloak;

--
-- Name: identity_provider_mapper; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.identity_provider_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    idp_alias character varying(255) NOT NULL,
    idp_mapper_name character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.identity_provider_mapper OWNER TO keycloak;

--
-- Name: idp_mapper_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.idp_mapper_config (
    idp_mapper_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.idp_mapper_config OWNER TO keycloak;

--
-- Name: keycloak_group; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.keycloak_group (
    id character varying(36) NOT NULL,
    name character varying(255),
    parent_group character varying(36) NOT NULL,
    realm_id character varying(36)
);


ALTER TABLE public.keycloak_group OWNER TO keycloak;

--
-- Name: keycloak_role; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.keycloak_role (
    id character varying(36) NOT NULL,
    client_realm_constraint character varying(255),
    client_role boolean DEFAULT false NOT NULL,
    description character varying(255),
    name character varying(255),
    realm_id character varying(255),
    client character varying(36),
    realm character varying(36)
);


ALTER TABLE public.keycloak_role OWNER TO keycloak;

--
-- Name: migration_model; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.migration_model (
    id character varying(36) NOT NULL,
    version character varying(36),
    update_time bigint DEFAULT 0 NOT NULL
);


ALTER TABLE public.migration_model OWNER TO keycloak;

--
-- Name: offline_client_session; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.offline_client_session (
    user_session_id character varying(36) NOT NULL,
    client_id character varying(255) NOT NULL,
    offline_flag character varying(4) NOT NULL,
    "timestamp" integer,
    data text,
    client_storage_provider character varying(36) DEFAULT 'local'::character varying NOT NULL,
    external_client_id character varying(255) DEFAULT 'local'::character varying NOT NULL
);


ALTER TABLE public.offline_client_session OWNER TO keycloak;

--
-- Name: offline_user_session; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.offline_user_session (
    user_session_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    created_on integer NOT NULL,
    offline_flag character varying(4) NOT NULL,
    data text,
    last_session_refresh integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.offline_user_session OWNER TO keycloak;

--
-- Name: policy_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.policy_config (
    policy_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


ALTER TABLE public.policy_config OWNER TO keycloak;

--
-- Name: protocol_mapper; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.protocol_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    protocol character varying(255) NOT NULL,
    protocol_mapper_name character varying(255) NOT NULL,
    client_id character varying(36),
    client_scope_id character varying(36)
);


ALTER TABLE public.protocol_mapper OWNER TO keycloak;

--
-- Name: protocol_mapper_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.protocol_mapper_config (
    protocol_mapper_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.protocol_mapper_config OWNER TO keycloak;

--
-- Name: realm; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm (
    id character varying(36) NOT NULL,
    access_code_lifespan integer,
    user_action_lifespan integer,
    access_token_lifespan integer,
    account_theme character varying(255),
    admin_theme character varying(255),
    email_theme character varying(255),
    enabled boolean DEFAULT false NOT NULL,
    events_enabled boolean DEFAULT false NOT NULL,
    events_expiration bigint,
    login_theme character varying(255),
    name character varying(255),
    not_before integer,
    password_policy character varying(2550),
    registration_allowed boolean DEFAULT false NOT NULL,
    remember_me boolean DEFAULT false NOT NULL,
    reset_password_allowed boolean DEFAULT false NOT NULL,
    social boolean DEFAULT false NOT NULL,
    ssl_required character varying(255),
    sso_idle_timeout integer,
    sso_max_lifespan integer,
    update_profile_on_soc_login boolean DEFAULT false NOT NULL,
    verify_email boolean DEFAULT false NOT NULL,
    master_admin_client character varying(36),
    login_lifespan integer,
    internationalization_enabled boolean DEFAULT false NOT NULL,
    default_locale character varying(255),
    reg_email_as_username boolean DEFAULT false NOT NULL,
    admin_events_enabled boolean DEFAULT false NOT NULL,
    admin_events_details_enabled boolean DEFAULT false NOT NULL,
    edit_username_allowed boolean DEFAULT false NOT NULL,
    otp_policy_counter integer DEFAULT 0,
    otp_policy_window integer DEFAULT 1,
    otp_policy_period integer DEFAULT 30,
    otp_policy_digits integer DEFAULT 6,
    otp_policy_alg character varying(36) DEFAULT 'HmacSHA1'::character varying,
    otp_policy_type character varying(36) DEFAULT 'totp'::character varying,
    browser_flow character varying(36),
    registration_flow character varying(36),
    direct_grant_flow character varying(36),
    reset_credentials_flow character varying(36),
    client_auth_flow character varying(36),
    offline_session_idle_timeout integer DEFAULT 0,
    revoke_refresh_token boolean DEFAULT false NOT NULL,
    access_token_life_implicit integer DEFAULT 0,
    login_with_email_allowed boolean DEFAULT true NOT NULL,
    duplicate_emails_allowed boolean DEFAULT false NOT NULL,
    docker_auth_flow character varying(36),
    refresh_token_max_reuse integer DEFAULT 0,
    allow_user_managed_access boolean DEFAULT false NOT NULL,
    sso_max_lifespan_remember_me integer DEFAULT 0 NOT NULL,
    sso_idle_timeout_remember_me integer DEFAULT 0 NOT NULL,
    default_role character varying(255)
);


ALTER TABLE public.realm OWNER TO keycloak;

--
-- Name: realm_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_attribute (
    name character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    value text
);


ALTER TABLE public.realm_attribute OWNER TO keycloak;

--
-- Name: realm_default_groups; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_default_groups (
    realm_id character varying(36) NOT NULL,
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.realm_default_groups OWNER TO keycloak;

--
-- Name: realm_enabled_event_types; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_enabled_event_types (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_enabled_event_types OWNER TO keycloak;

--
-- Name: realm_events_listeners; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_events_listeners (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_events_listeners OWNER TO keycloak;

--
-- Name: realm_localizations; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_localizations (
    realm_id character varying(255) NOT NULL,
    locale character varying(255) NOT NULL,
    texts text NOT NULL
);


ALTER TABLE public.realm_localizations OWNER TO keycloak;

--
-- Name: realm_required_credential; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_required_credential (
    type character varying(255) NOT NULL,
    form_label character varying(255),
    input boolean DEFAULT false NOT NULL,
    secret boolean DEFAULT false NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.realm_required_credential OWNER TO keycloak;

--
-- Name: realm_smtp_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_smtp_config (
    realm_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.realm_smtp_config OWNER TO keycloak;

--
-- Name: realm_supported_locales; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_supported_locales (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_supported_locales OWNER TO keycloak;

--
-- Name: redirect_uris; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.redirect_uris (
    client_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.redirect_uris OWNER TO keycloak;

--
-- Name: required_action_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.required_action_config (
    required_action_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.required_action_config OWNER TO keycloak;

--
-- Name: required_action_provider; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.required_action_provider (
    id character varying(36) NOT NULL,
    alias character varying(255),
    name character varying(255),
    realm_id character varying(36),
    enabled boolean DEFAULT false NOT NULL,
    default_action boolean DEFAULT false NOT NULL,
    provider_id character varying(255),
    priority integer
);


ALTER TABLE public.required_action_provider OWNER TO keycloak;

--
-- Name: resource_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_attribute (
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255),
    resource_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_attribute OWNER TO keycloak;

--
-- Name: resource_policy; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_policy (
    resource_id character varying(36) NOT NULL,
    policy_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_policy OWNER TO keycloak;

--
-- Name: resource_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_scope (
    resource_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_scope OWNER TO keycloak;

--
-- Name: resource_server; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_server (
    id character varying(36) NOT NULL,
    allow_rs_remote_mgmt boolean DEFAULT false NOT NULL,
    policy_enforce_mode character varying(15) NOT NULL,
    decision_strategy smallint DEFAULT 1 NOT NULL
);


ALTER TABLE public.resource_server OWNER TO keycloak;

--
-- Name: resource_server_perm_ticket; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_server_perm_ticket (
    id character varying(36) NOT NULL,
    owner character varying(255) NOT NULL,
    requester character varying(255) NOT NULL,
    created_timestamp bigint NOT NULL,
    granted_timestamp bigint,
    resource_id character varying(36) NOT NULL,
    scope_id character varying(36),
    resource_server_id character varying(36) NOT NULL,
    policy_id character varying(36)
);


ALTER TABLE public.resource_server_perm_ticket OWNER TO keycloak;

--
-- Name: resource_server_policy; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_server_policy (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    type character varying(255) NOT NULL,
    decision_strategy character varying(20),
    logic character varying(20),
    resource_server_id character varying(36) NOT NULL,
    owner character varying(255)
);


ALTER TABLE public.resource_server_policy OWNER TO keycloak;

--
-- Name: resource_server_resource; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_server_resource (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(255),
    icon_uri character varying(255),
    owner character varying(255) NOT NULL,
    resource_server_id character varying(36) NOT NULL,
    owner_managed_access boolean DEFAULT false NOT NULL,
    display_name character varying(255)
);


ALTER TABLE public.resource_server_resource OWNER TO keycloak;

--
-- Name: resource_server_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_server_scope (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    icon_uri character varying(255),
    resource_server_id character varying(36) NOT NULL,
    display_name character varying(255)
);


ALTER TABLE public.resource_server_scope OWNER TO keycloak;

--
-- Name: resource_uris; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_uris (
    resource_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.resource_uris OWNER TO keycloak;

--
-- Name: role_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.role_attribute (
    id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255)
);


ALTER TABLE public.role_attribute OWNER TO keycloak;

--
-- Name: scope_mapping; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.scope_mapping (
    client_id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL
);


ALTER TABLE public.scope_mapping OWNER TO keycloak;

--
-- Name: scope_policy; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.scope_policy (
    scope_id character varying(36) NOT NULL,
    policy_id character varying(36) NOT NULL
);


ALTER TABLE public.scope_policy OWNER TO keycloak;

--
-- Name: user_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_attribute (
    name character varying(255) NOT NULL,
    value character varying(255),
    user_id character varying(36) NOT NULL,
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL
);


ALTER TABLE public.user_attribute OWNER TO keycloak;

--
-- Name: user_consent; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_consent (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    user_id character varying(36) NOT NULL,
    created_date bigint,
    last_updated_date bigint,
    client_storage_provider character varying(36),
    external_client_id character varying(255)
);


ALTER TABLE public.user_consent OWNER TO keycloak;

--
-- Name: user_consent_client_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_consent_client_scope (
    user_consent_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.user_consent_client_scope OWNER TO keycloak;

--
-- Name: user_entity; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_entity (
    id character varying(36) NOT NULL,
    email character varying(255),
    email_constraint character varying(255),
    email_verified boolean DEFAULT false NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    federation_link character varying(255),
    first_name character varying(255),
    last_name character varying(255),
    realm_id character varying(255),
    username character varying(255),
    created_timestamp bigint,
    service_account_client_link character varying(255),
    not_before integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.user_entity OWNER TO keycloak;

--
-- Name: user_federation_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_federation_config (
    user_federation_provider_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.user_federation_config OWNER TO keycloak;

--
-- Name: user_federation_mapper; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_federation_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    federation_provider_id character varying(36) NOT NULL,
    federation_mapper_type character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.user_federation_mapper OWNER TO keycloak;

--
-- Name: user_federation_mapper_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_federation_mapper_config (
    user_federation_mapper_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.user_federation_mapper_config OWNER TO keycloak;

--
-- Name: user_federation_provider; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_federation_provider (
    id character varying(36) NOT NULL,
    changed_sync_period integer,
    display_name character varying(255),
    full_sync_period integer,
    last_sync integer,
    priority integer,
    provider_name character varying(255),
    realm_id character varying(36)
);


ALTER TABLE public.user_federation_provider OWNER TO keycloak;

--
-- Name: user_group_membership; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_group_membership (
    group_id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.user_group_membership OWNER TO keycloak;

--
-- Name: user_required_action; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_required_action (
    user_id character varying(36) NOT NULL,
    required_action character varying(255) DEFAULT ' '::character varying NOT NULL
);


ALTER TABLE public.user_required_action OWNER TO keycloak;

--
-- Name: user_role_mapping; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_role_mapping (
    role_id character varying(255) NOT NULL,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.user_role_mapping OWNER TO keycloak;

--
-- Name: user_session; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_session (
    id character varying(36) NOT NULL,
    auth_method character varying(255),
    ip_address character varying(255),
    last_session_refresh integer,
    login_username character varying(255),
    realm_id character varying(255),
    remember_me boolean DEFAULT false NOT NULL,
    started integer,
    user_id character varying(255),
    user_session_state integer,
    broker_session_id character varying(255),
    broker_user_id character varying(255)
);


ALTER TABLE public.user_session OWNER TO keycloak;

--
-- Name: user_session_note; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_session_note (
    user_session character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(2048)
);


ALTER TABLE public.user_session_note OWNER TO keycloak;

--
-- Name: username_login_failure; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.username_login_failure (
    realm_id character varying(36) NOT NULL,
    username character varying(255) NOT NULL,
    failed_login_not_before integer,
    last_failure bigint,
    last_ip_failure character varying(255),
    num_failures integer
);


ALTER TABLE public.username_login_failure OWNER TO keycloak;

--
-- Name: web_origins; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.web_origins (
    client_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.web_origins OWNER TO keycloak;

--
-- Data for Name: admin_event_entity; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.admin_event_entity (id, admin_event_time, realm_id, operation_type, auth_realm_id, auth_client_id, auth_user_id, ip_address, resource_path, representation, error, resource_type) FROM stdin;
\.


--
-- Data for Name: associated_policy; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.associated_policy (policy_id, associated_policy_id) FROM stdin;
\.


--
-- Data for Name: authentication_execution; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.authentication_execution (id, alias, authenticator, realm_id, flow_id, requirement, priority, authenticator_flow, auth_flow_id, auth_config) FROM stdin;
adf65d55-7856-46b1-91e0-f89d956d3d0f	\N	auth-cookie	091121bd-5b90-4312-8e4f-1be85be87c5c	68ee5cbd-ef49-4923-b982-914a3410fd1c	2	10	f	\N	\N
47e677f7-f34d-42a5-a43e-65f744c6072e	\N	auth-spnego	091121bd-5b90-4312-8e4f-1be85be87c5c	68ee5cbd-ef49-4923-b982-914a3410fd1c	3	20	f	\N	\N
892a6ac7-e3cf-4593-bc8a-e151bd64dedd	\N	identity-provider-redirector	091121bd-5b90-4312-8e4f-1be85be87c5c	68ee5cbd-ef49-4923-b982-914a3410fd1c	2	25	f	\N	\N
ed326c45-1b88-4f38-ba38-cb2bbb643454	\N	\N	091121bd-5b90-4312-8e4f-1be85be87c5c	68ee5cbd-ef49-4923-b982-914a3410fd1c	2	30	t	c2ee40cc-6c8f-4b15-932b-ed8e055d4a5e	\N
b4cba1ed-fe45-42b5-88a1-a06e7ed82126	\N	auth-username-password-form	091121bd-5b90-4312-8e4f-1be85be87c5c	c2ee40cc-6c8f-4b15-932b-ed8e055d4a5e	0	10	f	\N	\N
30927cbf-5b41-41b0-af61-6f9591fbcece	\N	\N	091121bd-5b90-4312-8e4f-1be85be87c5c	c2ee40cc-6c8f-4b15-932b-ed8e055d4a5e	1	20	t	fd798671-a035-49f8-819a-8beca9addc0c	\N
f5a58bb8-ef57-4b24-95d1-041deaecb308	\N	conditional-user-configured	091121bd-5b90-4312-8e4f-1be85be87c5c	fd798671-a035-49f8-819a-8beca9addc0c	0	10	f	\N	\N
f8aac248-7b0b-4729-a814-6c00f4ac91a9	\N	auth-otp-form	091121bd-5b90-4312-8e4f-1be85be87c5c	fd798671-a035-49f8-819a-8beca9addc0c	0	20	f	\N	\N
748dfe88-da37-4cb4-85fd-7f5531f11c3c	\N	direct-grant-validate-username	091121bd-5b90-4312-8e4f-1be85be87c5c	3e78fade-907d-4d90-9390-20f00ed9c19c	0	10	f	\N	\N
0bb8c9d0-1146-473e-b1cf-52413ddb146a	\N	direct-grant-validate-password	091121bd-5b90-4312-8e4f-1be85be87c5c	3e78fade-907d-4d90-9390-20f00ed9c19c	0	20	f	\N	\N
2d466741-4ead-4728-8229-b61930a08d17	\N	\N	091121bd-5b90-4312-8e4f-1be85be87c5c	3e78fade-907d-4d90-9390-20f00ed9c19c	1	30	t	59697a66-9741-415f-b293-f42e57e17cad	\N
0c5ea8fd-1440-4d0f-9b20-2d145d3a2646	\N	conditional-user-configured	091121bd-5b90-4312-8e4f-1be85be87c5c	59697a66-9741-415f-b293-f42e57e17cad	0	10	f	\N	\N
893bf3b8-81cf-46da-8b09-6d755aec75d0	\N	direct-grant-validate-otp	091121bd-5b90-4312-8e4f-1be85be87c5c	59697a66-9741-415f-b293-f42e57e17cad	0	20	f	\N	\N
3d869ee9-d803-4e3d-ba2a-a8bfde276fcd	\N	registration-page-form	091121bd-5b90-4312-8e4f-1be85be87c5c	99ca4bdc-2b5e-492e-856a-fae45fad14f5	0	10	t	a3bedf35-ec71-4372-a94b-c57bd79a2a8a	\N
60169dfb-f4b0-4d9b-99fe-ce046574aa03	\N	registration-user-creation	091121bd-5b90-4312-8e4f-1be85be87c5c	a3bedf35-ec71-4372-a94b-c57bd79a2a8a	0	20	f	\N	\N
6e16aa4c-d7c4-41b0-b45f-fe38725ebcd4	\N	registration-profile-action	091121bd-5b90-4312-8e4f-1be85be87c5c	a3bedf35-ec71-4372-a94b-c57bd79a2a8a	0	40	f	\N	\N
54207f32-c187-4ba7-807c-90d56f3cbd9a	\N	registration-password-action	091121bd-5b90-4312-8e4f-1be85be87c5c	a3bedf35-ec71-4372-a94b-c57bd79a2a8a	0	50	f	\N	\N
a8b7e2ea-aefb-4403-bc0f-8941856e68dd	\N	registration-recaptcha-action	091121bd-5b90-4312-8e4f-1be85be87c5c	a3bedf35-ec71-4372-a94b-c57bd79a2a8a	3	60	f	\N	\N
6a5c2d6d-1092-40c1-9692-9b44422a257b	\N	reset-credentials-choose-user	091121bd-5b90-4312-8e4f-1be85be87c5c	2d4b185b-41a4-4ff9-9ecf-2326e0f7fcdb	0	10	f	\N	\N
348c5fa0-31fe-4c24-a319-d6c8ca44baba	\N	reset-credential-email	091121bd-5b90-4312-8e4f-1be85be87c5c	2d4b185b-41a4-4ff9-9ecf-2326e0f7fcdb	0	20	f	\N	\N
bd21fe7a-78e7-4b8b-8793-586ff33a602a	\N	reset-password	091121bd-5b90-4312-8e4f-1be85be87c5c	2d4b185b-41a4-4ff9-9ecf-2326e0f7fcdb	0	30	f	\N	\N
56ce1c50-c375-419d-9f21-ceb59cd4ddef	\N	\N	091121bd-5b90-4312-8e4f-1be85be87c5c	2d4b185b-41a4-4ff9-9ecf-2326e0f7fcdb	1	40	t	1181fd3a-0005-45b0-8ca0-be5bf39bb008	\N
0da1cda2-2c5d-41c4-9665-86736ba29004	\N	conditional-user-configured	091121bd-5b90-4312-8e4f-1be85be87c5c	1181fd3a-0005-45b0-8ca0-be5bf39bb008	0	10	f	\N	\N
109af7a4-30fd-40f1-af24-e47f8a7070e2	\N	reset-otp	091121bd-5b90-4312-8e4f-1be85be87c5c	1181fd3a-0005-45b0-8ca0-be5bf39bb008	0	20	f	\N	\N
07bdf85e-cc23-4503-bcf9-4c40600dd545	\N	client-secret	091121bd-5b90-4312-8e4f-1be85be87c5c	88bc3fe8-de3e-4d10-a51c-2d76b8b74e89	2	10	f	\N	\N
fa296ffa-09ec-4309-b0de-01ea1cb5efe8	\N	client-jwt	091121bd-5b90-4312-8e4f-1be85be87c5c	88bc3fe8-de3e-4d10-a51c-2d76b8b74e89	2	20	f	\N	\N
7a181cb0-e04d-4dd5-9235-d90da34072d7	\N	client-secret-jwt	091121bd-5b90-4312-8e4f-1be85be87c5c	88bc3fe8-de3e-4d10-a51c-2d76b8b74e89	2	30	f	\N	\N
670dd9ae-3976-4138-8068-0d2a297f7969	\N	client-x509	091121bd-5b90-4312-8e4f-1be85be87c5c	88bc3fe8-de3e-4d10-a51c-2d76b8b74e89	2	40	f	\N	\N
ecda0749-ef5e-4c49-938a-c6fbfdfb9ccd	\N	idp-review-profile	091121bd-5b90-4312-8e4f-1be85be87c5c	8fea41f3-1147-4469-a55f-1b36ef859cd5	0	10	f	\N	479bf758-4e37-437f-8fac-84830db7404c
47a69dbf-85de-45d0-a40e-d171d0829acd	\N	\N	091121bd-5b90-4312-8e4f-1be85be87c5c	8fea41f3-1147-4469-a55f-1b36ef859cd5	0	20	t	588b89e8-4e41-478e-917e-e972636b318a	\N
5b143da6-4d44-4e81-a54c-2ba59bfb008e	\N	idp-create-user-if-unique	091121bd-5b90-4312-8e4f-1be85be87c5c	588b89e8-4e41-478e-917e-e972636b318a	2	10	f	\N	9b50bbd7-1b09-4ae8-8d69-af49ca0b8fbd
831cd48c-26ff-4945-b860-9f93bb6168c7	\N	\N	091121bd-5b90-4312-8e4f-1be85be87c5c	588b89e8-4e41-478e-917e-e972636b318a	2	20	t	534b7361-c9d3-477a-ad27-efd7ca3cf151	\N
9c93c97c-ff55-4593-a8ca-68552fc7b084	\N	idp-confirm-link	091121bd-5b90-4312-8e4f-1be85be87c5c	534b7361-c9d3-477a-ad27-efd7ca3cf151	0	10	f	\N	\N
380b5af8-3123-4fdd-a5d3-1cdb67e34a0d	\N	\N	091121bd-5b90-4312-8e4f-1be85be87c5c	534b7361-c9d3-477a-ad27-efd7ca3cf151	0	20	t	836b7cf9-2e82-412f-bbac-6a514d948d94	\N
491848ec-9009-4836-bac6-d049f54c06c5	\N	idp-email-verification	091121bd-5b90-4312-8e4f-1be85be87c5c	836b7cf9-2e82-412f-bbac-6a514d948d94	2	10	f	\N	\N
ab157d04-2322-4636-adea-eaf3f077047d	\N	\N	091121bd-5b90-4312-8e4f-1be85be87c5c	836b7cf9-2e82-412f-bbac-6a514d948d94	2	20	t	196ad400-99e8-4348-8a51-2fadf7c54a35	\N
8b071514-6e97-4abb-a6f8-c6eab22452f6	\N	idp-username-password-form	091121bd-5b90-4312-8e4f-1be85be87c5c	196ad400-99e8-4348-8a51-2fadf7c54a35	0	10	f	\N	\N
3dc8178b-b09c-4f15-b357-0d8d453490c5	\N	\N	091121bd-5b90-4312-8e4f-1be85be87c5c	196ad400-99e8-4348-8a51-2fadf7c54a35	1	20	t	0721c2f5-b3a6-4ab9-9552-330f4e73cfd4	\N
ec233c50-0709-4e77-848d-248977a8458a	\N	conditional-user-configured	091121bd-5b90-4312-8e4f-1be85be87c5c	0721c2f5-b3a6-4ab9-9552-330f4e73cfd4	0	10	f	\N	\N
d2e931d2-b758-4526-b052-78b84d160a2e	\N	auth-otp-form	091121bd-5b90-4312-8e4f-1be85be87c5c	0721c2f5-b3a6-4ab9-9552-330f4e73cfd4	0	20	f	\N	\N
c5f962bb-f00c-4a91-8286-3d007c31e013	\N	http-basic-authenticator	091121bd-5b90-4312-8e4f-1be85be87c5c	ff3fc9cb-ac00-4cba-9579-c4b526b4e24f	0	10	f	\N	\N
f9e77e2f-5585-45ec-87d8-6714c0bae3df	\N	docker-http-basic-authenticator	091121bd-5b90-4312-8e4f-1be85be87c5c	196847b3-ff4b-411e-b4d4-3a9ed856b024	0	10	f	\N	\N
e68aa037-a967-4f7c-9aef-1ce24a5bcce0	\N	no-cookie-redirect	091121bd-5b90-4312-8e4f-1be85be87c5c	ff308753-36fb-4131-8076-405354fc6bbb	0	10	f	\N	\N
d39c77e1-88e4-4a85-a94a-6c51acdefe4c	\N	\N	091121bd-5b90-4312-8e4f-1be85be87c5c	ff308753-36fb-4131-8076-405354fc6bbb	0	20	t	3d9ac357-d9fd-495e-80dc-8e6a554b056c	\N
11240e35-8cc5-40a9-ada3-b58081d022b4	\N	basic-auth	091121bd-5b90-4312-8e4f-1be85be87c5c	3d9ac357-d9fd-495e-80dc-8e6a554b056c	0	10	f	\N	\N
9770afa7-a992-4632-937c-ad106c64cfe0	\N	basic-auth-otp	091121bd-5b90-4312-8e4f-1be85be87c5c	3d9ac357-d9fd-495e-80dc-8e6a554b056c	3	20	f	\N	\N
2b1f8f24-f0e3-4a0f-b105-e3458cffb22c	\N	auth-spnego	091121bd-5b90-4312-8e4f-1be85be87c5c	3d9ac357-d9fd-495e-80dc-8e6a554b056c	3	30	f	\N	\N
17d7a8db-1ef7-4422-b0dc-95354e5b552b	\N	idp-email-verification	On-premise	6742d112-c9fb-474c-b777-60c9d5152026	2	10	f	\N	\N
95764083-78c9-4ddc-94de-6b84bc9aab79	\N	\N	On-premise	6742d112-c9fb-474c-b777-60c9d5152026	2	20	t	110d8832-3a2d-4384-bcb2-57d11cb78d68	\N
e16d23e4-dc69-4112-b819-894f8d0ed580	\N	basic-auth	On-premise	6dbf4510-3b25-4d74-a82d-b2106937a18f	0	10	f	\N	\N
10f6f067-ea0a-4332-a867-a9918bfb3ef9	\N	basic-auth-otp	On-premise	6dbf4510-3b25-4d74-a82d-b2106937a18f	3	20	f	\N	\N
9ed250df-1b1f-4e07-86dd-985036038372	\N	auth-spnego	On-premise	6dbf4510-3b25-4d74-a82d-b2106937a18f	3	30	f	\N	\N
d37b11a0-85c5-458e-9f9f-72398e94e5de	\N	conditional-user-configured	On-premise	45a4cd63-386e-4b38-8922-3369d9d2d351	0	10	f	\N	\N
b5849d18-9fa0-4ab5-bfdc-ddb68a653a3f	\N	auth-otp-form	On-premise	45a4cd63-386e-4b38-8922-3369d9d2d351	0	20	f	\N	\N
9b01bd38-484f-4849-99ed-2314e8a2d4e1	\N	conditional-user-configured	On-premise	b17f233b-4f23-4c20-8bcb-8848e2cca065	0	10	f	\N	\N
f5ee286e-89f4-470f-a15b-9529aab3f464	\N	direct-grant-validate-otp	On-premise	b17f233b-4f23-4c20-8bcb-8848e2cca065	0	20	f	\N	\N
e203615e-87c3-4f73-bda0-417e8d4cfcba	\N	conditional-user-configured	On-premise	ac24292d-8055-4ac6-8a00-48c5f4b6b0eb	0	10	f	\N	\N
882245c7-902c-47b6-8288-4d92c6b3dc53	\N	auth-otp-form	On-premise	ac24292d-8055-4ac6-8a00-48c5f4b6b0eb	0	20	f	\N	\N
743d4885-6ece-421c-b5a0-f93f3b182712	\N	idp-confirm-link	On-premise	b19adc30-119b-41ea-91d0-b5f8f7ef2c6f	0	10	f	\N	\N
6b30d3e0-ba09-40c4-94bb-d33e670e3a72	\N	\N	On-premise	b19adc30-119b-41ea-91d0-b5f8f7ef2c6f	0	20	t	6742d112-c9fb-474c-b777-60c9d5152026	\N
d908016e-92e0-47f6-a8c9-a690d12e9c18	\N	conditional-user-configured	On-premise	d8551231-831e-47d7-99e0-07ca5059f450	0	10	f	\N	\N
a2a9a50e-981b-4af7-8044-320a9db960d5	\N	reset-otp	On-premise	d8551231-831e-47d7-99e0-07ca5059f450	0	20	f	\N	\N
0aef4f7e-d23c-4e71-a738-62eee8b98677	\N	idp-create-user-if-unique	On-premise	166c462e-8a08-4db2-b969-b8e85d43d0ec	2	10	f	\N	d47b74ae-0627-42bf-9ba2-0f23e838700d
209b8b55-b69c-41dd-b503-7cf1bc5d3499	\N	\N	On-premise	166c462e-8a08-4db2-b969-b8e85d43d0ec	2	20	t	b19adc30-119b-41ea-91d0-b5f8f7ef2c6f	\N
046a69f7-b8ed-4758-9e25-dcdc856c0dc6	\N	idp-username-password-form	On-premise	110d8832-3a2d-4384-bcb2-57d11cb78d68	0	10	f	\N	\N
6ebf0fdd-fb05-48fb-a8c0-ebdfe2dc1eb4	\N	\N	On-premise	110d8832-3a2d-4384-bcb2-57d11cb78d68	1	20	t	ac24292d-8055-4ac6-8a00-48c5f4b6b0eb	\N
dccbf377-5c7d-4f46-ae0f-49fb8210232b	\N	auth-cookie	On-premise	c2707c8a-a5b6-4e78-add6-808d7ec5e428	2	10	f	\N	\N
e4df1dfd-b786-4eac-aa11-db693a7eb567	\N	auth-spnego	On-premise	c2707c8a-a5b6-4e78-add6-808d7ec5e428	3	20	f	\N	\N
b57ceadd-3154-4999-bfa7-fdac0f024274	\N	identity-provider-redirector	On-premise	c2707c8a-a5b6-4e78-add6-808d7ec5e428	2	25	f	\N	\N
47ba70f1-5b8b-45f5-a29b-e749a0ebdc5c	\N	\N	On-premise	c2707c8a-a5b6-4e78-add6-808d7ec5e428	2	30	t	17a4dc7b-9b2b-4f0a-94fe-ed0b258a44b0	\N
6876d61d-5fe9-40de-8eb7-fabea750b547	\N	client-secret	On-premise	5a2ea00b-95ef-4f39-a09a-9412954bbf6c	2	10	f	\N	\N
47b3d2bf-d86c-4242-aa2e-5549156a852b	\N	client-jwt	On-premise	5a2ea00b-95ef-4f39-a09a-9412954bbf6c	2	20	f	\N	\N
d646766f-4ed2-470d-8b23-9cb23362c978	\N	client-secret-jwt	On-premise	5a2ea00b-95ef-4f39-a09a-9412954bbf6c	2	30	f	\N	\N
85c2a600-bf13-4930-a5e8-77352c1e98fb	\N	client-x509	On-premise	5a2ea00b-95ef-4f39-a09a-9412954bbf6c	2	40	f	\N	\N
591afa6c-eb9c-4500-a925-cf2a3c060741	\N	direct-grant-validate-username	On-premise	36ef8c4c-7c54-40e2-b207-fec6f3658272	0	10	f	\N	\N
7169e000-3632-412e-80b0-9510a74376fb	\N	direct-grant-validate-password	On-premise	36ef8c4c-7c54-40e2-b207-fec6f3658272	0	20	f	\N	\N
17fdf5f1-9331-44f2-a0a0-adb57a3d96a4	\N	\N	On-premise	36ef8c4c-7c54-40e2-b207-fec6f3658272	1	30	t	b17f233b-4f23-4c20-8bcb-8848e2cca065	\N
9358b419-6d2d-438a-9c27-d8f2939efa85	\N	docker-http-basic-authenticator	On-premise	dfa7479a-057e-4c43-babb-f7a666d89af6	0	10	f	\N	\N
47985ec4-b322-4747-908f-753ab5fd6d8e	\N	idp-review-profile	On-premise	a0668911-5cde-4dea-a7d9-539a39037f1a	0	10	f	\N	c6c23214-3dea-40e2-ac85-d2e8b1a8a5bc
f05cb34d-09bc-43e3-93c7-b43e914e0dce	\N	\N	On-premise	a0668911-5cde-4dea-a7d9-539a39037f1a	0	20	t	166c462e-8a08-4db2-b969-b8e85d43d0ec	\N
9f5a8d7b-af55-4f43-aa39-f81d358f95e8	\N	auth-username-password-form	On-premise	17a4dc7b-9b2b-4f0a-94fe-ed0b258a44b0	0	10	f	\N	\N
d096452b-de65-482e-a6cc-7cbda90720e2	\N	\N	On-premise	17a4dc7b-9b2b-4f0a-94fe-ed0b258a44b0	1	20	t	45a4cd63-386e-4b38-8922-3369d9d2d351	\N
c0be0b00-55ef-46b7-8340-f68bfdf6605d	\N	no-cookie-redirect	On-premise	c0500008-463c-4fee-9cc6-e1e6428e9ec8	0	10	f	\N	\N
7cd29480-e548-4bc9-8ef0-ca3f11a5ea22	\N	\N	On-premise	c0500008-463c-4fee-9cc6-e1e6428e9ec8	0	20	t	6dbf4510-3b25-4d74-a82d-b2106937a18f	\N
3662a0fd-40a7-4a74-8afd-d2071bb09537	\N	registration-page-form	On-premise	24eebbdf-6ebd-4241-8232-436e878fe1d0	0	10	t	cbcce7af-8f51-48aa-9f84-663f88266aa3	\N
64a7ed95-d66e-4ef1-8a01-09fa0d9872f9	\N	registration-user-creation	On-premise	cbcce7af-8f51-48aa-9f84-663f88266aa3	0	20	f	\N	\N
762d6582-1dc5-494b-aa9d-23175d464c82	\N	registration-profile-action	On-premise	cbcce7af-8f51-48aa-9f84-663f88266aa3	0	40	f	\N	\N
d5316cb7-a62b-44b0-8aa2-77ad6e4d188b	\N	registration-password-action	On-premise	cbcce7af-8f51-48aa-9f84-663f88266aa3	0	50	f	\N	\N
47f008c7-616f-4685-961c-5ca02e3d564a	\N	registration-recaptcha-action	On-premise	cbcce7af-8f51-48aa-9f84-663f88266aa3	3	60	f	\N	\N
8527abe2-c75b-4dac-b62d-2ae62442307d	\N	reset-credentials-choose-user	On-premise	5237249c-cf5b-4411-bc6c-cecbc5f19eb1	0	10	f	\N	\N
956f8072-6c17-4b76-9533-c5f43565467c	\N	reset-credential-email	On-premise	5237249c-cf5b-4411-bc6c-cecbc5f19eb1	0	20	f	\N	\N
f6171ea3-1d5a-4fbb-a0ff-056a0693863f	\N	reset-password	On-premise	5237249c-cf5b-4411-bc6c-cecbc5f19eb1	0	30	f	\N	\N
9dcd2f72-1322-4802-ab21-d44233052c72	\N	\N	On-premise	5237249c-cf5b-4411-bc6c-cecbc5f19eb1	1	40	t	d8551231-831e-47d7-99e0-07ca5059f450	\N
dfe8d519-7d21-4842-8251-e7c5eb4df740	\N	http-basic-authenticator	On-premise	b60dc404-252c-412c-8c5c-4521fc1f59bd	0	10	f	\N	\N
\.


--
-- Data for Name: authentication_flow; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.authentication_flow (id, alias, description, realm_id, provider_id, top_level, built_in) FROM stdin;
68ee5cbd-ef49-4923-b982-914a3410fd1c	browser	browser based authentication	091121bd-5b90-4312-8e4f-1be85be87c5c	basic-flow	t	t
c2ee40cc-6c8f-4b15-932b-ed8e055d4a5e	forms	Username, password, otp and other auth forms.	091121bd-5b90-4312-8e4f-1be85be87c5c	basic-flow	f	t
fd798671-a035-49f8-819a-8beca9addc0c	Browser - Conditional OTP	Flow to determine if the OTP is required for the authentication	091121bd-5b90-4312-8e4f-1be85be87c5c	basic-flow	f	t
3e78fade-907d-4d90-9390-20f00ed9c19c	direct grant	OpenID Connect Resource Owner Grant	091121bd-5b90-4312-8e4f-1be85be87c5c	basic-flow	t	t
59697a66-9741-415f-b293-f42e57e17cad	Direct Grant - Conditional OTP	Flow to determine if the OTP is required for the authentication	091121bd-5b90-4312-8e4f-1be85be87c5c	basic-flow	f	t
99ca4bdc-2b5e-492e-856a-fae45fad14f5	registration	registration flow	091121bd-5b90-4312-8e4f-1be85be87c5c	basic-flow	t	t
a3bedf35-ec71-4372-a94b-c57bd79a2a8a	registration form	registration form	091121bd-5b90-4312-8e4f-1be85be87c5c	form-flow	f	t
2d4b185b-41a4-4ff9-9ecf-2326e0f7fcdb	reset credentials	Reset credentials for a user if they forgot their password or something	091121bd-5b90-4312-8e4f-1be85be87c5c	basic-flow	t	t
1181fd3a-0005-45b0-8ca0-be5bf39bb008	Reset - Conditional OTP	Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.	091121bd-5b90-4312-8e4f-1be85be87c5c	basic-flow	f	t
88bc3fe8-de3e-4d10-a51c-2d76b8b74e89	clients	Base authentication for clients	091121bd-5b90-4312-8e4f-1be85be87c5c	client-flow	t	t
8fea41f3-1147-4469-a55f-1b36ef859cd5	first broker login	Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account	091121bd-5b90-4312-8e4f-1be85be87c5c	basic-flow	t	t
588b89e8-4e41-478e-917e-e972636b318a	User creation or linking	Flow for the existing/non-existing user alternatives	091121bd-5b90-4312-8e4f-1be85be87c5c	basic-flow	f	t
534b7361-c9d3-477a-ad27-efd7ca3cf151	Handle Existing Account	Handle what to do if there is existing account with same email/username like authenticated identity provider	091121bd-5b90-4312-8e4f-1be85be87c5c	basic-flow	f	t
836b7cf9-2e82-412f-bbac-6a514d948d94	Account verification options	Method with which to verity the existing account	091121bd-5b90-4312-8e4f-1be85be87c5c	basic-flow	f	t
196ad400-99e8-4348-8a51-2fadf7c54a35	Verify Existing Account by Re-authentication	Reauthentication of existing account	091121bd-5b90-4312-8e4f-1be85be87c5c	basic-flow	f	t
0721c2f5-b3a6-4ab9-9552-330f4e73cfd4	First broker login - Conditional OTP	Flow to determine if the OTP is required for the authentication	091121bd-5b90-4312-8e4f-1be85be87c5c	basic-flow	f	t
ff3fc9cb-ac00-4cba-9579-c4b526b4e24f	saml ecp	SAML ECP Profile Authentication Flow	091121bd-5b90-4312-8e4f-1be85be87c5c	basic-flow	t	t
196847b3-ff4b-411e-b4d4-3a9ed856b024	docker auth	Used by Docker clients to authenticate against the IDP	091121bd-5b90-4312-8e4f-1be85be87c5c	basic-flow	t	t
ff308753-36fb-4131-8076-405354fc6bbb	http challenge	An authentication flow based on challenge-response HTTP Authentication Schemes	091121bd-5b90-4312-8e4f-1be85be87c5c	basic-flow	t	t
3d9ac357-d9fd-495e-80dc-8e6a554b056c	Authentication Options	Authentication options.	091121bd-5b90-4312-8e4f-1be85be87c5c	basic-flow	f	t
6742d112-c9fb-474c-b777-60c9d5152026	Account verification options	Method with which to verity the existing account	On-premise	basic-flow	f	t
6dbf4510-3b25-4d74-a82d-b2106937a18f	Authentication Options	Authentication options.	On-premise	basic-flow	f	t
45a4cd63-386e-4b38-8922-3369d9d2d351	Browser - Conditional OTP	Flow to determine if the OTP is required for the authentication	On-premise	basic-flow	f	t
b17f233b-4f23-4c20-8bcb-8848e2cca065	Direct Grant - Conditional OTP	Flow to determine if the OTP is required for the authentication	On-premise	basic-flow	f	t
ac24292d-8055-4ac6-8a00-48c5f4b6b0eb	First broker login - Conditional OTP	Flow to determine if the OTP is required for the authentication	On-premise	basic-flow	f	t
b19adc30-119b-41ea-91d0-b5f8f7ef2c6f	Handle Existing Account	Handle what to do if there is existing account with same email/username like authenticated identity provider	On-premise	basic-flow	f	t
d8551231-831e-47d7-99e0-07ca5059f450	Reset - Conditional OTP	Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.	On-premise	basic-flow	f	t
166c462e-8a08-4db2-b969-b8e85d43d0ec	User creation or linking	Flow for the existing/non-existing user alternatives	On-premise	basic-flow	f	t
110d8832-3a2d-4384-bcb2-57d11cb78d68	Verify Existing Account by Re-authentication	Reauthentication of existing account	On-premise	basic-flow	f	t
c2707c8a-a5b6-4e78-add6-808d7ec5e428	browser	browser based authentication	On-premise	basic-flow	t	t
5a2ea00b-95ef-4f39-a09a-9412954bbf6c	clients	Base authentication for clients	On-premise	client-flow	t	t
36ef8c4c-7c54-40e2-b207-fec6f3658272	direct grant	OpenID Connect Resource Owner Grant	On-premise	basic-flow	t	t
dfa7479a-057e-4c43-babb-f7a666d89af6	docker auth	Used by Docker clients to authenticate against the IDP	On-premise	basic-flow	t	t
a0668911-5cde-4dea-a7d9-539a39037f1a	first broker login	Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account	On-premise	basic-flow	t	t
17a4dc7b-9b2b-4f0a-94fe-ed0b258a44b0	forms	Username, password, otp and other auth forms.	On-premise	basic-flow	f	t
c0500008-463c-4fee-9cc6-e1e6428e9ec8	http challenge	An authentication flow based on challenge-response HTTP Authentication Schemes	On-premise	basic-flow	t	t
24eebbdf-6ebd-4241-8232-436e878fe1d0	registration	registration flow	On-premise	basic-flow	t	t
cbcce7af-8f51-48aa-9f84-663f88266aa3	registration form	registration form	On-premise	form-flow	f	t
5237249c-cf5b-4411-bc6c-cecbc5f19eb1	reset credentials	Reset credentials for a user if they forgot their password or something	On-premise	basic-flow	t	t
b60dc404-252c-412c-8c5c-4521fc1f59bd	saml ecp	SAML ECP Profile Authentication Flow	On-premise	basic-flow	t	t
\.


--
-- Data for Name: authenticator_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.authenticator_config (id, alias, realm_id) FROM stdin;
479bf758-4e37-437f-8fac-84830db7404c	review profile config	091121bd-5b90-4312-8e4f-1be85be87c5c
9b50bbd7-1b09-4ae8-8d69-af49ca0b8fbd	create unique user config	091121bd-5b90-4312-8e4f-1be85be87c5c
d47b74ae-0627-42bf-9ba2-0f23e838700d	create unique user config	On-premise
c6c23214-3dea-40e2-ac85-d2e8b1a8a5bc	review profile config	On-premise
\.


--
-- Data for Name: authenticator_config_entry; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.authenticator_config_entry (authenticator_id, value, name) FROM stdin;
479bf758-4e37-437f-8fac-84830db7404c	missing	update.profile.on.first.login
9b50bbd7-1b09-4ae8-8d69-af49ca0b8fbd	false	require.password.update.after.registration
c6c23214-3dea-40e2-ac85-d2e8b1a8a5bc	missing	update.profile.on.first.login
d47b74ae-0627-42bf-9ba2-0f23e838700d	false	require.password.update.after.registration
\.


--
-- Data for Name: broker_link; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.broker_link (identity_provider, storage_provider_id, realm_id, broker_user_id, broker_username, token, user_id) FROM stdin;
\.


--
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client (id, enabled, full_scope_allowed, client_id, not_before, public_client, secret, base_url, bearer_only, management_url, surrogate_auth_required, realm_id, protocol, node_rereg_timeout, frontchannel_logout, consent_required, name, service_accounts_enabled, client_authenticator_type, root_url, description, registration_token, standard_flow_enabled, implicit_flow_enabled, direct_access_grants_enabled, always_display_in_console) FROM stdin;
6aa3754c-83c0-40f4-9474-3c745b7d49c5	t	f	master-realm	0	f	\N	\N	t	\N	f	091121bd-5b90-4312-8e4f-1be85be87c5c	\N	0	f	f	master Realm	f	client-secret	\N	\N	\N	t	f	f	f
192e12a1-d757-45fa-af0c-4e1403d6839b	t	f	account	0	t	\N	/realms/master/account/	f	\N	f	091121bd-5b90-4312-8e4f-1be85be87c5c	openid-connect	0	f	f	${client_account}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
8159c06d-88e2-43ed-8b46-235e9f914801	t	f	account-console	0	t	\N	/realms/master/account/	f	\N	f	091121bd-5b90-4312-8e4f-1be85be87c5c	openid-connect	0	f	f	${client_account-console}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
e717a919-aca7-4c82-829f-406898377038	t	f	broker	0	f	\N	\N	t	\N	f	091121bd-5b90-4312-8e4f-1be85be87c5c	openid-connect	0	f	f	${client_broker}	f	client-secret	\N	\N	\N	t	f	f	f
716e3e61-eb87-4888-9954-a77d44ffa498	t	f	security-admin-console	0	t	\N	/admin/master/console/	f	\N	f	091121bd-5b90-4312-8e4f-1be85be87c5c	openid-connect	0	f	f	${client_security-admin-console}	f	client-secret	${authAdminUrl}	\N	\N	t	f	f	f
8ea63dd2-b1d6-40da-ad8e-2a44916fc1f9	t	f	admin-cli	0	t	\N	\N	f	\N	f	091121bd-5b90-4312-8e4f-1be85be87c5c	openid-connect	0	f	f	${client_admin-cli}	f	client-secret	\N	\N	\N	f	f	t	f
7abb271f-4aaa-4949-a6a4-3d44226fcb9a	t	f	On-premise-realm	0	f	\N	\N	t	\N	f	091121bd-5b90-4312-8e4f-1be85be87c5c	\N	0	f	f	On-premise Realm	f	client-secret	\N	\N	\N	t	f	f	f
676ec99d-bef5-49ef-b9c4-1be17bd4f92f	t	f	account	0	t	\N	/realms/On-premise/account/	f	\N	f	On-premise	openid-connect	0	f	f	${client_account}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
63e63428-fdea-4672-8e4f-d7a4df56393f	t	f	account-console	0	t	\N	/realms/On-premise/account/	f	\N	f	On-premise	openid-connect	0	f	f	${client_account-console}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
4ee575c8-6afb-4a08-bdba-2f771515c63b	t	f	admin-cli	0	t	\N	\N	f	\N	f	On-premise	openid-connect	0	f	f	${client_admin-cli}	f	client-secret	\N	\N	\N	f	f	t	f
915277c7-706e-4aa8-ad41-dfc2c3818c0b	t	t	avni-client	0	t	\N		f		f	On-premise	openid-connect	-1	f	f		t	client-secret	https://3.109.55.3:8022		\N	t	f	t	f
82b820b4-c7f1-4946-8e97-7cda75eca5a3	t	f	broker	0	f	\N	\N	t	\N	f	On-premise	openid-connect	0	f	f	${client_broker}	f	client-secret	\N	\N	\N	t	f	f	f
818e3596-2ff1-4056-9230-704e8fac0ca1	t	f	realm-management	0	f	\N	\N	t	\N	f	On-premise	openid-connect	0	f	f	${client_realm-management}	f	client-secret	\N	\N	\N	t	f	f	f
f355103f-48b5-4615-adb5-9992c317295c	t	f	security-admin-console	0	t	\N	/admin/On-premise/console/	f	\N	f	On-premise	openid-connect	0	f	f	${client_security-admin-console}	f	client-secret	${authAdminUrl}	\N	\N	t	f	f	f
4381c433-5988-418a-bc71-177bb46e873a	t	t	admin-api	0	f	ZhDeYYH86NnwrxWcy5CszN2m4q9ORdD3	\N	f	http://localhost:8080	f	On-premise	openid-connect	-1	f	f	\N	t	client-secret	http://localhost:8080	\N	\N	t	f	t	f
\.


--
-- Data for Name: client_attributes; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_attributes (client_id, name, value) FROM stdin;
192e12a1-d757-45fa-af0c-4e1403d6839b	post.logout.redirect.uris	+
8159c06d-88e2-43ed-8b46-235e9f914801	post.logout.redirect.uris	+
8159c06d-88e2-43ed-8b46-235e9f914801	pkce.code.challenge.method	S256
716e3e61-eb87-4888-9954-a77d44ffa498	post.logout.redirect.uris	+
716e3e61-eb87-4888-9954-a77d44ffa498	pkce.code.challenge.method	S256
676ec99d-bef5-49ef-b9c4-1be17bd4f92f	post.logout.redirect.uris	+
63e63428-fdea-4672-8e4f-d7a4df56393f	post.logout.redirect.uris	+
63e63428-fdea-4672-8e4f-d7a4df56393f	pkce.code.challenge.method	S256
4381c433-5988-418a-bc71-177bb46e873a	saml.multivalued.roles	false
4381c433-5988-418a-bc71-177bb46e873a	saml.force.post.binding	false
4381c433-5988-418a-bc71-177bb46e873a	frontchannel.logout.session.required	false
4381c433-5988-418a-bc71-177bb46e873a	post.logout.redirect.uris	+
4381c433-5988-418a-bc71-177bb46e873a	oauth2.device.authorization.grant.enabled	false
4381c433-5988-418a-bc71-177bb46e873a	backchannel.logout.revoke.offline.tokens	false
4381c433-5988-418a-bc71-177bb46e873a	saml.server.signature.keyinfo.ext	false
4381c433-5988-418a-bc71-177bb46e873a	use.refresh.tokens	true
4381c433-5988-418a-bc71-177bb46e873a	oidc.ciba.grant.enabled	false
4381c433-5988-418a-bc71-177bb46e873a	backchannel.logout.session.required	true
4381c433-5988-418a-bc71-177bb46e873a	client_credentials.use_refresh_token	false
4381c433-5988-418a-bc71-177bb46e873a	saml.client.signature	false
4381c433-5988-418a-bc71-177bb46e873a	require.pushed.authorization.requests	false
4381c433-5988-418a-bc71-177bb46e873a	saml.allow.ecp.flow	false
4381c433-5988-418a-bc71-177bb46e873a	saml.assertion.signature	false
4381c433-5988-418a-bc71-177bb46e873a	id.token.as.detached.signature	false
4381c433-5988-418a-bc71-177bb46e873a	saml.encrypt	false
4381c433-5988-418a-bc71-177bb46e873a	saml.server.signature	false
4381c433-5988-418a-bc71-177bb46e873a	exclude.session.state.from.auth.response	false
4381c433-5988-418a-bc71-177bb46e873a	saml.artifact.binding	false
4381c433-5988-418a-bc71-177bb46e873a	saml_force_name_id_format	false
4381c433-5988-418a-bc71-177bb46e873a	tls.client.certificate.bound.access.tokens	false
4381c433-5988-418a-bc71-177bb46e873a	acr.loa.map	{}
4381c433-5988-418a-bc71-177bb46e873a	saml.authnstatement	false
4381c433-5988-418a-bc71-177bb46e873a	display.on.consent.screen	false
4381c433-5988-418a-bc71-177bb46e873a	token.response.type.bearer.lower-case	false
4381c433-5988-418a-bc71-177bb46e873a	saml.onetimeuse.condition	false
4ee575c8-6afb-4a08-bdba-2f771515c63b	post.logout.redirect.uris	+
915277c7-706e-4aa8-ad41-dfc2c3818c0b	access.token.lifespan	600
915277c7-706e-4aa8-ad41-dfc2c3818c0b	saml.force.post.binding	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	saml.multivalued.roles	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	frontchannel.logout.session.required	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	post.logout.redirect.uris	+
915277c7-706e-4aa8-ad41-dfc2c3818c0b	oauth2.device.authorization.grant.enabled	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	backchannel.logout.revoke.offline.tokens	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	saml.server.signature.keyinfo.ext	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	use.refresh.tokens	true
915277c7-706e-4aa8-ad41-dfc2c3818c0b	oidc.ciba.grant.enabled	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	backchannel.logout.session.required	true
915277c7-706e-4aa8-ad41-dfc2c3818c0b	client_credentials.use_refresh_token	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	require.pushed.authorization.requests	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	saml.client.signature	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	saml.allow.ecp.flow	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	id.token.as.detached.signature	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	saml.assertion.signature	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	client.secret.creation.time	1656653576
915277c7-706e-4aa8-ad41-dfc2c3818c0b	saml.encrypt	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	saml.server.signature	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	exclude.session.state.from.auth.response	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	tls-client-certificate-bound-access-tokens	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	saml.artifact.binding	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	saml_force_name_id_format	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	acr.loa.map	{}
915277c7-706e-4aa8-ad41-dfc2c3818c0b	tls.client.certificate.bound.access.tokens	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	saml.authnstatement	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	display.on.consent.screen	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	token.response.type.bearer.lower-case	false
915277c7-706e-4aa8-ad41-dfc2c3818c0b	saml.onetimeuse.condition	false
82b820b4-c7f1-4946-8e97-7cda75eca5a3	post.logout.redirect.uris	+
818e3596-2ff1-4056-9230-704e8fac0ca1	post.logout.redirect.uris	+
f355103f-48b5-4615-adb5-9992c317295c	post.logout.redirect.uris	+
f355103f-48b5-4615-adb5-9992c317295c	pkce.code.challenge.method	S256
4381c433-5988-418a-bc71-177bb46e873a	client.secret.creation.time	1687143783
\.


--
-- Data for Name: client_auth_flow_bindings; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_auth_flow_bindings (client_id, flow_id, binding_name) FROM stdin;
915277c7-706e-4aa8-ad41-dfc2c3818c0b	c2707c8a-a5b6-4e78-add6-808d7ec5e428	browser
915277c7-706e-4aa8-ad41-dfc2c3818c0b	36ef8c4c-7c54-40e2-b207-fec6f3658272	direct_grant
\.


--
-- Data for Name: client_initial_access; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_initial_access (id, realm_id, "timestamp", expiration, count, remaining_count) FROM stdin;
\.


--
-- Data for Name: client_node_registrations; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_node_registrations (client_id, value, name) FROM stdin;
\.


--
-- Data for Name: client_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_scope (id, name, realm_id, description, protocol) FROM stdin;
9d829b78-9254-4a08-bf78-1eb7692267f8	offline_access	091121bd-5b90-4312-8e4f-1be85be87c5c	OpenID Connect built-in scope: offline_access	openid-connect
32166985-f2e4-49d4-ab1f-c2432532ee62	role_list	091121bd-5b90-4312-8e4f-1be85be87c5c	SAML role list	saml
ef01bb50-d052-4900-9927-8bbfc8f278eb	profile	091121bd-5b90-4312-8e4f-1be85be87c5c	OpenID Connect built-in scope: profile	openid-connect
ba667fc7-c7d1-460f-aae4-20e776c0fec1	email	091121bd-5b90-4312-8e4f-1be85be87c5c	OpenID Connect built-in scope: email	openid-connect
79758ce2-ff28-413d-a328-58f8e5221183	address	091121bd-5b90-4312-8e4f-1be85be87c5c	OpenID Connect built-in scope: address	openid-connect
61333193-449f-4aff-848c-70d4fdfabc0c	phone	091121bd-5b90-4312-8e4f-1be85be87c5c	OpenID Connect built-in scope: phone	openid-connect
f5544b08-7f55-4388-ae84-538d48366597	roles	091121bd-5b90-4312-8e4f-1be85be87c5c	OpenID Connect scope for add user roles to the access token	openid-connect
86349b8b-15ca-427f-a2a9-c39e5adac3b5	web-origins	091121bd-5b90-4312-8e4f-1be85be87c5c	OpenID Connect scope for add allowed web origins to the access token	openid-connect
001899db-8719-4fb4-84b5-932697fc8f11	microprofile-jwt	091121bd-5b90-4312-8e4f-1be85be87c5c	Microprofile - JWT built-in scope	openid-connect
b497f044-6cfc-404d-82ca-c69889619eda	acr	091121bd-5b90-4312-8e4f-1be85be87c5c	OpenID Connect scope for add acr (authentication context class reference) to the token	openid-connect
79cee3fc-a552-47d4-8deb-7fe5b231bfe1	phone	On-premise	OpenID Connect built-in scope: phone	openid-connect
fb5fb072-87e0-490e-9dba-3bfaa677b35e	email	On-premise	OpenID Connect built-in scope: email	openid-connect
b97a5f52-b8bf-4313-a458-d5af0b16c629	microprofile-jwt	On-premise	Microprofile - JWT built-in scope	openid-connect
ac87c569-2002-45ff-b330-b4fc5303051e	offline_access	On-premise	OpenID Connect built-in scope: offline_access	openid-connect
5c4d2c3e-85e6-4ef6-98f7-b9afc76c9442	web-origins	On-premise	OpenID Connect scope for add allowed web origins to the access token	openid-connect
9db74845-4196-4859-82b4-dd4ac268d672	acr	On-premise	OpenID Connect scope for add acr (authentication context class reference) to the token	openid-connect
36eeab00-16ef-4cb7-9f43-1626bfe6aae2	roles	On-premise	OpenID Connect scope for add user roles to the access token	openid-connect
445e57d8-6cb8-49a7-a566-480c1b754409	role_list	On-premise	SAML role list	saml
c32f274c-e449-4afe-bb2f-8cd75d24207d	address	On-premise	OpenID Connect built-in scope: address	openid-connect
fa931807-b3af-4ae0-81b7-267055627626	avni-server	On-premise	\N	openid-connect
ae2a301a-d22f-46e6-a736-5e3837e6b18a	profile	On-premise	OpenID Connect built-in scope: profile	openid-connect
\.


--
-- Data for Name: client_scope_attributes; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_scope_attributes (scope_id, value, name) FROM stdin;
9d829b78-9254-4a08-bf78-1eb7692267f8	true	display.on.consent.screen
9d829b78-9254-4a08-bf78-1eb7692267f8	${offlineAccessScopeConsentText}	consent.screen.text
32166985-f2e4-49d4-ab1f-c2432532ee62	true	display.on.consent.screen
32166985-f2e4-49d4-ab1f-c2432532ee62	${samlRoleListScopeConsentText}	consent.screen.text
ef01bb50-d052-4900-9927-8bbfc8f278eb	true	display.on.consent.screen
ef01bb50-d052-4900-9927-8bbfc8f278eb	${profileScopeConsentText}	consent.screen.text
ef01bb50-d052-4900-9927-8bbfc8f278eb	true	include.in.token.scope
ba667fc7-c7d1-460f-aae4-20e776c0fec1	true	display.on.consent.screen
ba667fc7-c7d1-460f-aae4-20e776c0fec1	${emailScopeConsentText}	consent.screen.text
ba667fc7-c7d1-460f-aae4-20e776c0fec1	true	include.in.token.scope
79758ce2-ff28-413d-a328-58f8e5221183	true	display.on.consent.screen
79758ce2-ff28-413d-a328-58f8e5221183	${addressScopeConsentText}	consent.screen.text
79758ce2-ff28-413d-a328-58f8e5221183	true	include.in.token.scope
61333193-449f-4aff-848c-70d4fdfabc0c	true	display.on.consent.screen
61333193-449f-4aff-848c-70d4fdfabc0c	${phoneScopeConsentText}	consent.screen.text
61333193-449f-4aff-848c-70d4fdfabc0c	true	include.in.token.scope
f5544b08-7f55-4388-ae84-538d48366597	true	display.on.consent.screen
f5544b08-7f55-4388-ae84-538d48366597	${rolesScopeConsentText}	consent.screen.text
f5544b08-7f55-4388-ae84-538d48366597	false	include.in.token.scope
86349b8b-15ca-427f-a2a9-c39e5adac3b5	false	display.on.consent.screen
86349b8b-15ca-427f-a2a9-c39e5adac3b5		consent.screen.text
86349b8b-15ca-427f-a2a9-c39e5adac3b5	false	include.in.token.scope
001899db-8719-4fb4-84b5-932697fc8f11	false	display.on.consent.screen
001899db-8719-4fb4-84b5-932697fc8f11	true	include.in.token.scope
b497f044-6cfc-404d-82ca-c69889619eda	false	display.on.consent.screen
b497f044-6cfc-404d-82ca-c69889619eda	false	include.in.token.scope
79cee3fc-a552-47d4-8deb-7fe5b231bfe1	true	include.in.token.scope
79cee3fc-a552-47d4-8deb-7fe5b231bfe1	true	display.on.consent.screen
79cee3fc-a552-47d4-8deb-7fe5b231bfe1	${phoneScopeConsentText}	consent.screen.text
fb5fb072-87e0-490e-9dba-3bfaa677b35e	true	include.in.token.scope
fb5fb072-87e0-490e-9dba-3bfaa677b35e	true	display.on.consent.screen
fb5fb072-87e0-490e-9dba-3bfaa677b35e	${emailScopeConsentText}	consent.screen.text
b97a5f52-b8bf-4313-a458-d5af0b16c629	true	include.in.token.scope
b97a5f52-b8bf-4313-a458-d5af0b16c629	false	display.on.consent.screen
ac87c569-2002-45ff-b330-b4fc5303051e	${offlineAccessScopeConsentText}	consent.screen.text
ac87c569-2002-45ff-b330-b4fc5303051e	true	display.on.consent.screen
5c4d2c3e-85e6-4ef6-98f7-b9afc76c9442	false	include.in.token.scope
5c4d2c3e-85e6-4ef6-98f7-b9afc76c9442	false	display.on.consent.screen
5c4d2c3e-85e6-4ef6-98f7-b9afc76c9442		consent.screen.text
9db74845-4196-4859-82b4-dd4ac268d672	false	include.in.token.scope
9db74845-4196-4859-82b4-dd4ac268d672	false	display.on.consent.screen
36eeab00-16ef-4cb7-9f43-1626bfe6aae2	false	include.in.token.scope
36eeab00-16ef-4cb7-9f43-1626bfe6aae2	true	display.on.consent.screen
36eeab00-16ef-4cb7-9f43-1626bfe6aae2	${rolesScopeConsentText}	consent.screen.text
445e57d8-6cb8-49a7-a566-480c1b754409	${samlRoleListScopeConsentText}	consent.screen.text
445e57d8-6cb8-49a7-a566-480c1b754409	true	display.on.consent.screen
c32f274c-e449-4afe-bb2f-8cd75d24207d	true	include.in.token.scope
c32f274c-e449-4afe-bb2f-8cd75d24207d	true	display.on.consent.screen
c32f274c-e449-4afe-bb2f-8cd75d24207d	${addressScopeConsentText}	consent.screen.text
fa931807-b3af-4ae0-81b7-267055627626	true	include.in.token.scope
fa931807-b3af-4ae0-81b7-267055627626	true	display.on.consent.screen
ae2a301a-d22f-46e6-a736-5e3837e6b18a	true	include.in.token.scope
ae2a301a-d22f-46e6-a736-5e3837e6b18a	true	display.on.consent.screen
ae2a301a-d22f-46e6-a736-5e3837e6b18a	${profileScopeConsentText}	consent.screen.text
\.


--
-- Data for Name: client_scope_client; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_scope_client (client_id, scope_id, default_scope) FROM stdin;
192e12a1-d757-45fa-af0c-4e1403d6839b	b497f044-6cfc-404d-82ca-c69889619eda	t
192e12a1-d757-45fa-af0c-4e1403d6839b	86349b8b-15ca-427f-a2a9-c39e5adac3b5	t
192e12a1-d757-45fa-af0c-4e1403d6839b	ef01bb50-d052-4900-9927-8bbfc8f278eb	t
192e12a1-d757-45fa-af0c-4e1403d6839b	ba667fc7-c7d1-460f-aae4-20e776c0fec1	t
192e12a1-d757-45fa-af0c-4e1403d6839b	f5544b08-7f55-4388-ae84-538d48366597	t
192e12a1-d757-45fa-af0c-4e1403d6839b	61333193-449f-4aff-848c-70d4fdfabc0c	f
192e12a1-d757-45fa-af0c-4e1403d6839b	79758ce2-ff28-413d-a328-58f8e5221183	f
192e12a1-d757-45fa-af0c-4e1403d6839b	001899db-8719-4fb4-84b5-932697fc8f11	f
192e12a1-d757-45fa-af0c-4e1403d6839b	9d829b78-9254-4a08-bf78-1eb7692267f8	f
8159c06d-88e2-43ed-8b46-235e9f914801	b497f044-6cfc-404d-82ca-c69889619eda	t
8159c06d-88e2-43ed-8b46-235e9f914801	86349b8b-15ca-427f-a2a9-c39e5adac3b5	t
8159c06d-88e2-43ed-8b46-235e9f914801	ef01bb50-d052-4900-9927-8bbfc8f278eb	t
8159c06d-88e2-43ed-8b46-235e9f914801	ba667fc7-c7d1-460f-aae4-20e776c0fec1	t
8159c06d-88e2-43ed-8b46-235e9f914801	f5544b08-7f55-4388-ae84-538d48366597	t
8159c06d-88e2-43ed-8b46-235e9f914801	61333193-449f-4aff-848c-70d4fdfabc0c	f
8159c06d-88e2-43ed-8b46-235e9f914801	79758ce2-ff28-413d-a328-58f8e5221183	f
8159c06d-88e2-43ed-8b46-235e9f914801	001899db-8719-4fb4-84b5-932697fc8f11	f
8159c06d-88e2-43ed-8b46-235e9f914801	9d829b78-9254-4a08-bf78-1eb7692267f8	f
8ea63dd2-b1d6-40da-ad8e-2a44916fc1f9	b497f044-6cfc-404d-82ca-c69889619eda	t
8ea63dd2-b1d6-40da-ad8e-2a44916fc1f9	86349b8b-15ca-427f-a2a9-c39e5adac3b5	t
8ea63dd2-b1d6-40da-ad8e-2a44916fc1f9	ef01bb50-d052-4900-9927-8bbfc8f278eb	t
8ea63dd2-b1d6-40da-ad8e-2a44916fc1f9	ba667fc7-c7d1-460f-aae4-20e776c0fec1	t
8ea63dd2-b1d6-40da-ad8e-2a44916fc1f9	f5544b08-7f55-4388-ae84-538d48366597	t
8ea63dd2-b1d6-40da-ad8e-2a44916fc1f9	61333193-449f-4aff-848c-70d4fdfabc0c	f
8ea63dd2-b1d6-40da-ad8e-2a44916fc1f9	79758ce2-ff28-413d-a328-58f8e5221183	f
8ea63dd2-b1d6-40da-ad8e-2a44916fc1f9	001899db-8719-4fb4-84b5-932697fc8f11	f
8ea63dd2-b1d6-40da-ad8e-2a44916fc1f9	9d829b78-9254-4a08-bf78-1eb7692267f8	f
e717a919-aca7-4c82-829f-406898377038	b497f044-6cfc-404d-82ca-c69889619eda	t
e717a919-aca7-4c82-829f-406898377038	86349b8b-15ca-427f-a2a9-c39e5adac3b5	t
e717a919-aca7-4c82-829f-406898377038	ef01bb50-d052-4900-9927-8bbfc8f278eb	t
e717a919-aca7-4c82-829f-406898377038	ba667fc7-c7d1-460f-aae4-20e776c0fec1	t
e717a919-aca7-4c82-829f-406898377038	f5544b08-7f55-4388-ae84-538d48366597	t
e717a919-aca7-4c82-829f-406898377038	61333193-449f-4aff-848c-70d4fdfabc0c	f
e717a919-aca7-4c82-829f-406898377038	79758ce2-ff28-413d-a328-58f8e5221183	f
e717a919-aca7-4c82-829f-406898377038	001899db-8719-4fb4-84b5-932697fc8f11	f
e717a919-aca7-4c82-829f-406898377038	9d829b78-9254-4a08-bf78-1eb7692267f8	f
6aa3754c-83c0-40f4-9474-3c745b7d49c5	b497f044-6cfc-404d-82ca-c69889619eda	t
6aa3754c-83c0-40f4-9474-3c745b7d49c5	86349b8b-15ca-427f-a2a9-c39e5adac3b5	t
6aa3754c-83c0-40f4-9474-3c745b7d49c5	ef01bb50-d052-4900-9927-8bbfc8f278eb	t
6aa3754c-83c0-40f4-9474-3c745b7d49c5	ba667fc7-c7d1-460f-aae4-20e776c0fec1	t
6aa3754c-83c0-40f4-9474-3c745b7d49c5	f5544b08-7f55-4388-ae84-538d48366597	t
6aa3754c-83c0-40f4-9474-3c745b7d49c5	61333193-449f-4aff-848c-70d4fdfabc0c	f
6aa3754c-83c0-40f4-9474-3c745b7d49c5	79758ce2-ff28-413d-a328-58f8e5221183	f
6aa3754c-83c0-40f4-9474-3c745b7d49c5	001899db-8719-4fb4-84b5-932697fc8f11	f
6aa3754c-83c0-40f4-9474-3c745b7d49c5	9d829b78-9254-4a08-bf78-1eb7692267f8	f
716e3e61-eb87-4888-9954-a77d44ffa498	b497f044-6cfc-404d-82ca-c69889619eda	t
716e3e61-eb87-4888-9954-a77d44ffa498	86349b8b-15ca-427f-a2a9-c39e5adac3b5	t
716e3e61-eb87-4888-9954-a77d44ffa498	ef01bb50-d052-4900-9927-8bbfc8f278eb	t
716e3e61-eb87-4888-9954-a77d44ffa498	ba667fc7-c7d1-460f-aae4-20e776c0fec1	t
716e3e61-eb87-4888-9954-a77d44ffa498	f5544b08-7f55-4388-ae84-538d48366597	t
716e3e61-eb87-4888-9954-a77d44ffa498	61333193-449f-4aff-848c-70d4fdfabc0c	f
716e3e61-eb87-4888-9954-a77d44ffa498	79758ce2-ff28-413d-a328-58f8e5221183	f
716e3e61-eb87-4888-9954-a77d44ffa498	001899db-8719-4fb4-84b5-932697fc8f11	f
716e3e61-eb87-4888-9954-a77d44ffa498	9d829b78-9254-4a08-bf78-1eb7692267f8	f
676ec99d-bef5-49ef-b9c4-1be17bd4f92f	5c4d2c3e-85e6-4ef6-98f7-b9afc76c9442	t
676ec99d-bef5-49ef-b9c4-1be17bd4f92f	9db74845-4196-4859-82b4-dd4ac268d672	t
676ec99d-bef5-49ef-b9c4-1be17bd4f92f	36eeab00-16ef-4cb7-9f43-1626bfe6aae2	t
676ec99d-bef5-49ef-b9c4-1be17bd4f92f	ae2a301a-d22f-46e6-a736-5e3837e6b18a	t
676ec99d-bef5-49ef-b9c4-1be17bd4f92f	fb5fb072-87e0-490e-9dba-3bfaa677b35e	t
676ec99d-bef5-49ef-b9c4-1be17bd4f92f	c32f274c-e449-4afe-bb2f-8cd75d24207d	f
676ec99d-bef5-49ef-b9c4-1be17bd4f92f	79cee3fc-a552-47d4-8deb-7fe5b231bfe1	f
676ec99d-bef5-49ef-b9c4-1be17bd4f92f	ac87c569-2002-45ff-b330-b4fc5303051e	f
676ec99d-bef5-49ef-b9c4-1be17bd4f92f	b97a5f52-b8bf-4313-a458-d5af0b16c629	f
63e63428-fdea-4672-8e4f-d7a4df56393f	5c4d2c3e-85e6-4ef6-98f7-b9afc76c9442	t
63e63428-fdea-4672-8e4f-d7a4df56393f	9db74845-4196-4859-82b4-dd4ac268d672	t
63e63428-fdea-4672-8e4f-d7a4df56393f	36eeab00-16ef-4cb7-9f43-1626bfe6aae2	t
63e63428-fdea-4672-8e4f-d7a4df56393f	ae2a301a-d22f-46e6-a736-5e3837e6b18a	t
63e63428-fdea-4672-8e4f-d7a4df56393f	fb5fb072-87e0-490e-9dba-3bfaa677b35e	t
63e63428-fdea-4672-8e4f-d7a4df56393f	c32f274c-e449-4afe-bb2f-8cd75d24207d	f
63e63428-fdea-4672-8e4f-d7a4df56393f	79cee3fc-a552-47d4-8deb-7fe5b231bfe1	f
63e63428-fdea-4672-8e4f-d7a4df56393f	ac87c569-2002-45ff-b330-b4fc5303051e	f
63e63428-fdea-4672-8e4f-d7a4df56393f	b97a5f52-b8bf-4313-a458-d5af0b16c629	f
4381c433-5988-418a-bc71-177bb46e873a	5c4d2c3e-85e6-4ef6-98f7-b9afc76c9442	t
4381c433-5988-418a-bc71-177bb46e873a	9db74845-4196-4859-82b4-dd4ac268d672	t
4381c433-5988-418a-bc71-177bb46e873a	36eeab00-16ef-4cb7-9f43-1626bfe6aae2	t
4381c433-5988-418a-bc71-177bb46e873a	ae2a301a-d22f-46e6-a736-5e3837e6b18a	t
4381c433-5988-418a-bc71-177bb46e873a	fb5fb072-87e0-490e-9dba-3bfaa677b35e	t
4381c433-5988-418a-bc71-177bb46e873a	fa931807-b3af-4ae0-81b7-267055627626	t
4381c433-5988-418a-bc71-177bb46e873a	c32f274c-e449-4afe-bb2f-8cd75d24207d	f
4381c433-5988-418a-bc71-177bb46e873a	79cee3fc-a552-47d4-8deb-7fe5b231bfe1	f
4381c433-5988-418a-bc71-177bb46e873a	ac87c569-2002-45ff-b330-b4fc5303051e	f
4381c433-5988-418a-bc71-177bb46e873a	b97a5f52-b8bf-4313-a458-d5af0b16c629	f
4ee575c8-6afb-4a08-bdba-2f771515c63b	5c4d2c3e-85e6-4ef6-98f7-b9afc76c9442	t
4ee575c8-6afb-4a08-bdba-2f771515c63b	9db74845-4196-4859-82b4-dd4ac268d672	t
4ee575c8-6afb-4a08-bdba-2f771515c63b	36eeab00-16ef-4cb7-9f43-1626bfe6aae2	t
4ee575c8-6afb-4a08-bdba-2f771515c63b	ae2a301a-d22f-46e6-a736-5e3837e6b18a	t
4ee575c8-6afb-4a08-bdba-2f771515c63b	fb5fb072-87e0-490e-9dba-3bfaa677b35e	t
4ee575c8-6afb-4a08-bdba-2f771515c63b	c32f274c-e449-4afe-bb2f-8cd75d24207d	f
4ee575c8-6afb-4a08-bdba-2f771515c63b	79cee3fc-a552-47d4-8deb-7fe5b231bfe1	f
4ee575c8-6afb-4a08-bdba-2f771515c63b	ac87c569-2002-45ff-b330-b4fc5303051e	f
4ee575c8-6afb-4a08-bdba-2f771515c63b	b97a5f52-b8bf-4313-a458-d5af0b16c629	f
915277c7-706e-4aa8-ad41-dfc2c3818c0b	5c4d2c3e-85e6-4ef6-98f7-b9afc76c9442	t
915277c7-706e-4aa8-ad41-dfc2c3818c0b	9db74845-4196-4859-82b4-dd4ac268d672	t
915277c7-706e-4aa8-ad41-dfc2c3818c0b	36eeab00-16ef-4cb7-9f43-1626bfe6aae2	t
915277c7-706e-4aa8-ad41-dfc2c3818c0b	ae2a301a-d22f-46e6-a736-5e3837e6b18a	t
915277c7-706e-4aa8-ad41-dfc2c3818c0b	fb5fb072-87e0-490e-9dba-3bfaa677b35e	t
915277c7-706e-4aa8-ad41-dfc2c3818c0b	fa931807-b3af-4ae0-81b7-267055627626	t
915277c7-706e-4aa8-ad41-dfc2c3818c0b	c32f274c-e449-4afe-bb2f-8cd75d24207d	f
915277c7-706e-4aa8-ad41-dfc2c3818c0b	79cee3fc-a552-47d4-8deb-7fe5b231bfe1	f
915277c7-706e-4aa8-ad41-dfc2c3818c0b	ac87c569-2002-45ff-b330-b4fc5303051e	f
915277c7-706e-4aa8-ad41-dfc2c3818c0b	b97a5f52-b8bf-4313-a458-d5af0b16c629	f
82b820b4-c7f1-4946-8e97-7cda75eca5a3	5c4d2c3e-85e6-4ef6-98f7-b9afc76c9442	t
82b820b4-c7f1-4946-8e97-7cda75eca5a3	9db74845-4196-4859-82b4-dd4ac268d672	t
82b820b4-c7f1-4946-8e97-7cda75eca5a3	36eeab00-16ef-4cb7-9f43-1626bfe6aae2	t
82b820b4-c7f1-4946-8e97-7cda75eca5a3	ae2a301a-d22f-46e6-a736-5e3837e6b18a	t
82b820b4-c7f1-4946-8e97-7cda75eca5a3	fb5fb072-87e0-490e-9dba-3bfaa677b35e	t
82b820b4-c7f1-4946-8e97-7cda75eca5a3	c32f274c-e449-4afe-bb2f-8cd75d24207d	f
82b820b4-c7f1-4946-8e97-7cda75eca5a3	79cee3fc-a552-47d4-8deb-7fe5b231bfe1	f
82b820b4-c7f1-4946-8e97-7cda75eca5a3	ac87c569-2002-45ff-b330-b4fc5303051e	f
82b820b4-c7f1-4946-8e97-7cda75eca5a3	b97a5f52-b8bf-4313-a458-d5af0b16c629	f
818e3596-2ff1-4056-9230-704e8fac0ca1	5c4d2c3e-85e6-4ef6-98f7-b9afc76c9442	t
818e3596-2ff1-4056-9230-704e8fac0ca1	9db74845-4196-4859-82b4-dd4ac268d672	t
818e3596-2ff1-4056-9230-704e8fac0ca1	36eeab00-16ef-4cb7-9f43-1626bfe6aae2	t
818e3596-2ff1-4056-9230-704e8fac0ca1	ae2a301a-d22f-46e6-a736-5e3837e6b18a	t
818e3596-2ff1-4056-9230-704e8fac0ca1	fb5fb072-87e0-490e-9dba-3bfaa677b35e	t
818e3596-2ff1-4056-9230-704e8fac0ca1	c32f274c-e449-4afe-bb2f-8cd75d24207d	f
818e3596-2ff1-4056-9230-704e8fac0ca1	79cee3fc-a552-47d4-8deb-7fe5b231bfe1	f
818e3596-2ff1-4056-9230-704e8fac0ca1	ac87c569-2002-45ff-b330-b4fc5303051e	f
818e3596-2ff1-4056-9230-704e8fac0ca1	b97a5f52-b8bf-4313-a458-d5af0b16c629	f
f355103f-48b5-4615-adb5-9992c317295c	5c4d2c3e-85e6-4ef6-98f7-b9afc76c9442	t
f355103f-48b5-4615-adb5-9992c317295c	9db74845-4196-4859-82b4-dd4ac268d672	t
f355103f-48b5-4615-adb5-9992c317295c	36eeab00-16ef-4cb7-9f43-1626bfe6aae2	t
f355103f-48b5-4615-adb5-9992c317295c	ae2a301a-d22f-46e6-a736-5e3837e6b18a	t
f355103f-48b5-4615-adb5-9992c317295c	fb5fb072-87e0-490e-9dba-3bfaa677b35e	t
f355103f-48b5-4615-adb5-9992c317295c	c32f274c-e449-4afe-bb2f-8cd75d24207d	f
f355103f-48b5-4615-adb5-9992c317295c	79cee3fc-a552-47d4-8deb-7fe5b231bfe1	f
f355103f-48b5-4615-adb5-9992c317295c	ac87c569-2002-45ff-b330-b4fc5303051e	f
f355103f-48b5-4615-adb5-9992c317295c	b97a5f52-b8bf-4313-a458-d5af0b16c629	f
\.


--
-- Data for Name: client_scope_role_mapping; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_scope_role_mapping (scope_id, role_id) FROM stdin;
9d829b78-9254-4a08-bf78-1eb7692267f8	0cb8ad12-2b7b-43a3-85f7-94d2965b88f2
ac87c569-2002-45ff-b330-b4fc5303051e	3ee7ccc9-1bc8-4218-b4fd-834c267f876b
\.


--
-- Data for Name: client_session; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_session (id, client_id, redirect_uri, state, "timestamp", session_id, auth_method, realm_id, auth_user_id, current_action) FROM stdin;
\.


--
-- Data for Name: client_session_auth_status; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_session_auth_status (authenticator, status, client_session) FROM stdin;
\.


--
-- Data for Name: client_session_note; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_session_note (name, value, client_session) FROM stdin;
\.


--
-- Data for Name: client_session_prot_mapper; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_session_prot_mapper (protocol_mapper_id, client_session) FROM stdin;
\.


--
-- Data for Name: client_session_role; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_session_role (role_id, client_session) FROM stdin;
\.


--
-- Data for Name: client_user_session_note; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_user_session_note (name, value, client_session) FROM stdin;
\.


--
-- Data for Name: component; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.component (id, name, parent_id, provider_id, provider_type, realm_id, sub_type) FROM stdin;
fafa0645-649b-40d1-bbb4-9dcf17c5d7bc	Trusted Hosts	091121bd-5b90-4312-8e4f-1be85be87c5c	trusted-hosts	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	091121bd-5b90-4312-8e4f-1be85be87c5c	anonymous
48c38589-6e64-4fbc-ba99-9e3a4edf3052	Consent Required	091121bd-5b90-4312-8e4f-1be85be87c5c	consent-required	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	091121bd-5b90-4312-8e4f-1be85be87c5c	anonymous
d6992ccd-c2bf-41db-899d-7c257aff1b28	Full Scope Disabled	091121bd-5b90-4312-8e4f-1be85be87c5c	scope	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	091121bd-5b90-4312-8e4f-1be85be87c5c	anonymous
1694d49f-1382-47da-ab11-ff69e2c44618	Max Clients Limit	091121bd-5b90-4312-8e4f-1be85be87c5c	max-clients	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	091121bd-5b90-4312-8e4f-1be85be87c5c	anonymous
5bd9b148-9eef-46fa-8d06-34efdd2023e7	Allowed Protocol Mapper Types	091121bd-5b90-4312-8e4f-1be85be87c5c	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	091121bd-5b90-4312-8e4f-1be85be87c5c	anonymous
302885f2-52a4-4526-b04c-31d14cef8eb1	Allowed Client Scopes	091121bd-5b90-4312-8e4f-1be85be87c5c	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	091121bd-5b90-4312-8e4f-1be85be87c5c	anonymous
ee8c7e1d-6a2d-4d38-bc18-8e3d3f761e6f	Allowed Protocol Mapper Types	091121bd-5b90-4312-8e4f-1be85be87c5c	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	091121bd-5b90-4312-8e4f-1be85be87c5c	authenticated
b0ab9a2c-979e-43a3-a9ef-e14aa3dccb2c	Allowed Client Scopes	091121bd-5b90-4312-8e4f-1be85be87c5c	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	091121bd-5b90-4312-8e4f-1be85be87c5c	authenticated
34743300-fa8e-4bb0-ba29-14d30e0baf64	rsa-generated	091121bd-5b90-4312-8e4f-1be85be87c5c	rsa-generated	org.keycloak.keys.KeyProvider	091121bd-5b90-4312-8e4f-1be85be87c5c	\N
22c9161d-274b-4121-bcda-a0c8f2ac1c9d	rsa-enc-generated	091121bd-5b90-4312-8e4f-1be85be87c5c	rsa-enc-generated	org.keycloak.keys.KeyProvider	091121bd-5b90-4312-8e4f-1be85be87c5c	\N
f2840e7a-2068-4013-9d6b-6bcf73db2263	hmac-generated	091121bd-5b90-4312-8e4f-1be85be87c5c	hmac-generated	org.keycloak.keys.KeyProvider	091121bd-5b90-4312-8e4f-1be85be87c5c	\N
ec06afbd-d38d-4505-90c4-789fd55d6471	aes-generated	091121bd-5b90-4312-8e4f-1be85be87c5c	aes-generated	org.keycloak.keys.KeyProvider	091121bd-5b90-4312-8e4f-1be85be87c5c	\N
94c15efc-8ace-4893-9b56-802a93222086	Full Scope Disabled	On-premise	scope	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	On-premise	anonymous
3fd3805c-e371-449c-adb6-bd7375a11a42	Max Clients Limit	On-premise	max-clients	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	On-premise	anonymous
52b4d82e-484c-411c-9644-c1ca8bd4e513	Trusted Hosts	On-premise	trusted-hosts	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	On-premise	anonymous
98959d63-700b-40c1-98cd-18edf25df8fe	Allowed Protocol Mapper Types	On-premise	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	On-premise	authenticated
7f041d01-ebee-44b9-a17c-2f8e256d00e7	Consent Required	On-premise	consent-required	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	On-premise	anonymous
a99c7d98-7312-4c31-8db7-3aad3254e805	Allowed Client Scopes	On-premise	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	On-premise	anonymous
052e3758-7f2b-4c65-ad0e-9430d29769e6	Allowed Protocol Mapper Types	On-premise	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	On-premise	anonymous
e34baa09-e3fc-4251-9b60-9928b2f4520d	Allowed Client Scopes	On-premise	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	On-premise	authenticated
93651be0-058b-4c0c-86ff-113e7d4d33cd	\N	On-premise	declarative-user-profile	org.keycloak.userprofile.UserProfileProvider	On-premise	\N
d56cdec7-6a5f-40ad-800f-ab5092ac1c00	hmac-generated	On-premise	hmac-generated	org.keycloak.keys.KeyProvider	On-premise	\N
93bc66e1-e7e8-4915-a30b-189312230aa6	rsa-generated	On-premise	rsa-generated	org.keycloak.keys.KeyProvider	On-premise	\N
2a4271b6-e4ce-45d7-ad60-def6e56a51aa	aes-generated	On-premise	aes-generated	org.keycloak.keys.KeyProvider	On-premise	\N
b84452da-cbd1-4077-bd02-b1130551ac9f	rsa-enc-generated	On-premise	rsa-enc-generated	org.keycloak.keys.KeyProvider	On-premise	\N
\.


--
-- Data for Name: component_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.component_config (id, component_id, name, value) FROM stdin;
541f4fa5-4431-4c3c-9ba8-5e9fea786e97	1694d49f-1382-47da-ab11-ff69e2c44618	max-clients	200
aaf16afd-4b05-4ac7-bf79-c356d0779fa2	ee8c7e1d-6a2d-4d38-bc18-8e3d3f761e6f	allowed-protocol-mapper-types	saml-role-list-mapper
b0ef09ef-482c-40f2-bd30-68aa8eaa2497	ee8c7e1d-6a2d-4d38-bc18-8e3d3f761e6f	allowed-protocol-mapper-types	saml-user-property-mapper
1d2c0aaf-e648-4cac-8bf4-ea077c509269	ee8c7e1d-6a2d-4d38-bc18-8e3d3f761e6f	allowed-protocol-mapper-types	oidc-address-mapper
a43b277e-29fe-428e-9324-26ff01a46954	ee8c7e1d-6a2d-4d38-bc18-8e3d3f761e6f	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
75202e76-58d4-4ae1-b791-9aebe1c4d218	ee8c7e1d-6a2d-4d38-bc18-8e3d3f761e6f	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
f8c738a1-cc16-45bd-afcb-00134b48f6da	ee8c7e1d-6a2d-4d38-bc18-8e3d3f761e6f	allowed-protocol-mapper-types	saml-user-attribute-mapper
7996f179-aa75-4423-908e-27a92587dc35	ee8c7e1d-6a2d-4d38-bc18-8e3d3f761e6f	allowed-protocol-mapper-types	oidc-full-name-mapper
4591edf4-375a-4376-9cf3-cdae31b254e5	ee8c7e1d-6a2d-4d38-bc18-8e3d3f761e6f	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
919d37ee-d7ec-4368-bf39-092c78e2af16	fafa0645-649b-40d1-bbb4-9dcf17c5d7bc	client-uris-must-match	true
3a31822e-52c9-4e95-bef7-8a08c9446764	fafa0645-649b-40d1-bbb4-9dcf17c5d7bc	host-sending-registration-request-must-match	true
589f8336-b3d9-4585-967b-a47f933d6148	5bd9b148-9eef-46fa-8d06-34efdd2023e7	allowed-protocol-mapper-types	oidc-full-name-mapper
deb24544-74eb-4880-a22f-645dfc22db5a	5bd9b148-9eef-46fa-8d06-34efdd2023e7	allowed-protocol-mapper-types	saml-user-attribute-mapper
3cf19a0f-ac9d-431c-8a51-6a6f8dff724e	5bd9b148-9eef-46fa-8d06-34efdd2023e7	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
4775c9c3-3a70-4109-bc64-3af7151254cc	5bd9b148-9eef-46fa-8d06-34efdd2023e7	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
eb23616f-4e50-4274-bf2a-dca9bd0a8462	5bd9b148-9eef-46fa-8d06-34efdd2023e7	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
86ea912b-1736-41bb-bd95-9e5fa743ee4e	5bd9b148-9eef-46fa-8d06-34efdd2023e7	allowed-protocol-mapper-types	oidc-address-mapper
381fe4a0-1c6b-42d0-aaea-c7fd75df7e87	5bd9b148-9eef-46fa-8d06-34efdd2023e7	allowed-protocol-mapper-types	saml-user-property-mapper
11843975-1fe0-4c87-a5c8-3fbb0d87f4d1	5bd9b148-9eef-46fa-8d06-34efdd2023e7	allowed-protocol-mapper-types	saml-role-list-mapper
0a36f24e-3000-428f-8b55-27b7e1ca13bc	302885f2-52a4-4526-b04c-31d14cef8eb1	allow-default-scopes	true
4f71a3ef-bac6-4fee-8636-9d897fd80acb	b0ab9a2c-979e-43a3-a9ef-e14aa3dccb2c	allow-default-scopes	true
ccdb716d-82bb-48a1-916e-642f9302540e	34743300-fa8e-4bb0-ba29-14d30e0baf64	privateKey	MIIEogIBAAKCAQEAqbUWlOqUClSrV6BrDJhF8TkciICw7qEYw95mxsVkrS1OwT5XSl5lucvBtjraX8o6HMdYddeBG3RqPreV3eO/1M4runuCEhgdIRBj6HYk3fWg5toRgfN1xABKGQ05M7C0Zjv6OwjtpbhcH4BYuJ29UddKCJkvTSoQXSIOqi6gbPiedFFx1LagBbcUYWt0BSwldAZ7Br5hCkfyJzV8anJNAI8oeJcGPL3TUI/iU3tsLO0Pt+QlOuCubpOihryEtaTpPW9zK52zjmsODbwYZilqnj2Mz8SjIsBmO8InC7YoLnlQ0IduzeHlWeKti1nKNvCy7HsADFIqcJWAqAjsbjwu1QIDAQABAoIBACUSipLQZbOWCHIVeJ0hPJI0DDAjkMMoTP0oveHpKBOOpLghMrdrxKQgRzpUQ/UN+8DiqUfg4nLJbRYzS5lT0cmemj3cEi96tg5Ngs261VXpfRNBCvcM5KqC96zeTyMkFFyK+KBh1GxRyEoXYwo9ZyiUM7eKIyOjrzxxHqv9kI0NLZqsZorObiiDkzhqODUsIgmDf+sZCQX7gU8ZniayB9lFuA4BEnUCFqRa/0F9E9+KgbH+RR1drB6zWozGI2udHvh/kpxc9Fz4qvR6Nk8tJ/efzesAbuqJbi5FUnFuNHK4P6d6RKEq8s6pPY3kAfkU+RfgBSZIELmGNry+knLk4wECgYEA0ebgn6+ew8IJyaJfVgoc/WJX7ZhPvdJFtf4qsgRTa3j8uS1K3OnvoZh2wqGmPrDFkvh2+pvMDO7sowzXdGZ4KKcCcp74s6CuJcwkBMjeq48zgDt7Kx8/lX43blPWXqOjpd3yI162o97yTj6ZgJ+1USntpJ1/dyz64CXY/cCroVUCgYEAzvpkc7WMksgO5M3hjpmgPjQl0Gnh1jUchkSnBoLDc8bTlHvMeHcjx/pkJLzMCu+UzSkkbDngE9XC0Sku9JRdzLWHonebFt81a7NFwREOpObvaff6k8ZzHUKyN8eJIsf3xRzyHY0zEgehJQNItSVq2qHoVCQMQGs0IDEgAWQ8V4ECgYBORsNNybhzWFE+GIdlFrBo7dvMhxh1uYy1qetSJ7rUQXI9vF5GtBbhNHJVcuMETffgLzhvjNozmIY25/sRNYVp455OEGq+0hUfk1l7T016vRR/pa7xDd4wablSM4GmGXBV0scR2ahSxDmoZD/qb6S2d+RflzyJvQRxwquBNfDLYQKBgCtlipxMK343HhBRLoLEqTmBm5AYMzbDigiI6nBOCIcE4CXY0yVK7aCnWkntn+aHFy7w+mcKt3XRMvjB5st3NDeQtDCXXVgtUrkTLIPvfJ+MoBQa31oOmOJAsrdJSfKV9NhKWmVhzpxwJxRonN0GTGIs4laJ/FuhXpuFUU2ZY6GBAoGAN+dLSGcJT0oDnGBeO6zDXUIs4uIJ7DZhNMmXuVRzZG8qb6vOyahhYc5rI4jFdM/iz7I7ydMEqhux8LWGk1Jh2GiwDPyZQxnSilZbtYhrf7yhQMpqJlnX7tnDKcjhdiURqBJTfA+Dlx8gUAu7sz9poP41lURQstk2VbDB2keMSAo=
91fec42b-5c95-41c5-8e57-0241f5a043c5	34743300-fa8e-4bb0-ba29-14d30e0baf64	priority	100
efbbf84f-bffb-433d-87b3-dcf829de6109	34743300-fa8e-4bb0-ba29-14d30e0baf64	keyUse	SIG
5e02fb98-e6c4-4f50-8d9e-b6de8a2a1fe2	34743300-fa8e-4bb0-ba29-14d30e0baf64	certificate	MIICmzCCAYMCBgGI0ZmGZzANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZtYXN0ZXIwHhcNMjMwNjE5MDI1OTM5WhcNMzMwNjE5MDMwMTE5WjARMQ8wDQYDVQQDDAZtYXN0ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCptRaU6pQKVKtXoGsMmEXxORyIgLDuoRjD3mbGxWStLU7BPldKXmW5y8G2Otpfyjocx1h114EbdGo+t5Xd47/Uziu6e4ISGB0hEGPodiTd9aDm2hGB83XEAEoZDTkzsLRmO/o7CO2luFwfgFi4nb1R10oImS9NKhBdIg6qLqBs+J50UXHUtqAFtxRha3QFLCV0BnsGvmEKR/InNXxqck0Ajyh4lwY8vdNQj+JTe2ws7Q+35CU64K5uk6KGvIS1pOk9b3MrnbOOaw4NvBhmKWqePYzPxKMiwGY7wicLtigueVDQh27N4eVZ4q2LWco28LLsewAMUipwlYCoCOxuPC7VAgMBAAEwDQYJKoZIhvcNAQELBQADggEBAKCMf/xy3clE2cunI4FFCFMhJmJG6ZQq7aO6lcgALVnXs3stbQNWULWO9lo0LOPMDp2MwJy5jQSgyOpLNL7Y+Q0qGAKPytrgu8bGQogANGhMbKtxzHlWVIQPXDlZibengY3jBOcGNdR/ft1oX36nO8lL5mxps76KxtqMosL7sy5+zk/5CylCVzEtSPypCFkgEyeA7QSaX2JLzHxLGZ6XbkqEbQzdE21fyA4hhw0UT+fXcoP7kzST55q4smNKymj82clZppXERi/xJOy8y51/y5/BbEE7nz0lAqP1w56TZa2z/K/z/QVHewP6UtEh2wsioH+QeGJLDae0JaL9b2Mchm0=
d9399191-f759-4322-847b-28620ff0a4ab	22c9161d-274b-4121-bcda-a0c8f2ac1c9d	priority	100
97bfad59-5cb8-4c7b-87b0-bcdd55b2e7f8	22c9161d-274b-4121-bcda-a0c8f2ac1c9d	privateKey	MIIEpAIBAAKCAQEAlyZEa8UECZvFpDTno7iTKB/uhME/BClJuq4E30s9qPPXQ2RzcSNOwSSow/YLurcIUDhxBBv/09oEJ2bvVspYhHNHE7GuW3qWU9RIFwPN+G5qpKmHB1TsXProYJOxsriaukE4vOWQcUMAZILr61VTevzHRfFMOA2uW4Wx7brhaYmMZ/pnQolopqnyIhTiuSRpeqVmKlM3guXXnqPresOmg2dcYDMcIc5ZlyHgkQ5HJpcw570R1MS0u/i0Fog6nq2IAjbfhxrLMB9vm8WfnH9u4EY3z5a9nFngm9p02x0kH2pZ3qd5yoe+fBb7xNtCKQ68qf8FL6ITzj2qKlixIyjQSQIDAQABAoIBABThdCRQjv07fXNGMmtGDWDxVa8V+eb7mTQ75BprjN9xSDSxhNfatn+CLqUGXEUgEfrwa9R91bq7l0VQ4rw3r0DPosBlack4xy8E2CytxDTkyWtpVr5m4fxPq+3jmXHaL4M5jWVdxWA65FapANR9m3nAaqW5RFFIuo8+31S7M3azvkne5zJk2MNOcd65sK3MY+67PhmFQu6sob9P8GckNm2kIAsHToBSLPMKJTrsuEDQwaDGy2w2VWgw1StpS1FZ8OEsXDUjT61mxFb2+VEeWjAUhAYXxMk9Rbv9fh6tb3SCXDSXUhP9tGNo4n/EHuw5w7KVtuDrxL1kb8BWYlW9vn0CgYEA1YKyln3l9vyUoSLm+dV2ecVBsN5y8r87IA1fHlfVLnuITFo0qu7RVgiKmKuRMUdhL8oJckHWH794jZhZQcjepIzl1eYyHG1wPKs1wBv3CmV7GzLWlzcc3ZD+dzMbyPVYxVzjCgwaRTHWtltwuCxt3jDnDQAXVL5az24dc2NN9pcCgYEAtTqVU7u/ynI5IwszF3SNrmW42fx8c5dG1brcqPgpOpKYhfeNzfbAR3gvMwR4jmf2SU7aGeK246wuVpLjGy525aHc8fKVSJk9AAz/ph5NbcBXbEbCnQf+DUCC0xiozUcaj6BArjJFPGiv3ngmMhiB/nZDifLTK5vDAJpfOg0aLB8CgYEAkSGaS3mgy9a9IRscbk6Pjg5rrNJIyID8q7jrIzEJE+OcrmnSyy4y1YxQyZ41v42JnnZzHVtrNYFtbLJWWcU0sh2kTVWAUpqBZHvsuX1I26RHniFchMVNtb5NerEe/eboRJ/zJG09njNWg/Z8FHT+6b3MEKYzNcN+7ukm07x4zlkCgYBgymsaj3m9bAfsGX0uF8fbzuRNODZXngHtAKH9dJzAda8UTcTkrda/1QaQXuDsXcYCHSULEjTPoBQXlNfKmqRRvIM+jWsBnSYhMtAPLrv30/RdFeW27J/ZAA1fJRpymHktIE+rOZoUy2yyisULmF9FQnCL6q6x6bzaQ5h8bqb9zQKBgQCDetn4peAv4Isuy+Fqd5AfKPjBzYIwSUgRtcws5/OoIRTKAY0dMuS51zS+Wz4nnJo96erWDGtPXxbyA0xbbLafxWjqsVpKVl3nMzWqYhlc+X84FGw9CjQbGZdB9mIYvWHozHQ0KV7/wVonUSoyUv3Pp5JBrfQ2nimmWahQmj1dPw==
e388bb6f-6c9c-4500-ac34-67f2b1db24ee	22c9161d-274b-4121-bcda-a0c8f2ac1c9d	algorithm	RSA-OAEP
d3086065-4fd0-4ca0-8ad6-bdde50300db7	22c9161d-274b-4121-bcda-a0c8f2ac1c9d	certificate	MIICmzCCAYMCBgGI0ZmICDANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZtYXN0ZXIwHhcNMjMwNjE5MDI1OTQwWhcNMzMwNjE5MDMwMTIwWjARMQ8wDQYDVQQDDAZtYXN0ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCXJkRrxQQJm8WkNOejuJMoH+6EwT8EKUm6rgTfSz2o89dDZHNxI07BJKjD9gu6twhQOHEEG//T2gQnZu9WyliEc0cTsa5bepZT1EgXA834bmqkqYcHVOxc+uhgk7GyuJq6QTi85ZBxQwBkguvrVVN6/MdF8Uw4Da5bhbHtuuFpiYxn+mdCiWimqfIiFOK5JGl6pWYqUzeC5deeo+t6w6aDZ1xgMxwhzlmXIeCRDkcmlzDnvRHUxLS7+LQWiDqerYgCNt+HGsswH2+bxZ+cf27gRjfPlr2cWeCb2nTbHSQfalnep3nKh758FvvE20IpDryp/wUvohPOPaoqWLEjKNBJAgMBAAEwDQYJKoZIhvcNAQELBQADggEBAD2oOYHlMwMdamyYCGjJGJf9NcrwVcGa6BPQ3SVuZOhQ7dPMlqN8ZST907QxtWQS2zyoWgUJU1VVZ4X0u1I3F5OcE40TxlolzHJAr5kUjGF0V+4JRG5RDvagIQchV6eIVzAnr1IsmFtQ8OhRjrH1DciwOIyKU2vL+DWr/3Vgxup/PHBnp2bDyvZOsoFRw4rMCcGs/TqUJtluLThfMcjxFUnlNqWXaGeoPXmZZLAf01ad8KLDIyVdZ3b3VbhuKF2IgLeMs1At2Hf5F4zpx7h60RnEzZs8mY7lgt+cVICkyAYc2tGFeIAw4OQbe1StH+qLfwT1ePmIbHkKxH8sZKlJKY4=
09618833-5332-4578-9b44-6b80a8459311	22c9161d-274b-4121-bcda-a0c8f2ac1c9d	keyUse	ENC
cd16ff60-a6a5-4dac-885e-1734bfce3bd6	ec06afbd-d38d-4505-90c4-789fd55d6471	secret	l5sR80WtMGucCmQO23u2yQ
b21e3291-4452-4f08-96ca-4a5a2f4e78f3	ec06afbd-d38d-4505-90c4-789fd55d6471	priority	100
37bff1a5-6095-4ec4-b01d-887ac30b0cd3	ec06afbd-d38d-4505-90c4-789fd55d6471	kid	98322c6a-4cb9-4b0c-aa28-4c699a265d97
312902f3-67f6-413d-b6e0-07789269b4ee	f2840e7a-2068-4013-9d6b-6bcf73db2263	algorithm	HS256
9c09c976-6c30-4c8a-b116-a4c8f07b84af	f2840e7a-2068-4013-9d6b-6bcf73db2263	secret	WkQtj0IjZrWIlYeNIcbqLDk8brMq5dpEiulNiv8_E30qzzJDiAruNb_9wuQnKXGZ85K2JJlOWjsZBdBeZ41m2Q
5bfcf3e3-4c2e-4b1b-9550-f94547f34690	f2840e7a-2068-4013-9d6b-6bcf73db2263	priority	100
7c21025b-1662-4683-96c6-526b7d32e423	f2840e7a-2068-4013-9d6b-6bcf73db2263	kid	39dfc8d8-2d76-4b48-b801-ecba60ce7c13
15e68ce2-196e-414d-a80a-94254bbf2fe7	d56cdec7-6a5f-40ad-800f-ab5092ac1c00	algorithm	HS256
24a1c675-5c07-4744-a743-acfaeb98c8cf	d56cdec7-6a5f-40ad-800f-ab5092ac1c00	secret	bkcROl2bmbQWiCpDkTA69J9OSgMqs-fRCtpbQZw6HEhDT_37CTGyZHgklkExEopBVByq3z7FTjBaZjrNzqUA4Q
1e763a3e-2056-41b1-9f1f-236664288505	d56cdec7-6a5f-40ad-800f-ab5092ac1c00	kid	6a232ada-412e-464b-a95f-69ec77199994
dcb5c279-6e77-46aa-a9d3-5830179c480a	d56cdec7-6a5f-40ad-800f-ab5092ac1c00	priority	100
277847fc-d53a-4dd2-bf43-f292eefc251c	3fd3805c-e371-449c-adb6-bd7375a11a42	max-clients	200
13e6cc9e-90ff-4959-aa6f-64b6b87c306b	52b4d82e-484c-411c-9644-c1ca8bd4e513	host-sending-registration-request-must-match	true
2326cebd-e35d-43fe-a8f2-083cce95a256	52b4d82e-484c-411c-9644-c1ca8bd4e513	client-uris-must-match	true
58c76ec5-37f9-427d-b810-1dfebabfabd1	93bc66e1-e7e8-4915-a30b-189312230aa6	certificate	MIICozCCAYsCBgGI0Zpj5DANBgkqhkiG9w0BAQsFADAVMRMwEQYDVQQDDApPbi1wcmVtaXNlMB4XDTIzMDYxOTAzMDAzNloXDTMzMDYxOTAzMDIxNlowFTETMBEGA1UEAwwKT24tcHJlbWlzZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALO3hLVNEkpjgfEAsnnrARYN0NOzm7H/cGXYEJYs+dVBKSKGCFFWqZ8ytk70K7zrOlPyKvyLDxwcr5zUYtLZkAPSPcyt99aH3Pm4206I6m/CTBUIZvapxdTczpWKzC4p1e7QX8a+kaX8sGCKTwdaWk4tjyYP6OxGXzjv8udsJM7hXJUdDDNNGrVysFTG1tiUvFvNIw9MXEa/33bT2fwW9xiFmB0bWR/Hhdq9/gK0f4Vh9UgSuScOG0l0ED93VM8CznVBrloHfwUZSOKkrGUpQJHuWdexa2GdmW2qLJLKFzl9YytiLpX1jCHeG8ntOTHHtBjrI/tPNayKg+c84uJbhNsCAwEAATANBgkqhkiG9w0BAQsFAAOCAQEAE8EVpqLW9NY0kbbMihHo9ck/eOzfN9t9DaoJ4IlAzMFTtsyJQlG2KUYLOcdw6hmnXK5R/wTQeeK4xqBtEI17UC6RNAzcWVHGjU3/KgntEea82+7eJRBNmiJoItwchIM/RTgm4K7dJR/P8SPury5qp2hlHPsCMfgkrL/ERyPf7pCivDNF36b7BeoqaT5m1oQN6UyH90zlYLqkUBaCuwyo22WL+1qEN/Xbmr1zrMeN7JB0s+zHoV3lm9unW5zEWG76cmLXZLk/4F/CCNoBEHY52HL+L7ucmtmSkpG3al1ufoYbPftPZrlYVaNgkVjNgqqDauwYGuE1GEly4e9JO3RbWw==
01c9cf38-dfe7-4cfb-b545-aac3b1bdfc26	93bc66e1-e7e8-4915-a30b-189312230aa6	priority	100
11d787df-2189-4a28-838e-f1fcb447deb0	93bc66e1-e7e8-4915-a30b-189312230aa6	privateKey	MIIEowIBAAKCAQEAs7eEtU0SSmOB8QCyeesBFg3Q07Obsf9wZdgQliz51UEpIoYIUVapnzK2TvQrvOs6U/Iq/IsPHByvnNRi0tmQA9I9zK331ofc+bjbTojqb8JMFQhm9qnF1NzOlYrMLinV7tBfxr6RpfywYIpPB1paTi2PJg/o7EZfOO/y52wkzuFclR0MM00atXKwVMbW2JS8W80jD0xcRr/fdtPZ/Bb3GIWYHRtZH8eF2r3+ArR/hWH1SBK5Jw4bSXQQP3dUzwLOdUGuWgd/BRlI4qSsZSlAke5Z17FrYZ2ZbaosksoXOX1jK2IulfWMId4bye05Mce0GOsj+081rIqD5zzi4luE2wIDAQABAoIBAAK+IBQvlGy2ibhMBUKaD7QD9aC9eCNRHX3YZyG7lvvRA5fcyXS1qLS0GUHUNR9WzFbqoQr7SPmUsH4UDwazvksTTXvPAzNuyF8L71Y1UwqYlwD9K1Zury+5R50oTJxpvrOR0jGzcn/rfs+XshllIMVaVE8a5WLxt1NO9NCLqct5xg92uVTpcPEzxW64I6nLRRZAU6XXvJnvwcFdKfoWTBd2ApPjTF155Jy9i/tHn32WoxzNY/OqECOKGS7hRnel99ytXw4RnNH99wGqlMoj1aBcTF7qtAuucpzWrQcHm5C7PtDcE0hmhwgkLHmD8UXk+vRRA/js1QeX8cMDfeWxYxECgYEA8n2tSd5LjUlYuKL8lorsYcRKhjqf06MB/FVptTOMdC21tC/X78EbUd50iwWTawFAfMq3jf8jpjcwKylXozAlo5mTV2LJM2drYYRxBCTXzkI5gL+qcLwBL3qUMNRGApoKBRiKylqCkfSVAr2o+J5o6EQkeEc5H54QvJrY9FLAEgsCgYEAvbqUSQ8PU38dmg8nR3HOsVA0nTbHH/545ng/Wq714eWJ9iA7Bzmp1Yu11TxIAHRmOqYYYkz7sxJ14KfGMMP+hkhyIVup6UJFr9WVW+BuLG2Ah+Z7Bc+BHy3sxBBCfQ1OBzwJI4Yb+BYGsJyP/AVVntWt+3MJrw2ATL+MhiAxanECgYBE3ZQ9CjiCo3Xi2cbKKiH/kfNoM3X4cK67rrYak80roV+dEIlOuZS8p2SJpse699wMlLWUSgUhy0KOv2r4GVBXKeJCSvfA9Xn1c9t0xdHT7dLO0Z/h7EKZ7UHwrBhF3OFDmTixRwsV0FQRNzOph7NbYx7IWdHLPOSb6435tRZ/CQKBgDIFBJ8WR1YeBzHcmOBvEq0Qli50iJ7YugsY3KsNwWli2LJ44NcQzsOr565mDB2CkokXzQntfdZCIa2uzcOBiJLieqRsxCjo/fJTfuMQEjvISsCJdRmdEU+lDezK1Jyfa1jg7Q/ehXUsaWsae6NXzLDpaMsIEx+BkbeqMGQUDLMhAoGBAKGPhN4zuUZXtrjpKo+p+WTBAIWwGTiG+KxeeSrNoIVc0TV4VfrnVWvBo32tEm4WYakR4l3zYQtTB0PoyonnAbqn12qIO+VKiPWnUoZv+0owzoZUAreJ1W5hPm8KSwF7QB3EhZQk9mEKiuGzIktoDHgn/arrFH2oPPbl7B3wUR4Q
7b54ae38-73b9-4f50-8829-1de46ca3f283	2a4271b6-e4ce-45d7-ad60-def6e56a51aa	kid	484f636f-ba94-459d-bca0-a65d66ca0ed8
f77129ff-af1b-4681-bec5-5d6fd4bf3383	2a4271b6-e4ce-45d7-ad60-def6e56a51aa	priority	100
309fb7a7-fd6e-4a3d-9cf7-b55d1efa9257	2a4271b6-e4ce-45d7-ad60-def6e56a51aa	secret	Sg3-IlmplXWIF2c18fkoWA
0ff9ece8-2fdc-4bb7-b778-fbd024634c12	98959d63-700b-40c1-98cd-18edf25df8fe	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
dd30f791-6323-4092-8a4e-6fa14179f1ef	98959d63-700b-40c1-98cd-18edf25df8fe	allowed-protocol-mapper-types	oidc-full-name-mapper
2e527d56-62e4-421f-984a-bec445b8e9cd	98959d63-700b-40c1-98cd-18edf25df8fe	allowed-protocol-mapper-types	saml-user-attribute-mapper
49b59db4-17b4-414e-bf40-885e87a7ea88	98959d63-700b-40c1-98cd-18edf25df8fe	allowed-protocol-mapper-types	saml-user-property-mapper
db4f303f-dd43-4a69-9b8c-97cf30538c4d	98959d63-700b-40c1-98cd-18edf25df8fe	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
056492b6-1598-401d-9dc1-163d3d27ac4e	98959d63-700b-40c1-98cd-18edf25df8fe	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
dd1c677b-09f2-4e96-ab1e-71fca0cc9214	98959d63-700b-40c1-98cd-18edf25df8fe	allowed-protocol-mapper-types	oidc-address-mapper
df58803d-e1a5-4d5b-bdad-687169c677f2	98959d63-700b-40c1-98cd-18edf25df8fe	allowed-protocol-mapper-types	saml-role-list-mapper
67666762-f802-4c2d-a201-cd7d056c29e3	a99c7d98-7312-4c31-8db7-3aad3254e805	allow-default-scopes	true
f1d0eba2-1499-4ea8-9c4f-64ff2f76da52	b84452da-cbd1-4077-bd02-b1130551ac9f	privateKey	MIIEogIBAAKCAQEAsE/wVOpeL4pnJtiaXUrhPh203pXwYGGfJMjlh8Wk1QlwSUfPOMtDR+L7bKn8S9UkcPHCWDDxvqOOGecjNtTcZvzZCQxcEOJEcMpyJQnbSPOvhTekXNyv8IJdTpLcMKNCwHoIwbk//mA5UxvLC1n7X4GVP6Yxptl8L3crgkcTP9a3Pm5FGPe9+Mln1JWlThMIwmSvb39C16gR8xotRaU9eExHNwdB8vOWKDuJkDVsPufx8Vbs0uwJP+vqKssnsgZxIkIOe2W/lEMJcQh+LgUhYQKQkMvLjX9fey0EZJq/BMC2Q0/sGTS6M8xC/awEK/XFyjKMYB9X/IQDslhYaSMjzwIDAQABAoIBAAiCu1OmAojh8eu+nejt8eR5M59g9nr4i2GPrwC4SiYccAahiD+yFBvWuZM7u1l/vuQSz3JJXon4xCW88ga2DLON9f4JUjJgcbROGWdvS94AIVNZZb4zyuxdppph3W4dm13GJkEPq6agR3QbDdiM7eTk0OsDHzdyHRv/cSK3QpcctjTz7N35+LZfRJZdV3tfbBd4RsQYqGYB4SqzPgCyPkkFYlF7bd/VLFxAu3oBvVWtzUOzlvqmFJz+PcgMsAeBFHoZIOTKkRG5ftFJcepn3IOFSnHsQxBY/t9vpfxmY2g1Ql7cXxdKgqozI5hW480WaUkMpWENL/hxllVZtBoVGq0CgYEA2LYA4eyX0CpHIkR0kh2tFseR3vu+3uc52u2o3w4KE27/e54QKvvE03PZEgTSq13lqTkvTe9kZzKqJfXPDb2RsbQ+cyyUxCl6PuntBG4cpop9j9y3BDt5NDMpBrQ3+ggY4iOWbWqrtaVqIN28+SiNGgkYlEeMDtb+hyD1vkJC+JUCgYEA0EbzKvCV7gWJwqjGp+iBgJ2HqHyJr9Tk6jgG4BYAzhYc0inBxeZjJIGOtprIurHmko+0fjeQRUR/pnwUAfx1ZYzgsGUSyKeiG0QfTZPnbzHRCF+zwMG7yHB5syetMZ5JLsnYfgVwN+zgeIMGdXgp4orZHXdpaAISjbAsYzjx/dMCgYBX3mw7LuBbclkHZvRRLqE5JFBcNn0tClpmD4kycBHb0Vzb9boeg5lKF6YDbVsySs9NLzekBRYT1fIxlBqROrUxdaEAuCnV4++CRP1ql28cg/jndRnsKGU7qibPZhFwWwoj30QmN2NKMrj2fJIcALo9vURvExeSCNCJX+7kZx+ahQKBgGkoOWQnvntDvo9S6aIjKSeH4dN2tYnaYo3DJe2EDnn+/iQ6QwSpUss+wpB9y/U/FxxOhCHp6eSfNhgXs35hOeDA5T0KexZmVNmRZoCjuYkRzOl+cGJVLnuAFmIXGUHhGjAOZ0kRc9w4tAkEloE+317rHb3b6ZNC4J07It4iBURTAoGAXIle3KJWOc+jK1/KYpfRNJmnpt6tIFPLzgvapd8NhExt3SnVyuZgKlLqPXxBaRtb5+o/K14SCeAOFfV5Dik1YUniZyKI3intCZ8G5FVY4CMzGR6cEC7+kmM5ZYK3RjIAou0ibv6DkYIOkzS66c0Vv7h2V/Qm6eQ5OY2dZsQtXg8=
7c6763fa-dacb-45c0-9b1e-d1970dafe943	b84452da-cbd1-4077-bd02-b1130551ac9f	priority	100
62c4d9b0-3c6c-4244-a08e-3334e99621a2	b84452da-cbd1-4077-bd02-b1130551ac9f	certificate	MIICozCCAYsCBgGI0ZpkUzANBgkqhkiG9w0BAQsFADAVMRMwEQYDVQQDDApPbi1wcmVtaXNlMB4XDTIzMDYxOTAzMDAzNloXDTMzMDYxOTAzMDIxNlowFTETMBEGA1UEAwwKT24tcHJlbWlzZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALBP8FTqXi+KZybYml1K4T4dtN6V8GBhnyTI5YfFpNUJcElHzzjLQ0fi+2yp/EvVJHDxwlgw8b6jjhnnIzbU3Gb82QkMXBDiRHDKciUJ20jzr4U3pFzcr/CCXU6S3DCjQsB6CMG5P/5gOVMbywtZ+1+BlT+mMabZfC93K4JHEz/Wtz5uRRj3vfjJZ9SVpU4TCMJkr29/QteoEfMaLUWlPXhMRzcHQfLzlig7iZA1bD7n8fFW7NLsCT/r6irLJ7IGcSJCDntlv5RDCXEIfi4FIWECkJDLy41/X3stBGSavwTAtkNP7Bk0ujPMQv2sBCv1xcoyjGAfV/yEA7JYWGkjI88CAwEAATANBgkqhkiG9w0BAQsFAAOCAQEAWlFHxTFdTA8LQ+Xve0rkfhpKmOJIYzYO/1woo2LZ+gKguPKpYak1SSEZ5PUIl5xj+lKQHi4mzh/ipNX1vMqmVXl2+b9N8zXVVkCfjruD7lGgQ3iCYpOxaaQXVmvCNyHqig0LT99PpT5cuHz9qCvpFWJjstDXT+8SpGi4OsLnEuN08xq/yAQmjrjL8tZwkr5dFR3hEEo2Sbg2a4Wmskov8dBIV0SNg0rbkMVA5PP9MMBP1QAAl+qsck8NcO77QYaTqbUTvcmMDQGJlCUGzh2u2GZzJeSs/1lrl4dTcKYjtF+fc55cWdxEhxJsSCdqvUyb175TL3v4nxFLFa80L4B1jQ==
8228580e-52e6-44b4-815d-30bb1480580a	b84452da-cbd1-4077-bd02-b1130551ac9f	algorithm	RSA-OAEP
aede48e0-b903-4b5d-99fb-c587e1a49418	052e3758-7f2b-4c65-ad0e-9430d29769e6	allowed-protocol-mapper-types	saml-user-attribute-mapper
1007be18-ee9e-43a1-b095-8c8592815815	052e3758-7f2b-4c65-ad0e-9430d29769e6	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
e751346f-083e-4bdb-a045-4e7a50f5b418	052e3758-7f2b-4c65-ad0e-9430d29769e6	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
f2bed136-3529-4422-a6a3-2933ca7a5f66	052e3758-7f2b-4c65-ad0e-9430d29769e6	allowed-protocol-mapper-types	oidc-full-name-mapper
3168c80a-467d-4757-a0bb-f0215f8b83ac	052e3758-7f2b-4c65-ad0e-9430d29769e6	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
1db97a58-f7e3-4f83-94f7-54b8e75885ce	052e3758-7f2b-4c65-ad0e-9430d29769e6	allowed-protocol-mapper-types	saml-user-property-mapper
f92a4def-c7fc-4bd6-aacf-5d6249500f45	052e3758-7f2b-4c65-ad0e-9430d29769e6	allowed-protocol-mapper-types	saml-role-list-mapper
ad151e4c-ab92-457c-908d-1a1a6bed0453	052e3758-7f2b-4c65-ad0e-9430d29769e6	allowed-protocol-mapper-types	oidc-address-mapper
68bfb0c3-bacc-4bb4-bd63-21cee76f8f38	e34baa09-e3fc-4251-9b60-9928b2f4520d	allow-default-scopes	true
\.


--
-- Data for Name: composite_role; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.composite_role (composite, child_role) FROM stdin;
c7e49872-a95c-4ac9-bd10-147c32a0cf33	90448f36-0397-4c33-8408-435a4bca4b84
c7e49872-a95c-4ac9-bd10-147c32a0cf33	0d7a4a52-d40c-479a-b5a9-d09ee83f4afd
c7e49872-a95c-4ac9-bd10-147c32a0cf33	a64674f3-2115-4d10-a9bd-6fd0029bf5ef
c7e49872-a95c-4ac9-bd10-147c32a0cf33	9145a900-7454-4ddb-80b0-8668799c0cb1
c7e49872-a95c-4ac9-bd10-147c32a0cf33	609fa6d0-ff62-47e0-9f64-04472fcdedcb
c7e49872-a95c-4ac9-bd10-147c32a0cf33	e5139f79-fac9-4014-819d-89969d676ae5
c7e49872-a95c-4ac9-bd10-147c32a0cf33	0802cd38-3054-4412-92b1-6c573b7148d5
c7e49872-a95c-4ac9-bd10-147c32a0cf33	1a266613-626a-493b-9d51-1f94ae05518a
c7e49872-a95c-4ac9-bd10-147c32a0cf33	d4e72fb7-b794-4d89-ab7e-f98a2da460c1
c7e49872-a95c-4ac9-bd10-147c32a0cf33	c205de85-88e3-4cd3-9a4e-7e764628bcac
c7e49872-a95c-4ac9-bd10-147c32a0cf33	6ee985d2-2d4e-4f20-966c-6f56254ef8d1
c7e49872-a95c-4ac9-bd10-147c32a0cf33	999e4a0f-ea2b-4172-85fb-a765fdd392dd
c7e49872-a95c-4ac9-bd10-147c32a0cf33	e46d98fc-4d2e-4ad4-b395-ebd3bb3de9be
c7e49872-a95c-4ac9-bd10-147c32a0cf33	5c8fe8b6-cd89-4c16-9ff7-6d27993dd769
c7e49872-a95c-4ac9-bd10-147c32a0cf33	f984e392-76ec-49cf-afce-6d4ae058b4ba
c7e49872-a95c-4ac9-bd10-147c32a0cf33	e50cad44-ccbd-4aa4-9c79-ab641da4f04c
c7e49872-a95c-4ac9-bd10-147c32a0cf33	6b5243b9-7c1c-4490-a0c0-e6ae5a3f1395
c7e49872-a95c-4ac9-bd10-147c32a0cf33	7261994a-cdc1-4648-bbff-a0ae0f7997cd
609fa6d0-ff62-47e0-9f64-04472fcdedcb	e50cad44-ccbd-4aa4-9c79-ab641da4f04c
9145a900-7454-4ddb-80b0-8668799c0cb1	f984e392-76ec-49cf-afce-6d4ae058b4ba
9145a900-7454-4ddb-80b0-8668799c0cb1	7261994a-cdc1-4648-bbff-a0ae0f7997cd
c83f012e-6f48-41b1-86ba-cfd0d4b627e7	e9c7673a-d9d9-457a-9979-ce377ee173c3
c83f012e-6f48-41b1-86ba-cfd0d4b627e7	6e5f311d-f00d-4291-be03-24217c579ee1
6e5f311d-f00d-4291-be03-24217c579ee1	e1f04f44-4231-423f-aec9-8d33d2024329
85eaf1c2-0c0b-42dc-86b7-a5b8258ae068	5383f398-00ef-43de-b318-e4d77b77d963
c7e49872-a95c-4ac9-bd10-147c32a0cf33	971eeb93-d5c7-4e23-802b-17fd7d8bfbfd
c83f012e-6f48-41b1-86ba-cfd0d4b627e7	0cb8ad12-2b7b-43a3-85f7-94d2965b88f2
c83f012e-6f48-41b1-86ba-cfd0d4b627e7	69deb56b-23a0-48ab-a2df-2964270f85a4
c7e49872-a95c-4ac9-bd10-147c32a0cf33	06f1d0ae-77f8-4dc3-a027-987f514fe058
c7e49872-a95c-4ac9-bd10-147c32a0cf33	74539763-cd50-4957-bc8c-d8404b085829
c7e49872-a95c-4ac9-bd10-147c32a0cf33	b1b40619-025a-4c98-a128-a8eed362adf7
c7e49872-a95c-4ac9-bd10-147c32a0cf33	b4dc1581-7cbd-417b-9cbb-9217caab806f
c7e49872-a95c-4ac9-bd10-147c32a0cf33	8a3759ed-c8f0-49fc-ab90-cdd171ff28f2
c7e49872-a95c-4ac9-bd10-147c32a0cf33	e58bd9ca-9045-495b-9c41-1e250e519ab8
c7e49872-a95c-4ac9-bd10-147c32a0cf33	6d10438f-a980-4e4d-9957-ca4035faf8ae
c7e49872-a95c-4ac9-bd10-147c32a0cf33	5de67731-9d6b-42eb-bd9b-53cc92e7ae9a
c7e49872-a95c-4ac9-bd10-147c32a0cf33	60be1184-9c2f-4521-961f-e22aeb0d5176
c7e49872-a95c-4ac9-bd10-147c32a0cf33	52e32be9-8a01-41df-ad01-ec6e678677bc
c7e49872-a95c-4ac9-bd10-147c32a0cf33	cc4da88c-9298-4e3d-86e4-0caa89d740af
c7e49872-a95c-4ac9-bd10-147c32a0cf33	863b0172-20b5-4e92-87bd-67e17f211d5a
c7e49872-a95c-4ac9-bd10-147c32a0cf33	e0058054-cc40-4d41-a091-b4338c8dfddb
c7e49872-a95c-4ac9-bd10-147c32a0cf33	3f4b9565-3e05-4525-a3c5-188a6ef376ae
c7e49872-a95c-4ac9-bd10-147c32a0cf33	a277648e-96b6-4a3f-b41e-9c6c396ec05c
c7e49872-a95c-4ac9-bd10-147c32a0cf33	1e230aae-0b47-4d34-9b92-fd110fd07bbc
c7e49872-a95c-4ac9-bd10-147c32a0cf33	5b5b0cb4-1e98-41ec-b267-855a93e0f38a
b1b40619-025a-4c98-a128-a8eed362adf7	3f4b9565-3e05-4525-a3c5-188a6ef376ae
b1b40619-025a-4c98-a128-a8eed362adf7	5b5b0cb4-1e98-41ec-b267-855a93e0f38a
b4dc1581-7cbd-417b-9cbb-9217caab806f	a277648e-96b6-4a3f-b41e-9c6c396ec05c
14301fed-c796-4dfc-9688-427859fa5a3d	8f215bd4-c353-467c-a990-30dea2e04962
2ee509b1-2f53-45ee-9673-d71e8e60a78a	20fe2009-0460-4839-8db5-72acc882762b
44056ddc-8fac-46ef-9c6e-be9f4b768ce9	392b2dfa-3566-45ef-a21b-0e3518f8bd8a
44056ddc-8fac-46ef-9c6e-be9f4b768ce9	0d0dc25e-8456-4b9d-be76-5aeb6b8e2aa9
44056ddc-8fac-46ef-9c6e-be9f4b768ce9	f4c2141e-7651-4e28-ae5f-f01f160ce670
44056ddc-8fac-46ef-9c6e-be9f4b768ce9	0a6c0fd7-8037-4c34-a437-bc7fe8f55a51
44056ddc-8fac-46ef-9c6e-be9f4b768ce9	d03f9041-b734-4ea0-ad4f-c8a9c6405715
44056ddc-8fac-46ef-9c6e-be9f4b768ce9	53d6cd2d-49da-42bf-acd7-21d06edd9147
69c368f8-4e0e-4420-93e7-918f504378e4	392b2dfa-3566-45ef-a21b-0e3518f8bd8a
69c368f8-4e0e-4420-93e7-918f504378e4	3ee7ccc9-1bc8-4218-b4fd-834c267f876b
69c368f8-4e0e-4420-93e7-918f504378e4	0d0dc25e-8456-4b9d-be76-5aeb6b8e2aa9
69c368f8-4e0e-4420-93e7-918f504378e4	6bcbf8ef-8206-4b82-8b66-37f18605d4e8
69c368f8-4e0e-4420-93e7-918f504378e4	f4c2141e-7651-4e28-ae5f-f01f160ce670
69c368f8-4e0e-4420-93e7-918f504378e4	2ee509b1-2f53-45ee-9673-d71e8e60a78a
69c368f8-4e0e-4420-93e7-918f504378e4	050929c5-9ab9-4a12-a838-6386eb3fd446
69c368f8-4e0e-4420-93e7-918f504378e4	0a6c0fd7-8037-4c34-a437-bc7fe8f55a51
69c368f8-4e0e-4420-93e7-918f504378e4	d03f9041-b734-4ea0-ad4f-c8a9c6405715
69c368f8-4e0e-4420-93e7-918f504378e4	53d6cd2d-49da-42bf-acd7-21d06edd9147
8e85020a-c3a3-4c72-ba5e-b4268bc85721	44409bce-0213-417f-9d56-99773b859c79
d03f9041-b734-4ea0-ad4f-c8a9c6405715	f4c2141e-7651-4e28-ae5f-f01f160ce670
d03f9041-b734-4ea0-ad4f-c8a9c6405715	af7d6d1e-5bf7-4799-bb7d-bfe5710d8f8a
f961073e-14fb-4e4f-894c-5167fc9a42ce	70fb6a4b-c4a0-4ace-9d57-db0765201a5a
f961073e-14fb-4e4f-894c-5167fc9a42ce	53801b14-d53e-4e86-93a8-39f12ffb1298
f961073e-14fb-4e4f-894c-5167fc9a42ce	f4c2141e-7651-4e28-ae5f-f01f160ce670
f961073e-14fb-4e4f-894c-5167fc9a42ce	f6b60156-2015-491a-9806-f7863ad39a60
f961073e-14fb-4e4f-894c-5167fc9a42ce	af7d6d1e-5bf7-4799-bb7d-bfe5710d8f8a
f961073e-14fb-4e4f-894c-5167fc9a42ce	7027be45-43d8-47f1-a990-687021281335
f961073e-14fb-4e4f-894c-5167fc9a42ce	c660e4db-fbdd-44db-86e3-66acaa901b57
f961073e-14fb-4e4f-894c-5167fc9a42ce	d03f9041-b734-4ea0-ad4f-c8a9c6405715
f961073e-14fb-4e4f-894c-5167fc9a42ce	14301fed-c796-4dfc-9688-427859fa5a3d
f961073e-14fb-4e4f-894c-5167fc9a42ce	392b2dfa-3566-45ef-a21b-0e3518f8bd8a
f961073e-14fb-4e4f-894c-5167fc9a42ce	8f215bd4-c353-467c-a990-30dea2e04962
f961073e-14fb-4e4f-894c-5167fc9a42ce	0d0dc25e-8456-4b9d-be76-5aeb6b8e2aa9
f961073e-14fb-4e4f-894c-5167fc9a42ce	0e54c49c-93ed-4977-9d0b-919126741de6
f961073e-14fb-4e4f-894c-5167fc9a42ce	13d3c77f-6b8d-4345-84f1-6f5f99bb6d2c
f961073e-14fb-4e4f-894c-5167fc9a42ce	ead4cb4d-0d86-4f41-baf3-a23928cd0561
f961073e-14fb-4e4f-894c-5167fc9a42ce	4422c51f-fc48-4fcf-9e04-65ae7a72dc06
f961073e-14fb-4e4f-894c-5167fc9a42ce	0a6c0fd7-8037-4c34-a437-bc7fe8f55a51
f961073e-14fb-4e4f-894c-5167fc9a42ce	53d6cd2d-49da-42bf-acd7-21d06edd9147
c7e49872-a95c-4ac9-bd10-147c32a0cf33	c4b2720e-2733-4c66-ab0b-8d7ae629e5da
\.


--
-- Data for Name: credential; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.credential (id, salt, type, user_id, created_date, user_label, secret_data, credential_data, priority) FROM stdin;
f557622c-1e8e-4aee-a5dc-aac1cea1e069	\N	password	24aab309-a259-4c6e-9546-6d5f601c5538	1687143680712	\N	{"value":"Tn42FV52eR5pcHUQv/cKy6kyb5gYoCrfAhj8YyHZSEHXoi7GH1HJ/I3QIsA6HBwk0m4v0FbtpJnsrbIytiz5Xg==","salt":"fDj3i70UGG5NjsBZsnLFMQ==","additionalParameters":{}}	{"hashIterations":27500,"algorithm":"pbkdf2-sha256","additionalParameters":{}}	10
35007fbf-0848-40dc-86aa-9df12fd7d306	\N	password	8e570c12-99a2-4f26-b30c-796b220467df	1687143768788	My password	{"value":"/P3aP/wBa07gTk8Ev+OFdAsu3iPgTy0cTGX/1T1AbpWouo1Q0W55Xy0KCtWWAd/V+GGQHdQOuflp0OMOyT02lw==","salt":"MqsalidCwXOxgOzMbVvOuw==","additionalParameters":{}}	{"hashIterations":27500,"algorithm":"pbkdf2-sha256","additionalParameters":{}}	10
7b1c416c-f9d2-4fe9-92f6-28cf45e3283d	\N	password	ddb50d3a-b3d8-402b-87be-1cc710809460	1687144253111	\N	{"value":"EVp6ocB1zla3ViFExQwzny4JbMrAY2VKEBeyu+KrJ6suZOqa0rF6bw093gwryJK75Ib+wy83nv3Btc1xgsyLnQ==","salt":"9HuTPgCSGYNm9rucKQTHiQ==","additionalParameters":{}}	{"hashIterations":27500,"algorithm":"pbkdf2-sha256","additionalParameters":{}}	10
b18c841a-4e13-4bd8-855d-ea6ef6fd1ddd	\N	password	5d2b9204-81d3-42ae-9e61-80e2d9bcb83c	1687144652423	\N	{"value":"Qbh9O2IYM/XiM+m4sfNRNfghcvZ3SBGT/AuBf4Ma4vlkqbGqEEImUrkgC6jb5+ZROYt+oldIgOYYEWz3o+VBMQ==","salt":"UiY/kYe1i7Wfy4ZibX5OHQ==","additionalParameters":{}}	{"hashIterations":27500,"algorithm":"pbkdf2-sha256","additionalParameters":{}}	10
\.


--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM stdin;
1.0.0.Final-KEYCLOAK-5461	sthorger@redhat.com	META-INF/jpa-changelog-1.0.0.Final.xml	2023-06-19 03:01:16.123936	1	EXECUTED	8:bda77d94bf90182a1e30c24f1c155ec7	createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...		\N	4.8.0	\N	\N	7143675732
1.0.0.Final-KEYCLOAK-5461	sthorger@redhat.com	META-INF/db2-jpa-changelog-1.0.0.Final.xml	2023-06-19 03:01:16.132165	2	MARK_RAN	8:1ecb330f30986693d1cba9ab579fa219	createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...		\N	4.8.0	\N	\N	7143675732
1.1.0.Beta1	sthorger@redhat.com	META-INF/jpa-changelog-1.1.0.Beta1.xml	2023-06-19 03:01:16.171813	3	EXECUTED	8:cb7ace19bc6d959f305605d255d4c843	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=CLIENT_ATTRIBUTES; createTable tableName=CLIENT_SESSION_NOTE; createTable tableName=APP_NODE_REGISTRATIONS; addColumn table...		\N	4.8.0	\N	\N	7143675732
1.1.0.Final	sthorger@redhat.com	META-INF/jpa-changelog-1.1.0.Final.xml	2023-06-19 03:01:16.175119	4	EXECUTED	8:80230013e961310e6872e871be424a63	renameColumn newColumnName=EVENT_TIME, oldColumnName=TIME, tableName=EVENT_ENTITY		\N	4.8.0	\N	\N	7143675732
1.2.0.Beta1	psilva@redhat.com	META-INF/jpa-changelog-1.2.0.Beta1.xml	2023-06-19 03:01:16.284902	5	EXECUTED	8:67f4c20929126adc0c8e9bf48279d244	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...		\N	4.8.0	\N	\N	7143675732
1.2.0.Beta1	psilva@redhat.com	META-INF/db2-jpa-changelog-1.2.0.Beta1.xml	2023-06-19 03:01:16.287672	6	MARK_RAN	8:7311018b0b8179ce14628ab412bb6783	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...		\N	4.8.0	\N	\N	7143675732
1.2.0.RC1	bburke@redhat.com	META-INF/jpa-changelog-1.2.0.CR1.xml	2023-06-19 03:01:16.387979	7	EXECUTED	8:037ba1216c3640f8785ee6b8e7c8e3c1	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...		\N	4.8.0	\N	\N	7143675732
1.2.0.RC1	bburke@redhat.com	META-INF/db2-jpa-changelog-1.2.0.CR1.xml	2023-06-19 03:01:16.391997	8	MARK_RAN	8:7fe6ffe4af4df289b3157de32c624263	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...		\N	4.8.0	\N	\N	7143675732
1.2.0.Final	keycloak	META-INF/jpa-changelog-1.2.0.Final.xml	2023-06-19 03:01:16.39826	9	EXECUTED	8:9c136bc3187083a98745c7d03bc8a303	update tableName=CLIENT; update tableName=CLIENT; update tableName=CLIENT		\N	4.8.0	\N	\N	7143675732
1.3.0	bburke@redhat.com	META-INF/jpa-changelog-1.3.0.xml	2023-06-19 03:01:16.493476	10	EXECUTED	8:b5f09474dca81fb56a97cf5b6553d331	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=ADMI...		\N	4.8.0	\N	\N	7143675732
1.4.0	bburke@redhat.com	META-INF/jpa-changelog-1.4.0.xml	2023-06-19 03:01:16.565335	11	EXECUTED	8:ca924f31bd2a3b219fdcfe78c82dacf4	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.8.0	\N	\N	7143675732
1.4.0	bburke@redhat.com	META-INF/db2-jpa-changelog-1.4.0.xml	2023-06-19 03:01:16.568294	12	MARK_RAN	8:8acad7483e106416bcfa6f3b824a16cd	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.8.0	\N	\N	7143675732
1.5.0	bburke@redhat.com	META-INF/jpa-changelog-1.5.0.xml	2023-06-19 03:01:16.599211	13	EXECUTED	8:9b1266d17f4f87c78226f5055408fd5e	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.8.0	\N	\N	7143675732
1.6.1_from15	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2023-06-19 03:01:16.6313	14	EXECUTED	8:d80ec4ab6dbfe573550ff72396c7e910	addColumn tableName=REALM; addColumn tableName=KEYCLOAK_ROLE; addColumn tableName=CLIENT; createTable tableName=OFFLINE_USER_SESSION; createTable tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_US_SES_PK2, tableName=...		\N	4.8.0	\N	\N	7143675732
1.6.1_from16-pre	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2023-06-19 03:01:16.634597	15	MARK_RAN	8:d86eb172171e7c20b9c849b584d147b2	delete tableName=OFFLINE_CLIENT_SESSION; delete tableName=OFFLINE_USER_SESSION		\N	4.8.0	\N	\N	7143675732
1.6.1_from16	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2023-06-19 03:01:16.637779	16	MARK_RAN	8:5735f46f0fa60689deb0ecdc2a0dea22	dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_US_SES_PK, tableName=OFFLINE_USER_SESSION; dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_CL_SES_PK, tableName=OFFLINE_CLIENT_SESSION; addColumn tableName=OFFLINE_USER_SESSION; update tableName=OF...		\N	4.8.0	\N	\N	7143675732
1.6.1	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2023-06-19 03:01:16.640521	17	EXECUTED	8:d41d8cd98f00b204e9800998ecf8427e	empty		\N	4.8.0	\N	\N	7143675732
1.7.0	bburke@redhat.com	META-INF/jpa-changelog-1.7.0.xml	2023-06-19 03:01:16.699043	18	EXECUTED	8:5c1a8fd2014ac7fc43b90a700f117b23	createTable tableName=KEYCLOAK_GROUP; createTable tableName=GROUP_ROLE_MAPPING; createTable tableName=GROUP_ATTRIBUTE; createTable tableName=USER_GROUP_MEMBERSHIP; createTable tableName=REALM_DEFAULT_GROUPS; addColumn tableName=IDENTITY_PROVIDER; ...		\N	4.8.0	\N	\N	7143675732
1.8.0	mposolda@redhat.com	META-INF/jpa-changelog-1.8.0.xml	2023-06-19 03:01:16.74871	19	EXECUTED	8:1f6c2c2dfc362aff4ed75b3f0ef6b331	addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...		\N	4.8.0	\N	\N	7143675732
1.8.0-2	keycloak	META-INF/jpa-changelog-1.8.0.xml	2023-06-19 03:01:16.75363	20	EXECUTED	8:dee9246280915712591f83a127665107	dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL		\N	4.8.0	\N	\N	7143675732
authz-3.4.0.CR1-resource-server-pk-change-part1	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2023-06-19 03:01:17.255428	45	EXECUTED	8:a164ae073c56ffdbc98a615493609a52	addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_RESOURCE; addColumn tableName=RESOURCE_SERVER_SCOPE		\N	4.8.0	\N	\N	7143675732
1.8.0	mposolda@redhat.com	META-INF/db2-jpa-changelog-1.8.0.xml	2023-06-19 03:01:16.75645	21	MARK_RAN	8:9eb2ee1fa8ad1c5e426421a6f8fdfa6a	addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...		\N	4.8.0	\N	\N	7143675732
1.8.0-2	keycloak	META-INF/db2-jpa-changelog-1.8.0.xml	2023-06-19 03:01:16.758983	22	MARK_RAN	8:dee9246280915712591f83a127665107	dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL		\N	4.8.0	\N	\N	7143675732
1.9.0	mposolda@redhat.com	META-INF/jpa-changelog-1.9.0.xml	2023-06-19 03:01:16.787688	23	EXECUTED	8:d9fa18ffa355320395b86270680dd4fe	update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=REALM; update tableName=REALM; customChange; dr...		\N	4.8.0	\N	\N	7143675732
1.9.1	keycloak	META-INF/jpa-changelog-1.9.1.xml	2023-06-19 03:01:16.793661	24	EXECUTED	8:90cff506fedb06141ffc1c71c4a1214c	modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=PUBLIC_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM		\N	4.8.0	\N	\N	7143675732
1.9.1	keycloak	META-INF/db2-jpa-changelog-1.9.1.xml	2023-06-19 03:01:16.795782	25	MARK_RAN	8:11a788aed4961d6d29c427c063af828c	modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM		\N	4.8.0	\N	\N	7143675732
1.9.2	keycloak	META-INF/jpa-changelog-1.9.2.xml	2023-06-19 03:01:16.829669	26	EXECUTED	8:a4218e51e1faf380518cce2af5d39b43	createIndex indexName=IDX_USER_EMAIL, tableName=USER_ENTITY; createIndex indexName=IDX_USER_ROLE_MAPPING, tableName=USER_ROLE_MAPPING; createIndex indexName=IDX_USER_GROUP_MAPPING, tableName=USER_GROUP_MEMBERSHIP; createIndex indexName=IDX_USER_CO...		\N	4.8.0	\N	\N	7143675732
authz-2.0.0	psilva@redhat.com	META-INF/jpa-changelog-authz-2.0.0.xml	2023-06-19 03:01:16.914045	27	EXECUTED	8:d9e9a1bfaa644da9952456050f07bbdc	createTable tableName=RESOURCE_SERVER; addPrimaryKey constraintName=CONSTRAINT_FARS, tableName=RESOURCE_SERVER; addUniqueConstraint constraintName=UK_AU8TT6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER; createTable tableName=RESOURCE_SERVER_RESOU...		\N	4.8.0	\N	\N	7143675732
authz-2.5.1	psilva@redhat.com	META-INF/jpa-changelog-authz-2.5.1.xml	2023-06-19 03:01:16.917601	28	EXECUTED	8:d1bf991a6163c0acbfe664b615314505	update tableName=RESOURCE_SERVER_POLICY		\N	4.8.0	\N	\N	7143675732
2.1.0-KEYCLOAK-5461	bburke@redhat.com	META-INF/jpa-changelog-2.1.0.xml	2023-06-19 03:01:16.978736	29	EXECUTED	8:88a743a1e87ec5e30bf603da68058a8c	createTable tableName=BROKER_LINK; createTable tableName=FED_USER_ATTRIBUTE; createTable tableName=FED_USER_CONSENT; createTable tableName=FED_USER_CONSENT_ROLE; createTable tableName=FED_USER_CONSENT_PROT_MAPPER; createTable tableName=FED_USER_CR...		\N	4.8.0	\N	\N	7143675732
2.2.0	bburke@redhat.com	META-INF/jpa-changelog-2.2.0.xml	2023-06-19 03:01:16.992355	30	EXECUTED	8:c5517863c875d325dea463d00ec26d7a	addColumn tableName=ADMIN_EVENT_ENTITY; createTable tableName=CREDENTIAL_ATTRIBUTE; createTable tableName=FED_CREDENTIAL_ATTRIBUTE; modifyDataType columnName=VALUE, tableName=CREDENTIAL; addForeignKeyConstraint baseTableName=FED_CREDENTIAL_ATTRIBU...		\N	4.8.0	\N	\N	7143675732
2.3.0	bburke@redhat.com	META-INF/jpa-changelog-2.3.0.xml	2023-06-19 03:01:17.015209	31	EXECUTED	8:ada8b4833b74a498f376d7136bc7d327	createTable tableName=FEDERATED_USER; addPrimaryKey constraintName=CONSTR_FEDERATED_USER, tableName=FEDERATED_USER; dropDefaultValue columnName=TOTP, tableName=USER_ENTITY; dropColumn columnName=TOTP, tableName=USER_ENTITY; addColumn tableName=IDE...		\N	4.8.0	\N	\N	7143675732
2.4.0	bburke@redhat.com	META-INF/jpa-changelog-2.4.0.xml	2023-06-19 03:01:17.021854	32	EXECUTED	8:b9b73c8ea7299457f99fcbb825c263ba	customChange		\N	4.8.0	\N	\N	7143675732
2.5.0	bburke@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2023-06-19 03:01:17.028928	33	EXECUTED	8:07724333e625ccfcfc5adc63d57314f3	customChange; modifyDataType columnName=USER_ID, tableName=OFFLINE_USER_SESSION		\N	4.8.0	\N	\N	7143675732
2.5.0-unicode-oracle	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2023-06-19 03:01:17.031141	34	MARK_RAN	8:8b6fd445958882efe55deb26fc541a7b	modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...		\N	4.8.0	\N	\N	7143675732
2.5.0-unicode-other-dbs	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2023-06-19 03:01:17.067665	35	EXECUTED	8:29b29cfebfd12600897680147277a9d7	modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...		\N	4.8.0	\N	\N	7143675732
2.5.0-duplicate-email-support	slawomir@dabek.name	META-INF/jpa-changelog-2.5.0.xml	2023-06-19 03:01:17.074788	36	EXECUTED	8:73ad77ca8fd0410c7f9f15a471fa52bc	addColumn tableName=REALM		\N	4.8.0	\N	\N	7143675732
2.5.0-unique-group-names	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2023-06-19 03:01:17.081062	37	EXECUTED	8:64f27a6fdcad57f6f9153210f2ec1bdb	addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.8.0	\N	\N	7143675732
2.5.1	bburke@redhat.com	META-INF/jpa-changelog-2.5.1.xml	2023-06-19 03:01:17.085053	38	EXECUTED	8:27180251182e6c31846c2ddab4bc5781	addColumn tableName=FED_USER_CONSENT		\N	4.8.0	\N	\N	7143675732
3.0.0	bburke@redhat.com	META-INF/jpa-changelog-3.0.0.xml	2023-06-19 03:01:17.089133	39	EXECUTED	8:d56f201bfcfa7a1413eb3e9bc02978f9	addColumn tableName=IDENTITY_PROVIDER		\N	4.8.0	\N	\N	7143675732
3.2.0-fix	keycloak	META-INF/jpa-changelog-3.2.0.xml	2023-06-19 03:01:17.091371	40	MARK_RAN	8:91f5522bf6afdc2077dfab57fbd3455c	addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS		\N	4.8.0	\N	\N	7143675732
3.2.0-fix-with-keycloak-5416	keycloak	META-INF/jpa-changelog-3.2.0.xml	2023-06-19 03:01:17.093251	41	MARK_RAN	8:0f01b554f256c22caeb7d8aee3a1cdc8	dropIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS; addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS; createIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS		\N	4.8.0	\N	\N	7143675732
3.2.0-fix-offline-sessions	hmlnarik	META-INF/jpa-changelog-3.2.0.xml	2023-06-19 03:01:17.098767	42	EXECUTED	8:ab91cf9cee415867ade0e2df9651a947	customChange		\N	4.8.0	\N	\N	7143675732
3.2.0-fixed	keycloak	META-INF/jpa-changelog-3.2.0.xml	2023-06-19 03:01:17.24428	43	EXECUTED	8:ceac9b1889e97d602caf373eadb0d4b7	addColumn tableName=REALM; dropPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_PK2, tableName=OFFLINE_CLIENT_SESSION; dropColumn columnName=CLIENT_SESSION_ID, tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_P...		\N	4.8.0	\N	\N	7143675732
3.3.0	keycloak	META-INF/jpa-changelog-3.3.0.xml	2023-06-19 03:01:17.250731	44	EXECUTED	8:84b986e628fe8f7fd8fd3c275c5259f2	addColumn tableName=USER_ENTITY		\N	4.8.0	\N	\N	7143675732
authz-3.4.0.CR1-resource-server-pk-change-part2-KEYCLOAK-6095	hmlnarik@redhat.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2023-06-19 03:01:17.261403	46	EXECUTED	8:70a2b4f1f4bd4dbf487114bdb1810e64	customChange		\N	4.8.0	\N	\N	7143675732
authz-3.4.0.CR1-resource-server-pk-change-part3-fixed	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2023-06-19 03:01:17.263584	47	MARK_RAN	8:7be68b71d2f5b94b8df2e824f2860fa2	dropIndex indexName=IDX_RES_SERV_POL_RES_SERV, tableName=RESOURCE_SERVER_POLICY; dropIndex indexName=IDX_RES_SRV_RES_RES_SRV, tableName=RESOURCE_SERVER_RESOURCE; dropIndex indexName=IDX_RES_SRV_SCOPE_RES_SRV, tableName=RESOURCE_SERVER_SCOPE		\N	4.8.0	\N	\N	7143675732
authz-3.4.0.CR1-resource-server-pk-change-part3-fixed-nodropindex	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2023-06-19 03:01:17.311256	48	EXECUTED	8:bab7c631093c3861d6cf6144cd944982	addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_POLICY; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_RESOURCE; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, ...		\N	4.8.0	\N	\N	7143675732
authn-3.4.0.CR1-refresh-token-max-reuse	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2023-06-19 03:01:17.315066	49	EXECUTED	8:fa809ac11877d74d76fe40869916daad	addColumn tableName=REALM		\N	4.8.0	\N	\N	7143675732
3.4.0	keycloak	META-INF/jpa-changelog-3.4.0.xml	2023-06-19 03:01:17.364199	50	EXECUTED	8:fac23540a40208f5f5e326f6ceb4d291	addPrimaryKey constraintName=CONSTRAINT_REALM_DEFAULT_ROLES, tableName=REALM_DEFAULT_ROLES; addPrimaryKey constraintName=CONSTRAINT_COMPOSITE_ROLE, tableName=COMPOSITE_ROLE; addPrimaryKey constraintName=CONSTR_REALM_DEFAULT_GROUPS, tableName=REALM...		\N	4.8.0	\N	\N	7143675732
3.4.0-KEYCLOAK-5230	hmlnarik@redhat.com	META-INF/jpa-changelog-3.4.0.xml	2023-06-19 03:01:17.399437	51	EXECUTED	8:2612d1b8a97e2b5588c346e817307593	createIndex indexName=IDX_FU_ATTRIBUTE, tableName=FED_USER_ATTRIBUTE; createIndex indexName=IDX_FU_CONSENT, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CONSENT_RU, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CREDENTIAL, t...		\N	4.8.0	\N	\N	7143675732
3.4.1	psilva@redhat.com	META-INF/jpa-changelog-3.4.1.xml	2023-06-19 03:01:17.403708	52	EXECUTED	8:9842f155c5db2206c88bcb5d1046e941	modifyDataType columnName=VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.8.0	\N	\N	7143675732
3.4.2	keycloak	META-INF/jpa-changelog-3.4.2.xml	2023-06-19 03:01:17.407252	53	EXECUTED	8:2e12e06e45498406db72d5b3da5bbc76	update tableName=REALM		\N	4.8.0	\N	\N	7143675732
3.4.2-KEYCLOAK-5172	mkanis@redhat.com	META-INF/jpa-changelog-3.4.2.xml	2023-06-19 03:01:17.410512	54	EXECUTED	8:33560e7c7989250c40da3abdabdc75a4	update tableName=CLIENT		\N	4.8.0	\N	\N	7143675732
4.0.0-KEYCLOAK-6335	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2023-06-19 03:01:17.417111	55	EXECUTED	8:87a8d8542046817a9107c7eb9cbad1cd	createTable tableName=CLIENT_AUTH_FLOW_BINDINGS; addPrimaryKey constraintName=C_CLI_FLOW_BIND, tableName=CLIENT_AUTH_FLOW_BINDINGS		\N	4.8.0	\N	\N	7143675732
4.0.0-CLEANUP-UNUSED-TABLE	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2023-06-19 03:01:17.422529	56	EXECUTED	8:3ea08490a70215ed0088c273d776311e	dropTable tableName=CLIENT_IDENTITY_PROV_MAPPING		\N	4.8.0	\N	\N	7143675732
4.0.0-KEYCLOAK-6228	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2023-06-19 03:01:17.448574	57	EXECUTED	8:2d56697c8723d4592ab608ce14b6ed68	dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; dropNotNullConstraint columnName=CLIENT_ID, tableName=USER_CONSENT; addColumn tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHO...		\N	4.8.0	\N	\N	7143675732
4.0.0-KEYCLOAK-5579-fixed	mposolda@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2023-06-19 03:01:17.552867	58	EXECUTED	8:3e423e249f6068ea2bbe48bf907f9d86	dropForeignKeyConstraint baseTableName=CLIENT_TEMPLATE_ATTRIBUTES, constraintName=FK_CL_TEMPL_ATTR_TEMPL; renameTable newTableName=CLIENT_SCOPE_ATTRIBUTES, oldTableName=CLIENT_TEMPLATE_ATTRIBUTES; renameColumn newColumnName=SCOPE_ID, oldColumnName...		\N	4.8.0	\N	\N	7143675732
authz-4.0.0.CR1	psilva@redhat.com	META-INF/jpa-changelog-authz-4.0.0.CR1.xml	2023-06-19 03:01:17.580871	59	EXECUTED	8:15cabee5e5df0ff099510a0fc03e4103	createTable tableName=RESOURCE_SERVER_PERM_TICKET; addPrimaryKey constraintName=CONSTRAINT_FAPMT, tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRHO213XCX4WNKOG82SSPMT...		\N	4.8.0	\N	\N	7143675732
authz-4.0.0.Beta3	psilva@redhat.com	META-INF/jpa-changelog-authz-4.0.0.Beta3.xml	2023-06-19 03:01:17.585763	60	EXECUTED	8:4b80200af916ac54d2ffbfc47918ab0e	addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRPO2128CX4WNKOG82SSRFY, referencedTableName=RESOURCE_SERVER_POLICY		\N	4.8.0	\N	\N	7143675732
authz-4.2.0.Final	mhajas@redhat.com	META-INF/jpa-changelog-authz-4.2.0.Final.xml	2023-06-19 03:01:17.597105	61	EXECUTED	8:66564cd5e168045d52252c5027485bbb	createTable tableName=RESOURCE_URIS; addForeignKeyConstraint baseTableName=RESOURCE_URIS, constraintName=FK_RESOURCE_SERVER_URIS, referencedTableName=RESOURCE_SERVER_RESOURCE; customChange; dropColumn columnName=URI, tableName=RESOURCE_SERVER_RESO...		\N	4.8.0	\N	\N	7143675732
authz-4.2.0.Final-KEYCLOAK-9944	hmlnarik@redhat.com	META-INF/jpa-changelog-authz-4.2.0.Final.xml	2023-06-19 03:01:17.601275	62	EXECUTED	8:1c7064fafb030222be2bd16ccf690f6f	addPrimaryKey constraintName=CONSTRAINT_RESOUR_URIS_PK, tableName=RESOURCE_URIS		\N	4.8.0	\N	\N	7143675732
4.2.0-KEYCLOAK-6313	wadahiro@gmail.com	META-INF/jpa-changelog-4.2.0.xml	2023-06-19 03:01:17.604325	63	EXECUTED	8:2de18a0dce10cdda5c7e65c9b719b6e5	addColumn tableName=REQUIRED_ACTION_PROVIDER		\N	4.8.0	\N	\N	7143675732
4.3.0-KEYCLOAK-7984	wadahiro@gmail.com	META-INF/jpa-changelog-4.3.0.xml	2023-06-19 03:01:17.607305	64	EXECUTED	8:03e413dd182dcbd5c57e41c34d0ef682	update tableName=REQUIRED_ACTION_PROVIDER		\N	4.8.0	\N	\N	7143675732
4.6.0-KEYCLOAK-7950	psilva@redhat.com	META-INF/jpa-changelog-4.6.0.xml	2023-06-19 03:01:17.610857	65	EXECUTED	8:d27b42bb2571c18fbe3fe4e4fb7582a7	update tableName=RESOURCE_SERVER_RESOURCE		\N	4.8.0	\N	\N	7143675732
4.6.0-KEYCLOAK-8377	keycloak	META-INF/jpa-changelog-4.6.0.xml	2023-06-19 03:01:17.622786	66	EXECUTED	8:698baf84d9fd0027e9192717c2154fb8	createTable tableName=ROLE_ATTRIBUTE; addPrimaryKey constraintName=CONSTRAINT_ROLE_ATTRIBUTE_PK, tableName=ROLE_ATTRIBUTE; addForeignKeyConstraint baseTableName=ROLE_ATTRIBUTE, constraintName=FK_ROLE_ATTRIBUTE_ID, referencedTableName=KEYCLOAK_ROLE...		\N	4.8.0	\N	\N	7143675732
4.6.0-KEYCLOAK-8555	gideonray@gmail.com	META-INF/jpa-changelog-4.6.0.xml	2023-06-19 03:01:17.629057	67	EXECUTED	8:ced8822edf0f75ef26eb51582f9a821a	createIndex indexName=IDX_COMPONENT_PROVIDER_TYPE, tableName=COMPONENT		\N	4.8.0	\N	\N	7143675732
4.7.0-KEYCLOAK-1267	sguilhen@redhat.com	META-INF/jpa-changelog-4.7.0.xml	2023-06-19 03:01:17.634623	68	EXECUTED	8:f0abba004cf429e8afc43056df06487d	addColumn tableName=REALM		\N	4.8.0	\N	\N	7143675732
4.7.0-KEYCLOAK-7275	keycloak	META-INF/jpa-changelog-4.7.0.xml	2023-06-19 03:01:17.64809	69	EXECUTED	8:6662f8b0b611caa359fcf13bf63b4e24	renameColumn newColumnName=CREATED_ON, oldColumnName=LAST_SESSION_REFRESH, tableName=OFFLINE_USER_SESSION; addNotNullConstraint columnName=CREATED_ON, tableName=OFFLINE_USER_SESSION; addColumn tableName=OFFLINE_USER_SESSION; customChange; createIn...		\N	4.8.0	\N	\N	7143675732
4.8.0-KEYCLOAK-8835	sguilhen@redhat.com	META-INF/jpa-changelog-4.8.0.xml	2023-06-19 03:01:17.653671	70	EXECUTED	8:9e6b8009560f684250bdbdf97670d39e	addNotNullConstraint columnName=SSO_MAX_LIFESPAN_REMEMBER_ME, tableName=REALM; addNotNullConstraint columnName=SSO_IDLE_TIMEOUT_REMEMBER_ME, tableName=REALM		\N	4.8.0	\N	\N	7143675732
authz-7.0.0-KEYCLOAK-10443	psilva@redhat.com	META-INF/jpa-changelog-authz-7.0.0.xml	2023-06-19 03:01:17.657939	71	EXECUTED	8:4223f561f3b8dc655846562b57bb502e	addColumn tableName=RESOURCE_SERVER		\N	4.8.0	\N	\N	7143675732
8.0.0-adding-credential-columns	keycloak	META-INF/jpa-changelog-8.0.0.xml	2023-06-19 03:01:17.664925	72	EXECUTED	8:215a31c398b363ce383a2b301202f29e	addColumn tableName=CREDENTIAL; addColumn tableName=FED_USER_CREDENTIAL		\N	4.8.0	\N	\N	7143675732
8.0.0-updating-credential-data-not-oracle-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2023-06-19 03:01:17.676025	73	EXECUTED	8:83f7a671792ca98b3cbd3a1a34862d3d	update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL		\N	4.8.0	\N	\N	7143675732
8.0.0-updating-credential-data-oracle-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2023-06-19 03:01:17.678724	74	MARK_RAN	8:f58ad148698cf30707a6efbdf8061aa7	update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL		\N	4.8.0	\N	\N	7143675732
8.0.0-credential-cleanup-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2023-06-19 03:01:17.70687	75	EXECUTED	8:79e4fd6c6442980e58d52ffc3ee7b19c	dropDefaultValue columnName=COUNTER, tableName=CREDENTIAL; dropDefaultValue columnName=DIGITS, tableName=CREDENTIAL; dropDefaultValue columnName=PERIOD, tableName=CREDENTIAL; dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; dropColumn ...		\N	4.8.0	\N	\N	7143675732
8.0.0-resource-tag-support	keycloak	META-INF/jpa-changelog-8.0.0.xml	2023-06-19 03:01:17.718484	76	EXECUTED	8:87af6a1e6d241ca4b15801d1f86a297d	addColumn tableName=MIGRATION_MODEL; createIndex indexName=IDX_UPDATE_TIME, tableName=MIGRATION_MODEL		\N	4.8.0	\N	\N	7143675732
9.0.0-always-display-client	keycloak	META-INF/jpa-changelog-9.0.0.xml	2023-06-19 03:01:17.726219	77	EXECUTED	8:b44f8d9b7b6ea455305a6d72a200ed15	addColumn tableName=CLIENT		\N	4.8.0	\N	\N	7143675732
9.0.0-drop-constraints-for-column-increase	keycloak	META-INF/jpa-changelog-9.0.0.xml	2023-06-19 03:01:17.729122	78	MARK_RAN	8:2d8ed5aaaeffd0cb004c046b4a903ac5	dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5PMT, tableName=RESOURCE_SERVER_PERM_TICKET; dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER_RESOURCE; dropPrimaryKey constraintName=CONSTRAINT_O...		\N	4.8.0	\N	\N	7143675732
9.0.0-increase-column-size-federated-fk	keycloak	META-INF/jpa-changelog-9.0.0.xml	2023-06-19 03:01:17.75405	79	EXECUTED	8:e290c01fcbc275326c511633f6e2acde	modifyDataType columnName=CLIENT_ID, tableName=FED_USER_CONSENT; modifyDataType columnName=CLIENT_REALM_CONSTRAINT, tableName=KEYCLOAK_ROLE; modifyDataType columnName=OWNER, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=CLIENT_ID, ta...		\N	4.8.0	\N	\N	7143675732
9.0.0-recreate-constraints-after-column-increase	keycloak	META-INF/jpa-changelog-9.0.0.xml	2023-06-19 03:01:17.759682	80	MARK_RAN	8:c9db8784c33cea210872ac2d805439f8	addNotNullConstraint columnName=CLIENT_ID, tableName=OFFLINE_CLIENT_SESSION; addNotNullConstraint columnName=OWNER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNullConstraint columnName=REQUESTER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNull...		\N	4.8.0	\N	\N	7143675732
9.0.1-add-index-to-client.client_id	keycloak	META-INF/jpa-changelog-9.0.1.xml	2023-06-19 03:01:17.767712	81	EXECUTED	8:95b676ce8fc546a1fcfb4c92fae4add5	createIndex indexName=IDX_CLIENT_ID, tableName=CLIENT		\N	4.8.0	\N	\N	7143675732
9.0.1-KEYCLOAK-12579-drop-constraints	keycloak	META-INF/jpa-changelog-9.0.1.xml	2023-06-19 03:01:17.772372	82	MARK_RAN	8:38a6b2a41f5651018b1aca93a41401e5	dropUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.8.0	\N	\N	7143675732
9.0.1-KEYCLOAK-12579-add-not-null-constraint	keycloak	META-INF/jpa-changelog-9.0.1.xml	2023-06-19 03:01:17.780375	83	EXECUTED	8:3fb99bcad86a0229783123ac52f7609c	addNotNullConstraint columnName=PARENT_GROUP, tableName=KEYCLOAK_GROUP		\N	4.8.0	\N	\N	7143675732
9.0.1-KEYCLOAK-12579-recreate-constraints	keycloak	META-INF/jpa-changelog-9.0.1.xml	2023-06-19 03:01:17.78306	84	MARK_RAN	8:64f27a6fdcad57f6f9153210f2ec1bdb	addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.8.0	\N	\N	7143675732
9.0.1-add-index-to-events	keycloak	META-INF/jpa-changelog-9.0.1.xml	2023-06-19 03:01:17.792734	85	EXECUTED	8:ab4f863f39adafd4c862f7ec01890abc	createIndex indexName=IDX_EVENT_TIME, tableName=EVENT_ENTITY		\N	4.8.0	\N	\N	7143675732
map-remove-ri	keycloak	META-INF/jpa-changelog-11.0.0.xml	2023-06-19 03:01:17.80208	86	EXECUTED	8:13c419a0eb336e91ee3a3bf8fda6e2a7	dropForeignKeyConstraint baseTableName=REALM, constraintName=FK_TRAF444KK6QRKMS7N56AIWQ5Y; dropForeignKeyConstraint baseTableName=KEYCLOAK_ROLE, constraintName=FK_KJHO5LE2C0RAL09FL8CM9WFW9		\N	4.8.0	\N	\N	7143675732
map-remove-ri	keycloak	META-INF/jpa-changelog-12.0.0.xml	2023-06-19 03:01:17.819111	87	EXECUTED	8:e3fb1e698e0471487f51af1ed80fe3ac	dropForeignKeyConstraint baseTableName=REALM_DEFAULT_GROUPS, constraintName=FK_DEF_GROUPS_GROUP; dropForeignKeyConstraint baseTableName=REALM_DEFAULT_ROLES, constraintName=FK_H4WPD7W4HSOOLNI3H0SW7BTJE; dropForeignKeyConstraint baseTableName=CLIENT...		\N	4.8.0	\N	\N	7143675732
12.1.0-add-realm-localization-table	keycloak	META-INF/jpa-changelog-12.0.0.xml	2023-06-19 03:01:17.834102	88	EXECUTED	8:babadb686aab7b56562817e60bf0abd0	createTable tableName=REALM_LOCALIZATIONS; addPrimaryKey tableName=REALM_LOCALIZATIONS		\N	4.8.0	\N	\N	7143675732
default-roles	keycloak	META-INF/jpa-changelog-13.0.0.xml	2023-06-19 03:01:17.891158	89	EXECUTED	8:72d03345fda8e2f17093d08801947773	addColumn tableName=REALM; customChange		\N	4.8.0	\N	\N	7143675732
default-roles-cleanup	keycloak	META-INF/jpa-changelog-13.0.0.xml	2023-06-19 03:01:17.964128	90	EXECUTED	8:61c9233951bd96ffecd9ba75f7d978a4	dropTable tableName=REALM_DEFAULT_ROLES; dropTable tableName=CLIENT_DEFAULT_ROLES		\N	4.8.0	\N	\N	7143675732
13.0.0-KEYCLOAK-16844	keycloak	META-INF/jpa-changelog-13.0.0.xml	2023-06-19 03:01:17.969169	91	EXECUTED	8:ea82e6ad945cec250af6372767b25525	createIndex indexName=IDX_OFFLINE_USS_PRELOAD, tableName=OFFLINE_USER_SESSION		\N	4.8.0	\N	\N	7143675732
map-remove-ri-13.0.0	keycloak	META-INF/jpa-changelog-13.0.0.xml	2023-06-19 03:01:17.975566	92	EXECUTED	8:d3f4a33f41d960ddacd7e2ef30d126b3	dropForeignKeyConstraint baseTableName=DEFAULT_CLIENT_SCOPE, constraintName=FK_R_DEF_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SCOPE_CLIENT, constraintName=FK_C_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SC...		\N	4.8.0	\N	\N	7143675732
13.0.0-KEYCLOAK-17992-drop-constraints	keycloak	META-INF/jpa-changelog-13.0.0.xml	2023-06-19 03:01:17.977003	93	MARK_RAN	8:1284a27fbd049d65831cb6fc07c8a783	dropPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CLSCOPE_CL, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CL_CLSCOPE, tableName=CLIENT_SCOPE_CLIENT		\N	4.8.0	\N	\N	7143675732
13.0.0-increase-column-size-federated	keycloak	META-INF/jpa-changelog-13.0.0.xml	2023-06-19 03:01:17.983138	94	EXECUTED	8:9d11b619db2ae27c25853b8a37cd0dea	modifyDataType columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; modifyDataType columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT		\N	4.8.0	\N	\N	7143675732
13.0.0-KEYCLOAK-17992-recreate-constraints	keycloak	META-INF/jpa-changelog-13.0.0.xml	2023-06-19 03:01:17.984556	95	MARK_RAN	8:3002bb3997451bb9e8bac5c5cd8d6327	addNotNullConstraint columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; addNotNullConstraint columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT; addPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; createIndex indexName=...		\N	4.8.0	\N	\N	7143675732
json-string-accomodation-fixed	keycloak	META-INF/jpa-changelog-13.0.0.xml	2023-06-19 03:01:17.988671	96	EXECUTED	8:dfbee0d6237a23ef4ccbb7a4e063c163	addColumn tableName=REALM_ATTRIBUTE; update tableName=REALM_ATTRIBUTE; dropColumn columnName=VALUE, tableName=REALM_ATTRIBUTE; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=REALM_ATTRIBUTE		\N	4.8.0	\N	\N	7143675732
14.0.0-KEYCLOAK-11019	keycloak	META-INF/jpa-changelog-14.0.0.xml	2023-06-19 03:01:17.995988	97	EXECUTED	8:75f3e372df18d38c62734eebb986b960	createIndex indexName=IDX_OFFLINE_CSS_PRELOAD, tableName=OFFLINE_CLIENT_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USER, tableName=OFFLINE_USER_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USERSESS, tableName=OFFLINE_USER_SESSION		\N	4.8.0	\N	\N	7143675732
14.0.0-KEYCLOAK-18286	keycloak	META-INF/jpa-changelog-14.0.0.xml	2023-06-19 03:01:17.997626	98	MARK_RAN	8:7fee73eddf84a6035691512c85637eef	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.8.0	\N	\N	7143675732
14.0.0-KEYCLOAK-18286-revert	keycloak	META-INF/jpa-changelog-14.0.0.xml	2023-06-19 03:01:18.006536	99	MARK_RAN	8:7a11134ab12820f999fbf3bb13c3adc8	dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.8.0	\N	\N	7143675732
14.0.0-KEYCLOAK-18286-supported-dbs	keycloak	META-INF/jpa-changelog-14.0.0.xml	2023-06-19 03:01:18.011226	100	EXECUTED	8:c0f6eaac1f3be773ffe54cb5b8482b70	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.8.0	\N	\N	7143675732
14.0.0-KEYCLOAK-18286-unsupported-dbs	keycloak	META-INF/jpa-changelog-14.0.0.xml	2023-06-19 03:01:18.012867	101	MARK_RAN	8:18186f0008b86e0f0f49b0c4d0e842ac	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.8.0	\N	\N	7143675732
KEYCLOAK-17267-add-index-to-user-attributes	keycloak	META-INF/jpa-changelog-14.0.0.xml	2023-06-19 03:01:18.017485	102	EXECUTED	8:09c2780bcb23b310a7019d217dc7b433	createIndex indexName=IDX_USER_ATTRIBUTE_NAME, tableName=USER_ATTRIBUTE		\N	4.8.0	\N	\N	7143675732
KEYCLOAK-18146-add-saml-art-binding-identifier	keycloak	META-INF/jpa-changelog-14.0.0.xml	2023-06-19 03:01:18.021677	103	EXECUTED	8:276a44955eab693c970a42880197fff2	customChange		\N	4.8.0	\N	\N	7143675732
15.0.0-KEYCLOAK-18467	keycloak	META-INF/jpa-changelog-15.0.0.xml	2023-06-19 03:01:18.026816	104	EXECUTED	8:ba8ee3b694d043f2bfc1a1079d0760d7	addColumn tableName=REALM_LOCALIZATIONS; update tableName=REALM_LOCALIZATIONS; dropColumn columnName=TEXTS, tableName=REALM_LOCALIZATIONS; renameColumn newColumnName=TEXTS, oldColumnName=TEXTS_NEW, tableName=REALM_LOCALIZATIONS; addNotNullConstrai...		\N	4.8.0	\N	\N	7143675732
17.0.0-9562	keycloak	META-INF/jpa-changelog-17.0.0.xml	2023-06-19 03:01:18.030975	105	EXECUTED	8:5e06b1d75f5d17685485e610c2851b17	createIndex indexName=IDX_USER_SERVICE_ACCOUNT, tableName=USER_ENTITY		\N	4.8.0	\N	\N	7143675732
18.0.0-10625-IDX_ADMIN_EVENT_TIME	keycloak	META-INF/jpa-changelog-18.0.0.xml	2023-06-19 03:01:18.034842	106	EXECUTED	8:4b80546c1dc550ac552ee7b24a4ab7c0	createIndex indexName=IDX_ADMIN_EVENT_TIME, tableName=ADMIN_EVENT_ENTITY		\N	4.8.0	\N	\N	7143675732
19.0.0-10135	keycloak	META-INF/jpa-changelog-19.0.0.xml	2023-06-19 03:01:18.038783	107	EXECUTED	8:af510cd1bb2ab6339c45372f3e491696	customChange		\N	4.8.0	\N	\N	7143675732
20.0.0-12964-supported-dbs	keycloak	META-INF/jpa-changelog-20.0.0.xml	2023-06-19 03:01:18.043424	108	EXECUTED	8:05c99fc610845ef66ee812b7921af0ef	createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE		\N	4.8.0	\N	\N	7143675732
20.0.0-12964-unsupported-dbs	keycloak	META-INF/jpa-changelog-20.0.0.xml	2023-06-19 03:01:18.04509	109	MARK_RAN	8:314e803baf2f1ec315b3464e398b8247	createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE		\N	4.8.0	\N	\N	7143675732
client-attributes-string-accomodation-fixed	keycloak	META-INF/jpa-changelog-20.0.0.xml	2023-06-19 03:01:18.049748	110	EXECUTED	8:56e4677e7e12556f70b604c573840100	addColumn tableName=CLIENT_ATTRIBUTES; update tableName=CLIENT_ATTRIBUTES; dropColumn columnName=VALUE, tableName=CLIENT_ATTRIBUTES; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=CLIENT_ATTRIBUTES		\N	4.8.0	\N	\N	7143675732
\.


--
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
1	f	\N	\N
1000	f	\N	\N
1001	f	\N	\N
\.


--
-- Data for Name: default_client_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.default_client_scope (realm_id, scope_id, default_scope) FROM stdin;
091121bd-5b90-4312-8e4f-1be85be87c5c	9d829b78-9254-4a08-bf78-1eb7692267f8	f
091121bd-5b90-4312-8e4f-1be85be87c5c	32166985-f2e4-49d4-ab1f-c2432532ee62	t
091121bd-5b90-4312-8e4f-1be85be87c5c	ef01bb50-d052-4900-9927-8bbfc8f278eb	t
091121bd-5b90-4312-8e4f-1be85be87c5c	ba667fc7-c7d1-460f-aae4-20e776c0fec1	t
091121bd-5b90-4312-8e4f-1be85be87c5c	79758ce2-ff28-413d-a328-58f8e5221183	f
091121bd-5b90-4312-8e4f-1be85be87c5c	61333193-449f-4aff-848c-70d4fdfabc0c	f
091121bd-5b90-4312-8e4f-1be85be87c5c	f5544b08-7f55-4388-ae84-538d48366597	t
091121bd-5b90-4312-8e4f-1be85be87c5c	86349b8b-15ca-427f-a2a9-c39e5adac3b5	t
091121bd-5b90-4312-8e4f-1be85be87c5c	001899db-8719-4fb4-84b5-932697fc8f11	f
091121bd-5b90-4312-8e4f-1be85be87c5c	b497f044-6cfc-404d-82ca-c69889619eda	t
On-premise	445e57d8-6cb8-49a7-a566-480c1b754409	t
On-premise	ae2a301a-d22f-46e6-a736-5e3837e6b18a	t
On-premise	fb5fb072-87e0-490e-9dba-3bfaa677b35e	t
On-premise	36eeab00-16ef-4cb7-9f43-1626bfe6aae2	t
On-premise	5c4d2c3e-85e6-4ef6-98f7-b9afc76c9442	t
On-premise	9db74845-4196-4859-82b4-dd4ac268d672	t
On-premise	ac87c569-2002-45ff-b330-b4fc5303051e	f
On-premise	c32f274c-e449-4afe-bb2f-8cd75d24207d	f
On-premise	79cee3fc-a552-47d4-8deb-7fe5b231bfe1	f
On-premise	b97a5f52-b8bf-4313-a458-d5af0b16c629	f
\.


--
-- Data for Name: event_entity; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.event_entity (id, client_id, details_json, error, ip_address, realm_id, session_id, event_time, type, user_id) FROM stdin;
\.


--
-- Data for Name: fed_user_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_attribute (id, name, user_id, realm_id, storage_provider_id, value) FROM stdin;
\.


--
-- Data for Name: fed_user_consent; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_consent (id, client_id, user_id, realm_id, storage_provider_id, created_date, last_updated_date, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: fed_user_consent_cl_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_consent_cl_scope (user_consent_id, scope_id) FROM stdin;
\.


--
-- Data for Name: fed_user_credential; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_credential (id, salt, type, created_date, user_id, realm_id, storage_provider_id, user_label, secret_data, credential_data, priority) FROM stdin;
\.


--
-- Data for Name: fed_user_group_membership; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_group_membership (group_id, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: fed_user_required_action; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_required_action (required_action, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: fed_user_role_mapping; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_role_mapping (role_id, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: federated_identity; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.federated_identity (identity_provider, realm_id, federated_user_id, federated_username, token, user_id) FROM stdin;
\.


--
-- Data for Name: federated_user; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.federated_user (id, storage_provider_id, realm_id) FROM stdin;
\.


--
-- Data for Name: group_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.group_attribute (id, name, value, group_id) FROM stdin;
\.


--
-- Data for Name: group_role_mapping; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.group_role_mapping (role_id, group_id) FROM stdin;
\.


--
-- Data for Name: identity_provider; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.identity_provider (internal_id, enabled, provider_alias, provider_id, store_token, authenticate_by_default, realm_id, add_token_role, trust_email, first_broker_login_flow_id, post_broker_login_flow_id, provider_display_name, link_only) FROM stdin;
\.


--
-- Data for Name: identity_provider_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.identity_provider_config (identity_provider_id, value, name) FROM stdin;
\.


--
-- Data for Name: identity_provider_mapper; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.identity_provider_mapper (id, name, idp_alias, idp_mapper_name, realm_id) FROM stdin;
\.


--
-- Data for Name: idp_mapper_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.idp_mapper_config (idp_mapper_id, value, name) FROM stdin;
\.


--
-- Data for Name: keycloak_group; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.keycloak_group (id, name, parent_group, realm_id) FROM stdin;
\.


--
-- Data for Name: keycloak_role; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.keycloak_role (id, client_realm_constraint, client_role, description, name, realm_id, client, realm) FROM stdin;
c83f012e-6f48-41b1-86ba-cfd0d4b627e7	091121bd-5b90-4312-8e4f-1be85be87c5c	f	${role_default-roles}	default-roles-master	091121bd-5b90-4312-8e4f-1be85be87c5c	\N	\N
90448f36-0397-4c33-8408-435a4bca4b84	091121bd-5b90-4312-8e4f-1be85be87c5c	f	${role_create-realm}	create-realm	091121bd-5b90-4312-8e4f-1be85be87c5c	\N	\N
c7e49872-a95c-4ac9-bd10-147c32a0cf33	091121bd-5b90-4312-8e4f-1be85be87c5c	f	${role_admin}	admin	091121bd-5b90-4312-8e4f-1be85be87c5c	\N	\N
0d7a4a52-d40c-479a-b5a9-d09ee83f4afd	6aa3754c-83c0-40f4-9474-3c745b7d49c5	t	${role_create-client}	create-client	091121bd-5b90-4312-8e4f-1be85be87c5c	6aa3754c-83c0-40f4-9474-3c745b7d49c5	\N
a64674f3-2115-4d10-a9bd-6fd0029bf5ef	6aa3754c-83c0-40f4-9474-3c745b7d49c5	t	${role_view-realm}	view-realm	091121bd-5b90-4312-8e4f-1be85be87c5c	6aa3754c-83c0-40f4-9474-3c745b7d49c5	\N
9145a900-7454-4ddb-80b0-8668799c0cb1	6aa3754c-83c0-40f4-9474-3c745b7d49c5	t	${role_view-users}	view-users	091121bd-5b90-4312-8e4f-1be85be87c5c	6aa3754c-83c0-40f4-9474-3c745b7d49c5	\N
609fa6d0-ff62-47e0-9f64-04472fcdedcb	6aa3754c-83c0-40f4-9474-3c745b7d49c5	t	${role_view-clients}	view-clients	091121bd-5b90-4312-8e4f-1be85be87c5c	6aa3754c-83c0-40f4-9474-3c745b7d49c5	\N
e5139f79-fac9-4014-819d-89969d676ae5	6aa3754c-83c0-40f4-9474-3c745b7d49c5	t	${role_view-events}	view-events	091121bd-5b90-4312-8e4f-1be85be87c5c	6aa3754c-83c0-40f4-9474-3c745b7d49c5	\N
0802cd38-3054-4412-92b1-6c573b7148d5	6aa3754c-83c0-40f4-9474-3c745b7d49c5	t	${role_view-identity-providers}	view-identity-providers	091121bd-5b90-4312-8e4f-1be85be87c5c	6aa3754c-83c0-40f4-9474-3c745b7d49c5	\N
1a266613-626a-493b-9d51-1f94ae05518a	6aa3754c-83c0-40f4-9474-3c745b7d49c5	t	${role_view-authorization}	view-authorization	091121bd-5b90-4312-8e4f-1be85be87c5c	6aa3754c-83c0-40f4-9474-3c745b7d49c5	\N
d4e72fb7-b794-4d89-ab7e-f98a2da460c1	6aa3754c-83c0-40f4-9474-3c745b7d49c5	t	${role_manage-realm}	manage-realm	091121bd-5b90-4312-8e4f-1be85be87c5c	6aa3754c-83c0-40f4-9474-3c745b7d49c5	\N
c205de85-88e3-4cd3-9a4e-7e764628bcac	6aa3754c-83c0-40f4-9474-3c745b7d49c5	t	${role_manage-users}	manage-users	091121bd-5b90-4312-8e4f-1be85be87c5c	6aa3754c-83c0-40f4-9474-3c745b7d49c5	\N
6ee985d2-2d4e-4f20-966c-6f56254ef8d1	6aa3754c-83c0-40f4-9474-3c745b7d49c5	t	${role_manage-clients}	manage-clients	091121bd-5b90-4312-8e4f-1be85be87c5c	6aa3754c-83c0-40f4-9474-3c745b7d49c5	\N
999e4a0f-ea2b-4172-85fb-a765fdd392dd	6aa3754c-83c0-40f4-9474-3c745b7d49c5	t	${role_manage-events}	manage-events	091121bd-5b90-4312-8e4f-1be85be87c5c	6aa3754c-83c0-40f4-9474-3c745b7d49c5	\N
e46d98fc-4d2e-4ad4-b395-ebd3bb3de9be	6aa3754c-83c0-40f4-9474-3c745b7d49c5	t	${role_manage-identity-providers}	manage-identity-providers	091121bd-5b90-4312-8e4f-1be85be87c5c	6aa3754c-83c0-40f4-9474-3c745b7d49c5	\N
5c8fe8b6-cd89-4c16-9ff7-6d27993dd769	6aa3754c-83c0-40f4-9474-3c745b7d49c5	t	${role_manage-authorization}	manage-authorization	091121bd-5b90-4312-8e4f-1be85be87c5c	6aa3754c-83c0-40f4-9474-3c745b7d49c5	\N
f984e392-76ec-49cf-afce-6d4ae058b4ba	6aa3754c-83c0-40f4-9474-3c745b7d49c5	t	${role_query-users}	query-users	091121bd-5b90-4312-8e4f-1be85be87c5c	6aa3754c-83c0-40f4-9474-3c745b7d49c5	\N
e50cad44-ccbd-4aa4-9c79-ab641da4f04c	6aa3754c-83c0-40f4-9474-3c745b7d49c5	t	${role_query-clients}	query-clients	091121bd-5b90-4312-8e4f-1be85be87c5c	6aa3754c-83c0-40f4-9474-3c745b7d49c5	\N
6b5243b9-7c1c-4490-a0c0-e6ae5a3f1395	6aa3754c-83c0-40f4-9474-3c745b7d49c5	t	${role_query-realms}	query-realms	091121bd-5b90-4312-8e4f-1be85be87c5c	6aa3754c-83c0-40f4-9474-3c745b7d49c5	\N
7261994a-cdc1-4648-bbff-a0ae0f7997cd	6aa3754c-83c0-40f4-9474-3c745b7d49c5	t	${role_query-groups}	query-groups	091121bd-5b90-4312-8e4f-1be85be87c5c	6aa3754c-83c0-40f4-9474-3c745b7d49c5	\N
e9c7673a-d9d9-457a-9979-ce377ee173c3	192e12a1-d757-45fa-af0c-4e1403d6839b	t	${role_view-profile}	view-profile	091121bd-5b90-4312-8e4f-1be85be87c5c	192e12a1-d757-45fa-af0c-4e1403d6839b	\N
6e5f311d-f00d-4291-be03-24217c579ee1	192e12a1-d757-45fa-af0c-4e1403d6839b	t	${role_manage-account}	manage-account	091121bd-5b90-4312-8e4f-1be85be87c5c	192e12a1-d757-45fa-af0c-4e1403d6839b	\N
e1f04f44-4231-423f-aec9-8d33d2024329	192e12a1-d757-45fa-af0c-4e1403d6839b	t	${role_manage-account-links}	manage-account-links	091121bd-5b90-4312-8e4f-1be85be87c5c	192e12a1-d757-45fa-af0c-4e1403d6839b	\N
9b1527df-9541-443f-84a8-19098b3153aa	192e12a1-d757-45fa-af0c-4e1403d6839b	t	${role_view-applications}	view-applications	091121bd-5b90-4312-8e4f-1be85be87c5c	192e12a1-d757-45fa-af0c-4e1403d6839b	\N
5383f398-00ef-43de-b318-e4d77b77d963	192e12a1-d757-45fa-af0c-4e1403d6839b	t	${role_view-consent}	view-consent	091121bd-5b90-4312-8e4f-1be85be87c5c	192e12a1-d757-45fa-af0c-4e1403d6839b	\N
85eaf1c2-0c0b-42dc-86b7-a5b8258ae068	192e12a1-d757-45fa-af0c-4e1403d6839b	t	${role_manage-consent}	manage-consent	091121bd-5b90-4312-8e4f-1be85be87c5c	192e12a1-d757-45fa-af0c-4e1403d6839b	\N
8486fe5e-61db-48d7-b8c7-cebddda3dcc1	192e12a1-d757-45fa-af0c-4e1403d6839b	t	${role_view-groups}	view-groups	091121bd-5b90-4312-8e4f-1be85be87c5c	192e12a1-d757-45fa-af0c-4e1403d6839b	\N
8b980cb1-8f98-4a86-bffe-173dc8184cc2	192e12a1-d757-45fa-af0c-4e1403d6839b	t	${role_delete-account}	delete-account	091121bd-5b90-4312-8e4f-1be85be87c5c	192e12a1-d757-45fa-af0c-4e1403d6839b	\N
f9db5251-fbe5-43bc-b6d3-4174c3130490	e717a919-aca7-4c82-829f-406898377038	t	${role_read-token}	read-token	091121bd-5b90-4312-8e4f-1be85be87c5c	e717a919-aca7-4c82-829f-406898377038	\N
971eeb93-d5c7-4e23-802b-17fd7d8bfbfd	6aa3754c-83c0-40f4-9474-3c745b7d49c5	t	${role_impersonation}	impersonation	091121bd-5b90-4312-8e4f-1be85be87c5c	6aa3754c-83c0-40f4-9474-3c745b7d49c5	\N
0cb8ad12-2b7b-43a3-85f7-94d2965b88f2	091121bd-5b90-4312-8e4f-1be85be87c5c	f	${role_offline-access}	offline_access	091121bd-5b90-4312-8e4f-1be85be87c5c	\N	\N
69deb56b-23a0-48ab-a2df-2964270f85a4	091121bd-5b90-4312-8e4f-1be85be87c5c	f	${role_uma_authorization}	uma_authorization	091121bd-5b90-4312-8e4f-1be85be87c5c	\N	\N
69c368f8-4e0e-4420-93e7-918f504378e4	On-premise	f	${role_default-roles}	default-roles-amrit	On-premise	\N	\N
06f1d0ae-77f8-4dc3-a027-987f514fe058	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	t	${role_create-client}	create-client	091121bd-5b90-4312-8e4f-1be85be87c5c	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	\N
74539763-cd50-4957-bc8c-d8404b085829	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	t	${role_view-realm}	view-realm	091121bd-5b90-4312-8e4f-1be85be87c5c	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	\N
b1b40619-025a-4c98-a128-a8eed362adf7	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	t	${role_view-users}	view-users	091121bd-5b90-4312-8e4f-1be85be87c5c	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	\N
b4dc1581-7cbd-417b-9cbb-9217caab806f	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	t	${role_view-clients}	view-clients	091121bd-5b90-4312-8e4f-1be85be87c5c	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	\N
8a3759ed-c8f0-49fc-ab90-cdd171ff28f2	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	t	${role_view-events}	view-events	091121bd-5b90-4312-8e4f-1be85be87c5c	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	\N
e58bd9ca-9045-495b-9c41-1e250e519ab8	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	t	${role_view-identity-providers}	view-identity-providers	091121bd-5b90-4312-8e4f-1be85be87c5c	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	\N
6d10438f-a980-4e4d-9957-ca4035faf8ae	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	t	${role_view-authorization}	view-authorization	091121bd-5b90-4312-8e4f-1be85be87c5c	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	\N
5de67731-9d6b-42eb-bd9b-53cc92e7ae9a	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	t	${role_manage-realm}	manage-realm	091121bd-5b90-4312-8e4f-1be85be87c5c	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	\N
60be1184-9c2f-4521-961f-e22aeb0d5176	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	t	${role_manage-users}	manage-users	091121bd-5b90-4312-8e4f-1be85be87c5c	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	\N
52e32be9-8a01-41df-ad01-ec6e678677bc	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	t	${role_manage-clients}	manage-clients	091121bd-5b90-4312-8e4f-1be85be87c5c	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	\N
cc4da88c-9298-4e3d-86e4-0caa89d740af	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	t	${role_manage-events}	manage-events	091121bd-5b90-4312-8e4f-1be85be87c5c	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	\N
863b0172-20b5-4e92-87bd-67e17f211d5a	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	t	${role_manage-identity-providers}	manage-identity-providers	091121bd-5b90-4312-8e4f-1be85be87c5c	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	\N
e0058054-cc40-4d41-a091-b4338c8dfddb	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	t	${role_manage-authorization}	manage-authorization	091121bd-5b90-4312-8e4f-1be85be87c5c	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	\N
3f4b9565-3e05-4525-a3c5-188a6ef376ae	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	t	${role_query-users}	query-users	091121bd-5b90-4312-8e4f-1be85be87c5c	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	\N
a277648e-96b6-4a3f-b41e-9c6c396ec05c	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	t	${role_query-clients}	query-clients	091121bd-5b90-4312-8e4f-1be85be87c5c	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	\N
1e230aae-0b47-4d34-9b92-fd110fd07bbc	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	t	${role_query-realms}	query-realms	091121bd-5b90-4312-8e4f-1be85be87c5c	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	\N
5b5b0cb4-1e98-41ec-b267-855a93e0f38a	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	t	${role_query-groups}	query-groups	091121bd-5b90-4312-8e4f-1be85be87c5c	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	\N
3ee7ccc9-1bc8-4218-b4fd-834c267f876b	On-premise	f	${role_offline-access}	offline_access	On-premise	\N	\N
6bcbf8ef-8206-4b82-8b66-37f18605d4e8	On-premise	f	${role_uma_authorization}	uma_authorization	On-premise	\N	\N
70fb6a4b-c4a0-4ace-9d57-db0765201a5a	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_manage-authorization}	manage-authorization	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
53801b14-d53e-4e86-93a8-39f12ffb1298	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_create-client}	create-client	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
f4c2141e-7651-4e28-ae5f-f01f160ce670	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_query-users}	query-users	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
f6b60156-2015-491a-9806-f7863ad39a60	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_view-authorization}	view-authorization	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
af7d6d1e-5bf7-4799-bb7d-bfe5710d8f8a	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_query-groups}	query-groups	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
7027be45-43d8-47f1-a990-687021281335	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_view-events}	view-events	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
c660e4db-fbdd-44db-86e3-66acaa901b57	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_view-identity-providers}	view-identity-providers	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
d03f9041-b734-4ea0-ad4f-c8a9c6405715	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_view-users}	view-users	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
14301fed-c796-4dfc-9688-427859fa5a3d	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_view-clients}	view-clients	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
392b2dfa-3566-45ef-a21b-0e3518f8bd8a	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_query-realms}	query-realms	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
8f215bd4-c353-467c-a990-30dea2e04962	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_query-clients}	query-clients	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
0d0dc25e-8456-4b9d-be76-5aeb6b8e2aa9	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_view-realm}	view-realm	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
0e54c49c-93ed-4977-9d0b-919126741de6	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_manage-events}	manage-events	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
13d3c77f-6b8d-4345-84f1-6f5f99bb6d2c	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_impersonation}	impersonation	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
ead4cb4d-0d86-4f41-baf3-a23928cd0561	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_manage-identity-providers}	manage-identity-providers	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
4422c51f-fc48-4fcf-9e04-65ae7a72dc06	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_manage-clients}	manage-clients	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
0a6c0fd7-8037-4c34-a437-bc7fe8f55a51	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_manage-realm}	manage-realm	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
f961073e-14fb-4e4f-894c-5167fc9a42ce	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_realm-admin}	realm-admin	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
53d6cd2d-49da-42bf-acd7-21d06edd9147	818e3596-2ff1-4056-9230-704e8fac0ca1	t	${role_manage-users}	manage-users	On-premise	818e3596-2ff1-4056-9230-704e8fac0ca1	\N
44056ddc-8fac-46ef-9c6e-be9f4b768ce9	4381c433-5988-418a-bc71-177bb46e873a	t	Users managements	user_mgt	On-premise	4381c433-5988-418a-bc71-177bb46e873a	\N
b432d132-af2e-4fd6-a3fb-80c7ff4c183b	82b820b4-c7f1-4946-8e97-7cda75eca5a3	t	${role_read-token}	read-token	On-premise	82b820b4-c7f1-4946-8e97-7cda75eca5a3	\N
403bd78d-d2a0-4d23-a76f-73e732b3d864	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	t	${role_view-applications}	view-applications	On-premise	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	\N
9add80b2-bd14-4e8c-87be-01ed5464849f	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	t	${role_delete-account}	delete-account	On-premise	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	\N
8e85020a-c3a3-4c72-ba5e-b4268bc85721	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	t	${role_manage-consent}	manage-consent	On-premise	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	\N
20fe2009-0460-4839-8db5-72acc882762b	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	t	${role_manage-account-links}	manage-account-links	On-premise	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	\N
2ee509b1-2f53-45ee-9673-d71e8e60a78a	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	t	${role_manage-account}	manage-account	On-premise	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	\N
01ded32e-7299-4877-b1de-ceab307fdf0d	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	t	${role_view-groups}	view-groups	On-premise	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	\N
050929c5-9ab9-4a12-a838-6386eb3fd446	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	t	${role_view-profile}	view-profile	On-premise	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	\N
44409bce-0213-417f-9d56-99773b859c79	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	t	${role_view-consent}	view-consent	On-premise	676ec99d-bef5-49ef-b9c4-1be17bd4f92f	\N
c4b2720e-2733-4c66-ab0b-8d7ae629e5da	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	t	${role_impersonation}	impersonation	091121bd-5b90-4312-8e4f-1be85be87c5c	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	\N
\.


--
-- Data for Name: migration_model; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.migration_model (id, version, update_time) FROM stdin;
jsnr8	20.0.2	1687143678
\.


--
-- Data for Name: offline_client_session; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.offline_client_session (user_session_id, client_id, offline_flag, "timestamp", data, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: offline_user_session; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.offline_user_session (user_session_id, user_id, realm_id, created_on, offline_flag, data, last_session_refresh) FROM stdin;
\.


--
-- Data for Name: policy_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.policy_config (policy_id, name, value) FROM stdin;
\.


--
-- Data for Name: protocol_mapper; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.protocol_mapper (id, name, protocol, protocol_mapper_name, client_id, client_scope_id) FROM stdin;
c0b597ce-0e0b-4b0f-92de-07ad415c8de3	audience resolve	openid-connect	oidc-audience-resolve-mapper	8159c06d-88e2-43ed-8b46-235e9f914801	\N
b3b10280-f554-42b4-9a94-3baa3a63ae28	locale	openid-connect	oidc-usermodel-attribute-mapper	716e3e61-eb87-4888-9954-a77d44ffa498	\N
47874ab1-1f45-4d52-b396-c439e532d91c	role list	saml	saml-role-list-mapper	\N	32166985-f2e4-49d4-ab1f-c2432532ee62
4c5a676d-574e-4fa6-8f72-6d893589aa6d	full name	openid-connect	oidc-full-name-mapper	\N	ef01bb50-d052-4900-9927-8bbfc8f278eb
7aa06c54-d7b8-4fbb-b28c-c470d553a4b7	family name	openid-connect	oidc-usermodel-property-mapper	\N	ef01bb50-d052-4900-9927-8bbfc8f278eb
9d2f88ea-8865-4397-af52-b9d54261deef	given name	openid-connect	oidc-usermodel-property-mapper	\N	ef01bb50-d052-4900-9927-8bbfc8f278eb
a8242871-ea00-4c09-a4f9-6b23d847fb6e	middle name	openid-connect	oidc-usermodel-attribute-mapper	\N	ef01bb50-d052-4900-9927-8bbfc8f278eb
c70fe0e4-4499-4df8-a2f4-643a26ba3de4	nickname	openid-connect	oidc-usermodel-attribute-mapper	\N	ef01bb50-d052-4900-9927-8bbfc8f278eb
d815275e-e331-4df1-9a59-5bc6b8031316	username	openid-connect	oidc-usermodel-property-mapper	\N	ef01bb50-d052-4900-9927-8bbfc8f278eb
bf710864-a0ed-423e-a50e-fe6d9c28af68	profile	openid-connect	oidc-usermodel-attribute-mapper	\N	ef01bb50-d052-4900-9927-8bbfc8f278eb
cb6a4aed-84a6-4670-b9af-bdfd34d18579	picture	openid-connect	oidc-usermodel-attribute-mapper	\N	ef01bb50-d052-4900-9927-8bbfc8f278eb
96c45142-ad1c-4217-bf6f-487ab37615f6	website	openid-connect	oidc-usermodel-attribute-mapper	\N	ef01bb50-d052-4900-9927-8bbfc8f278eb
0fbd3d41-eec7-4732-aea4-1923c1392c06	gender	openid-connect	oidc-usermodel-attribute-mapper	\N	ef01bb50-d052-4900-9927-8bbfc8f278eb
c0a94eaa-aa99-4909-b130-98c59d87b196	birthdate	openid-connect	oidc-usermodel-attribute-mapper	\N	ef01bb50-d052-4900-9927-8bbfc8f278eb
a369b7ac-66bb-4a98-a4e6-eac658f94ae8	zoneinfo	openid-connect	oidc-usermodel-attribute-mapper	\N	ef01bb50-d052-4900-9927-8bbfc8f278eb
fe535c36-0fde-4728-8d15-230a35eaba4b	locale	openid-connect	oidc-usermodel-attribute-mapper	\N	ef01bb50-d052-4900-9927-8bbfc8f278eb
95fc60b2-2131-4f6d-b056-af20db803023	updated at	openid-connect	oidc-usermodel-attribute-mapper	\N	ef01bb50-d052-4900-9927-8bbfc8f278eb
06ba9e04-6890-431b-81c9-98c03f5b255b	email	openid-connect	oidc-usermodel-property-mapper	\N	ba667fc7-c7d1-460f-aae4-20e776c0fec1
ed0f12b6-c642-47b6-99ad-a241e4c59e85	email verified	openid-connect	oidc-usermodel-property-mapper	\N	ba667fc7-c7d1-460f-aae4-20e776c0fec1
69028f3b-d1af-40f1-b1ec-5389377da9e1	address	openid-connect	oidc-address-mapper	\N	79758ce2-ff28-413d-a328-58f8e5221183
d01dda04-3b0d-4d9b-bb0d-99d48c40ecdc	phone number	openid-connect	oidc-usermodel-attribute-mapper	\N	61333193-449f-4aff-848c-70d4fdfabc0c
87029a7b-f41e-4b85-97c3-9c612ba6b6c9	phone number verified	openid-connect	oidc-usermodel-attribute-mapper	\N	61333193-449f-4aff-848c-70d4fdfabc0c
4c8ebe38-ecbd-4b9f-9fe9-cb63aa64537d	realm roles	openid-connect	oidc-usermodel-realm-role-mapper	\N	f5544b08-7f55-4388-ae84-538d48366597
da785dde-a941-4c1d-9417-f319b70c070d	client roles	openid-connect	oidc-usermodel-client-role-mapper	\N	f5544b08-7f55-4388-ae84-538d48366597
e83f42ec-c71a-49fa-a833-9188a14ca4dc	audience resolve	openid-connect	oidc-audience-resolve-mapper	\N	f5544b08-7f55-4388-ae84-538d48366597
ef47fbb3-34e7-4300-9f04-26f2b91b3cb4	allowed web origins	openid-connect	oidc-allowed-origins-mapper	\N	86349b8b-15ca-427f-a2a9-c39e5adac3b5
f8160422-27d0-432c-8166-bfcfd0c97d9e	upn	openid-connect	oidc-usermodel-property-mapper	\N	001899db-8719-4fb4-84b5-932697fc8f11
174a9b29-2027-40bb-8240-0e4ee5245844	groups	openid-connect	oidc-usermodel-realm-role-mapper	\N	001899db-8719-4fb4-84b5-932697fc8f11
10d876a4-d2ed-4361-a5e7-753606b0cc36	acr loa level	openid-connect	oidc-acr-mapper	\N	b497f044-6cfc-404d-82ca-c69889619eda
4d93033d-2070-4b3f-bb3c-b8bb1c19940a	phone number verified	openid-connect	oidc-usermodel-attribute-mapper	\N	79cee3fc-a552-47d4-8deb-7fe5b231bfe1
387125c5-5735-482d-b6c1-cb8cd02848f2	phone number	openid-connect	oidc-usermodel-attribute-mapper	\N	79cee3fc-a552-47d4-8deb-7fe5b231bfe1
ec55de66-9ba8-401b-81a6-648deaa4dcdb	email verified	openid-connect	oidc-usermodel-property-mapper	\N	fb5fb072-87e0-490e-9dba-3bfaa677b35e
0132cd45-2832-4fb2-b3da-deb2bde01f7b	email	openid-connect	oidc-usermodel-property-mapper	\N	fb5fb072-87e0-490e-9dba-3bfaa677b35e
016d0122-6dff-486c-b1ac-6417db3b7c16	groups	openid-connect	oidc-usermodel-realm-role-mapper	\N	b97a5f52-b8bf-4313-a458-d5af0b16c629
9015add1-eb40-4c3e-975e-bdd82293e7ce	upn	openid-connect	oidc-usermodel-property-mapper	\N	b97a5f52-b8bf-4313-a458-d5af0b16c629
3a811bd1-d368-4091-b7ae-c8e4ef05acc1	allowed web origins	openid-connect	oidc-allowed-origins-mapper	\N	5c4d2c3e-85e6-4ef6-98f7-b9afc76c9442
2acd9feb-49ca-42f5-ad96-70cd81d217e5	acr loa level	openid-connect	oidc-acr-mapper	\N	9db74845-4196-4859-82b4-dd4ac268d672
cb29807a-92ec-4f8f-8966-0a5504548d19	realm roles	openid-connect	oidc-usermodel-realm-role-mapper	\N	36eeab00-16ef-4cb7-9f43-1626bfe6aae2
33bcd5c2-ac56-44fe-9189-57e2b89f18dd	client roles	openid-connect	oidc-usermodel-client-role-mapper	\N	36eeab00-16ef-4cb7-9f43-1626bfe6aae2
3f6e599e-0aa0-4d36-81ad-dbcbace13f2f	audience resolve	openid-connect	oidc-audience-resolve-mapper	\N	36eeab00-16ef-4cb7-9f43-1626bfe6aae2
3de03083-9f1a-4fee-b76a-8a464b4689c8	role list	saml	saml-role-list-mapper	\N	445e57d8-6cb8-49a7-a566-480c1b754409
828ba905-f502-4e9a-b531-42fd14290041	address	openid-connect	oidc-address-mapper	\N	c32f274c-e449-4afe-bb2f-8cd75d24207d
c375ea26-006d-4f9b-b9ce-7b203d6a6c8d	avni-service-audience	openid-connect	oidc-audience-mapper	\N	fa931807-b3af-4ae0-81b7-267055627626
838a8c95-e6ff-466f-accd-e2d891901f00	middle name	openid-connect	oidc-usermodel-attribute-mapper	\N	ae2a301a-d22f-46e6-a736-5e3837e6b18a
0d400723-54ed-4379-b560-5330d718d8b2	full name	openid-connect	oidc-full-name-mapper	\N	ae2a301a-d22f-46e6-a736-5e3837e6b18a
488e7cd9-2dae-41a1-ad81-09f934273ac9	zoneinfo	openid-connect	oidc-usermodel-attribute-mapper	\N	ae2a301a-d22f-46e6-a736-5e3837e6b18a
9796fa98-06e7-4e85-a720-3382778bea21	locale	openid-connect	oidc-usermodel-attribute-mapper	\N	ae2a301a-d22f-46e6-a736-5e3837e6b18a
0e8f93cd-4bfe-4dd1-a519-50596e20c289	given name	openid-connect	oidc-usermodel-property-mapper	\N	ae2a301a-d22f-46e6-a736-5e3837e6b18a
2be4448d-1dd3-4dac-8f67-b63da7e9f4e7	website	openid-connect	oidc-usermodel-attribute-mapper	\N	ae2a301a-d22f-46e6-a736-5e3837e6b18a
2882bede-5489-4338-87a0-aa3de0cf20ae	birthdate	openid-connect	oidc-usermodel-attribute-mapper	\N	ae2a301a-d22f-46e6-a736-5e3837e6b18a
8d85e784-ea8d-4d21-a78b-e3a08db7c847	gender	openid-connect	oidc-usermodel-attribute-mapper	\N	ae2a301a-d22f-46e6-a736-5e3837e6b18a
2ece4931-9f38-4d06-8841-3d08dfc7153c	family name	openid-connect	oidc-usermodel-property-mapper	\N	ae2a301a-d22f-46e6-a736-5e3837e6b18a
8ec75a95-e52e-4b6c-9d01-9c8fc6c7f933	picture	openid-connect	oidc-usermodel-attribute-mapper	\N	ae2a301a-d22f-46e6-a736-5e3837e6b18a
0fbdfa9f-58da-4d11-a94c-6290d8542f08	username	openid-connect	oidc-usermodel-property-mapper	\N	ae2a301a-d22f-46e6-a736-5e3837e6b18a
89417ce2-f8f4-42e8-b117-529febfdaca9	profile	openid-connect	oidc-usermodel-attribute-mapper	\N	ae2a301a-d22f-46e6-a736-5e3837e6b18a
10ac7431-86ab-45ec-8bf8-3a08001e63fc	updated at	openid-connect	oidc-usermodel-attribute-mapper	\N	ae2a301a-d22f-46e6-a736-5e3837e6b18a
f0436fb7-ae5a-4be2-b147-2826d6ed6750	nickname	openid-connect	oidc-usermodel-attribute-mapper	\N	ae2a301a-d22f-46e6-a736-5e3837e6b18a
10c7a76d-0feb-4ef9-a424-708b58ab1224	audience resolve	openid-connect	oidc-audience-resolve-mapper	63e63428-fdea-4672-8e4f-d7a4df56393f	\N
1616b5cc-bac8-40c1-8601-0c2e89c08df8	Client Host	openid-connect	oidc-usersessionmodel-note-mapper	4381c433-5988-418a-bc71-177bb46e873a	\N
e31728b0-a369-41b8-b964-bd0e596f2a4c	Client ID	openid-connect	oidc-usersessionmodel-note-mapper	4381c433-5988-418a-bc71-177bb46e873a	\N
edb01d0b-1d97-42d8-8f16-4ea59b40a523	Client IP Address	openid-connect	oidc-usersessionmodel-note-mapper	4381c433-5988-418a-bc71-177bb46e873a	\N
71e84e97-63ee-4953-9a85-e37026f5c07d	Client Host	openid-connect	oidc-usersessionmodel-note-mapper	915277c7-706e-4aa8-ad41-dfc2c3818c0b	\N
a832dff7-e378-4a7e-ab25-b198aa36e901	Client IP Address	openid-connect	oidc-usersessionmodel-note-mapper	915277c7-706e-4aa8-ad41-dfc2c3818c0b	\N
febab41d-a1e4-46fb-adab-5581d1d4c71e	Client ID	openid-connect	oidc-usersessionmodel-note-mapper	915277c7-706e-4aa8-ad41-dfc2c3818c0b	\N
c3ad0583-c1b5-4759-b4fb-1bbdb7aef033	userUUID	openid-connect	oidc-usermodel-attribute-mapper	915277c7-706e-4aa8-ad41-dfc2c3818c0b	\N
47ddea50-e388-4d57-8e81-a4e7c3430e94	locale	openid-connect	oidc-usermodel-attribute-mapper	f355103f-48b5-4615-adb5-9992c317295c	\N
\.


--
-- Data for Name: protocol_mapper_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.protocol_mapper_config (protocol_mapper_id, value, name) FROM stdin;
b3b10280-f554-42b4-9a94-3baa3a63ae28	true	userinfo.token.claim
b3b10280-f554-42b4-9a94-3baa3a63ae28	locale	user.attribute
b3b10280-f554-42b4-9a94-3baa3a63ae28	true	id.token.claim
b3b10280-f554-42b4-9a94-3baa3a63ae28	true	access.token.claim
b3b10280-f554-42b4-9a94-3baa3a63ae28	locale	claim.name
b3b10280-f554-42b4-9a94-3baa3a63ae28	String	jsonType.label
47874ab1-1f45-4d52-b396-c439e532d91c	false	single
47874ab1-1f45-4d52-b396-c439e532d91c	Basic	attribute.nameformat
47874ab1-1f45-4d52-b396-c439e532d91c	Role	attribute.name
0fbd3d41-eec7-4732-aea4-1923c1392c06	true	userinfo.token.claim
0fbd3d41-eec7-4732-aea4-1923c1392c06	gender	user.attribute
0fbd3d41-eec7-4732-aea4-1923c1392c06	true	id.token.claim
0fbd3d41-eec7-4732-aea4-1923c1392c06	true	access.token.claim
0fbd3d41-eec7-4732-aea4-1923c1392c06	gender	claim.name
0fbd3d41-eec7-4732-aea4-1923c1392c06	String	jsonType.label
4c5a676d-574e-4fa6-8f72-6d893589aa6d	true	userinfo.token.claim
4c5a676d-574e-4fa6-8f72-6d893589aa6d	true	id.token.claim
4c5a676d-574e-4fa6-8f72-6d893589aa6d	true	access.token.claim
7aa06c54-d7b8-4fbb-b28c-c470d553a4b7	true	userinfo.token.claim
7aa06c54-d7b8-4fbb-b28c-c470d553a4b7	lastName	user.attribute
7aa06c54-d7b8-4fbb-b28c-c470d553a4b7	true	id.token.claim
7aa06c54-d7b8-4fbb-b28c-c470d553a4b7	true	access.token.claim
7aa06c54-d7b8-4fbb-b28c-c470d553a4b7	family_name	claim.name
7aa06c54-d7b8-4fbb-b28c-c470d553a4b7	String	jsonType.label
95fc60b2-2131-4f6d-b056-af20db803023	true	userinfo.token.claim
95fc60b2-2131-4f6d-b056-af20db803023	updatedAt	user.attribute
95fc60b2-2131-4f6d-b056-af20db803023	true	id.token.claim
95fc60b2-2131-4f6d-b056-af20db803023	true	access.token.claim
95fc60b2-2131-4f6d-b056-af20db803023	updated_at	claim.name
95fc60b2-2131-4f6d-b056-af20db803023	long	jsonType.label
96c45142-ad1c-4217-bf6f-487ab37615f6	true	userinfo.token.claim
96c45142-ad1c-4217-bf6f-487ab37615f6	website	user.attribute
96c45142-ad1c-4217-bf6f-487ab37615f6	true	id.token.claim
96c45142-ad1c-4217-bf6f-487ab37615f6	true	access.token.claim
96c45142-ad1c-4217-bf6f-487ab37615f6	website	claim.name
96c45142-ad1c-4217-bf6f-487ab37615f6	String	jsonType.label
9d2f88ea-8865-4397-af52-b9d54261deef	true	userinfo.token.claim
9d2f88ea-8865-4397-af52-b9d54261deef	firstName	user.attribute
9d2f88ea-8865-4397-af52-b9d54261deef	true	id.token.claim
9d2f88ea-8865-4397-af52-b9d54261deef	true	access.token.claim
9d2f88ea-8865-4397-af52-b9d54261deef	given_name	claim.name
9d2f88ea-8865-4397-af52-b9d54261deef	String	jsonType.label
a369b7ac-66bb-4a98-a4e6-eac658f94ae8	true	userinfo.token.claim
a369b7ac-66bb-4a98-a4e6-eac658f94ae8	zoneinfo	user.attribute
a369b7ac-66bb-4a98-a4e6-eac658f94ae8	true	id.token.claim
a369b7ac-66bb-4a98-a4e6-eac658f94ae8	true	access.token.claim
a369b7ac-66bb-4a98-a4e6-eac658f94ae8	zoneinfo	claim.name
a369b7ac-66bb-4a98-a4e6-eac658f94ae8	String	jsonType.label
a8242871-ea00-4c09-a4f9-6b23d847fb6e	true	userinfo.token.claim
a8242871-ea00-4c09-a4f9-6b23d847fb6e	middleName	user.attribute
a8242871-ea00-4c09-a4f9-6b23d847fb6e	true	id.token.claim
a8242871-ea00-4c09-a4f9-6b23d847fb6e	true	access.token.claim
a8242871-ea00-4c09-a4f9-6b23d847fb6e	middle_name	claim.name
a8242871-ea00-4c09-a4f9-6b23d847fb6e	String	jsonType.label
bf710864-a0ed-423e-a50e-fe6d9c28af68	true	userinfo.token.claim
bf710864-a0ed-423e-a50e-fe6d9c28af68	profile	user.attribute
bf710864-a0ed-423e-a50e-fe6d9c28af68	true	id.token.claim
bf710864-a0ed-423e-a50e-fe6d9c28af68	true	access.token.claim
bf710864-a0ed-423e-a50e-fe6d9c28af68	profile	claim.name
bf710864-a0ed-423e-a50e-fe6d9c28af68	String	jsonType.label
c0a94eaa-aa99-4909-b130-98c59d87b196	true	userinfo.token.claim
c0a94eaa-aa99-4909-b130-98c59d87b196	birthdate	user.attribute
c0a94eaa-aa99-4909-b130-98c59d87b196	true	id.token.claim
c0a94eaa-aa99-4909-b130-98c59d87b196	true	access.token.claim
c0a94eaa-aa99-4909-b130-98c59d87b196	birthdate	claim.name
c0a94eaa-aa99-4909-b130-98c59d87b196	String	jsonType.label
c70fe0e4-4499-4df8-a2f4-643a26ba3de4	true	userinfo.token.claim
c70fe0e4-4499-4df8-a2f4-643a26ba3de4	nickname	user.attribute
c70fe0e4-4499-4df8-a2f4-643a26ba3de4	true	id.token.claim
c70fe0e4-4499-4df8-a2f4-643a26ba3de4	true	access.token.claim
c70fe0e4-4499-4df8-a2f4-643a26ba3de4	nickname	claim.name
c70fe0e4-4499-4df8-a2f4-643a26ba3de4	String	jsonType.label
cb6a4aed-84a6-4670-b9af-bdfd34d18579	true	userinfo.token.claim
cb6a4aed-84a6-4670-b9af-bdfd34d18579	picture	user.attribute
cb6a4aed-84a6-4670-b9af-bdfd34d18579	true	id.token.claim
cb6a4aed-84a6-4670-b9af-bdfd34d18579	true	access.token.claim
cb6a4aed-84a6-4670-b9af-bdfd34d18579	picture	claim.name
cb6a4aed-84a6-4670-b9af-bdfd34d18579	String	jsonType.label
d815275e-e331-4df1-9a59-5bc6b8031316	true	userinfo.token.claim
d815275e-e331-4df1-9a59-5bc6b8031316	username	user.attribute
d815275e-e331-4df1-9a59-5bc6b8031316	true	id.token.claim
d815275e-e331-4df1-9a59-5bc6b8031316	true	access.token.claim
d815275e-e331-4df1-9a59-5bc6b8031316	preferred_username	claim.name
d815275e-e331-4df1-9a59-5bc6b8031316	String	jsonType.label
fe535c36-0fde-4728-8d15-230a35eaba4b	true	userinfo.token.claim
fe535c36-0fde-4728-8d15-230a35eaba4b	locale	user.attribute
fe535c36-0fde-4728-8d15-230a35eaba4b	true	id.token.claim
fe535c36-0fde-4728-8d15-230a35eaba4b	true	access.token.claim
fe535c36-0fde-4728-8d15-230a35eaba4b	locale	claim.name
fe535c36-0fde-4728-8d15-230a35eaba4b	String	jsonType.label
06ba9e04-6890-431b-81c9-98c03f5b255b	true	userinfo.token.claim
06ba9e04-6890-431b-81c9-98c03f5b255b	email	user.attribute
06ba9e04-6890-431b-81c9-98c03f5b255b	true	id.token.claim
06ba9e04-6890-431b-81c9-98c03f5b255b	true	access.token.claim
06ba9e04-6890-431b-81c9-98c03f5b255b	email	claim.name
06ba9e04-6890-431b-81c9-98c03f5b255b	String	jsonType.label
ed0f12b6-c642-47b6-99ad-a241e4c59e85	true	userinfo.token.claim
ed0f12b6-c642-47b6-99ad-a241e4c59e85	emailVerified	user.attribute
ed0f12b6-c642-47b6-99ad-a241e4c59e85	true	id.token.claim
ed0f12b6-c642-47b6-99ad-a241e4c59e85	true	access.token.claim
ed0f12b6-c642-47b6-99ad-a241e4c59e85	email_verified	claim.name
ed0f12b6-c642-47b6-99ad-a241e4c59e85	boolean	jsonType.label
69028f3b-d1af-40f1-b1ec-5389377da9e1	formatted	user.attribute.formatted
69028f3b-d1af-40f1-b1ec-5389377da9e1	country	user.attribute.country
69028f3b-d1af-40f1-b1ec-5389377da9e1	postal_code	user.attribute.postal_code
69028f3b-d1af-40f1-b1ec-5389377da9e1	true	userinfo.token.claim
69028f3b-d1af-40f1-b1ec-5389377da9e1	street	user.attribute.street
69028f3b-d1af-40f1-b1ec-5389377da9e1	true	id.token.claim
69028f3b-d1af-40f1-b1ec-5389377da9e1	region	user.attribute.region
69028f3b-d1af-40f1-b1ec-5389377da9e1	true	access.token.claim
69028f3b-d1af-40f1-b1ec-5389377da9e1	locality	user.attribute.locality
87029a7b-f41e-4b85-97c3-9c612ba6b6c9	true	userinfo.token.claim
87029a7b-f41e-4b85-97c3-9c612ba6b6c9	phoneNumberVerified	user.attribute
87029a7b-f41e-4b85-97c3-9c612ba6b6c9	true	id.token.claim
87029a7b-f41e-4b85-97c3-9c612ba6b6c9	true	access.token.claim
87029a7b-f41e-4b85-97c3-9c612ba6b6c9	phone_number_verified	claim.name
87029a7b-f41e-4b85-97c3-9c612ba6b6c9	boolean	jsonType.label
d01dda04-3b0d-4d9b-bb0d-99d48c40ecdc	true	userinfo.token.claim
d01dda04-3b0d-4d9b-bb0d-99d48c40ecdc	phoneNumber	user.attribute
d01dda04-3b0d-4d9b-bb0d-99d48c40ecdc	true	id.token.claim
d01dda04-3b0d-4d9b-bb0d-99d48c40ecdc	true	access.token.claim
d01dda04-3b0d-4d9b-bb0d-99d48c40ecdc	phone_number	claim.name
d01dda04-3b0d-4d9b-bb0d-99d48c40ecdc	String	jsonType.label
4c8ebe38-ecbd-4b9f-9fe9-cb63aa64537d	true	multivalued
4c8ebe38-ecbd-4b9f-9fe9-cb63aa64537d	foo	user.attribute
4c8ebe38-ecbd-4b9f-9fe9-cb63aa64537d	true	access.token.claim
4c8ebe38-ecbd-4b9f-9fe9-cb63aa64537d	realm_access.roles	claim.name
4c8ebe38-ecbd-4b9f-9fe9-cb63aa64537d	String	jsonType.label
da785dde-a941-4c1d-9417-f319b70c070d	true	multivalued
da785dde-a941-4c1d-9417-f319b70c070d	foo	user.attribute
da785dde-a941-4c1d-9417-f319b70c070d	true	access.token.claim
da785dde-a941-4c1d-9417-f319b70c070d	resource_access.${client_id}.roles	claim.name
da785dde-a941-4c1d-9417-f319b70c070d	String	jsonType.label
174a9b29-2027-40bb-8240-0e4ee5245844	true	multivalued
174a9b29-2027-40bb-8240-0e4ee5245844	foo	user.attribute
174a9b29-2027-40bb-8240-0e4ee5245844	true	id.token.claim
174a9b29-2027-40bb-8240-0e4ee5245844	true	access.token.claim
174a9b29-2027-40bb-8240-0e4ee5245844	groups	claim.name
174a9b29-2027-40bb-8240-0e4ee5245844	String	jsonType.label
f8160422-27d0-432c-8166-bfcfd0c97d9e	true	userinfo.token.claim
f8160422-27d0-432c-8166-bfcfd0c97d9e	username	user.attribute
f8160422-27d0-432c-8166-bfcfd0c97d9e	true	id.token.claim
f8160422-27d0-432c-8166-bfcfd0c97d9e	true	access.token.claim
f8160422-27d0-432c-8166-bfcfd0c97d9e	upn	claim.name
f8160422-27d0-432c-8166-bfcfd0c97d9e	String	jsonType.label
10d876a4-d2ed-4361-a5e7-753606b0cc36	true	id.token.claim
10d876a4-d2ed-4361-a5e7-753606b0cc36	true	access.token.claim
387125c5-5735-482d-b6c1-cb8cd02848f2	true	userinfo.token.claim
387125c5-5735-482d-b6c1-cb8cd02848f2	phoneNumber	user.attribute
387125c5-5735-482d-b6c1-cb8cd02848f2	true	id.token.claim
387125c5-5735-482d-b6c1-cb8cd02848f2	true	access.token.claim
387125c5-5735-482d-b6c1-cb8cd02848f2	phone_number	claim.name
387125c5-5735-482d-b6c1-cb8cd02848f2	String	jsonType.label
4d93033d-2070-4b3f-bb3c-b8bb1c19940a	true	userinfo.token.claim
4d93033d-2070-4b3f-bb3c-b8bb1c19940a	phoneNumberVerified	user.attribute
4d93033d-2070-4b3f-bb3c-b8bb1c19940a	true	id.token.claim
4d93033d-2070-4b3f-bb3c-b8bb1c19940a	true	access.token.claim
4d93033d-2070-4b3f-bb3c-b8bb1c19940a	phone_number_verified	claim.name
4d93033d-2070-4b3f-bb3c-b8bb1c19940a	boolean	jsonType.label
0132cd45-2832-4fb2-b3da-deb2bde01f7b	true	userinfo.token.claim
0132cd45-2832-4fb2-b3da-deb2bde01f7b	email	user.attribute
0132cd45-2832-4fb2-b3da-deb2bde01f7b	true	id.token.claim
0132cd45-2832-4fb2-b3da-deb2bde01f7b	true	access.token.claim
0132cd45-2832-4fb2-b3da-deb2bde01f7b	email	claim.name
0132cd45-2832-4fb2-b3da-deb2bde01f7b	String	jsonType.label
ec55de66-9ba8-401b-81a6-648deaa4dcdb	true	userinfo.token.claim
ec55de66-9ba8-401b-81a6-648deaa4dcdb	emailVerified	user.attribute
ec55de66-9ba8-401b-81a6-648deaa4dcdb	true	id.token.claim
ec55de66-9ba8-401b-81a6-648deaa4dcdb	true	access.token.claim
ec55de66-9ba8-401b-81a6-648deaa4dcdb	email_verified	claim.name
ec55de66-9ba8-401b-81a6-648deaa4dcdb	boolean	jsonType.label
016d0122-6dff-486c-b1ac-6417db3b7c16	true	multivalued
016d0122-6dff-486c-b1ac-6417db3b7c16	true	userinfo.token.claim
016d0122-6dff-486c-b1ac-6417db3b7c16	foo	user.attribute
016d0122-6dff-486c-b1ac-6417db3b7c16	true	id.token.claim
016d0122-6dff-486c-b1ac-6417db3b7c16	true	access.token.claim
016d0122-6dff-486c-b1ac-6417db3b7c16	groups	claim.name
016d0122-6dff-486c-b1ac-6417db3b7c16	String	jsonType.label
9015add1-eb40-4c3e-975e-bdd82293e7ce	true	userinfo.token.claim
9015add1-eb40-4c3e-975e-bdd82293e7ce	username	user.attribute
9015add1-eb40-4c3e-975e-bdd82293e7ce	true	id.token.claim
9015add1-eb40-4c3e-975e-bdd82293e7ce	true	access.token.claim
9015add1-eb40-4c3e-975e-bdd82293e7ce	upn	claim.name
9015add1-eb40-4c3e-975e-bdd82293e7ce	String	jsonType.label
2acd9feb-49ca-42f5-ad96-70cd81d217e5	true	id.token.claim
2acd9feb-49ca-42f5-ad96-70cd81d217e5	true	access.token.claim
2acd9feb-49ca-42f5-ad96-70cd81d217e5	true	userinfo.token.claim
33bcd5c2-ac56-44fe-9189-57e2b89f18dd	foo	user.attribute
33bcd5c2-ac56-44fe-9189-57e2b89f18dd	true	access.token.claim
33bcd5c2-ac56-44fe-9189-57e2b89f18dd	resource_access.${client_id}.roles	claim.name
33bcd5c2-ac56-44fe-9189-57e2b89f18dd	String	jsonType.label
33bcd5c2-ac56-44fe-9189-57e2b89f18dd	true	multivalued
cb29807a-92ec-4f8f-8966-0a5504548d19	foo	user.attribute
cb29807a-92ec-4f8f-8966-0a5504548d19	true	access.token.claim
cb29807a-92ec-4f8f-8966-0a5504548d19	realm_access.roles	claim.name
cb29807a-92ec-4f8f-8966-0a5504548d19	String	jsonType.label
cb29807a-92ec-4f8f-8966-0a5504548d19	true	multivalued
3de03083-9f1a-4fee-b76a-8a464b4689c8	false	single
3de03083-9f1a-4fee-b76a-8a464b4689c8	Basic	attribute.nameformat
3de03083-9f1a-4fee-b76a-8a464b4689c8	Role	attribute.name
828ba905-f502-4e9a-b531-42fd14290041	formatted	user.attribute.formatted
828ba905-f502-4e9a-b531-42fd14290041	country	user.attribute.country
828ba905-f502-4e9a-b531-42fd14290041	postal_code	user.attribute.postal_code
828ba905-f502-4e9a-b531-42fd14290041	true	userinfo.token.claim
828ba905-f502-4e9a-b531-42fd14290041	street	user.attribute.street
828ba905-f502-4e9a-b531-42fd14290041	true	id.token.claim
828ba905-f502-4e9a-b531-42fd14290041	region	user.attribute.region
828ba905-f502-4e9a-b531-42fd14290041	true	access.token.claim
828ba905-f502-4e9a-b531-42fd14290041	locality	user.attribute.locality
c375ea26-006d-4f9b-b9ce-7b203d6a6c8d	avni-server	included.client.audience
c375ea26-006d-4f9b-b9ce-7b203d6a6c8d	false	id.token.claim
c375ea26-006d-4f9b-b9ce-7b203d6a6c8d	true	access.token.claim
c375ea26-006d-4f9b-b9ce-7b203d6a6c8d	false	userinfo.token.claim
0d400723-54ed-4379-b560-5330d718d8b2	true	id.token.claim
0d400723-54ed-4379-b560-5330d718d8b2	true	access.token.claim
0d400723-54ed-4379-b560-5330d718d8b2	true	userinfo.token.claim
0e8f93cd-4bfe-4dd1-a519-50596e20c289	true	userinfo.token.claim
0e8f93cd-4bfe-4dd1-a519-50596e20c289	firstName	user.attribute
0e8f93cd-4bfe-4dd1-a519-50596e20c289	true	id.token.claim
0e8f93cd-4bfe-4dd1-a519-50596e20c289	true	access.token.claim
0e8f93cd-4bfe-4dd1-a519-50596e20c289	given_name	claim.name
0e8f93cd-4bfe-4dd1-a519-50596e20c289	String	jsonType.label
0fbdfa9f-58da-4d11-a94c-6290d8542f08	true	userinfo.token.claim
0fbdfa9f-58da-4d11-a94c-6290d8542f08	username	user.attribute
0fbdfa9f-58da-4d11-a94c-6290d8542f08	true	id.token.claim
0fbdfa9f-58da-4d11-a94c-6290d8542f08	true	access.token.claim
0fbdfa9f-58da-4d11-a94c-6290d8542f08	preferred_username	claim.name
0fbdfa9f-58da-4d11-a94c-6290d8542f08	String	jsonType.label
10ac7431-86ab-45ec-8bf8-3a08001e63fc	true	userinfo.token.claim
10ac7431-86ab-45ec-8bf8-3a08001e63fc	updatedAt	user.attribute
10ac7431-86ab-45ec-8bf8-3a08001e63fc	true	id.token.claim
10ac7431-86ab-45ec-8bf8-3a08001e63fc	true	access.token.claim
10ac7431-86ab-45ec-8bf8-3a08001e63fc	updated_at	claim.name
10ac7431-86ab-45ec-8bf8-3a08001e63fc	long	jsonType.label
2882bede-5489-4338-87a0-aa3de0cf20ae	true	userinfo.token.claim
2882bede-5489-4338-87a0-aa3de0cf20ae	birthdate	user.attribute
2882bede-5489-4338-87a0-aa3de0cf20ae	true	id.token.claim
2882bede-5489-4338-87a0-aa3de0cf20ae	true	access.token.claim
2882bede-5489-4338-87a0-aa3de0cf20ae	birthdate	claim.name
2882bede-5489-4338-87a0-aa3de0cf20ae	String	jsonType.label
2be4448d-1dd3-4dac-8f67-b63da7e9f4e7	true	userinfo.token.claim
2be4448d-1dd3-4dac-8f67-b63da7e9f4e7	website	user.attribute
2be4448d-1dd3-4dac-8f67-b63da7e9f4e7	true	id.token.claim
2be4448d-1dd3-4dac-8f67-b63da7e9f4e7	true	access.token.claim
2be4448d-1dd3-4dac-8f67-b63da7e9f4e7	website	claim.name
2be4448d-1dd3-4dac-8f67-b63da7e9f4e7	String	jsonType.label
2ece4931-9f38-4d06-8841-3d08dfc7153c	true	userinfo.token.claim
2ece4931-9f38-4d06-8841-3d08dfc7153c	lastName	user.attribute
2ece4931-9f38-4d06-8841-3d08dfc7153c	true	id.token.claim
2ece4931-9f38-4d06-8841-3d08dfc7153c	true	access.token.claim
2ece4931-9f38-4d06-8841-3d08dfc7153c	family_name	claim.name
2ece4931-9f38-4d06-8841-3d08dfc7153c	String	jsonType.label
488e7cd9-2dae-41a1-ad81-09f934273ac9	true	userinfo.token.claim
488e7cd9-2dae-41a1-ad81-09f934273ac9	zoneinfo	user.attribute
488e7cd9-2dae-41a1-ad81-09f934273ac9	true	id.token.claim
488e7cd9-2dae-41a1-ad81-09f934273ac9	true	access.token.claim
488e7cd9-2dae-41a1-ad81-09f934273ac9	zoneinfo	claim.name
488e7cd9-2dae-41a1-ad81-09f934273ac9	String	jsonType.label
838a8c95-e6ff-466f-accd-e2d891901f00	true	userinfo.token.claim
838a8c95-e6ff-466f-accd-e2d891901f00	middleName	user.attribute
838a8c95-e6ff-466f-accd-e2d891901f00	true	id.token.claim
838a8c95-e6ff-466f-accd-e2d891901f00	true	access.token.claim
838a8c95-e6ff-466f-accd-e2d891901f00	middle_name	claim.name
838a8c95-e6ff-466f-accd-e2d891901f00	String	jsonType.label
89417ce2-f8f4-42e8-b117-529febfdaca9	true	userinfo.token.claim
89417ce2-f8f4-42e8-b117-529febfdaca9	profile	user.attribute
89417ce2-f8f4-42e8-b117-529febfdaca9	true	id.token.claim
89417ce2-f8f4-42e8-b117-529febfdaca9	true	access.token.claim
89417ce2-f8f4-42e8-b117-529febfdaca9	profile	claim.name
89417ce2-f8f4-42e8-b117-529febfdaca9	String	jsonType.label
8d85e784-ea8d-4d21-a78b-e3a08db7c847	true	userinfo.token.claim
8d85e784-ea8d-4d21-a78b-e3a08db7c847	gender	user.attribute
8d85e784-ea8d-4d21-a78b-e3a08db7c847	true	id.token.claim
8d85e784-ea8d-4d21-a78b-e3a08db7c847	true	access.token.claim
8d85e784-ea8d-4d21-a78b-e3a08db7c847	gender	claim.name
8d85e784-ea8d-4d21-a78b-e3a08db7c847	String	jsonType.label
8ec75a95-e52e-4b6c-9d01-9c8fc6c7f933	true	userinfo.token.claim
8ec75a95-e52e-4b6c-9d01-9c8fc6c7f933	picture	user.attribute
8ec75a95-e52e-4b6c-9d01-9c8fc6c7f933	true	id.token.claim
8ec75a95-e52e-4b6c-9d01-9c8fc6c7f933	true	access.token.claim
8ec75a95-e52e-4b6c-9d01-9c8fc6c7f933	picture	claim.name
8ec75a95-e52e-4b6c-9d01-9c8fc6c7f933	String	jsonType.label
9796fa98-06e7-4e85-a720-3382778bea21	true	userinfo.token.claim
9796fa98-06e7-4e85-a720-3382778bea21	locale	user.attribute
9796fa98-06e7-4e85-a720-3382778bea21	true	id.token.claim
9796fa98-06e7-4e85-a720-3382778bea21	true	access.token.claim
9796fa98-06e7-4e85-a720-3382778bea21	locale	claim.name
9796fa98-06e7-4e85-a720-3382778bea21	String	jsonType.label
f0436fb7-ae5a-4be2-b147-2826d6ed6750	true	userinfo.token.claim
f0436fb7-ae5a-4be2-b147-2826d6ed6750	nickname	user.attribute
f0436fb7-ae5a-4be2-b147-2826d6ed6750	true	id.token.claim
f0436fb7-ae5a-4be2-b147-2826d6ed6750	true	access.token.claim
f0436fb7-ae5a-4be2-b147-2826d6ed6750	nickname	claim.name
f0436fb7-ae5a-4be2-b147-2826d6ed6750	String	jsonType.label
1616b5cc-bac8-40c1-8601-0c2e89c08df8	clientHost	user.session.note
1616b5cc-bac8-40c1-8601-0c2e89c08df8	true	userinfo.token.claim
1616b5cc-bac8-40c1-8601-0c2e89c08df8	true	id.token.claim
1616b5cc-bac8-40c1-8601-0c2e89c08df8	true	access.token.claim
1616b5cc-bac8-40c1-8601-0c2e89c08df8	clientHost	claim.name
1616b5cc-bac8-40c1-8601-0c2e89c08df8	String	jsonType.label
e31728b0-a369-41b8-b964-bd0e596f2a4c	clientId	user.session.note
e31728b0-a369-41b8-b964-bd0e596f2a4c	true	userinfo.token.claim
e31728b0-a369-41b8-b964-bd0e596f2a4c	true	id.token.claim
e31728b0-a369-41b8-b964-bd0e596f2a4c	true	access.token.claim
e31728b0-a369-41b8-b964-bd0e596f2a4c	clientId	claim.name
e31728b0-a369-41b8-b964-bd0e596f2a4c	String	jsonType.label
edb01d0b-1d97-42d8-8f16-4ea59b40a523	clientAddress	user.session.note
edb01d0b-1d97-42d8-8f16-4ea59b40a523	true	userinfo.token.claim
edb01d0b-1d97-42d8-8f16-4ea59b40a523	true	id.token.claim
edb01d0b-1d97-42d8-8f16-4ea59b40a523	true	access.token.claim
edb01d0b-1d97-42d8-8f16-4ea59b40a523	clientAddress	claim.name
edb01d0b-1d97-42d8-8f16-4ea59b40a523	String	jsonType.label
71e84e97-63ee-4953-9a85-e37026f5c07d	clientHost	user.session.note
71e84e97-63ee-4953-9a85-e37026f5c07d	true	userinfo.token.claim
71e84e97-63ee-4953-9a85-e37026f5c07d	true	id.token.claim
71e84e97-63ee-4953-9a85-e37026f5c07d	true	access.token.claim
71e84e97-63ee-4953-9a85-e37026f5c07d	clientHost	claim.name
71e84e97-63ee-4953-9a85-e37026f5c07d	String	jsonType.label
a832dff7-e378-4a7e-ab25-b198aa36e901	clientAddress	user.session.note
a832dff7-e378-4a7e-ab25-b198aa36e901	true	userinfo.token.claim
a832dff7-e378-4a7e-ab25-b198aa36e901	true	id.token.claim
a832dff7-e378-4a7e-ab25-b198aa36e901	true	access.token.claim
a832dff7-e378-4a7e-ab25-b198aa36e901	clientAddress	claim.name
a832dff7-e378-4a7e-ab25-b198aa36e901	String	jsonType.label
c3ad0583-c1b5-4759-b4fb-1bbdb7aef033	true	userinfo.token.claim
c3ad0583-c1b5-4759-b4fb-1bbdb7aef033	custom:userUUID	user.attribute
c3ad0583-c1b5-4759-b4fb-1bbdb7aef033	true	id.token.claim
c3ad0583-c1b5-4759-b4fb-1bbdb7aef033	true	access.token.claim
c3ad0583-c1b5-4759-b4fb-1bbdb7aef033	custom:userUUID	claim.name
c3ad0583-c1b5-4759-b4fb-1bbdb7aef033	String	jsonType.label
febab41d-a1e4-46fb-adab-5581d1d4c71e	clientId	user.session.note
febab41d-a1e4-46fb-adab-5581d1d4c71e	true	userinfo.token.claim
febab41d-a1e4-46fb-adab-5581d1d4c71e	true	id.token.claim
febab41d-a1e4-46fb-adab-5581d1d4c71e	true	access.token.claim
febab41d-a1e4-46fb-adab-5581d1d4c71e	clientId	claim.name
febab41d-a1e4-46fb-adab-5581d1d4c71e	String	jsonType.label
47ddea50-e388-4d57-8e81-a4e7c3430e94	true	userinfo.token.claim
47ddea50-e388-4d57-8e81-a4e7c3430e94	locale	user.attribute
47ddea50-e388-4d57-8e81-a4e7c3430e94	true	id.token.claim
47ddea50-e388-4d57-8e81-a4e7c3430e94	true	access.token.claim
47ddea50-e388-4d57-8e81-a4e7c3430e94	locale	claim.name
47ddea50-e388-4d57-8e81-a4e7c3430e94	String	jsonType.label
\.


--
-- Data for Name: realm; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm (id, access_code_lifespan, user_action_lifespan, access_token_lifespan, account_theme, admin_theme, email_theme, enabled, events_enabled, events_expiration, login_theme, name, not_before, password_policy, registration_allowed, remember_me, reset_password_allowed, social, ssl_required, sso_idle_timeout, sso_max_lifespan, update_profile_on_soc_login, verify_email, master_admin_client, login_lifespan, internationalization_enabled, default_locale, reg_email_as_username, admin_events_enabled, admin_events_details_enabled, edit_username_allowed, otp_policy_counter, otp_policy_window, otp_policy_period, otp_policy_digits, otp_policy_alg, otp_policy_type, browser_flow, registration_flow, direct_grant_flow, reset_credentials_flow, client_auth_flow, offline_session_idle_timeout, revoke_refresh_token, access_token_life_implicit, login_with_email_allowed, duplicate_emails_allowed, docker_auth_flow, refresh_token_max_reuse, allow_user_managed_access, sso_max_lifespan_remember_me, sso_idle_timeout_remember_me, default_role) FROM stdin;
091121bd-5b90-4312-8e4f-1be85be87c5c	60	300	60	\N	\N	\N	t	f	0	\N	master	0	\N	f	f	f	f	EXTERNAL	1800	36000	f	f	6aa3754c-83c0-40f4-9474-3c745b7d49c5	1800	f	\N	f	f	f	f	0	1	30	6	HmacSHA1	totp	68ee5cbd-ef49-4923-b982-914a3410fd1c	99ca4bdc-2b5e-492e-856a-fae45fad14f5	3e78fade-907d-4d90-9390-20f00ed9c19c	2d4b185b-41a4-4ff9-9ecf-2326e0f7fcdb	88bc3fe8-de3e-4d10-a51c-2d76b8b74e89	2592000	f	900	t	f	196847b3-ff4b-411e-b4d4-3a9ed856b024	0	f	0	0	c83f012e-6f48-41b1-86ba-cfd0d4b627e7
On-premise	60	300	300	\N	\N	\N	t	f	0	\N	On-premise	0	\N	f	f	f	f	EXTERNAL	2592000	2592000	f	f	7abb271f-4aaa-4949-a6a4-3d44226fcb9a	1800	f	\N	f	f	f	f	0	1	30	6	HmacSHA1	totp	c2707c8a-a5b6-4e78-add6-808d7ec5e428	24eebbdf-6ebd-4241-8232-436e878fe1d0	36ef8c4c-7c54-40e2-b207-fec6f3658272	5237249c-cf5b-4411-bc6c-cecbc5f19eb1	5a2ea00b-95ef-4f39-a09a-9412954bbf6c	2592000	f	900	t	f	dfa7479a-057e-4c43-babb-f7a666d89af6	0	f	0	0	69c368f8-4e0e-4420-93e7-918f504378e4
\.


--
-- Data for Name: realm_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_attribute (name, realm_id, value) FROM stdin;
_browser_header.contentSecurityPolicyReportOnly	091121bd-5b90-4312-8e4f-1be85be87c5c	
_browser_header.xContentTypeOptions	091121bd-5b90-4312-8e4f-1be85be87c5c	nosniff
_browser_header.xRobotsTag	091121bd-5b90-4312-8e4f-1be85be87c5c	none
_browser_header.xFrameOptions	091121bd-5b90-4312-8e4f-1be85be87c5c	SAMEORIGIN
_browser_header.contentSecurityPolicy	091121bd-5b90-4312-8e4f-1be85be87c5c	frame-src 'self'; frame-ancestors 'self'; object-src 'none';
_browser_header.xXSSProtection	091121bd-5b90-4312-8e4f-1be85be87c5c	1; mode=block
_browser_header.strictTransportSecurity	091121bd-5b90-4312-8e4f-1be85be87c5c	max-age=31536000; includeSubDomains
bruteForceProtected	091121bd-5b90-4312-8e4f-1be85be87c5c	false
permanentLockout	091121bd-5b90-4312-8e4f-1be85be87c5c	false
maxFailureWaitSeconds	091121bd-5b90-4312-8e4f-1be85be87c5c	900
minimumQuickLoginWaitSeconds	091121bd-5b90-4312-8e4f-1be85be87c5c	60
waitIncrementSeconds	091121bd-5b90-4312-8e4f-1be85be87c5c	60
quickLoginCheckMilliSeconds	091121bd-5b90-4312-8e4f-1be85be87c5c	1000
maxDeltaTimeSeconds	091121bd-5b90-4312-8e4f-1be85be87c5c	43200
failureFactor	091121bd-5b90-4312-8e4f-1be85be87c5c	30
realmReusableOtpCode	091121bd-5b90-4312-8e4f-1be85be87c5c	false
displayName	091121bd-5b90-4312-8e4f-1be85be87c5c	Keycloak
displayNameHtml	091121bd-5b90-4312-8e4f-1be85be87c5c	<div class="kc-logo-text"><span>Keycloak</span></div>
defaultSignatureAlgorithm	091121bd-5b90-4312-8e4f-1be85be87c5c	RS256
offlineSessionMaxLifespanEnabled	091121bd-5b90-4312-8e4f-1be85be87c5c	false
offlineSessionMaxLifespan	091121bd-5b90-4312-8e4f-1be85be87c5c	5184000
_browser_header.contentSecurityPolicyReportOnly	On-premise	
_browser_header.xContentTypeOptions	On-premise	nosniff
_browser_header.xRobotsTag	On-premise	none
_browser_header.xFrameOptions	On-premise	SAMEORIGIN
_browser_header.contentSecurityPolicy	On-premise	frame-src 'self'; frame-ancestors 'self'; object-src 'none';
_browser_header.xXSSProtection	On-premise	1; mode=block
_browser_header.strictTransportSecurity	On-premise	max-age=31536000; includeSubDomains
bruteForceProtected	On-premise	false
permanentLockout	On-premise	false
maxFailureWaitSeconds	On-premise	900
minimumQuickLoginWaitSeconds	On-premise	60
waitIncrementSeconds	On-premise	60
quickLoginCheckMilliSeconds	On-premise	1000
maxDeltaTimeSeconds	On-premise	43200
failureFactor	On-premise	30
realmReusableOtpCode	On-premise	false
displayName	On-premise	On-premise
defaultSignatureAlgorithm	On-premise	RS256
offlineSessionMaxLifespanEnabled	On-premise	false
offlineSessionMaxLifespan	On-premise	5184000
clientSessionIdleTimeout	On-premise	0
clientSessionMaxLifespan	On-premise	0
clientOfflineSessionIdleTimeout	On-premise	0
clientOfflineSessionMaxLifespan	On-premise	0
actionTokenGeneratedByAdminLifespan	On-premise	43200
actionTokenGeneratedByUserLifespan	On-premise	300
oauth2DeviceCodeLifespan	On-premise	300
oauth2DevicePollingInterval	On-premise	5
webAuthnPolicyRpEntityName	On-premise	keycloak
webAuthnPolicySignatureAlgorithms	On-premise	ES256
webAuthnPolicyRpId	On-premise	
webAuthnPolicyAttestationConveyancePreference	On-premise	not specified
webAuthnPolicyAuthenticatorAttachment	On-premise	not specified
webAuthnPolicyRequireResidentKey	On-premise	not specified
webAuthnPolicyUserVerificationRequirement	On-premise	not specified
webAuthnPolicyCreateTimeout	On-premise	0
webAuthnPolicyAvoidSameAuthenticatorRegister	On-premise	false
webAuthnPolicyRpEntityNamePasswordless	On-premise	keycloak
webAuthnPolicySignatureAlgorithmsPasswordless	On-premise	ES256
webAuthnPolicyRpIdPasswordless	On-premise	
webAuthnPolicyAttestationConveyancePreferencePasswordless	On-premise	not specified
webAuthnPolicyAuthenticatorAttachmentPasswordless	On-premise	not specified
webAuthnPolicyRequireResidentKeyPasswordless	On-premise	not specified
webAuthnPolicyUserVerificationRequirementPasswordless	On-premise	not specified
webAuthnPolicyCreateTimeoutPasswordless	On-premise	0
webAuthnPolicyAvoidSameAuthenticatorRegisterPasswordless	On-premise	false
cibaBackchannelTokenDeliveryMode	On-premise	poll
cibaExpiresIn	On-premise	120
cibaInterval	On-premise	5
cibaAuthRequestedUserHint	On-premise	login_hint
parRequestUriLifespan	On-premise	60
userProfileEnabled	On-premise	false
client-policies.profiles	On-premise	{"profiles":[]}
client-policies.policies	On-premise	{"policies":[]}
\.


--
-- Data for Name: realm_default_groups; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_default_groups (realm_id, group_id) FROM stdin;
\.


--
-- Data for Name: realm_enabled_event_types; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_enabled_event_types (realm_id, value) FROM stdin;
\.


--
-- Data for Name: realm_events_listeners; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_events_listeners (realm_id, value) FROM stdin;
091121bd-5b90-4312-8e4f-1be85be87c5c	jboss-logging
On-premise	jboss-logging
\.


--
-- Data for Name: realm_localizations; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_localizations (realm_id, locale, texts) FROM stdin;
\.


--
-- Data for Name: realm_required_credential; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_required_credential (type, form_label, input, secret, realm_id) FROM stdin;
password	password	t	t	091121bd-5b90-4312-8e4f-1be85be87c5c
password	password	t	t	On-premise
\.


--
-- Data for Name: realm_smtp_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_smtp_config (realm_id, value, name) FROM stdin;
\.


--
-- Data for Name: realm_supported_locales; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_supported_locales (realm_id, value) FROM stdin;
\.


--
-- Data for Name: redirect_uris; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.redirect_uris (client_id, value) FROM stdin;
192e12a1-d757-45fa-af0c-4e1403d6839b	/realms/master/account/*
8159c06d-88e2-43ed-8b46-235e9f914801	/realms/master/account/*
716e3e61-eb87-4888-9954-a77d44ffa498	/admin/master/console/*
676ec99d-bef5-49ef-b9c4-1be17bd4f92f	/realms/On-premise/account/*
63e63428-fdea-4672-8e4f-d7a4df56393f	/realms/On-premise/account/*
4381c433-5988-418a-bc71-177bb46e873a	http://localhost:8080/*
915277c7-706e-4aa8-ad41-dfc2c3818c0b	https://3.109.55.3:8022
f355103f-48b5-4615-adb5-9992c317295c	/admin/On-premise/console/*
\.


--
-- Data for Name: required_action_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.required_action_config (required_action_id, value, name) FROM stdin;
\.


--
-- Data for Name: required_action_provider; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.required_action_provider (id, alias, name, realm_id, enabled, default_action, provider_id, priority) FROM stdin;
4fd3352d-4729-423c-a692-3256a78a5007	VERIFY_EMAIL	Verify Email	091121bd-5b90-4312-8e4f-1be85be87c5c	t	f	VERIFY_EMAIL	50
398bb74f-dc71-4f71-9e14-ec78b7910f29	UPDATE_PROFILE	Update Profile	091121bd-5b90-4312-8e4f-1be85be87c5c	t	f	UPDATE_PROFILE	40
55b1277c-4613-4bdc-9087-cdc528daaab9	CONFIGURE_TOTP	Configure OTP	091121bd-5b90-4312-8e4f-1be85be87c5c	t	f	CONFIGURE_TOTP	10
71f9a17c-f287-41b2-acc1-a5ab9841ec8b	UPDATE_PASSWORD	Update Password	091121bd-5b90-4312-8e4f-1be85be87c5c	t	f	UPDATE_PASSWORD	30
490e7840-3f33-4025-a9dc-5a3c9fe5c95c	terms_and_conditions	Terms and Conditions	091121bd-5b90-4312-8e4f-1be85be87c5c	f	f	terms_and_conditions	20
b2cf6d2c-a71b-4389-ada7-a573c12b0b5a	delete_account	Delete Account	091121bd-5b90-4312-8e4f-1be85be87c5c	f	f	delete_account	60
eccff344-ad0c-47fd-b1ca-967ee97f2d88	update_user_locale	Update User Locale	091121bd-5b90-4312-8e4f-1be85be87c5c	t	f	update_user_locale	1000
ebb3280f-0cf4-48d7-908d-b8978c52ccab	webauthn-register	Webauthn Register	091121bd-5b90-4312-8e4f-1be85be87c5c	t	f	webauthn-register	70
821e80e7-77f2-492f-bfbb-726a2df63b69	webauthn-register-passwordless	Webauthn Register Passwordless	091121bd-5b90-4312-8e4f-1be85be87c5c	t	f	webauthn-register-passwordless	80
c5c6a5f9-cb26-4cef-9ffc-41693089c4e5	CONFIGURE_TOTP	Configure OTP	On-premise	t	f	CONFIGURE_TOTP	10
bde7d130-f4a2-463c-91b7-898b2857f4dc	delete_account	Delete Account	On-premise	f	f	delete_account	20
ba255a63-3e6d-4c7f-8bfb-8ed0b33e8bdc	terms_and_conditions	Terms and Conditions	On-premise	f	f	terms_and_conditions	30
941288fa-471b-4fb5-a351-e49dd52c2527	UPDATE_PASSWORD	Update Password	On-premise	t	f	UPDATE_PASSWORD	40
c52c389d-3d89-48eb-bbf7-be2dc21fb1c9	UPDATE_PROFILE	Update Profile	On-premise	t	f	UPDATE_PROFILE	50
7d41012f-c908-4102-b98f-c564093c65e7	update_user_locale	Update User Locale	On-premise	t	f	update_user_locale	60
a0ac4678-7969-485f-901d-97761acda42f	VERIFY_EMAIL	Verify Email	On-premise	t	f	VERIFY_EMAIL	70
\.


--
-- Data for Name: resource_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_attribute (id, name, value, resource_id) FROM stdin;
\.


--
-- Data for Name: resource_policy; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_policy (resource_id, policy_id) FROM stdin;
\.


--
-- Data for Name: resource_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_scope (resource_id, scope_id) FROM stdin;
\.


--
-- Data for Name: resource_server; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_server (id, allow_rs_remote_mgmt, policy_enforce_mode, decision_strategy) FROM stdin;
\.


--
-- Data for Name: resource_server_perm_ticket; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_server_perm_ticket (id, owner, requester, created_timestamp, granted_timestamp, resource_id, scope_id, resource_server_id, policy_id) FROM stdin;
\.


--
-- Data for Name: resource_server_policy; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_server_policy (id, name, description, type, decision_strategy, logic, resource_server_id, owner) FROM stdin;
\.


--
-- Data for Name: resource_server_resource; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_server_resource (id, name, type, icon_uri, owner, resource_server_id, owner_managed_access, display_name) FROM stdin;
\.


--
-- Data for Name: resource_server_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_server_scope (id, name, icon_uri, resource_server_id, display_name) FROM stdin;
\.


--
-- Data for Name: resource_uris; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_uris (resource_id, value) FROM stdin;
\.


--
-- Data for Name: role_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.role_attribute (id, role_id, name, value) FROM stdin;
\.


--
-- Data for Name: scope_mapping; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.scope_mapping (client_id, role_id) FROM stdin;
8159c06d-88e2-43ed-8b46-235e9f914801	8486fe5e-61db-48d7-b8c7-cebddda3dcc1
8159c06d-88e2-43ed-8b46-235e9f914801	6e5f311d-f00d-4291-be03-24217c579ee1
63e63428-fdea-4672-8e4f-d7a4df56393f	2ee509b1-2f53-45ee-9673-d71e8e60a78a
63e63428-fdea-4672-8e4f-d7a4df56393f	01ded32e-7299-4877-b1de-ceab307fdf0d
\.


--
-- Data for Name: scope_policy; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.scope_policy (scope_id, policy_id) FROM stdin;
\.


--
-- Data for Name: user_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_attribute (name, value, user_id, id) FROM stdin;
custom:userUUID	c003963f-0596-49dc-b8bf-04121a94f157	ddb50d3a-b3d8-402b-87be-1cc710809460	cb9893fc-7688-497d-935f-59de11aa4b67
phone_number_verified	true	ddb50d3a-b3d8-402b-87be-1cc710809460	e37f446b-6795-4790-8bd0-544f3cf21e29
phone_number	+919876543210	ddb50d3a-b3d8-402b-87be-1cc710809460	9283af0d-ae4b-4ba7-a515-428c42f11540
custom:userUUID	4c410f18-8d8e-4b6e-a5b2-96ab8377d997	5d2b9204-81d3-42ae-9e61-80e2d9bcb83c	4f4008da-1324-4e2c-b160-7164bc015fea
phone_number_verified	true	5d2b9204-81d3-42ae-9e61-80e2d9bcb83c	ae8514d0-40f0-42d9-a0bb-3611ee2ca1df
phone_number	+919876543211	5d2b9204-81d3-42ae-9e61-80e2d9bcb83c	0b647f0c-5987-49c0-9a27-6f71a94ef4bf
\.


--
-- Data for Name: user_consent; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_consent (id, client_id, user_id, created_date, last_updated_date, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: user_consent_client_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_consent_client_scope (user_consent_id, scope_id) FROM stdin;
\.


--
-- Data for Name: user_entity; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_entity (id, email, email_constraint, email_verified, enabled, federation_link, first_name, last_name, realm_id, username, created_timestamp, service_account_client_link, not_before) FROM stdin;
24aab309-a259-4c6e-9546-6d5f601c5538	\N	7fed0d24-18de-4254-9831-a2107a4eeb59	f	t	\N	\N	\N	091121bd-5b90-4312-8e4f-1be85be87c5c	keycloakadmin	1687143680446	\N	0
f72df378-c154-4cef-99f6-07c40621a687	\N	d02766ff-14e8-48d5-a892-5a84b6e9f18c	f	t	\N	\N	\N	On-premise	service-account-admin-api	1656653394420	4381c433-5988-418a-bc71-177bb46e873a	0
b1a99303-174c-4b31-9263-f3a315a96b16	\N	4e48e44f-fda5-456f-b485-fab951c49c48	f	t	\N	\N	\N	On-premise	service-account-avni-client	1687143736486	915277c7-706e-4aa8-ad41-dfc2c3818c0b	0
8e570c12-99a2-4f26-b30c-796b220467df	admin@example.com	admin@example.com	t	t	\N	Admin		On-premise	admin	1687143750224	\N	0
ddb50d3a-b3d8-402b-87be-1cc710809460	bahmniadmin@example.com	bahmniadmin@example.com	t	t	\N	Administrator	\N	On-premise	admin@bahmni	1687144252954	\N	0
5d2b9204-81d3-42ae-9e61-80e2d9bcb83c	bahmniintegration@example.com	bahmniintegration@example.com	t	t	\N	Integration	\N	On-premise	integration@bahmni	1687144652305	\N	0
\.


--
-- Data for Name: user_federation_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_federation_config (user_federation_provider_id, value, name) FROM stdin;
\.


--
-- Data for Name: user_federation_mapper; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_federation_mapper (id, name, federation_provider_id, federation_mapper_type, realm_id) FROM stdin;
\.


--
-- Data for Name: user_federation_mapper_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_federation_mapper_config (user_federation_mapper_id, value, name) FROM stdin;
\.


--
-- Data for Name: user_federation_provider; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_federation_provider (id, changed_sync_period, display_name, full_sync_period, last_sync, priority, provider_name, realm_id) FROM stdin;
\.


--
-- Data for Name: user_group_membership; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_group_membership (group_id, user_id) FROM stdin;
\.


--
-- Data for Name: user_required_action; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_required_action (user_id, required_action) FROM stdin;
\.


--
-- Data for Name: user_role_mapping; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_role_mapping (role_id, user_id) FROM stdin;
c83f012e-6f48-41b1-86ba-cfd0d4b627e7	24aab309-a259-4c6e-9546-6d5f601c5538
c7e49872-a95c-4ac9-bd10-147c32a0cf33	24aab309-a259-4c6e-9546-6d5f601c5538
69c368f8-4e0e-4420-93e7-918f504378e4	f72df378-c154-4cef-99f6-07c40621a687
69c368f8-4e0e-4420-93e7-918f504378e4	b1a99303-174c-4b31-9263-f3a315a96b16
06f1d0ae-77f8-4dc3-a027-987f514fe058	24aab309-a259-4c6e-9546-6d5f601c5538
74539763-cd50-4957-bc8c-d8404b085829	24aab309-a259-4c6e-9546-6d5f601c5538
b1b40619-025a-4c98-a128-a8eed362adf7	24aab309-a259-4c6e-9546-6d5f601c5538
b4dc1581-7cbd-417b-9cbb-9217caab806f	24aab309-a259-4c6e-9546-6d5f601c5538
8a3759ed-c8f0-49fc-ab90-cdd171ff28f2	24aab309-a259-4c6e-9546-6d5f601c5538
e58bd9ca-9045-495b-9c41-1e250e519ab8	24aab309-a259-4c6e-9546-6d5f601c5538
6d10438f-a980-4e4d-9957-ca4035faf8ae	24aab309-a259-4c6e-9546-6d5f601c5538
5de67731-9d6b-42eb-bd9b-53cc92e7ae9a	24aab309-a259-4c6e-9546-6d5f601c5538
60be1184-9c2f-4521-961f-e22aeb0d5176	24aab309-a259-4c6e-9546-6d5f601c5538
52e32be9-8a01-41df-ad01-ec6e678677bc	24aab309-a259-4c6e-9546-6d5f601c5538
cc4da88c-9298-4e3d-86e4-0caa89d740af	24aab309-a259-4c6e-9546-6d5f601c5538
863b0172-20b5-4e92-87bd-67e17f211d5a	24aab309-a259-4c6e-9546-6d5f601c5538
e0058054-cc40-4d41-a091-b4338c8dfddb	24aab309-a259-4c6e-9546-6d5f601c5538
3f4b9565-3e05-4525-a3c5-188a6ef376ae	24aab309-a259-4c6e-9546-6d5f601c5538
a277648e-96b6-4a3f-b41e-9c6c396ec05c	24aab309-a259-4c6e-9546-6d5f601c5538
1e230aae-0b47-4d34-9b92-fd110fd07bbc	24aab309-a259-4c6e-9546-6d5f601c5538
5b5b0cb4-1e98-41ec-b267-855a93e0f38a	24aab309-a259-4c6e-9546-6d5f601c5538
69c368f8-4e0e-4420-93e7-918f504378e4	8e570c12-99a2-4f26-b30c-796b220467df
69c368f8-4e0e-4420-93e7-918f504378e4	ddb50d3a-b3d8-402b-87be-1cc710809460
69c368f8-4e0e-4420-93e7-918f504378e4	5d2b9204-81d3-42ae-9e61-80e2d9bcb83c
\.


--
-- Data for Name: user_session; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_session (id, auth_method, ip_address, last_session_refresh, login_username, realm_id, remember_me, started, user_id, user_session_state, broker_session_id, broker_user_id) FROM stdin;
\.


--
-- Data for Name: user_session_note; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_session_note (user_session, name, value) FROM stdin;
\.


--
-- Data for Name: username_login_failure; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.username_login_failure (realm_id, username, failed_login_not_before, last_failure, last_ip_failure, num_failures) FROM stdin;
\.


--
-- Data for Name: web_origins; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.web_origins (client_id, value) FROM stdin;
716e3e61-eb87-4888-9954-a77d44ffa498	+
4381c433-5988-418a-bc71-177bb46e873a	http://localhost:8080
915277c7-706e-4aa8-ad41-dfc2c3818c0b	*
f355103f-48b5-4615-adb5-9992c317295c	+
\.


--
-- Name: username_login_failure CONSTRAINT_17-2; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.username_login_failure
    ADD CONSTRAINT "CONSTRAINT_17-2" PRIMARY KEY (realm_id, username);


--
-- Name: keycloak_role UK_J3RWUVD56ONTGSUHOGM184WW2-2; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT "UK_J3RWUVD56ONTGSUHOGM184WW2-2" UNIQUE (name, client_realm_constraint);


--
-- Name: client_auth_flow_bindings c_cli_flow_bind; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_auth_flow_bindings
    ADD CONSTRAINT c_cli_flow_bind PRIMARY KEY (client_id, binding_name);


--
-- Name: client_scope_client c_cli_scope_bind; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope_client
    ADD CONSTRAINT c_cli_scope_bind PRIMARY KEY (client_id, scope_id);


--
-- Name: client_initial_access cnstr_client_init_acc_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_initial_access
    ADD CONSTRAINT cnstr_client_init_acc_pk PRIMARY KEY (id);


--
-- Name: realm_default_groups con_group_id_def_groups; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT con_group_id_def_groups UNIQUE (group_id);


--
-- Name: broker_link constr_broker_link_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.broker_link
    ADD CONSTRAINT constr_broker_link_pk PRIMARY KEY (identity_provider, user_id);


--
-- Name: client_user_session_note constr_cl_usr_ses_note; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_user_session_note
    ADD CONSTRAINT constr_cl_usr_ses_note PRIMARY KEY (client_session, name);


--
-- Name: component_config constr_component_config_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.component_config
    ADD CONSTRAINT constr_component_config_pk PRIMARY KEY (id);


--
-- Name: component constr_component_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.component
    ADD CONSTRAINT constr_component_pk PRIMARY KEY (id);


--
-- Name: fed_user_required_action constr_fed_required_action; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_required_action
    ADD CONSTRAINT constr_fed_required_action PRIMARY KEY (required_action, user_id);


--
-- Name: fed_user_attribute constr_fed_user_attr_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_attribute
    ADD CONSTRAINT constr_fed_user_attr_pk PRIMARY KEY (id);


--
-- Name: fed_user_consent constr_fed_user_consent_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_consent
    ADD CONSTRAINT constr_fed_user_consent_pk PRIMARY KEY (id);


--
-- Name: fed_user_credential constr_fed_user_cred_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_credential
    ADD CONSTRAINT constr_fed_user_cred_pk PRIMARY KEY (id);


--
-- Name: fed_user_group_membership constr_fed_user_group; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_group_membership
    ADD CONSTRAINT constr_fed_user_group PRIMARY KEY (group_id, user_id);


--
-- Name: fed_user_role_mapping constr_fed_user_role; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_role_mapping
    ADD CONSTRAINT constr_fed_user_role PRIMARY KEY (role_id, user_id);


--
-- Name: federated_user constr_federated_user; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.federated_user
    ADD CONSTRAINT constr_federated_user PRIMARY KEY (id);


--
-- Name: realm_default_groups constr_realm_default_groups; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT constr_realm_default_groups PRIMARY KEY (realm_id, group_id);


--
-- Name: realm_enabled_event_types constr_realm_enabl_event_types; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_enabled_event_types
    ADD CONSTRAINT constr_realm_enabl_event_types PRIMARY KEY (realm_id, value);


--
-- Name: realm_events_listeners constr_realm_events_listeners; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_events_listeners
    ADD CONSTRAINT constr_realm_events_listeners PRIMARY KEY (realm_id, value);


--
-- Name: realm_supported_locales constr_realm_supported_locales; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_supported_locales
    ADD CONSTRAINT constr_realm_supported_locales PRIMARY KEY (realm_id, value);


--
-- Name: identity_provider constraint_2b; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT constraint_2b PRIMARY KEY (internal_id);


--
-- Name: client_attributes constraint_3c; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_attributes
    ADD CONSTRAINT constraint_3c PRIMARY KEY (client_id, name);


--
-- Name: event_entity constraint_4; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.event_entity
    ADD CONSTRAINT constraint_4 PRIMARY KEY (id);


--
-- Name: federated_identity constraint_40; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.federated_identity
    ADD CONSTRAINT constraint_40 PRIMARY KEY (identity_provider, user_id);


--
-- Name: realm constraint_4a; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm
    ADD CONSTRAINT constraint_4a PRIMARY KEY (id);


--
-- Name: client_session_role constraint_5; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_role
    ADD CONSTRAINT constraint_5 PRIMARY KEY (client_session, role_id);


--
-- Name: user_session constraint_57; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_session
    ADD CONSTRAINT constraint_57 PRIMARY KEY (id);


--
-- Name: user_federation_provider constraint_5c; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_provider
    ADD CONSTRAINT constraint_5c PRIMARY KEY (id);


--
-- Name: client_session_note constraint_5e; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_note
    ADD CONSTRAINT constraint_5e PRIMARY KEY (client_session, name);


--
-- Name: client constraint_7; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT constraint_7 PRIMARY KEY (id);


--
-- Name: client_session constraint_8; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session
    ADD CONSTRAINT constraint_8 PRIMARY KEY (id);


--
-- Name: scope_mapping constraint_81; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.scope_mapping
    ADD CONSTRAINT constraint_81 PRIMARY KEY (client_id, role_id);


--
-- Name: client_node_registrations constraint_84; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_node_registrations
    ADD CONSTRAINT constraint_84 PRIMARY KEY (client_id, name);


--
-- Name: realm_attribute constraint_9; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_attribute
    ADD CONSTRAINT constraint_9 PRIMARY KEY (name, realm_id);


--
-- Name: realm_required_credential constraint_92; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_required_credential
    ADD CONSTRAINT constraint_92 PRIMARY KEY (realm_id, type);


--
-- Name: keycloak_role constraint_a; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT constraint_a PRIMARY KEY (id);


--
-- Name: admin_event_entity constraint_admin_event_entity; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.admin_event_entity
    ADD CONSTRAINT constraint_admin_event_entity PRIMARY KEY (id);


--
-- Name: authenticator_config_entry constraint_auth_cfg_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authenticator_config_entry
    ADD CONSTRAINT constraint_auth_cfg_pk PRIMARY KEY (authenticator_id, name);


--
-- Name: authentication_execution constraint_auth_exec_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT constraint_auth_exec_pk PRIMARY KEY (id);


--
-- Name: authentication_flow constraint_auth_flow_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authentication_flow
    ADD CONSTRAINT constraint_auth_flow_pk PRIMARY KEY (id);


--
-- Name: authenticator_config constraint_auth_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authenticator_config
    ADD CONSTRAINT constraint_auth_pk PRIMARY KEY (id);


--
-- Name: client_session_auth_status constraint_auth_status_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_auth_status
    ADD CONSTRAINT constraint_auth_status_pk PRIMARY KEY (client_session, authenticator);


--
-- Name: user_role_mapping constraint_c; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_role_mapping
    ADD CONSTRAINT constraint_c PRIMARY KEY (role_id, user_id);


--
-- Name: composite_role constraint_composite_role; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT constraint_composite_role PRIMARY KEY (composite, child_role);


--
-- Name: client_session_prot_mapper constraint_cs_pmp_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_prot_mapper
    ADD CONSTRAINT constraint_cs_pmp_pk PRIMARY KEY (client_session, protocol_mapper_id);


--
-- Name: identity_provider_config constraint_d; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider_config
    ADD CONSTRAINT constraint_d PRIMARY KEY (identity_provider_id, name);


--
-- Name: policy_config constraint_dpc; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.policy_config
    ADD CONSTRAINT constraint_dpc PRIMARY KEY (policy_id, name);


--
-- Name: realm_smtp_config constraint_e; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_smtp_config
    ADD CONSTRAINT constraint_e PRIMARY KEY (realm_id, name);


--
-- Name: credential constraint_f; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.credential
    ADD CONSTRAINT constraint_f PRIMARY KEY (id);


--
-- Name: user_federation_config constraint_f9; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_config
    ADD CONSTRAINT constraint_f9 PRIMARY KEY (user_federation_provider_id, name);


--
-- Name: resource_server_perm_ticket constraint_fapmt; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT constraint_fapmt PRIMARY KEY (id);


--
-- Name: resource_server_resource constraint_farsr; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT constraint_farsr PRIMARY KEY (id);


--
-- Name: resource_server_policy constraint_farsrp; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT constraint_farsrp PRIMARY KEY (id);


--
-- Name: associated_policy constraint_farsrpap; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT constraint_farsrpap PRIMARY KEY (policy_id, associated_policy_id);


--
-- Name: resource_policy constraint_farsrpp; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT constraint_farsrpp PRIMARY KEY (resource_id, policy_id);


--
-- Name: resource_server_scope constraint_farsrs; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT constraint_farsrs PRIMARY KEY (id);


--
-- Name: resource_scope constraint_farsrsp; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT constraint_farsrsp PRIMARY KEY (resource_id, scope_id);


--
-- Name: scope_policy constraint_farsrsps; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT constraint_farsrsps PRIMARY KEY (scope_id, policy_id);


--
-- Name: user_entity constraint_fb; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT constraint_fb PRIMARY KEY (id);


--
-- Name: user_federation_mapper_config constraint_fedmapper_cfg_pm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_mapper_config
    ADD CONSTRAINT constraint_fedmapper_cfg_pm PRIMARY KEY (user_federation_mapper_id, name);


--
-- Name: user_federation_mapper constraint_fedmapperpm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT constraint_fedmapperpm PRIMARY KEY (id);


--
-- Name: fed_user_consent_cl_scope constraint_fgrntcsnt_clsc_pm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_consent_cl_scope
    ADD CONSTRAINT constraint_fgrntcsnt_clsc_pm PRIMARY KEY (user_consent_id, scope_id);


--
-- Name: user_consent_client_scope constraint_grntcsnt_clsc_pm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_consent_client_scope
    ADD CONSTRAINT constraint_grntcsnt_clsc_pm PRIMARY KEY (user_consent_id, scope_id);


--
-- Name: user_consent constraint_grntcsnt_pm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT constraint_grntcsnt_pm PRIMARY KEY (id);


--
-- Name: keycloak_group constraint_group; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.keycloak_group
    ADD CONSTRAINT constraint_group PRIMARY KEY (id);


--
-- Name: group_attribute constraint_group_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.group_attribute
    ADD CONSTRAINT constraint_group_attribute_pk PRIMARY KEY (id);


--
-- Name: group_role_mapping constraint_group_role; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.group_role_mapping
    ADD CONSTRAINT constraint_group_role PRIMARY KEY (role_id, group_id);


--
-- Name: identity_provider_mapper constraint_idpm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider_mapper
    ADD CONSTRAINT constraint_idpm PRIMARY KEY (id);


--
-- Name: idp_mapper_config constraint_idpmconfig; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.idp_mapper_config
    ADD CONSTRAINT constraint_idpmconfig PRIMARY KEY (idp_mapper_id, name);


--
-- Name: migration_model constraint_migmod; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.migration_model
    ADD CONSTRAINT constraint_migmod PRIMARY KEY (id);


--
-- Name: offline_client_session constraint_offl_cl_ses_pk3; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.offline_client_session
    ADD CONSTRAINT constraint_offl_cl_ses_pk3 PRIMARY KEY (user_session_id, client_id, client_storage_provider, external_client_id, offline_flag);


--
-- Name: offline_user_session constraint_offl_us_ses_pk2; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.offline_user_session
    ADD CONSTRAINT constraint_offl_us_ses_pk2 PRIMARY KEY (user_session_id, offline_flag);


--
-- Name: protocol_mapper constraint_pcm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT constraint_pcm PRIMARY KEY (id);


--
-- Name: protocol_mapper_config constraint_pmconfig; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.protocol_mapper_config
    ADD CONSTRAINT constraint_pmconfig PRIMARY KEY (protocol_mapper_id, name);


--
-- Name: redirect_uris constraint_redirect_uris; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.redirect_uris
    ADD CONSTRAINT constraint_redirect_uris PRIMARY KEY (client_id, value);


--
-- Name: required_action_config constraint_req_act_cfg_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.required_action_config
    ADD CONSTRAINT constraint_req_act_cfg_pk PRIMARY KEY (required_action_id, name);


--
-- Name: required_action_provider constraint_req_act_prv_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.required_action_provider
    ADD CONSTRAINT constraint_req_act_prv_pk PRIMARY KEY (id);


--
-- Name: user_required_action constraint_required_action; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_required_action
    ADD CONSTRAINT constraint_required_action PRIMARY KEY (required_action, user_id);


--
-- Name: resource_uris constraint_resour_uris_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_uris
    ADD CONSTRAINT constraint_resour_uris_pk PRIMARY KEY (resource_id, value);


--
-- Name: role_attribute constraint_role_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.role_attribute
    ADD CONSTRAINT constraint_role_attribute_pk PRIMARY KEY (id);


--
-- Name: user_attribute constraint_user_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_attribute
    ADD CONSTRAINT constraint_user_attribute_pk PRIMARY KEY (id);


--
-- Name: user_group_membership constraint_user_group; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_group_membership
    ADD CONSTRAINT constraint_user_group PRIMARY KEY (group_id, user_id);


--
-- Name: user_session_note constraint_usn_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_session_note
    ADD CONSTRAINT constraint_usn_pk PRIMARY KEY (user_session, name);


--
-- Name: web_origins constraint_web_origins; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.web_origins
    ADD CONSTRAINT constraint_web_origins PRIMARY KEY (client_id, value);


--
-- Name: databasechangeloglock databasechangeloglock_pkey; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.databasechangeloglock
    ADD CONSTRAINT databasechangeloglock_pkey PRIMARY KEY (id);


--
-- Name: client_scope_attributes pk_cl_tmpl_attr; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope_attributes
    ADD CONSTRAINT pk_cl_tmpl_attr PRIMARY KEY (scope_id, name);


--
-- Name: client_scope pk_cli_template; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope
    ADD CONSTRAINT pk_cli_template PRIMARY KEY (id);


--
-- Name: resource_server pk_resource_server; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server
    ADD CONSTRAINT pk_resource_server PRIMARY KEY (id);


--
-- Name: client_scope_role_mapping pk_template_scope; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope_role_mapping
    ADD CONSTRAINT pk_template_scope PRIMARY KEY (scope_id, role_id);


--
-- Name: default_client_scope r_def_cli_scope_bind; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.default_client_scope
    ADD CONSTRAINT r_def_cli_scope_bind PRIMARY KEY (realm_id, scope_id);


--
-- Name: realm_localizations realm_localizations_pkey; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_localizations
    ADD CONSTRAINT realm_localizations_pkey PRIMARY KEY (realm_id, locale);


--
-- Name: resource_attribute res_attr_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_attribute
    ADD CONSTRAINT res_attr_pk PRIMARY KEY (id);


--
-- Name: keycloak_group sibling_names; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.keycloak_group
    ADD CONSTRAINT sibling_names UNIQUE (realm_id, parent_group, name);


--
-- Name: identity_provider uk_2daelwnibji49avxsrtuf6xj33; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT uk_2daelwnibji49avxsrtuf6xj33 UNIQUE (provider_alias, realm_id);


--
-- Name: client uk_b71cjlbenv945rb6gcon438at; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT uk_b71cjlbenv945rb6gcon438at UNIQUE (realm_id, client_id);


--
-- Name: client_scope uk_cli_scope; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope
    ADD CONSTRAINT uk_cli_scope UNIQUE (realm_id, name);


--
-- Name: user_entity uk_dykn684sl8up1crfei6eckhd7; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT uk_dykn684sl8up1crfei6eckhd7 UNIQUE (realm_id, email_constraint);


--
-- Name: resource_server_resource uk_frsr6t700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT uk_frsr6t700s9v50bu18ws5ha6 UNIQUE (name, owner, resource_server_id);


--
-- Name: resource_server_perm_ticket uk_frsr6t700s9v50bu18ws5pmt; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT uk_frsr6t700s9v50bu18ws5pmt UNIQUE (owner, requester, resource_server_id, resource_id, scope_id);


--
-- Name: resource_server_policy uk_frsrpt700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT uk_frsrpt700s9v50bu18ws5ha6 UNIQUE (name, resource_server_id);


--
-- Name: resource_server_scope uk_frsrst700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT uk_frsrst700s9v50bu18ws5ha6 UNIQUE (name, resource_server_id);


--
-- Name: user_consent uk_jkuwuvd56ontgsuhogm8uewrt; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT uk_jkuwuvd56ontgsuhogm8uewrt UNIQUE (client_id, client_storage_provider, external_client_id, user_id);


--
-- Name: realm uk_orvsdmla56612eaefiq6wl5oi; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm
    ADD CONSTRAINT uk_orvsdmla56612eaefiq6wl5oi UNIQUE (name);


--
-- Name: user_entity uk_ru8tt6t700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT uk_ru8tt6t700s9v50bu18ws5ha6 UNIQUE (realm_id, username);


--
-- Name: idx_admin_event_time; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_admin_event_time ON public.admin_event_entity USING btree (realm_id, admin_event_time);


--
-- Name: idx_assoc_pol_assoc_pol_id; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_assoc_pol_assoc_pol_id ON public.associated_policy USING btree (associated_policy_id);


--
-- Name: idx_auth_config_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_auth_config_realm ON public.authenticator_config USING btree (realm_id);


--
-- Name: idx_auth_exec_flow; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_auth_exec_flow ON public.authentication_execution USING btree (flow_id);


--
-- Name: idx_auth_exec_realm_flow; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_auth_exec_realm_flow ON public.authentication_execution USING btree (realm_id, flow_id);


--
-- Name: idx_auth_flow_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_auth_flow_realm ON public.authentication_flow USING btree (realm_id);


--
-- Name: idx_cl_clscope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_cl_clscope ON public.client_scope_client USING btree (scope_id);


--
-- Name: idx_client_id; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_client_id ON public.client USING btree (client_id);


--
-- Name: idx_client_init_acc_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_client_init_acc_realm ON public.client_initial_access USING btree (realm_id);


--
-- Name: idx_client_session_session; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_client_session_session ON public.client_session USING btree (session_id);


--
-- Name: idx_clscope_attrs; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_clscope_attrs ON public.client_scope_attributes USING btree (scope_id);


--
-- Name: idx_clscope_cl; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_clscope_cl ON public.client_scope_client USING btree (client_id);


--
-- Name: idx_clscope_protmap; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_clscope_protmap ON public.protocol_mapper USING btree (client_scope_id);


--
-- Name: idx_clscope_role; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_clscope_role ON public.client_scope_role_mapping USING btree (scope_id);


--
-- Name: idx_compo_config_compo; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_compo_config_compo ON public.component_config USING btree (component_id);


--
-- Name: idx_component_provider_type; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_component_provider_type ON public.component USING btree (provider_type);


--
-- Name: idx_component_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_component_realm ON public.component USING btree (realm_id);


--
-- Name: idx_composite; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_composite ON public.composite_role USING btree (composite);


--
-- Name: idx_composite_child; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_composite_child ON public.composite_role USING btree (child_role);


--
-- Name: idx_defcls_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_defcls_realm ON public.default_client_scope USING btree (realm_id);


--
-- Name: idx_defcls_scope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_defcls_scope ON public.default_client_scope USING btree (scope_id);


--
-- Name: idx_event_time; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_event_time ON public.event_entity USING btree (realm_id, event_time);


--
-- Name: idx_fedidentity_feduser; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fedidentity_feduser ON public.federated_identity USING btree (federated_user_id);


--
-- Name: idx_fedidentity_user; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fedidentity_user ON public.federated_identity USING btree (user_id);


--
-- Name: idx_fu_attribute; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_attribute ON public.fed_user_attribute USING btree (user_id, realm_id, name);


--
-- Name: idx_fu_cnsnt_ext; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_cnsnt_ext ON public.fed_user_consent USING btree (user_id, client_storage_provider, external_client_id);


--
-- Name: idx_fu_consent; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_consent ON public.fed_user_consent USING btree (user_id, client_id);


--
-- Name: idx_fu_consent_ru; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_consent_ru ON public.fed_user_consent USING btree (realm_id, user_id);


--
-- Name: idx_fu_credential; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_credential ON public.fed_user_credential USING btree (user_id, type);


--
-- Name: idx_fu_credential_ru; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_credential_ru ON public.fed_user_credential USING btree (realm_id, user_id);


--
-- Name: idx_fu_group_membership; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_group_membership ON public.fed_user_group_membership USING btree (user_id, group_id);


--
-- Name: idx_fu_group_membership_ru; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_group_membership_ru ON public.fed_user_group_membership USING btree (realm_id, user_id);


--
-- Name: idx_fu_required_action; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_required_action ON public.fed_user_required_action USING btree (user_id, required_action);


--
-- Name: idx_fu_required_action_ru; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_required_action_ru ON public.fed_user_required_action USING btree (realm_id, user_id);


--
-- Name: idx_fu_role_mapping; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_role_mapping ON public.fed_user_role_mapping USING btree (user_id, role_id);


--
-- Name: idx_fu_role_mapping_ru; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_role_mapping_ru ON public.fed_user_role_mapping USING btree (realm_id, user_id);


--
-- Name: idx_group_att_by_name_value; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_group_att_by_name_value ON public.group_attribute USING btree (name, ((value)::character varying(250)));


--
-- Name: idx_group_attr_group; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_group_attr_group ON public.group_attribute USING btree (group_id);


--
-- Name: idx_group_role_mapp_group; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_group_role_mapp_group ON public.group_role_mapping USING btree (group_id);


--
-- Name: idx_id_prov_mapp_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_id_prov_mapp_realm ON public.identity_provider_mapper USING btree (realm_id);


--
-- Name: idx_ident_prov_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_ident_prov_realm ON public.identity_provider USING btree (realm_id);


--
-- Name: idx_keycloak_role_client; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_keycloak_role_client ON public.keycloak_role USING btree (client);


--
-- Name: idx_keycloak_role_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_keycloak_role_realm ON public.keycloak_role USING btree (realm);


--
-- Name: idx_offline_css_preload; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_offline_css_preload ON public.offline_client_session USING btree (client_id, offline_flag);


--
-- Name: idx_offline_uss_by_user; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_offline_uss_by_user ON public.offline_user_session USING btree (user_id, realm_id, offline_flag);


--
-- Name: idx_offline_uss_by_usersess; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_offline_uss_by_usersess ON public.offline_user_session USING btree (realm_id, offline_flag, user_session_id);


--
-- Name: idx_offline_uss_createdon; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_offline_uss_createdon ON public.offline_user_session USING btree (created_on);


--
-- Name: idx_offline_uss_preload; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_offline_uss_preload ON public.offline_user_session USING btree (offline_flag, created_on, user_session_id);


--
-- Name: idx_protocol_mapper_client; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_protocol_mapper_client ON public.protocol_mapper USING btree (client_id);


--
-- Name: idx_realm_attr_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_attr_realm ON public.realm_attribute USING btree (realm_id);


--
-- Name: idx_realm_clscope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_clscope ON public.client_scope USING btree (realm_id);


--
-- Name: idx_realm_def_grp_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_def_grp_realm ON public.realm_default_groups USING btree (realm_id);


--
-- Name: idx_realm_evt_list_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_evt_list_realm ON public.realm_events_listeners USING btree (realm_id);


--
-- Name: idx_realm_evt_types_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_evt_types_realm ON public.realm_enabled_event_types USING btree (realm_id);


--
-- Name: idx_realm_master_adm_cli; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_master_adm_cli ON public.realm USING btree (master_admin_client);


--
-- Name: idx_realm_supp_local_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_supp_local_realm ON public.realm_supported_locales USING btree (realm_id);


--
-- Name: idx_redir_uri_client; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_redir_uri_client ON public.redirect_uris USING btree (client_id);


--
-- Name: idx_req_act_prov_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_req_act_prov_realm ON public.required_action_provider USING btree (realm_id);


--
-- Name: idx_res_policy_policy; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_res_policy_policy ON public.resource_policy USING btree (policy_id);


--
-- Name: idx_res_scope_scope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_res_scope_scope ON public.resource_scope USING btree (scope_id);


--
-- Name: idx_res_serv_pol_res_serv; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_res_serv_pol_res_serv ON public.resource_server_policy USING btree (resource_server_id);


--
-- Name: idx_res_srv_res_res_srv; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_res_srv_res_res_srv ON public.resource_server_resource USING btree (resource_server_id);


--
-- Name: idx_res_srv_scope_res_srv; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_res_srv_scope_res_srv ON public.resource_server_scope USING btree (resource_server_id);


--
-- Name: idx_role_attribute; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_role_attribute ON public.role_attribute USING btree (role_id);


--
-- Name: idx_role_clscope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_role_clscope ON public.client_scope_role_mapping USING btree (role_id);


--
-- Name: idx_scope_mapping_role; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_scope_mapping_role ON public.scope_mapping USING btree (role_id);


--
-- Name: idx_scope_policy_policy; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_scope_policy_policy ON public.scope_policy USING btree (policy_id);


--
-- Name: idx_update_time; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_update_time ON public.migration_model USING btree (update_time);


--
-- Name: idx_us_sess_id_on_cl_sess; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_us_sess_id_on_cl_sess ON public.offline_client_session USING btree (user_session_id);


--
-- Name: idx_usconsent_clscope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_usconsent_clscope ON public.user_consent_client_scope USING btree (user_consent_id);


--
-- Name: idx_user_attribute; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_attribute ON public.user_attribute USING btree (user_id);


--
-- Name: idx_user_attribute_name; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_attribute_name ON public.user_attribute USING btree (name, value);


--
-- Name: idx_user_consent; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_consent ON public.user_consent USING btree (user_id);


--
-- Name: idx_user_credential; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_credential ON public.credential USING btree (user_id);


--
-- Name: idx_user_email; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_email ON public.user_entity USING btree (email);


--
-- Name: idx_user_group_mapping; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_group_mapping ON public.user_group_membership USING btree (user_id);


--
-- Name: idx_user_reqactions; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_reqactions ON public.user_required_action USING btree (user_id);


--
-- Name: idx_user_role_mapping; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_role_mapping ON public.user_role_mapping USING btree (user_id);


--
-- Name: idx_user_service_account; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_service_account ON public.user_entity USING btree (realm_id, service_account_client_link);


--
-- Name: idx_usr_fed_map_fed_prv; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_usr_fed_map_fed_prv ON public.user_federation_mapper USING btree (federation_provider_id);


--
-- Name: idx_usr_fed_map_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_usr_fed_map_realm ON public.user_federation_mapper USING btree (realm_id);


--
-- Name: idx_usr_fed_prv_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_usr_fed_prv_realm ON public.user_federation_provider USING btree (realm_id);


--
-- Name: idx_web_orig_client; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_web_orig_client ON public.web_origins USING btree (client_id);


--
-- Name: client_session_auth_status auth_status_constraint; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_auth_status
    ADD CONSTRAINT auth_status_constraint FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: identity_provider fk2b4ebc52ae5c3b34; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT fk2b4ebc52ae5c3b34 FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: client_attributes fk3c47c64beacca966; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_attributes
    ADD CONSTRAINT fk3c47c64beacca966 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: federated_identity fk404288b92ef007a6; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.federated_identity
    ADD CONSTRAINT fk404288b92ef007a6 FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: client_node_registrations fk4129723ba992f594; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_node_registrations
    ADD CONSTRAINT fk4129723ba992f594 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: client_session_note fk5edfb00ff51c2736; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_note
    ADD CONSTRAINT fk5edfb00ff51c2736 FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: user_session_note fk5edfb00ff51d3472; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_session_note
    ADD CONSTRAINT fk5edfb00ff51d3472 FOREIGN KEY (user_session) REFERENCES public.user_session(id);


--
-- Name: client_session_role fk_11b7sgqw18i532811v7o2dv76; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_role
    ADD CONSTRAINT fk_11b7sgqw18i532811v7o2dv76 FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: redirect_uris fk_1burs8pb4ouj97h5wuppahv9f; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.redirect_uris
    ADD CONSTRAINT fk_1burs8pb4ouj97h5wuppahv9f FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: user_federation_provider fk_1fj32f6ptolw2qy60cd8n01e8; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_provider
    ADD CONSTRAINT fk_1fj32f6ptolw2qy60cd8n01e8 FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: client_session_prot_mapper fk_33a8sgqw18i532811v7o2dk89; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_prot_mapper
    ADD CONSTRAINT fk_33a8sgqw18i532811v7o2dk89 FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: realm_required_credential fk_5hg65lybevavkqfki3kponh9v; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_required_credential
    ADD CONSTRAINT fk_5hg65lybevavkqfki3kponh9v FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: resource_attribute fk_5hrm2vlf9ql5fu022kqepovbr; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_attribute
    ADD CONSTRAINT fk_5hrm2vlf9ql5fu022kqepovbr FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: user_attribute fk_5hrm2vlf9ql5fu043kqepovbr; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_attribute
    ADD CONSTRAINT fk_5hrm2vlf9ql5fu043kqepovbr FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: user_required_action fk_6qj3w1jw9cvafhe19bwsiuvmd; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_required_action
    ADD CONSTRAINT fk_6qj3w1jw9cvafhe19bwsiuvmd FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: keycloak_role fk_6vyqfe4cn4wlq8r6kt5vdsj5c; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT fk_6vyqfe4cn4wlq8r6kt5vdsj5c FOREIGN KEY (realm) REFERENCES public.realm(id);


--
-- Name: realm_smtp_config fk_70ej8xdxgxd0b9hh6180irr0o; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_smtp_config
    ADD CONSTRAINT fk_70ej8xdxgxd0b9hh6180irr0o FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_attribute fk_8shxd6l3e9atqukacxgpffptw; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_attribute
    ADD CONSTRAINT fk_8shxd6l3e9atqukacxgpffptw FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: composite_role fk_a63wvekftu8jo1pnj81e7mce2; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT fk_a63wvekftu8jo1pnj81e7mce2 FOREIGN KEY (composite) REFERENCES public.keycloak_role(id);


--
-- Name: authentication_execution fk_auth_exec_flow; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT fk_auth_exec_flow FOREIGN KEY (flow_id) REFERENCES public.authentication_flow(id);


--
-- Name: authentication_execution fk_auth_exec_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT fk_auth_exec_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: authentication_flow fk_auth_flow_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authentication_flow
    ADD CONSTRAINT fk_auth_flow_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: authenticator_config fk_auth_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authenticator_config
    ADD CONSTRAINT fk_auth_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: client_session fk_b4ao2vcvat6ukau74wbwtfqo1; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session
    ADD CONSTRAINT fk_b4ao2vcvat6ukau74wbwtfqo1 FOREIGN KEY (session_id) REFERENCES public.user_session(id);


--
-- Name: user_role_mapping fk_c4fqv34p1mbylloxang7b1q3l; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_role_mapping
    ADD CONSTRAINT fk_c4fqv34p1mbylloxang7b1q3l FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: client_scope_attributes fk_cl_scope_attr_scope; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope_attributes
    ADD CONSTRAINT fk_cl_scope_attr_scope FOREIGN KEY (scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_scope_role_mapping fk_cl_scope_rm_scope; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope_role_mapping
    ADD CONSTRAINT fk_cl_scope_rm_scope FOREIGN KEY (scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_user_session_note fk_cl_usr_ses_note; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_user_session_note
    ADD CONSTRAINT fk_cl_usr_ses_note FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: protocol_mapper fk_cli_scope_mapper; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT fk_cli_scope_mapper FOREIGN KEY (client_scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_initial_access fk_client_init_acc_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_initial_access
    ADD CONSTRAINT fk_client_init_acc_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: component_config fk_component_config; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.component_config
    ADD CONSTRAINT fk_component_config FOREIGN KEY (component_id) REFERENCES public.component(id);


--
-- Name: component fk_component_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.component
    ADD CONSTRAINT fk_component_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_default_groups fk_def_groups_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT fk_def_groups_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: user_federation_mapper_config fk_fedmapper_cfg; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_mapper_config
    ADD CONSTRAINT fk_fedmapper_cfg FOREIGN KEY (user_federation_mapper_id) REFERENCES public.user_federation_mapper(id);


--
-- Name: user_federation_mapper fk_fedmapperpm_fedprv; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT fk_fedmapperpm_fedprv FOREIGN KEY (federation_provider_id) REFERENCES public.user_federation_provider(id);


--
-- Name: user_federation_mapper fk_fedmapperpm_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT fk_fedmapperpm_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: associated_policy fk_frsr5s213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT fk_frsr5s213xcx4wnkog82ssrfy FOREIGN KEY (associated_policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: scope_policy fk_frsrasp13xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT fk_frsrasp13xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog82sspmt; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog82sspmt FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_server_resource fk_frsrho213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT fk_frsrho213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog83sspmt; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog83sspmt FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog84sspmt; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog84sspmt FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: associated_policy fk_frsrpas14xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT fk_frsrpas14xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: scope_policy fk_frsrpass3xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT fk_frsrpass3xcx4wnkog82ssrfy FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: resource_server_perm_ticket fk_frsrpo2128cx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrpo2128cx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_server_policy fk_frsrpo213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT fk_frsrpo213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_scope fk_frsrpos13xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT fk_frsrpos13xcx4wnkog82ssrfy FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_policy fk_frsrpos53xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT fk_frsrpos53xcx4wnkog82ssrfy FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_policy fk_frsrpp213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT fk_frsrpp213xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_scope fk_frsrps213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT fk_frsrps213xcx4wnkog82ssrfy FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: resource_server_scope fk_frsrso213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT fk_frsrso213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: composite_role fk_gr7thllb9lu8q4vqa4524jjy8; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT fk_gr7thllb9lu8q4vqa4524jjy8 FOREIGN KEY (child_role) REFERENCES public.keycloak_role(id);


--
-- Name: user_consent_client_scope fk_grntcsnt_clsc_usc; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_consent_client_scope
    ADD CONSTRAINT fk_grntcsnt_clsc_usc FOREIGN KEY (user_consent_id) REFERENCES public.user_consent(id);


--
-- Name: user_consent fk_grntcsnt_user; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT fk_grntcsnt_user FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: group_attribute fk_group_attribute_group; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.group_attribute
    ADD CONSTRAINT fk_group_attribute_group FOREIGN KEY (group_id) REFERENCES public.keycloak_group(id);


--
-- Name: group_role_mapping fk_group_role_group; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.group_role_mapping
    ADD CONSTRAINT fk_group_role_group FOREIGN KEY (group_id) REFERENCES public.keycloak_group(id);


--
-- Name: realm_enabled_event_types fk_h846o4h0w8epx5nwedrf5y69j; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_enabled_event_types
    ADD CONSTRAINT fk_h846o4h0w8epx5nwedrf5y69j FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_events_listeners fk_h846o4h0w8epx5nxev9f5y69j; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_events_listeners
    ADD CONSTRAINT fk_h846o4h0w8epx5nxev9f5y69j FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: identity_provider_mapper fk_idpm_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider_mapper
    ADD CONSTRAINT fk_idpm_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: idp_mapper_config fk_idpmconfig; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.idp_mapper_config
    ADD CONSTRAINT fk_idpmconfig FOREIGN KEY (idp_mapper_id) REFERENCES public.identity_provider_mapper(id);


--
-- Name: web_origins fk_lojpho213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.web_origins
    ADD CONSTRAINT fk_lojpho213xcx4wnkog82ssrfy FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: scope_mapping fk_ouse064plmlr732lxjcn1q5f1; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.scope_mapping
    ADD CONSTRAINT fk_ouse064plmlr732lxjcn1q5f1 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: protocol_mapper fk_pcm_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT fk_pcm_realm FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: credential fk_pfyr0glasqyl0dei3kl69r6v0; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.credential
    ADD CONSTRAINT fk_pfyr0glasqyl0dei3kl69r6v0 FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: protocol_mapper_config fk_pmconfig; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.protocol_mapper_config
    ADD CONSTRAINT fk_pmconfig FOREIGN KEY (protocol_mapper_id) REFERENCES public.protocol_mapper(id);


--
-- Name: default_client_scope fk_r_def_cli_scope_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.default_client_scope
    ADD CONSTRAINT fk_r_def_cli_scope_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: required_action_provider fk_req_act_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.required_action_provider
    ADD CONSTRAINT fk_req_act_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: resource_uris fk_resource_server_uris; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_uris
    ADD CONSTRAINT fk_resource_server_uris FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: role_attribute fk_role_attribute_id; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.role_attribute
    ADD CONSTRAINT fk_role_attribute_id FOREIGN KEY (role_id) REFERENCES public.keycloak_role(id);


--
-- Name: realm_supported_locales fk_supported_locales_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_supported_locales
    ADD CONSTRAINT fk_supported_locales_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: user_federation_config fk_t13hpu1j94r2ebpekr39x5eu5; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_config
    ADD CONSTRAINT fk_t13hpu1j94r2ebpekr39x5eu5 FOREIGN KEY (user_federation_provider_id) REFERENCES public.user_federation_provider(id);


--
-- Name: user_group_membership fk_user_group_user; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_group_membership
    ADD CONSTRAINT fk_user_group_user FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: policy_config fkdc34197cf864c4e43; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.policy_config
    ADD CONSTRAINT fkdc34197cf864c4e43 FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: identity_provider_config fkdc4897cf864c4e43; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider_config
    ADD CONSTRAINT fkdc4897cf864c4e43 FOREIGN KEY (identity_provider_id) REFERENCES public.identity_provider(internal_id);


--
-- PostgreSQL database dump complete
--

