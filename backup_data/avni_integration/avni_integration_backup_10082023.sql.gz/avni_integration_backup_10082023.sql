--
-- PostgreSQL database dump
--

-- Dumped from database version 15.3 (Debian 15.3-1.pgdg120+1)
-- Dumped by pg_dump version 15.3 (Debian 15.3-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: avni_entity_status; Type: TABLE; Schema: public; Owner: avni_int
--

CREATE TABLE public.avni_entity_status (
    id integer NOT NULL,
    entity_type character varying(100) NOT NULL,
    read_upto timestamp without time zone NOT NULL,
    entity_sub_type character varying(255),
    integration_system_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.avni_entity_status OWNER TO avni_int;

--
-- Name: avni_entity_status_id_seq; Type: SEQUENCE; Schema: public; Owner: avni_int
--

CREATE SEQUENCE public.avni_entity_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.avni_entity_status_id_seq OWNER TO avni_int;

--
-- Name: avni_entity_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avni_int
--

ALTER SEQUENCE public.avni_entity_status_id_seq OWNED BY public.avni_entity_status.id;


--
-- Name: integrating_entity_status; Type: TABLE; Schema: public; Owner: avni_int
--

CREATE TABLE public.integrating_entity_status (
    id integer NOT NULL,
    entity_type character varying(100) NOT NULL,
    read_upto_numeric integer,
    read_upto_date_time timestamp without time zone,
    integration_system_id integer DEFAULT 1,
    CONSTRAINT all_read_upto_cannot_be_null CHECK (((read_upto_numeric IS NOT NULL) OR (read_upto_date_time IS NOT NULL)))
);


ALTER TABLE public.integrating_entity_status OWNER TO avni_int;

--
-- Name: bahmni_entity_status_id_seq; Type: SEQUENCE; Schema: public; Owner: avni_int
--

CREATE SEQUENCE public.bahmni_entity_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bahmni_entity_status_id_seq OWNER TO avni_int;

--
-- Name: bahmni_entity_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avni_int
--

ALTER SEQUENCE public.bahmni_entity_status_id_seq OWNED BY public.integrating_entity_status.id;


--
-- Name: constants; Type: TABLE; Schema: public; Owner: avni_int
--

CREATE TABLE public.constants (
    id integer NOT NULL,
    key character varying(250) NOT NULL,
    value character varying(250) NOT NULL
);


ALTER TABLE public.constants OWNER TO avni_int;

--
-- Name: constants_id_seq; Type: SEQUENCE; Schema: public; Owner: avni_int
--

CREATE SEQUENCE public.constants_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.constants_id_seq OWNER TO avni_int;

--
-- Name: constants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avni_int
--

ALTER SEQUENCE public.constants_id_seq OWNED BY public.constants.id;


--
-- Name: error_record; Type: TABLE; Schema: public; Owner: avni_int
--

CREATE TABLE public.error_record (
    id integer NOT NULL,
    integrating_entity_type character varying(250),
    avni_entity_type character varying(250),
    entity_id character varying(250) DEFAULT 'foo'::character varying NOT NULL,
    processing_disabled boolean DEFAULT true NOT NULL,
    integration_system_id integer DEFAULT 1 NOT NULL,
    CONSTRAINT error_record_check CHECK (((integrating_entity_type IS NOT NULL) OR (avni_entity_type IS NOT NULL)))
);


ALTER TABLE public.error_record OWNER TO avni_int;

--
-- Name: error_record_id_seq; Type: SEQUENCE; Schema: public; Owner: avni_int
--

CREATE SEQUENCE public.error_record_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.error_record_id_seq OWNER TO avni_int;

--
-- Name: error_record_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avni_int
--

ALTER SEQUENCE public.error_record_id_seq OWNED BY public.error_record.id;


--
-- Name: error_record_log; Type: TABLE; Schema: public; Owner: avni_int
--

CREATE TABLE public.error_record_log (
    id integer NOT NULL,
    logged_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    error_record_id integer NOT NULL,
    error_type_id integer NOT NULL,
    error_msg text
);


ALTER TABLE public.error_record_log OWNER TO avni_int;

--
-- Name: error_record_log_id_seq; Type: SEQUENCE; Schema: public; Owner: avni_int
--

CREATE SEQUENCE public.error_record_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.error_record_log_id_seq OWNER TO avni_int;

--
-- Name: error_record_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avni_int
--

ALTER SEQUENCE public.error_record_log_id_seq OWNED BY public.error_record_log.id;


--
-- Name: error_type; Type: TABLE; Schema: public; Owner: avni_int
--

CREATE TABLE public.error_type (
    id integer NOT NULL,
    name character varying(250),
    integration_system_id integer NOT NULL,
    comparison_operator character varying(255) DEFAULT NULL::character varying,
    comparison_value text
);


ALTER TABLE public.error_type OWNER TO avni_int;

--
-- Name: error_type_id_seq; Type: SEQUENCE; Schema: public; Owner: avni_int
--

CREATE SEQUENCE public.error_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.error_type_id_seq OWNER TO avni_int;

--
-- Name: error_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avni_int
--

ALTER SEQUENCE public.error_type_id_seq OWNED BY public.error_type.id;


--
-- Name: failed_events; Type: TABLE; Schema: public; Owner: avni_int
--

CREATE TABLE public.failed_events (
    id integer NOT NULL,
    feed_uri character varying(255),
    failed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    error_message character varying(4000),
    event_id character varying(255),
    event_content character varying(4000),
    error_hash_code integer,
    title character varying(255),
    retries integer DEFAULT 0 NOT NULL,
    tags character varying(255)
);


ALTER TABLE public.failed_events OWNER TO avni_int;

--
-- Name: failed_events_id_seq; Type: SEQUENCE; Schema: public; Owner: avni_int
--

CREATE SEQUENCE public.failed_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.failed_events_id_seq OWNER TO avni_int;

--
-- Name: failed_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avni_int
--

ALTER SEQUENCE public.failed_events_id_seq OWNED BY public.failed_events.id;


--
-- Name: flyway_schema_history; Type: TABLE; Schema: public; Owner: avni_int
--

CREATE TABLE public.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.flyway_schema_history OWNER TO avni_int;

--
-- Name: ignored_integrating_concept; Type: TABLE; Schema: public; Owner: avni_int
--

CREATE TABLE public.ignored_integrating_concept (
    id integer NOT NULL,
    concept_id character varying(250) NOT NULL
);


ALTER TABLE public.ignored_integrating_concept OWNER TO avni_int;

--
-- Name: ignored_bahmni_concept_id_seq; Type: SEQUENCE; Schema: public; Owner: avni_int
--

CREATE SEQUENCE public.ignored_bahmni_concept_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ignored_bahmni_concept_id_seq OWNER TO avni_int;

--
-- Name: ignored_bahmni_concept_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avni_int
--

ALTER SEQUENCE public.ignored_bahmni_concept_id_seq OWNED BY public.ignored_integrating_concept.id;


--
-- Name: integrating_entity_type; Type: TABLE; Schema: public; Owner: avni_int
--

CREATE TABLE public.integrating_entity_type (
    id integer NOT NULL,
    name character varying(250),
    integration_system_id integer NOT NULL
);


ALTER TABLE public.integrating_entity_type OWNER TO avni_int;

--
-- Name: integrating_entity_type_id_seq; Type: SEQUENCE; Schema: public; Owner: avni_int
--

CREATE SEQUENCE public.integrating_entity_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.integrating_entity_type_id_seq OWNER TO avni_int;

--
-- Name: integrating_entity_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avni_int
--

ALTER SEQUENCE public.integrating_entity_type_id_seq OWNED BY public.integrating_entity_type.id;


--
-- Name: integration_system; Type: TABLE; Schema: public; Owner: avni_int
--

CREATE TABLE public.integration_system (
    id integer NOT NULL,
    name character varying(250)
);


ALTER TABLE public.integration_system OWNER TO avni_int;

--
-- Name: integration_system_id_seq; Type: SEQUENCE; Schema: public; Owner: avni_int
--

CREATE SEQUENCE public.integration_system_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.integration_system_id_seq OWNER TO avni_int;

--
-- Name: integration_system_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avni_int
--

ALTER SEQUENCE public.integration_system_id_seq OWNED BY public.integration_system.id;


--
-- Name: mapping_group; Type: TABLE; Schema: public; Owner: avni_int
--

CREATE TABLE public.mapping_group (
    id integer NOT NULL,
    name character varying(250),
    integration_system_id integer NOT NULL
);


ALTER TABLE public.mapping_group OWNER TO avni_int;

--
-- Name: mapping_group_id_seq; Type: SEQUENCE; Schema: public; Owner: avni_int
--

CREATE SEQUENCE public.mapping_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mapping_group_id_seq OWNER TO avni_int;

--
-- Name: mapping_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avni_int
--

ALTER SEQUENCE public.mapping_group_id_seq OWNED BY public.mapping_group.id;


--
-- Name: mapping_metadata; Type: TABLE; Schema: public; Owner: avni_int
--

CREATE TABLE public.mapping_metadata (
    id integer NOT NULL,
    int_system_value character varying(1000),
    avni_value character varying(1000),
    about character varying(1000),
    data_type_hint character varying(100),
    integration_system_id integer DEFAULT 1 NOT NULL,
    mapping_group_id integer,
    mapping_type_id integer
);


ALTER TABLE public.mapping_metadata OWNER TO avni_int;

--
-- Name: mapping_metadata_id_seq; Type: SEQUENCE; Schema: public; Owner: avni_int
--

CREATE SEQUENCE public.mapping_metadata_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mapping_metadata_id_seq OWNER TO avni_int;

--
-- Name: mapping_metadata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avni_int
--

ALTER SEQUENCE public.mapping_metadata_id_seq OWNED BY public.mapping_metadata.id;


--
-- Name: mapping_type; Type: TABLE; Schema: public; Owner: avni_int
--

CREATE TABLE public.mapping_type (
    id integer NOT NULL,
    name character varying(250),
    integration_system_id integer NOT NULL
);


ALTER TABLE public.mapping_type OWNER TO avni_int;

--
-- Name: mapping_type_id_seq; Type: SEQUENCE; Schema: public; Owner: avni_int
--

CREATE SEQUENCE public.mapping_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mapping_type_id_seq OWNER TO avni_int;

--
-- Name: mapping_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avni_int
--

ALTER SEQUENCE public.mapping_type_id_seq OWNED BY public.mapping_type.id;


--
-- Name: markers; Type: TABLE; Schema: public; Owner: avni_int
--

CREATE TABLE public.markers (
    id integer NOT NULL,
    feed_uri_for_last_read_entry character varying(250) NOT NULL,
    feed_uri character varying(250) NOT NULL,
    last_read_entry_id character varying(250) NOT NULL
);


ALTER TABLE public.markers OWNER TO avni_int;

--
-- Name: markers_id_seq; Type: SEQUENCE; Schema: public; Owner: avni_int
--

CREATE SEQUENCE public.markers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.markers_id_seq OWNER TO avni_int;

--
-- Name: markers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avni_int
--

ALTER SEQUENCE public.markers_id_seq OWNED BY public.markers.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: avni_int
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(250) NOT NULL,
    password character varying(250) NOT NULL,
    working_integration_system_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.users OWNER TO avni_int;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: avni_int
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO avni_int;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avni_int
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: avni_entity_status id; Type: DEFAULT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.avni_entity_status ALTER COLUMN id SET DEFAULT nextval('public.avni_entity_status_id_seq'::regclass);


--
-- Name: constants id; Type: DEFAULT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.constants ALTER COLUMN id SET DEFAULT nextval('public.constants_id_seq'::regclass);


--
-- Name: error_record id; Type: DEFAULT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.error_record ALTER COLUMN id SET DEFAULT nextval('public.error_record_id_seq'::regclass);


--
-- Name: error_record_log id; Type: DEFAULT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.error_record_log ALTER COLUMN id SET DEFAULT nextval('public.error_record_log_id_seq'::regclass);


--
-- Name: error_type id; Type: DEFAULT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.error_type ALTER COLUMN id SET DEFAULT nextval('public.error_type_id_seq'::regclass);


--
-- Name: failed_events id; Type: DEFAULT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.failed_events ALTER COLUMN id SET DEFAULT nextval('public.failed_events_id_seq'::regclass);


--
-- Name: ignored_integrating_concept id; Type: DEFAULT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.ignored_integrating_concept ALTER COLUMN id SET DEFAULT nextval('public.ignored_bahmni_concept_id_seq'::regclass);


--
-- Name: integrating_entity_status id; Type: DEFAULT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.integrating_entity_status ALTER COLUMN id SET DEFAULT nextval('public.bahmni_entity_status_id_seq'::regclass);


--
-- Name: integrating_entity_type id; Type: DEFAULT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.integrating_entity_type ALTER COLUMN id SET DEFAULT nextval('public.integrating_entity_type_id_seq'::regclass);


--
-- Name: integration_system id; Type: DEFAULT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.integration_system ALTER COLUMN id SET DEFAULT nextval('public.integration_system_id_seq'::regclass);


--
-- Name: mapping_group id; Type: DEFAULT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.mapping_group ALTER COLUMN id SET DEFAULT nextval('public.mapping_group_id_seq'::regclass);


--
-- Name: mapping_metadata id; Type: DEFAULT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.mapping_metadata ALTER COLUMN id SET DEFAULT nextval('public.mapping_metadata_id_seq'::regclass);


--
-- Name: mapping_type id; Type: DEFAULT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.mapping_type ALTER COLUMN id SET DEFAULT nextval('public.mapping_type_id_seq'::regclass);


--
-- Name: markers id; Type: DEFAULT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.markers ALTER COLUMN id SET DEFAULT nextval('public.markers_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: avni_entity_status; Type: TABLE DATA; Schema: public; Owner: avni_int
--

COPY public.avni_entity_status (id, entity_type, read_upto, entity_sub_type, integration_system_id) FROM stdin;
1	Subject	1900-01-01 00:00:00	\N	1
2	Enrolment	1900-01-01 00:00:00	\N	1
3	ProgramEncounter	1900-01-01 00:00:00	\N	1
4	GeneralEncounter	1900-01-01 00:00:00	\N	1
5	Encounter	1900-01-01 00:00:00	Distribution	2
6	Encounter	1900-01-01 00:00:00	Activity	2
7	Encounter	1900-01-01 00:00:00	Dispatch Receipt	2
\.


--
-- Data for Name: constants; Type: TABLE DATA; Schema: public; Owner: avni_int
--

COPY public.constants (id, key, value) FROM stdin;
1	IntegrationAvniSubjectType	Patient
7	IntegrationBahmniVisitType	d57ff862-dda2-41ff-b607-9dd97a5e3039
5	IntegrationBahmniEncounterRole	54ce9816-1062-4636-af95-655066cd6aba
6	IntegrationBahmniLocation	4ccfb300-009f-11ee-be56-0242ac120002
4	IntegrationBahmniProvider	d8fe5886-0e3c-11ee-be56-0242ac120002
2	BahmniIdentifierPrefix	KA
8	OutpatientVisitTypes	75ca880b-2c26-435c-868a-b294ffcfad39
9	OutpatientVisitTypes	bdd4d8cd-4fe1-445f-a980-a0eaf45903f4
3	IntegrationBahmniIdentifierType	26ec2124-2e0c-11ee-a63a-0242ac150007
\.


--
-- Data for Name: error_record; Type: TABLE DATA; Schema: public; Owner: avni_int
--

COPY public.error_record (id, integrating_entity_type, avni_entity_type, entity_id, processing_disabled, integration_system_id) FROM stdin;
\.


--
-- Data for Name: error_record_log; Type: TABLE DATA; Schema: public; Owner: avni_int
--

COPY public.error_record_log (id, logged_at, error_record_id, error_type_id, error_msg) FROM stdin;
\.


--
-- Data for Name: error_type; Type: TABLE DATA; Schema: public; Owner: avni_int
--

COPY public.error_type (id, name, integration_system_id, comparison_operator, comparison_value) FROM stdin;
1	NoPatientWithId	1	\N	\N
2	PatientIdChanged	1	\N	\N
3	EntityIsDeleted	1	\N	\N
4	NotACommunityMember	1	\N	\N
5	NoSubjectWithId	1	\N	\N
6	SubjectIdChanged	1	\N	\N
7	MultipleSubjectsWithId	1	\N	\N
8	SubjectIdNull	1	\N	\N
9	NoDemandWithId	2	2	Individual not found with UUID 'null' or External ID '.*'
10	BadValueForRestrictedPicklist	2	1	INVALID_OR_NULL_FOR_RESTRICTED_PICKLIST
11	MustNotHave2SimilarElements	2	1	System.ListException: Before Insert or Upsert list must not have two identically equal elements
12	FieldCustomValidationException	2	1	FIELD_CUSTOM_VALIDATION_EXCEPTION
13	BeneficiaryAmritIDFetchError	3	\N	\N
14	BeneficiaryCreationError	3	\N	\N
15	HouseholdCreationError	3	\N	\N
16	BornBirthCreationError	3	\N	\N
17	CBACCreationError	3	\N	\N
18	AmritEntityNotCreated	3	\N	\N
19	EntityIsDeleted	3	\N	\N
20	TaskNotSaved	4	\N	\N
21	CallSidDeleted	4	\N	\N
22	DispenseError	1	\N	\N
\.


--
-- Data for Name: failed_events; Type: TABLE DATA; Schema: public; Owner: avni_int
--

COPY public.failed_events (id, feed_uri, failed_at, error_message, event_id, event_content, error_hash_code, title, retries, tags) FROM stdin;
\.


--
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: public; Owner: avni_int
--

COPY public.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1.1	CreateAtomFeedTables	SQL	V1_1__CreateAtomFeedTables.sql	-1428408571	avni_int	2023-05-10 10:39:06.493866	30	t
2	1.2	CreateAvniFeedClientTableWithBaseData	SQL	V1_2__CreateAvniFeedClientTableWithBaseData.sql	-1017232557	avni_int	2023-05-10 10:39:06.570846	25	t
3	1.3	CreateMappingTable	SQL	V1_3__CreateMappingTable.sql	419789860	avni_int	2023-05-10 10:39:06.629895	24	t
4	1.4	Constants	SQL	V1_4__Constants.sql	1458483631	avni_int	2023-05-10 10:39:06.682857	39	t
5	1.5	ErrorRecord	SQL	V1_5__ErrorRecord.sql	-1232804766	avni_int	2023-05-10 10:39:06.757852	15	t
6	1.6	AddPatientSubjectId	SQL	V1_6__AddPatientSubjectId.sql	-109018304	avni_int	2023-05-10 10:39:06.788277	4	t
7	1.7	InsertEnrolmentBaseDataInAvniEntityStatusTable	SQL	V1_7__InsertEnrolmentBaseDataInAvniEntityStatusTable.sql	-1194846551	avni_int	2023-05-10 10:39:06.80288	5	t
8	1.8	ModifyErrorRecordAndAddErrorLog	SQL	V1_8__ModifyErrorRecordAndAddErrorLog.sql	-618317878	avni_int	2023-05-10 10:39:06.826852	27	t
9	1.9	CreateBahmniFirstRunFeedClientTableWithBaseData	SQL	V1_9__CreateBahmniFirstRunFeedClientTableWithBaseData.sql	-715076218	avni_int	2023-05-10 10:39:06.863509	10	t
10	1.10	InsertProgramEncounterBaseDataInAvniEntityStatusTable	SQL	V1_10__InsertProgramEncounterBaseDataInAvniEntityStatusTable.sql	771385885	avni_int	2023-05-10 10:39:06.882879	11	t
11	1.11	IgnoredConcepts	SQL	V1_11__IgnoredConcepts.sql	1266637149	avni_int	2023-05-10 10:39:06.90627	12	t
12	1.12	IgnoredConceptUuidIsUnique	SQL	V1_12__IgnoredConceptUuidIsUnique.sql	98672195	avni_int	2023-05-10 10:39:06.931884	9	t
13	1.13	CreateUserTable	SQL	V1_13__CreateUserTable.sql	-1650191993	avni_int	2023-05-10 10:39:06.943097	7	t
14	1.14	DisableErrorRecordProcessing	SQL	V1_14__DisableErrorRecordProcessing.sql	-1484471869	avni_int	2023-05-10 10:39:06.956368	2	t
15	1.20	InsertGeneralEncounterBaseDataInAvniEntityStatusTable	SQL	V1_20__InsertGeneralEncounterBaseDataInAvniEntityStatusTable.sql	-913649014	avni_int	2023-05-10 10:39:06.972231	2	t
16	1.21	DuplicateMappingCheck	SQL	V1_21__DuplicateMappingCheck.sql	-788945891	avni_int	2023-05-10 10:39:06.982643	8	t
17	2.1.1	Allv2InitialChanges	SQL	V2_1_1__Allv2InitialChanges.sql	-75575962	avni_int	2023-05-10 10:39:07.023059	68	t
18	2.1.2	ErrorClassificationAndStoringChanges	SQL	V2_1_2__ErrorClassificationAndStoringChanges.sql	351119764	avni_int	2023-05-10 10:39:07.100021	7	t
19	2.2.1	Bahmni Initial	SQL	V2_2_1__Bahmni_Initial.sql	-2068793490	avni_int	2023-05-10 10:39:07.128609	26	t
20	2.3.1	Goonj Initial	SQL	V2_3_1__Goonj_Initial.sql	-1247835750	avni_int	2023-05-10 10:39:07.170868	32	t
21	2.3.2	Goonj Error	SQL	V2_3_2__Goonj_Error.sql	-1767657858	avni_int	2023-05-10 10:39:07.210867	7	t
22	2.4.1	Amrit Initial	SQL	V2_4_1__Amrit_Initial.sql	-56396220	avni_int	2023-05-10 10:39:07.221864	3	t
23	2.4.2	Amrit Beneficiary	SQL	V2_4_2__Amrit_Beneficiary.sql	-77198356	avni_int	2023-05-10 10:39:07.255599	26	t
24	2.4.3	Amrit Forms	SQL	V2_4_3__Amrit_Forms.sql	-161618481	avni_int	2023-05-10 10:39:07.289493	7	t
25	2.4.4	Amrit Mappings	SQL	V2_4_4__Amrit_Mappings.sql	946712054	avni_int	2023-05-10 10:39:07.312523	12	t
26	2.5.1	Power Initial	SQL	V2_5_1__Power_Initial.sql	-1360895434	avni_int	2023-05-10 10:39:07.331441	6	t
27	2.5.2	Power map del bocw	SQL	V2_5_2__Power_map_del_bocw.sql	1977438473	avni_int	2023-05-10 10:39:07.343454	3	t
28	2.2.2	Bahmni Provider Mapping	SQL	V2_2_2__Bahmni_Provider_Mapping.sql	-270089590	avni_int	2023-06-28 17:35:51.429674	50	t
29	2.2.3	Bahmni Catchment Mapping	SQL	V2_2_3__Bahmni_Catchment_Mapping.sql	-357382618	avni_int	2023-06-28 17:35:51.588451	17	t
30	2.2.4	Diagnoses Mapping	SQL	V2_2_4__Diagnoses_Mapping.sql	819439902	avni_int	2023-07-21 05:37:10.612018	22	t
31	2.2.5	BahmniForm2 Mapping	SQL	V2_2_5__BahmniForm2_Mapping.sql	-1454104088	avni_int	2023-07-25 10:24:41.445071	12	t
32	2.2.6	DIspenseErrorType	SQL	V2_2_6__DIspenseErrorType.sql	241016317	avni_int	2023-08-06 16:29:00.34134	66	t
\.


--
-- Data for Name: ignored_integrating_concept; Type: TABLE DATA; Schema: public; Owner: avni_int
--

COPY public.ignored_integrating_concept (id, concept_id) FROM stdin;
\.


--
-- Data for Name: integrating_entity_status; Type: TABLE DATA; Schema: public; Owner: avni_int
--

COPY public.integrating_entity_status (id, entity_type, read_upto_numeric, read_upto_date_time, integration_system_id) FROM stdin;
1	Patient	0	2000-01-01 00:00:00	1
2	Encounter	0	2000-01-01 00:00:00	1
3	Demand	\N	2000-01-01 00:00:00	2
4	Dispatch	\N	2000-01-01 00:00:00	2
5	Demand	\N	2000-01-01 00:00:00	2
6	Dispatch	\N	2000-01-01 00:00:00	2
7	Beneficiary	0	2000-01-01 00:00:00	3
8	BeneficiaryScan	0	2000-01-01 00:00:00	3
9	BornBirth	0	2000-01-01 00:00:00	3
10	CBAC	0	2000-01-01 00:00:00	3
11	Household	0	2000-01-01 00:00:00	3
12	Call Details	0	2000-01-01 00:00:00	4
13	Call Details::01141236600	0	2000-01-01 00:00:00	4
16	Enrolment	\N	2000-01-01 00:00:00	1
14	Subject	0	2000-01-01 00:00:00	1
17	GeneralEncounter	0	2000-01-01 00:00:00	1
\.


--
-- Data for Name: integrating_entity_type; Type: TABLE DATA; Schema: public; Owner: avni_int
--

COPY public.integrating_entity_type (id, name, integration_system_id) FROM stdin;
\.


--
-- Data for Name: integration_system; Type: TABLE DATA; Schema: public; Owner: avni_int
--

COPY public.integration_system (id, name) FROM stdin;
1	bahmni
2	Goonj
3	Amrit
4	power
\.


--
-- Data for Name: mapping_group; Type: TABLE DATA; Schema: public; Owner: avni_int
--

COPY public.mapping_group (id, name, integration_system_id) FROM stdin;
1	Common	1
2	PatientSubject	1
3	GeneralEncounter	1
4	ProgramEnrolment	1
5	ProgramEncounter	1
6	Observation	1
7	Demand	2
8	Dispatch	2
9	DispatchLineItem	2
10	Beneficiary	3
11	MasterId	3
12	BornBirth	3
13	CBAC	3
14	Household	3
15	PhoneNumber	4
16	User	1
\.


--
-- Data for Name: mapping_metadata; Type: TABLE DATA; Schema: public; Owner: avni_int
--

COPY public.mapping_metadata (id, int_system_value, avni_value, about, data_type_hint, integration_system_id, mapping_group_id, mapping_type_id) FROM stdin;
1	Unit	Unit (Dispatched)	\N	Coded	1	9	26
2	Quantity	Quantity (Dispatched)	\N	Coded	1	9	26
3	avniBeneficiaryID	ID	\N	\N	3	10	27
4	firstName	First name	\N	\N	3	10	27
5	lastName	Last name	\N	\N	3	10	27
6	dOB	Date of birth	\N	\N	3	10	27
7	spouseName	Spouse name	\N	\N	3	10	27
8	maritalStatusID	Marital status	\N	Numeric	3	10	27
9	maritalStatusName	Marital status	\N	Coded	3	10	27
10	genderID	Gender	\N	Numeric	3	10	27
11	genderName	Gender	\N	Coded	3	10	27
12	occupationID	Occupation	\N	Numeric	3	10	28
13	educationID	Educational qualification	\N	Numeric	3	10	28
14	educationName	Educational qualification	\N	Coded	3	10	28
15	communityID	Caste	\N	Numeric	3	10	28
16	religionID	Religion	\N	Numeric	3	10	28
17	govtIdentityNo	Aadhar number	\N	\N	3	10	30
18	govtIdentityTypeID	Enrol with	\N	Numeric	3	10	30
19	govtIdentityTypeName	Enrol with	\N	Coded	3	10	30
20	Unmarried	Unmarried	\N	\N	3	10	31
21	Married	Married	\N	\N	3	10	31
22	Divorced	Divorced	\N	\N	3	10	31
23	Separated	Separated	\N	\N	3	10	31
24	Widow	Widow	\N	\N	3	10	31
25	Widower	Widower	\N	\N	3	10	31
26	Male	Male	\N	\N	3	10	31
27	Female	Female	\N	\N	3	10	31
28	Other	Transgender	\N	\N	3	10	31
29	Govt employee	Government	\N	\N	3	10	31
30	Private employee	Private	\N	\N	3	10	31
31	Other	Self	\N	\N	3	10	31
32	Not Applicable	Unemployed	\N	\N	3	10	31
33	Primary (1st to 5th std)	Illiterate	\N	\N	3	10	31
34	Upper Primary (6th to 8th std)	Non-metric	\N	\N	3	10	31
35	Secondary (9th to 10th)	Metric	\N	\N	3	10	31
36	Senior Secondary (11th to 12th/Intermediate)	Inter	\N	\N	3	10	31
37	Graduate	Graduate	\N	\N	3	10	31
38	Post Graduate	Post graduate	\N	\N	3	10	31
39	General	General	\N	\N	3	10	31
40	SC	SC	\N	\N	3	10	31
41	ST	ST	\N	\N	3	10	31
42	EBC	OC	\N	\N	3	10	31
43	OBC	OBC	\N	\N	3	10	31
44	Not given	Not given	\N	\N	3	10	31
45	Hindu	Hindu	\N	\N	3	10	31
46	Muslim	Muslim	\N	\N	3	10	31
47	Christian	Christian	\N	\N	3	10	31
48	Sikh	Sikh	\N	\N	3	10	31
49	Buddism	Buddhism	\N	\N	3	10	31
50	Jainism	Jainism	\N	\N	3	10	31
51	Parsi	Parsi	\N	\N	3	10	31
52	Other	Other	\N	\N	3	10	31
53	Not Disclosed	Not disclosed	\N	\N	3	10	31
54	Aadhar	Aadhar No	\N	\N	3	10	31
55	3	Self	\N	\N	3	11	32
56	5	Government	\N	\N	3	11	32
57	6	Private	\N	\N	3	11	32
58	4	Unemployed	\N	\N	3	11	32
59	1	APL	\N	\N	3	11	33
60	2	BPL	\N	\N	3	11	33
61	3	Don't Know	\N	\N	3	11	33
62	3	Divorced	\N	\N	3	11	34
63	2	Married	\N	\N	3	11	34
64	4	Separated	\N	\N	3	11	34
65	1	Unmarried	\N	\N	3	11	34
66	5	Widow	\N	\N	3	11	34
67	6	Widower	\N	\N	3	11	34
68	5	Buddhism	\N	\N	3	11	35
69	3	Christian	\N	\N	3	11	35
70	1	Hindu	\N	\N	3	11	35
71	6	Jainism	\N	\N	3	11	35
72	2	Muslim	\N	\N	3	11	35
73	9	Not disclosed	\N	\N	3	11	35
74	7	Other	\N	\N	3	11	35
75	8	Parsi	\N	\N	3	11	35
76	4	Sikh	\N	\N	3	11	35
77	4	BC	\N	\N	3	11	36
78	1	General	\N	\N	3	11	36
79	7	Not given	\N	\N	3	11	36
80	5	OBC	\N	\N	3	11	36
81	6	OC	\N	\N	3	11	36
82	2	SC	\N	\N	3	11	36
83	3	ST	\N	\N	3	11	36
84	7	Graduate	\N	\N	3	11	37
85	8	Post graduate	\N	\N	3	11	37
86	2	Illiterate	\N	\N	3	11	37
87	4	Metric	\N	\N	3	11	37
88	5	Inter	\N	\N	3	11	37
89	3	Non-metric	\N	\N	3	11	37
90	1	Aadhar No	\N	\N	3	11	38
91	2	Female	\N	\N	3	11	39
92	1	Male	\N	\N	3	11	39
93	3	Other	\N	\N	3	11	39
94	fatherName	Father's name	\N	\N	3	10	27
95	bankName	Bank name	\N	\N	3	10	27
96	ifscCode	IFSC Code	\N	\N	3	10	27
97	accountNo	Bank Account No.	\N	\N	3	10	27
98	ageAtMarriage	Age at marriage	\N	\N	3	10	27
99	phoneNo	Phone number	\N	\N	3	10	29
100	6	EBC	\N	\N	3	11	36
101	mohallaName	Mohalla name	\N	\N	3	14	43
102	bleedingAfterIntercourse	Bleeding after intercourse	\N	\N	3	13	42
103	birthWeight	Birth weight of the baby in kgs	\N	\N	3	12	41
104	anyNodulesOnSkin	Any nodules on skin	\N	\N	3	13	42
105	anyThickenedSkin	Any thickened skin	\N	\N	3	13	42
106	bleedingAfterMenopause	Bleeding after menopause	\N	\N	3	13	42
107	bleedingBetweenPeriods	Bleeding between periods	\N	\N	3	13	42
108	bloodInSputum	Blood in sputum	\N	\N	3	13	42
109	bloodStainedDischargeFromNipple	Blood stained discharge from the nipple	\N	\N	3	13	42
110	cbacFamilyhistory	Do you have a family history (any one of your parents or siblings) of high blood pressure, diabetes and heart disease?	\N	\N	3	13	42
111	changeInShapeAndSizeOfBreast	Change in shape and size of the breast	\N	\N	3	13	42
112	changeInToneOfyourVoice	Any change in tone of your voice	\N	\N	3	13	42
113	clawingOfFingers	Clawing of fingers in hand(s) or feet	\N	\N	3	13	42
114	cloudyOrBlurredVision	Cloudy or blurred vision	\N	\N	3	13	42
115	collectSputumSample	Collect Sputum sample and transport to nearest TB testing center	\N	\N	3	13	42
116	consumeAlcoholDaily	Do you consume alcohol daily?	\N	\N	3	13	42
117	coughingMoreThanTwoweeks	Coughing more than 2 weeks	\N	\N	3	13	42
118	currentlySufferingFromTB	Anyone in family currently suffering from TB?**	\N	\N	3	13	42
119	currentlyTakingAntiTBDrugs	Are you currently taking anti-TB drugs?	\N	\N	3	13	42
120	difficultyInBreathing	Difficulty in breathing	\N	\N	3	13	42
121	difficultyInHearing	Difficulty in hearing	\N	\N	3	13	42
122	difficultyInHoldingObject	Difficulty in holding object with fingers	\N	\N	3	13	42
123	difficultyInOpeningMouth	Difficulty in opening mouth	\N	\N	3	13	42
124	feelingDownDpressedHopeless	Feeling down, depressed or hopeless	\N	\N	3	13	42
125	feverForTwoWeeks	Fever for > 2 weeks	\N	\N	3	13	42
126	foulSmellingVaginalDischarge	Foul smelling vaginal discharge	\N	\N	3	13	42
127	historyOfFits	History of fits	\N	\N	3	13	42
128	historyOfTB	History of TB	\N	\N	3	13	42
129	hyperPigmentedPatchORDiscoloration	Any hyper pigmented patch or discoloration on skin with loss of sensation	\N	\N	3	13	42
130	inabilityToCloseEyelid	Inability to close eyelid	\N	\N	3	13	42
131	littleInterestOrPleasure	Little interest or pleasure in doing things	\N	\N	3	13	42
132	lossOfWeight	Loss of weight	\N	\N	3	13	42
133	lumpInBreast	Lump in breast	\N	\N	3	13	42
134	measurementOfWaistInCM	Measurement of waist in cm	\N	\N	3	13	42
135	nightSweats	Night sweats	\N	\N	3	13	42
136	occupationalExposure	Occupational exposure	\N	\N	3	13	42
137	painInEyes	Pain in eyes lasting for more than a week	\N	\N	3	13	42
138	painWhileChewing	Pain while chewing	\N	\N	3	13	42
139	personAtRiskPrioritizedForNCD	Person at risk and needs to be prioritized for attending the weekly NCD day	\N	\N	3	13	42
140	recurrentNumbnessOnPalmSole	Recurrent numbness on palm(s) or sole(s)	\N	\N	3	13	42
141	recurrentTinglingOnPalmOrsole	Recurrent tingling on palm(s) or sole(s)	\N	\N	3	13	42
142	recurrentUlcerationOnPalmOrSole	Recurrent ulceration on palm or sole	\N	\N	3	13	42
143	rednessInEyes	Redness in eyes lasting for more than a week	\N	\N	3	13	42
144	referThePatientImmediately	Refer the patient immediately to the nearest facility where a Medical Officer is available	\N	\N	3	13	42
145	shortnessOfBreath	Shortness of breath	\N	\N	3	13	42
146	smokeOrConsumeGutkaOrKhaini	Do you smoke or consume smokeless products such as gutka or khaini?	\N	\N	3	13	42
147	totalCbacRiskAssessmentScore	Total CBAC Risk Assessment Score	\N	\N	3	13	42
148	tracingFamilyMembers	Tracing of all family members to be done by ANM/MPW	\N	\N	3	13	42
149	typeOfFuelUsedForCooking	Type of fuel used for cooking	\N	Text	3	13	42
150	udertakeAnyPhysicalActivities	Do you undertake any physical activities for minimum of 150 minutes in a week?	\N	\N	3	13	42
151	ulcerPatchGrowthInMouth	Ulcer/patch/growth in mouth that has not healed in two weeks	\N	\N	3	13	42
152	weaknessInFeet	Weakness in feet that causes difficulty in walking	\N	\N	3	13	42
153	birthOrder	Birth order of the child	\N	\N	3	12	41
154	colostrum	Colostrum given to the child	\N	\N	3	12	41
155	nutritionalStatus	Nutritional Status	\N	\N	3	12	41
156	weightAtBirth	Birth weight of the baby in kgs	\N	\N	3	12	41
157	addressOne	Address 1	\N	\N	3	14	43
158	addressTwo	Address 2	\N	\N	3	14	43
159	availabilityOfElectricity	Availability of electricity	\N	Text	3	14	43
160	availabilityOfToilet	Availability of toilet	\N	\N	3	14	43
161	fuelType	Type of fuel used for cooking	\N	Text	3	14	43
162	houseOwnership	House ownership	\N	\N	3	14	43
163	houseType	Type of house	\N	\N	3	14	43
164	otherAvailabilityOfElectricity	Other availability of electricity	\N	\N	3	14	43
165	otherAvailabilityOfToilet	Other availability of toilet	\N	\N	3	14	43
166	otherHouseType	Other type of house	\N	\N	3	14	43
167	otherSourceOfWater	Other source of water	\N	\N	3	14	43
168	otherTypeOfFuelUsed	Other type of fuel used for cooking	\N	\N	3	14	43
169	primarySourceOfWater	Primary source of water	\N	Text	3	14	43
170	separateKitchen	Separate kitchen	\N	\N	3	14	43
177	01141236600	Delhi BoCW	\N	NA	4	15	44
178	01141236600	BoCW	\N	NA	4	15	45
182	dee1f37f-309a-4aa7-af94-0824cf475d40		\N	\N	1	1	13
187		Bahmni_UUID	\N	\N	1	1	14
184	164940ee-00a4-11ee-be56-0242ac120002		\N	\N	1	1	24
183	a6cfce26-00a4-11ee-be56-0242ac120002		\N	\N	1	1	23
186	36afac18-009c-11ee-be56-0242ac120002		\N	\N	1	2	16
185	ca87c010-00a6-11ee-be56-0242ac120002	Patient	\N	\N	1	2	1
180	e2643ed2-0099-11ee-be56-0242ac120002		\N	\N	1	1	11
181	930fce86-009a-11ee-be56-0242ac120002		\N	\N	1	1	12
197	5242AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA	Respiratory rate	\N	\N	1	6	25
198	5086AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA	Diastolic blood pressure	\N	\N	1	6	25
199	5085AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA	Systolic blood pressure	\N	\N	1	6	25
200	7daf07f2-00ed-11ee-be56-0242ac120002	Vitals	\N	\N	1	3	20
196	9bb0795c-4ff0-0305-1990-000000000020	Temperature	\N	\N	1	6	25
203	71d443d2-009f-11ee-be56-0242ac120002	Anupahalli SC1	\N	\N	1	1	47
204	61a5817e-009f-11ee-be56-0242ac120002	Nandagudi SC1	\N	\N	1	1	47
205	6a5a392c-009f-11ee-be56-0242ac120002	Nandagudi SC2	\N	\N	1	1	47
207	164359AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA	Reason for referral	\N	\N	1	6	25
208	9bb0795c-4ff0-0305-1990-000000000043	Relevant clinical history	\N	\N	1	6	25
209	9bb0795c-4ff0-0305-1990-000000000044	Treatment provided	\N	\N	1	6	25
210	9bb0795c-4ff0-0305-1990-000000000049	Referral	\N	\N	1	3	20
212	2	Hosakote UPHC	\N	\N	1	6	25
206	9bb0795c-4ff0-0305-1990-000000000042	Referred to	\N	Coded	1	6	25
213	3	Hosakote Nama Clinic	\N	\N	1	6	25
179	26ec2124-2e0c-11ee-a63a-0242ac150007	Patient Identifier	\N	\N	1	2	21
202	72d0b892-6983-4eb4-ab81-78ae6652142c	Phone Number	\N	\N	1	2	2
214	7	Bengaluru Rural District Hospital	\N	\N	1	6	25
215		Prescriptions	\N	\N	1	3	5
216		Prescription	\N	\N	1	3	6
217	aa75cb84-0e3e-11ee-9960-0242ac150002		\N	\N	1	3	4
218		Hospital Diagnoses	\N	\N	1	3	48
219		Diagnoses	\N	\N	1	3	49
221	addd2db5-e6f7-44f7-991d-466b23d76dcf	History and Examination	\N	\N	1	3	20
222	da47a35d-5806-48b7-b467-e29902759491	Chief Complaint	\N	\N	1	6	25
224	1731AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA	Sign/symptom duration	\N	\N	1	6	25
225	160531AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA	Other Chief Complaint	\N	\N	1	6	25
226	9bb0795c-4ff0-0305-1990-000000000003	Duration Units	\N	\N	1	6	25
227	1390AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA	History of present illness	\N	\N	1	6	25
228	163201AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA	Smoking status	\N	\N	1	6	25
230	021c8ef0-0c2a-11ee-be56-0242ac120002	Father/Mother's Name	\N	\N	1	2	2
232	3766473c-0c29-11ee-be56-0242ac120002	RCH ID	\N	\N	1	2	2
233	45bcdf58-0c29-11ee-be56-0242ac120002	Nikshay ID	\N	\N	1	2	2
234	Vitals	Hospital Vitals	\N	\N	1	3	50
235	151AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA	Abdominal pain	\N	\N	1	6	25
236	143264AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA	Cough	\N	\N	1	6	25
237	139084AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA	Headache	\N	\N	1	6	25
238	140238AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA	Fever	\N	\N	1	6	25
239	120749AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA	Chest pain	\N	\N	1	6	25
240	9bb0795c-4ff0-0305-1990-000000000001	Other	\N	\N	1	6	25
223	9bb0795c-4ff0-0305-1990-000000000002 	Chief Complaints	\N	Coded	1	6	25
201	aa2f24b2-7d79-49be-bd01-3be80f8ccee6	Vitals	\N	\N	1	3	10
211	aa2f24b2-7d79-49be-bd01-3be80f8ccee6	Referral	\N	\N	1	3	10
220	aa2f24b2-7d79-49be-bd01-3be80f8ccee6	History and Examination	\N	\N	1	3	10
229	2bafb776-2e0c-11ee-a63a-0242ac150007	ABHA Address	\N	\N	1	2	2
231	2bab78f3-2e0c-11ee-a63a-0242ac150007	ABHA Number	\N	\N	1	2	2
241	631f9e92-b15f-41da-a6ba-4f4cd67f36b7	Blood Pressure	\N	\N	1	6	25
243	159630AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA	sitting	\N	\N	1	6	25
244	159629AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA	recumbent	\N	\N	1	6	25
245	1067AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA	Unknown	\N	\N	1	6	25
246	5622AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA	Other body position	\N	\N	1	6	25
247	159632AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA	standing	\N	\N	1	6	25
248	159631AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA	Fowler's position	\N	\N	1	6	25
242	159633AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA	Body Position	\N	Coded	1	6	25
\.


--
-- Data for Name: mapping_type; Type: TABLE DATA; Schema: public; Owner: avni_int
--

COPY public.mapping_type (id, name, integration_system_id) FROM stdin;
1	Subject_EncounterType	1
2	PersonAttributeConcept	1
3	EncounterType	1
4	LabEncounterType	1
5	DrugOrderEncounterType	1
6	DrugOrderConcept	1
7	CommunityEnrolment_EncounterType	1
8	CommunityEnrolmentExit_EncounterType	1
9	CommunityProgramEncounter_EncounterType	1
10	CommunityEncounter_EncounterType	1
11	AvniUUID_Concept	1
12	AvniEventDate_Concept	1
13	AvniProgramData_Concept	1
14	BahmniUUID_Concept	1
15	BahmniForm_CommunityProgram	1
16	CommunityRegistration_BahmniForm	1
17	CommunityEnrolment_BahmniForm	1
18	CommunityEnrolmentExit_BahmniForm	1
19	CommunityProgramEncounter_BahmniForm	1
20	CommunityEncounter_BahmniForm	1
21	PatientIdentifier_Concept	1
22	CommunityEnrolment_VisitType	1
23	AvniEventDate_VisitAttributeType	1
24	AvniUUID_VisitAttributeType	1
25	Concept	1
26	Obs	2
27	BeneficiaryRoot	3
28	BeneficiaryDemographics	3
29	BeneficiaryPhoneMaps	3
30	BeneficiaryIdentity	3
31	BeneficiaryObservations	3
32	occupationID	3
33	incomeID	3
34	maritalStatusID	3
35	religionID	3
36	communityID	3
37	educationID	3
38	govtIdentityTypeID	3
39	genderID	3
40	otherGovIdEntityMaster	3
41	BornBirthRoot	3
42	CBACRoot	3
43	HouseholdRoot	3
44	State	4
45	Program	4
46	ProviderUUID	1
47	AvniCatchment_BahmniLocation	1
48	DiagnosesEncounterType	1
49	DiagnosesConcept	1
50	BahmniForm2Name	1
\.


--
-- Data for Name: markers; Type: TABLE DATA; Schema: public; Owner: avni_int
--

COPY public.markers (id, feed_uri_for_last_read_entry, feed_uri, last_read_entry_id) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: avni_int
--

COPY public.users (id, email, password, working_integration_system_id) FROM stdin;
1	integration@example.com	$2a$10$8EE/NtP7DaokckosbgfzTuac1sI.yH7CiQcv3jB2/dCdy1337i032	1
\.


--
-- Name: avni_entity_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avni_int
--

SELECT pg_catalog.setval('public.avni_entity_status_id_seq', 7, true);


--
-- Name: bahmni_entity_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avni_int
--

SELECT pg_catalog.setval('public.bahmni_entity_status_id_seq', 17, true);


--
-- Name: constants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avni_int
--

SELECT pg_catalog.setval('public.constants_id_seq', 9, true);


--
-- Name: error_record_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avni_int
--

SELECT pg_catalog.setval('public.error_record_id_seq', 2, true);


--
-- Name: error_record_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avni_int
--

SELECT pg_catalog.setval('public.error_record_log_id_seq', 2, true);


--
-- Name: error_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avni_int
--

SELECT pg_catalog.setval('public.error_type_id_seq', 22, true);


--
-- Name: failed_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avni_int
--

SELECT pg_catalog.setval('public.failed_events_id_seq', 10, true);


--
-- Name: ignored_bahmni_concept_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avni_int
--

SELECT pg_catalog.setval('public.ignored_bahmni_concept_id_seq', 1, false);


--
-- Name: integrating_entity_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avni_int
--

SELECT pg_catalog.setval('public.integrating_entity_type_id_seq', 1, false);


--
-- Name: integration_system_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avni_int
--

SELECT pg_catalog.setval('public.integration_system_id_seq', 4, true);


--
-- Name: mapping_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avni_int
--

SELECT pg_catalog.setval('public.mapping_group_id_seq', 16, true);


--
-- Name: mapping_metadata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avni_int
--

SELECT pg_catalog.setval('public.mapping_metadata_id_seq', 248, true);


--
-- Name: mapping_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avni_int
--

SELECT pg_catalog.setval('public.mapping_type_id_seq', 50, true);


--
-- Name: markers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avni_int
--

SELECT pg_catalog.setval('public.markers_id_seq', 17, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avni_int
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: avni_entity_status avni_entity_status_pkey; Type: CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.avni_entity_status
    ADD CONSTRAINT avni_entity_status_pkey PRIMARY KEY (id);


--
-- Name: integrating_entity_status bahmni_entity_status_pkey; Type: CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.integrating_entity_status
    ADD CONSTRAINT bahmni_entity_status_pkey PRIMARY KEY (id);


--
-- Name: constants constants_pkey; Type: CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.constants
    ADD CONSTRAINT constants_pkey PRIMARY KEY (id);


--
-- Name: error_record_log error_record_log_pkey; Type: CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.error_record_log
    ADD CONSTRAINT error_record_log_pkey PRIMARY KEY (id);


--
-- Name: error_record error_record_pkey; Type: CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.error_record
    ADD CONSTRAINT error_record_pkey PRIMARY KEY (id);


--
-- Name: error_type error_type_pkey; Type: CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.error_type
    ADD CONSTRAINT error_type_pkey PRIMARY KEY (id);


--
-- Name: failed_events failed_events_pkey; Type: CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.failed_events
    ADD CONSTRAINT failed_events_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: ignored_integrating_concept ignored_bahmni_concept_concept_uuid; Type: CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.ignored_integrating_concept
    ADD CONSTRAINT ignored_bahmni_concept_concept_uuid UNIQUE (concept_id);


--
-- Name: ignored_integrating_concept ignored_bahmni_concept_pkey; Type: CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.ignored_integrating_concept
    ADD CONSTRAINT ignored_bahmni_concept_pkey PRIMARY KEY (id);


--
-- Name: integrating_entity_type integrating_entity_type_pkey; Type: CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.integrating_entity_type
    ADD CONSTRAINT integrating_entity_type_pkey PRIMARY KEY (id);


--
-- Name: integration_system integration_system_pkey; Type: CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.integration_system
    ADD CONSTRAINT integration_system_pkey PRIMARY KEY (id);


--
-- Name: mapping_group mapping_group_pkey; Type: CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.mapping_group
    ADD CONSTRAINT mapping_group_pkey PRIMARY KEY (id);


--
-- Name: mapping_metadata mapping_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.mapping_metadata
    ADD CONSTRAINT mapping_metadata_pkey PRIMARY KEY (id);


--
-- Name: mapping_type mapping_type_pkey; Type: CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.mapping_type
    ADD CONSTRAINT mapping_type_pkey PRIMARY KEY (id);


--
-- Name: markers markers_pkey; Type: CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.markers
    ADD CONSTRAINT markers_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: public; Owner: avni_int
--

CREATE INDEX flyway_schema_history_s_idx ON public.flyway_schema_history USING btree (success);


--
-- Name: avni_entity_status avni_entity_status_integration_system_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.avni_entity_status
    ADD CONSTRAINT avni_entity_status_integration_system_id_fkey FOREIGN KEY (integration_system_id) REFERENCES public.integration_system(id);


--
-- Name: error_record error_record_integration_system_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.error_record
    ADD CONSTRAINT error_record_integration_system_id_fkey FOREIGN KEY (integration_system_id) REFERENCES public.integration_system(id);


--
-- Name: error_record_log error_record_log_error_record; Type: FK CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.error_record_log
    ADD CONSTRAINT error_record_log_error_record FOREIGN KEY (error_record_id) REFERENCES public.error_record(id);


--
-- Name: error_record_log error_record_log_error_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.error_record_log
    ADD CONSTRAINT error_record_log_error_type_id_fkey FOREIGN KEY (error_type_id) REFERENCES public.error_type(id);


--
-- Name: error_type error_type_integration_system_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.error_type
    ADD CONSTRAINT error_type_integration_system_id_fkey FOREIGN KEY (integration_system_id) REFERENCES public.integration_system(id);


--
-- Name: integrating_entity_status integrating_entity_status_integration_system_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.integrating_entity_status
    ADD CONSTRAINT integrating_entity_status_integration_system_id_fkey FOREIGN KEY (integration_system_id) REFERENCES public.integration_system(id);


--
-- Name: integrating_entity_type integrating_entity_type_integration_system_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.integrating_entity_type
    ADD CONSTRAINT integrating_entity_type_integration_system_id_fkey FOREIGN KEY (integration_system_id) REFERENCES public.integration_system(id);


--
-- Name: mapping_group mapping_group_integration_system_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.mapping_group
    ADD CONSTRAINT mapping_group_integration_system_id_fkey FOREIGN KEY (integration_system_id) REFERENCES public.integration_system(id);


--
-- Name: mapping_metadata mapping_metadata_integration_system_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.mapping_metadata
    ADD CONSTRAINT mapping_metadata_integration_system_id_fkey FOREIGN KEY (integration_system_id) REFERENCES public.integration_system(id);


--
-- Name: mapping_metadata mapping_metadata_mapping_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.mapping_metadata
    ADD CONSTRAINT mapping_metadata_mapping_group_id_fkey FOREIGN KEY (mapping_group_id) REFERENCES public.mapping_group(id);


--
-- Name: mapping_metadata mapping_metadata_mapping_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.mapping_metadata
    ADD CONSTRAINT mapping_metadata_mapping_type_id_fkey FOREIGN KEY (mapping_type_id) REFERENCES public.mapping_type(id);


--
-- Name: mapping_type mapping_type_integration_system_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.mapping_type
    ADD CONSTRAINT mapping_type_integration_system_id_fkey FOREIGN KEY (integration_system_id) REFERENCES public.integration_system(id);


--
-- Name: users users_working_integration_system_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: avni_int
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_working_integration_system_id_fkey FOREIGN KEY (working_integration_system_id) REFERENCES public.integration_system(id);


--
-- PostgreSQL database dump complete
--

